* @ValidationCode : MTozNjExMjI3NTI6SVNPLTg4NTktMToxNTM3MjU2MjkyMjk0OmE0MDkzNDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 18 Sep 2018 15:38:12
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40934
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.PAYMENT.INPUT
*-----------------------------------------------------------------------------
*This routine is added as input routine in FT version control, if the Txn Amount exceeds more that (>CHF100K) then raise Override message.
*-----------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------

* Date          Developer            Reference    Description           
*-----------------------------------------------------------------------------------------------
*10/08/2017    Sushmitha.B           JB2A-37983        To aviod Internal sever error when we delete FT
*05/10/2017    PuthumaiSamy          JB2A-43080        RNAU FT is missing in Authorise FT transaction queue_All FTs_due to VD Amendment.
*17/09/2017    Smitha Iyer           Day15-249         Same currency FTs asking for a check on Treasury Rate
*18/09/2017    Smitha Iyer           Day15-4366        Included the condition of debit amount equivalent in CHF is greater than equal to 100K CHF
*-------------------------------------------------------------------------------------------------
  
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER

*-----------------------------------------------------------------------------

         GOSUB INIT
		 GOSUB PROCESS
		 
	RETURN
*------------------------------------------------------------------
INIT:
*****	
	    Y.DR.AMT = ''
		Y.CR.AMT = ''
		Y.DR.CCY = ''
		Y.CR.CCY = ''
		Y.TXN.LOC.AMT = ''
		Y.CURR.NO = R.NEW(FT.CURR.NO)
		
		FN.CURRENCY = 'F.CURRENCY'
		F.CURRENCY = ''
		CALL OPF(FN.CURRENCY,F.CURRENCY)
		
		Y.VLDT.CHKD.POS = ''
		Y.LFT.VLDT.CHKD = ''
		
		Y.APP = 'FUNDS.TRANSFER'
		Y.LOCFIELD = 'L.FT.VALDT.CHKD'
		CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
		Y.VLDT.CHKD.POS =  Y.LOCPOS<1,1>
		
		
		
RETURN
*----------------------------------------------------------------
PROCESS:
********
	
	BEGIN CASE
	
	CASE V$FUNCTION EQ 'I'
	
	     GOSUB RAISE.CHK100K.OVERRIDE
		 
	CASE V$FUNCTION EQ 'R'
	
	     GOSUB CLEAR.VLDT.CHECKER.FLAG 
		 
	END CASE

RETURN
*
*----------------------------------------------------------------
RAISE.CHK100K.OVERRIDE:
***********************
	
    Y.CURR.NO = Y.CURR.NO + 1
  
    Y.BUY.CCY = R.NEW(FT.DEBIT.CURRENCY)
    Y.CREDIT.CCY = R.NEW(FT.CREDIT.CURRENCY)
       IF (Y.BUY.CCY EQ Y.CREDIT.CCY) THEN RETURN
	Y.BUY.AMT = R.NEW(FT.DEBIT.AMOUNT)
	GOSUB GET.EXCHRATE
    
    IF Y.TXN.LOC.AMT GE '100000' THEN
	    TEXT = 'FT-JBWW.AMT.EXCEEDS.LIMIT'
		CALL STORE.OVERRIDE(Y.CURR.NO)
	END ELSE
	    Y.TXN.LOC.AMT = ''
	    Y.BUY.CCY = R.NEW(FT.CREDIT.CURRENCY)
		Y.BUY.AMT = R.NEW(FT.CREDIT.AMOUNT)
		GOSUB GET.EXCHRATE
			IF Y.TXN.LOC.AMT GE '100000' THEN
				TEXT = 'FT-JBWW.AMT.EXCEEDS.LIMIT'
				CALL STORE.OVERRIDE(Y.CURR.NO)
			END		
	END	
	
RETURN
*
*------------------------------------------------------------------
CLEAR.VLDT.CHECKER.FLAG:
************************
* Clear the VD Checker flag for FT which already processed on VD queue to move FT again to Auth Queue if any.
  	
	Y.LFT.VLDT.CHKD = R.NEW(FT.LOCAL.REF)<1,Y.VLDT.CHKD.POS>
	
	IF Y.LFT.VLDT.CHKD EQ 'CHECKER' THEN
	    R.NEW(FT.LOCAL.REF)<1,Y.VLDT.CHKD.POS> = ''
	END	
	
RETURN  	
*------------------------------------------------------	
GET.EXCHRATE:
*************   
     
	CCY.MKT = '1'
	BUY.CCY = Y.BUY.CCY
	BUY.AMT = Y.BUY.AMT
	SELL.CCY = LCCY 
	SELL.AMT = ''
	BASE.CCY = ''
	EXCHANGE.RATE = ''
	DIFFERENCE = ''
	LCY.AMT = ''
	RETURN.CODE = ''
	CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)
	Y.TXN.LOC.AMT = LCY.AMT
			
RETURN
*------------------------------------------------------------------
END