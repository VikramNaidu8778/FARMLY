SUBROUTINE JB.R.FT.UPDTAXAMT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 2024/08/14     L1GST           Processing date is future dated then update TAX.AMT
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.L.FT.GSTENTRY.DETAILS
    $INSERT I_F.JBWW.L.FT.GSTENTRY.PROCESSED
    $INSERT I_BATCH.FILES
    $INSERT I_F.BATCH
    
    Y.BATCH.ID = BATCH.INFO<1>
    IF Y.BATCH.ID EQ 'HKD/FT.START.OF.DAY' OR Y.BATCH.ID EQ 'SGD/FT.START.OF.DAY' THEN
        IF R.NEW(FT.TAX.AMT) NE '' THEN
            RETURN
        END
        GOSUB INIT
        GOSUB PROCESS
    END
RETURN

INIT:
    
    FN.JBWW.L.FT.GSTENTRY.DETAILS='F.JBWW.L.FT.GSTENTRY.DETAILS'
    F.JBWW.L.FT.GSTENTRY.DETAILS = ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.DETAILS, F.JBWW.L.FT.GSTENTRY.DETAILS)
    
    FN.JBWW.L.FT.GSTENTRY.PROCESSED = 'F.JBWW.L.FT.GSTENTRY.PROCESSED'
    F.JBWW.L.FT.GSTENTRY.PROCESSED = ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.PROCESSED, F.JBWW.L.FT.GSTENTRY.PROCESSED)
    
RETURN

PROCESS:
        
    Y.ID = ''
    Y.ID = R.NEW(FT.PROCESSING.DATE):'*':FIELD(ID.NEW,';',1)
    
    R.JBWW.L.FT.DET = '' ; ERR.FT = ''
    CALL F.READ(FN.JBWW.L.FT.GSTENTRY.DETAILS, Y.ID, R.JBWW.L.FT.DET, F.JBWW.L.FT.GSTENTRY.DETAILS, ERR.FT)
    IF R.JBWW.L.FT.DET EQ '' THEN
        ERR.FT = ''
        CALL F.READ(FN.JBWW.L.FT.GSTENTRY.PROCESSED, Y.ID, R.JBWW.L.FT.DET, F.JBWW.L.FT.GSTENTRY.PROCESSED, ERR.FT)
    END
    
    IF R.JBWW.L.FT.DET NE '' THEN
        Y.BOOKING.DATE = R.JBWW.L.FT.DET<JBWW.FT.BOOKING.DATE>
        Y.PROCESSING.DATE = R.NEW(FT.PROCESSING.DATE)
        IF Y.BOOKING.DATE LT TODAY AND Y.PROCESSING.DATE EQ TODAY THEN
            Y.PAYMENT = R.NEW(FT.PAYMENT.DETAILS)
            Y.FM.POS = '' ; Y.VM.POS = ''; Y.SM.POS = ''
            FINDSTR 'DIARSC' IN Y.PAYMENT SETTING Y.FM.POS, Y.VM.POS, Y.SM.POS THEN
                Y.DIARY.ID = R.NEW(FT.PAYMENT.DETAILS)<Y.FM.POS,Y.VM.POS>
                Y.DIARY.ID = FIELD(Y.DIARY.ID,' ',2)
                Y.TAX.AMT = R.NEW(FT.TAX.AMT)
                IF Y.TAX.AMT EQ '' AND Y.DIARY.ID[1,6] EQ 'DIARSC' THEN
                    Y.TAX.AMT = R.JBWW.L.FT.DET<JBWW.FT.GST.AMT.FCY>
                    R.NEW(FT.TAX.AMT) = R.NEW(FT.DEBIT.CURRENCY):Y.TAX.AMT
                    R.NEW(FT.TAX.TYPE) = R.JBWW.L.FT.DET<JBWW.FT.GST.TYPE>
                END
            END
        END
    END
        
RETURN
END
