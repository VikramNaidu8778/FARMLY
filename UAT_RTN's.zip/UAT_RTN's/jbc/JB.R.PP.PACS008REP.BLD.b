SUBROUTINE JB.R.PP.PACS008REP.BLD(ENQ.DATA)

*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 30-May-2024   CTS                                    CBPAY_20_38_40              
*
* Description : Routine to List all the incoming pacs.008 which are failed due to BNC Check, Incoming Account Validation etc
* Attached to : ENQUIRY>JB.E.PP.INC.PACS008.REPAIR
* Attached as : BUILD.ROUTINE
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    
    GOSUB INITIALISE
    GOSUB PROCESS
    
RETURN
*----------
INITIALISE:
*----------

    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY  = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)


RETURN
*-------
PROCESS:
*-------

    SEL.CMD = "SELECT ":FN.PP.ORDER.ENTRY:" WITH (Warning EQ '' AND FunctionalError EQ '') OR WITH FunctionalError NE '' "
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    
    CHANGE FM TO ' ' IN SEL.LIST

    Y.FNL.SEL.LIST =  SEL.LIST
    ENQ.DATA<2,-1> = '@ID'
    ENQ.DATA<3,-1> = 'EQ'
    ENQ.DATA<4,-1> =  Y.FNL.SEL.LIST


RETURN
*-----------------------------------------------------------------------------
END

