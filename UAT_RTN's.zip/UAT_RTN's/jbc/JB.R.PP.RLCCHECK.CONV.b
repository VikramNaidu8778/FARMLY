*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.RLCCHECK.CONV
*-----------------------------------------------------------------------------
* This is a conversion routine to skip triggering RLC version if the transaction is rejected
* by RLC user.
*-----------------------------------------------------------------------------
* Modification History :
*------------------------
** Date          Developer              Reference       Description
* 04-May-2025    P Amala                CBPAY-2665      Initial draft
* 05-May-2025    P Amala                CBPAY-2392      Fix to null the RLC block check variable only for the RLC rejected payment.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
      
RETURN
*
*-----------------------------------------------------------------
INIT:
*****

    R.ORDER.ENTRY.REC = '' ; R.SOFT.REC = '' ; R.SOFT.ERR = ''
    Y.BLK.CATEG = '' ; Y.OVERALL.STATUS = ''
   
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    F.JBWW.H.XX.SOFTBLOCK = ''
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK, F.JBWW.H.XX.SOFTBLOCK)
    
    FN.PP.ORDER.ENTRY.NAU = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY.NAU = ''
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,F.PP.ORDER.ENTRY.NAU)
    
    CALL MULTI.GET.LOC.REF("PP.ORDER.ENTRY","L.XX.BLK.CATEG",Y.LOC.POS)
    Y.BLK.POS = Y.LOC.POS<1,1>

RETURN
*
*--------------------------------------------------------------------------
PROCESS:
********

    Y.OE.ID = O.DATA

    CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.OE.ID,R.ORDER.ENTRY.REC,F.PP.ORDER.ENTRY.NAU,'')
    IF R.ORDER.ENTRY.REC THEN
        Y.BLK.CATEG = R.ORDER.ENTRY.REC<PP.OEYG.LOCAL.REF,Y.BLK.POS>
        IF Y.BLK.CATEG NE '' THEN
            CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK, Y.OE.ID, R.SOFT.REC, F.JBWW.H.XX.SOFTBLOCK, R.SOFT.ERR)
            Y.OVERALL.STATUS = R.SOFT.REC<JHXS.OVERALL.STATUS>
        END
        IF Y.OVERALL.STATUS EQ 'REJECT' THEN
            O.DATA = ''
        END ELSE
            O.DATA = Y.BLK.CATEG
        END
    END
            
RETURN
*--------------------------------------------------------------------------
END
