*--------------------------------------------------------------------------------------------------
	SUBROUTINE JBWW.R.FT.ORDCUST.DEFAULT
*--------------------------------------------------------------------------------------------------
* Description: This Auto New Content routine attached to FUNDS.TRANSFER,JBWW.V.SC.EAMTRF.INP to default Ordering Customer
*---------------------------------------------------------------------------------------------------
* Modification History :
*
*---------------------------------------------------------------------------------------------------
* Date       	   Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
* 10-JUL-2018	   Rajagopalan R       JB2A-DAY15-2976	    		Defaulting Ordering Customer field
*
* 19-FEB-2019      Lakshmanan          T24-14630                        Address hardcode removed and generic parameter table value used for address
*--------------------------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
        $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

	GOSUB INIT
	GOSUB PROCESS
		
	RETURN
	
INIT:
*****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    RETURN

PROCESS:
********
        R.JBWW.H.EB.GENERICPARAMETER = ''
        CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'JBWW.D.XX.COM.ADDRESS',R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,GPM.ERR)
        IF R.JBWW.H.EB.GENERICPARAMETER THEN
	   R.NEW(FT.ORDERING.CUST)<1,1> = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,1,1>
	   R.NEW(FT.ORDERING.CUST)<1,2> = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,1,2>
	   R.NEW(FT.ORDERING.CUST)<1,3> = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,1,3>
        END

	RETURN
END
