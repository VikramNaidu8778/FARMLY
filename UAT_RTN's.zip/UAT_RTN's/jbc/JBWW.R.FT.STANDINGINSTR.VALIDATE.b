* @ValidationCode : MToxNDM2Njg1NzczOklTTy04ODU5LTE6MTUyNzE0Nzc1NTk3MDozMTE4NDk6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4Ljc=
* @ValidationInfo : Timestamp         : 24 May 2018 13:12:35
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.STANDINGINSTR.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date               Name                              Reference         Description
* 16-09-2016        Priyadarshni Priyanka               PMT058
* 18-JUL-2017       Mahesh J                            JB2A-37042       @ID of the template changed to ID.COMPANY
* 24-MAY-2018       Lakshmanan                          JB2A-52034       Defaulting the FT values logic changed. Condition
*                                                                        included to check FT CUR and BEN AC CUR
* 20-FEB-2025       Suresh D                            T24-21765        CID data masked for BEN.CUSTOMER in DEVSIT not for regression enviornment 
*------------------------------------------------------------------------------
* Description : Validate routine for the funds transfer versions that uses the
*               new template JBWW.H.FT.STANDINGINSTR. to default the value for
*               the selected Beneficiary Customer
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.FT.STANDINGINSTR
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
*
    RETURN
*
*****
INIT:
*****

    REC.FUNDS = ''
    REC.STNDINS = ''
    REC.ACC = ''
    ERR.FUNDS = ''
    ERR.STNDINS = ''
    ERR.ACC = ''

    FN.JBWW.H.FT.STANDINGINSTR = 'F.JBWW.H.FT.STANDINGINSTR'
    F.JBWW.H.FT.STANDINGINSTR = ''
    CALL OPF(FN.JBWW.H.FT.STANDINGINSTR,F.JBWW.H.FT.STANDINGINSTR)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
*
    RETURN
*
********
PROCESS:
********

    Y.STNDINS.ORDER.ID = ID.COMPANY
    Y.BEN.CUST = COMI

    CALL F.READ(FN.JBWW.H.FT.STANDINGINSTR,Y.STNDINS.ORDER.ID,REC.STNDINS,F.JBWW.H.FT.STANDINGINSTR,ERR.STNDINS)

    IF REC.STNDINS THEN
        Y.BEN.CUST.STNDINS = REC.STNDINS<JB.FT.STNG.BEN.CUSTOMER>

		ACCOUNT.ID = R.NEW(FT.CREDIT.ACCT.NO)
		GOSUB READ.ACCOUNT		

        IF REC.ACCOUNT THEN
            Y.CREDIT.CURR = REC.ACCOUNT<AC.CURRENCY>
            R.NEW(FT.CREDIT.CURRENCY) = Y.CREDIT.CURR
        END

        IF Y.CREDIT.CURR THEN
            I = 1
            BEN.CUST.CNT = DCOUNT(Y.BEN.CUST.STNDINS,VM)
            LOOP
            WHILE I LE BEN.CUST.CNT
                IF Y.BEN.CUST EQ Y.BEN.CUST.STNDINS<1,I> THEN
					ACCOUNT.ID = REC.STNDINS<JB.FT.STNG.BEN.ACCT.NO,I>
					GOSUB READ.ACCOUNT
                    GOSUB ASSIGN.DEFAULT.VALUES
                END
                I += 1
            REPEAT
        END

    END
*
    RETURN
*
**********************
ASSIGN.DEFAULT.VALUES:
**********************

    IF REC.ACCOUNT<AC.CURRENCY> EQ Y.CREDIT.CURR THEN
        R.NEW(FT.CREDIT.ACCT.NO) = REC.STNDINS<JB.FT.STNG.CREDIT.ACCT.NO,I>
        R.NEW(FT.BEN.ACCT.NO) = REC.STNDINS<JB.FT.STNG.BEN.ACCT.NO,I>
        R.NEW(FT.ACCT.WITH.BANK) = REC.STNDINS<JB.FT.STNG.ACCT.WITH.BANK,I>
        R.NEW(FT.ACCT.WITH.BANK.ACC) = REC.STNDINS<JB.FT.STNG.ACCT.WITH.BANK.ACC,I>
*T24-21765/S - Only for lower environments and not for regression.
        IF R.NEW(FT.BEN.CUSTOMER) NE '' AND R.NEW(FT.BEN.CUSTOMER)[1,3] NE 'CID' THEN
            R.NEW(FT.BEN.CUSTOMER) = 'CID Withheld'
        END
*T24-21765/S - Only for lower environments and not for regression.
        I = BEN.CUST.CNT
    END
*
	RETURN
*
*************
READ.ACCOUNT:
*************

    REC.ACCOUNT = ''
	E.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT,ACCOUNT.ID,REC.ACCOUNT,F.ACCOUNT,E.ACCOUNT)
*
	RETURN
*
    END
*