SUBROUTINE JBWW.R.FT.TAG.MAPPING604(MAT HANDOFF.REC,ERR.MSG)

*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is the MAPPING routine, attached to DE.MAPPING>604.FT.1 ROUTINE field.
* MT604 should be generated for Tag 86A get populated with the BIC code of the financial
* institution in the field "INTERMED.BANK"
* 
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: HANDOFF.REC
* OUT: MAT HANDOFF.REC, ERR.MSG
*
* Revision History:
*------------------
* Date               Developer            Reference       Description
* 14-12-2016         ARJUN. S		      CR-180	       Initial Version
* 08-02-2017         Mahesh J		      JIRA-25229       To change the tag88D values to BEN.ACCT.NO and BEN.NAME
* 2/MAY/2017         Mahesh J             JB2A-31125       Removed forward slash '/' for 88D and included new line at the end.
* 19-May-2017		 Balaji Pushparaj     JB2A-31125       Removed Map positions for TAG 86 and handled at DE.MAPPING level.
* 06-SEP-2017        Mahesh J             JB2A-40433       Validation err for 604 at AMH due to tag 88D
* 17-Oct-2017		 Balaji Pushparaj	  JB2A-44105       To Fix - Extra slash between Beneficiary Account & Ben Name
*27-DEC-2017	     Francis Xavier Raj   JB2A-45682	   Mapping AMOUNT.CREDITED field to 32F tag
* 30-Nov-17			 Balaji Pushparaj	  FX-604           To Fix 88 tag from FX-604
*-------------------------------------------------------------------------

	$INSERT I_COMMON
   	$INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.DE.ADDRESS
	$INSERT I_F.DE.BIC
	
	GOSUB OPEN.FILE
    GOSUB PROCESS
	
	RETURN
	
	
	OPEN.FILE:
	
	NEW.LINE = CHARX(013):CHARX(010)
	RETURN
	
	PROCESS:
	
*JIRA-25229(S)
        Y.BEN.NAME = R.NEW(FT.BEN.NAME) ; * JB2A-31125 - S
		Y.BEN.ACNO = R.NEW(FT.BEN.ACCT.NO)
		BEGIN CASE
		
		CASE Y.BEN.NAME AND Y.BEN.ACNO 
		* HANDOFF.REC(3)<22>= Y.BEN.ACNO:"/":Y.BEN.NAME 
		*  HANDOFF.REC(3)<22>= Y.BEN.ACNO:NEW.LINE:Y.BEN.NAME
*		 JB2A-40433 - S 

          HANDOFF.REC(3)<22,1> = "/":Y.BEN.ACNO ;*JB2A-44105
          HANDOFF.REC(3)<22,2> = Y.BEN.NAME	 

*        JB2A-40433  -E 
		 
		CASE Y.BEN.NAME EQ '' AND Y.BEN.ACNO NE ''  
           HANDOFF.REC(3)<22>= "/":Y.BEN.ACNO	;*JB2A-44105
        
        CASE Y.BEN.NAME NE '' AND Y.BEN.ACNO EQ ''	
		  HANDOFF.REC(3)<22>= "/":Y.BEN.NAME	;*JB2A-44105	 
		END CASE		
*JIRA-25229(E)

        AMT.CREDIT = R.NEW(FT.AMOUNT.CREDITED)
		HANDOFF.REC(3)<3> = HANDOFF.REC(3)<3>[1,3]:AMT.CREDIT[4,-1]  ;*JB2A-45682
   
		IF HANDOFF.REC(3)<16> NE "" THEN
			HANDOFF.REC(3)<16> = "/":HANDOFF.REC(3)<16>
		END
		RETURN
	
END