* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 09 May 2024 08:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 821829
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
* <Rating>-52</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PROCDATEREJECT.INPUT
*-------------------------------------------------------------------------
* 
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 13-08-2018	Parameshwari         DAY15-2867               Reject the FT if the processing date is less than or equal to today.
* 18-09-2018    Parameshwari         DAY15-4343               Direct rejection of forwarded dated FT after processing date.
* 24-09-2018    Lakshmanan           DAY15-4343               Block Status Flag variable replaced with Flag field from template 
* 07-05-2024    P Amala              CBPAY-356                Incorporated TPH Payment order with existing application Logic.
* 29-04-2025    P Amala              CBPAY-2286               Reversing the payment order changes done before as this changes are not applicable for TPH.
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_System
*-------------------------------------------------------------------------
 	
        V.FUNC = V$FUNCTION
	IF V.FUNC NE 'D' AND ID.NEW[1,2] EQ 'FT' THEN
		GOSUB INIT
		GOSUB PROCESS
	END
	
    RETURN

*--------------------------------------------------------------------------
INIT:
****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
	
    RETURN
*--------------------------------------------------------------------------
PROCESS:
********

	Y.FT.ID = ID.NEW
    	Y.OVERALL.STATUS = R.NEW(JHXS.OVERALL.STATUS)
	
	CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,FUNDS.TRANSFER.ERR)
	
	Y.PROC.DATE = R.FUNDS.TRANSFER<FT.PROCESSING.DATE>
	Y.FT.STATUS = R.FUNDS.TRANSFER<FT.STATUS>
	
	IF Y.FT.STATUS EQ 'IFWD' AND Y.PROC.DATE LE TODAY THEN
		IF Y.OVERALL.STATUS EQ '' OR  Y.OVERALL.STATUS EQ 'APPROVE' THEN
			AF = JHXS.OVERALL.STATUS
			ETEXT = "FT-JBWW.D.FT.PROCDATE.NOTFWD"
			CALL STORE.END.ERROR
            R.NEW(JHXS.BLOCK.STAT.FLAG) = 'YES'	
		END
	END

    RETURN
*--------------------------------------------------------------------------

END