* @ValidationCode : MTotOTgwNjYzODA1OklTTy04ODU5LTE6MTUzOTA1MjIzODEzOTphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjEx
* @ValidationInfo : Timestamp         : 09 Oct 2018 10:30:38
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.B.XX.RETROPAYCLEANUP.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 
* 09-10-2018 - T24-13868
*              Re-compilation of load, select and process routine of multi threaded
*              job JBWW.B.XX.RETROPAYCLEANUP
*
*-----------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_JBWW.B.XX.RETROPAYCLEANUP.COMMON
* </region>
*-----------------------------------------------------------------------------
* <region name = Main>
    
    SEL.CMD = ''
    SEL.CMD = "SELECT ":FN.JBWW.H.FT.RETROPAY:" WITH BEN.NAME NE " : "'" : "CID Withheld" : "'"
    LIST.PARAMETER = ''
    LIST.PARAMETER<3> = SEL.CMD
    CALL BATCH.BUILD.LIST(LIST.PARAMETER, '')   
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
END
