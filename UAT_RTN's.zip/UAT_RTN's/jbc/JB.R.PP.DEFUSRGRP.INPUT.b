SUBROUTINE JB.R.PP.DEFUSRGRP.INPUT
*-------------------------------------------------------------------------------------------------------------------------------------
* This is a input routine to default Inputter's User Group defined in GPM record
* for list of user roles in PAYMENT.ORDER>L.PO.USR.GRP , PP.ORDER.ENTRY>L.PO.USR.GRP field.
*-------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference               Description
* 16/05/2024      Prabhu D S                   CBPAY-49                Initial Draft
* 10/01/2024      Prabhu D S                   CBPAY-974               Default Group as SEC-USER-ROLES/CASH-USER-ROLES for transactions initiated
*                                                                      via interfaces like MUREX/Calculo/SAP-FI/EAM
* 09/05/2025      Vikram Pavuluru              CBPAY-2786              Default Group as SEC-USER-ROLES/CASH-USER-ROLES for transactions initiated
*                                                                      via PP.ORDER.ENTRY
*
*-------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.USER
    $INSERT I_F.EB.USER.ROLES
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB INIT
    GOSUB GET.PARAM.DETS
    GOSUB PROCESS

RETURN

*****
INIT:
*****
    
    Y.LOC.REF.FLDS.POS = '' ; Y.USER.ROLES.LIST = ''
    Y.USER.ROLES = ''       ; Y.ROLE.POS = ''
    Y.USR.GRP = ''
    Y.USERROLE.FIELD.NAMES = ''
    Y.USERROLE.FIELD.VALUES = ''
    Y.CONFIG.FIELD.NAMES = ''
    Y.CONFIG.FIELD.VALUES = ''
    Y.FM.POS = ''           ; Y.VM.POS = ''
    Y.SM.POS = ''
    
    FN.USER = "F.USER" ; F.USER = ""
    Y.PO.PRODUCT = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    Y.PP.MSGTYPE = R.NEW(PP.OEYG.IncomingMessageType)
    APPL = "PAYMENT.ORDER":@FM:"PP.ORDER.ENTRY"
    APPL.LOC.FLDS = 'L.PO.USR.GRP':@FM:'L.PO.USR.GRP'
    CALL MULTI.GET.LOC.REF(APPL,APPL.LOC.FLDS,Y.POS)
    Y.PO.LRF.POS = Y.POS<1,1>
    Y.OE.LRF.POS = Y.POS<2,1>
    

RETURN

***************
GET.PARAM.DETS:
***************

    Y.GPM.USR.GRP = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.USR.GRP,Y.MANUALINIT.USR.ROLES)
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.USR.GRP,Y.CONFIG.USR.ROLES)
    CONVERT ',' TO @VM IN Y.CONFIG.USR.ROLES
    
RETURN

********
PROCESS:
********
    BEGIN CASE
        CASE APPLICATION EQ 'PAYMENT.ORDER'
            FIND USER.ROLE IN Y.MANUALINIT.USR.ROLES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
                Y.USR.GRP = Y.GPM.USR.GRP<Y.FM.POS>
                R.NEW(PO.LOCAL.REF)<1,Y.PO.LRF.POS> = Y.USR.GRP
            END ELSE
                FIND Y.PO.PRODUCT IN Y.CONFIG.USR.ROLES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
                    Y.USR.GRP = Y.GPM.USR.GRP<Y.FM.POS>
                    R.NEW(PO.LOCAL.REF)<1,Y.PO.LRF.POS> = Y.USR.GRP
                END
            END
        CASE APPLICATION EQ 'PP.ORDER.ENTRY'
            FIND USER.ROLE IN Y.MANUALINIT.USR.ROLES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
                Y.USR.GRP = Y.GPM.USR.GRP<Y.FM.POS>
                R.NEW(PP.OEYG.LOCAL.REF)<1,Y.OE.LRF.POS> = Y.USR.GRP
            END ELSE
                FIND Y.PP.MSGTYPE IN Y.CONFIG.USR.ROLES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
                    Y.USR.GRP = Y.GPM.USR.GRP<Y.FM.POS>
                    R.NEW(PP.OEYG.LOCAL.REF)<1,Y.OE.LRF.POS> = Y.USR.GRP
                END
            END
    END CASE
        
RETURN
****************************************************************************************************************
END