SUBROUTINE JB.R.PP.SWMXCNCLBANK.NOF(OUT.ARR)
*-------------------------------------------------------------------------------------
* This a NoFile enquiry to Initiate Cancellation request based on user groups.
* Core API used to get list of eligible transactions and then to filter the transactions based on CURRENT USER ROLE.
*Attached to Enquiry JB.E.PP.SWIFTMXOUTCANCELBANK.INP  as NOFILE.JB.PP.SWFMXCNCLBNK.
*-------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------
** Date         Developer           Reference        Description
* 22-OCT-2024   Vikram Pavuluru     CBPAY-974       This routine is used to fetch the cancellation records based on user role group.
*
* 16-JUN-2025   Vikram Pavuluru     CBPAY-3236      Modified the logic to fetch pacs.009 transactions based on user role.
*-------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    

    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS

RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    FV.POR.SUPPL.INFO = ""
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    FV.POR.TRANSACTION = ""
    
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)
    CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
    
    OUT.ARR = '' ; Y.ENQ.DATA = '' ; OUT.POS = ''
    Y.FT.NONO = '' ; BP.POS = '' ;  PORS.ERR = ''
    R.POR.SUPPL.INFO.REC = ''
 
    
RETURN

*****************
GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)


    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END
    
    
RETURN
 

********
PROCESS:
********

    CALL E.NOFILE.PP.SWCR.RECALL.INITIATED(OUT.ARRAY)
    IF OUT.ARRAY THEN
        LOOP
            READNEXT Y.ENQ.DATA FROM OUT.ARRAY SETTING OUT.POS
        WHILE Y.ENQ.DATA
            Y.FT.NO = FIELD(Y.ENQ.DATA,"*",2)
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FV.POR.TRANSACTION,PORT.ERR)
            IF R.POR.TRANSACTION.REC THEN
                Y.MSG.TYPE = R.POR.TRANSACTION.REC<PPPTX.OutgoingMessageType>
                IF Y.MSG.TYPE EQ 'pacs.009' THEN
                    IF R.POR.SUPPL.INFO.REC THEN
                        LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                            Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                            IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                                OUT.ARR<-1> = Y.ENQ.DATA
                            END
                        END
                    END
                END
            END
        REPEAT
    END
 
RETURN
***********************************************************************************
END

