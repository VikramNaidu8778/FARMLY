*---------------------------------------------------------------------------------------------------------------
* <Rating>0</Rating>
*---------------------------------------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.DEBITPL.VALIDATE
*---------------------------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------------------------
* This is a validation routine used to populate the DEBIT-PL account based on TXN type
* PL accounts and TXN types parameterised in JBWW.H.EB.GENERIC.PARAMETER>JBWW.D.FT.BANKSRVFEE
*---------------------------------------------------------------------------------------------------------------
* Attached: VERSION>FUNDS.TRANSFER,JBWW.AC.REFDBNKSRVFEE.INP
*---------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: -NA-
* OUT:-NA-
*
* Dependencies:
*---------------
* CALLS:-NA-
* CALLED BY:-NA-
*
* Revision History:
*---------------------------------------------------------------------------------------------------------------
* Date               who                  Reference                 Description
* 27-04-2016         Ramesh K(CTS)        JB2A-42459                Initial Version
*---------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.FUNDS.TRANSFER

	FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
	F.JBWW.H.EB.GENERICPARAMETER = ''
	CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

	Y.GPM.ID = 'JBWW.D.FT.BANKSRVFEE'
	R.JBWW.H.EB.GENERICPARAMETER = ''; GPM.ERR = ''
	CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.GPM.ID,R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,GPM.ERR)
	FIELD.NAME.ARR = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
	
	Y.TXN.TYPE = COMI
	LOCATE Y.TXN.TYPE IN FIELD.NAME.ARR<1,1> SETTING TXN.TYP.POS THEN
		Y.DEBIT.PL = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,TXN.TYP.POS>
		R.NEW(FT.DEBIT.ACCT.NO) = Y.DEBIT.PL
	END
	
RETURN
