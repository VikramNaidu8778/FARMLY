* @ValidationCode : MToxNDE3NjM0NzgzOklTTy04ODU5LTE6MTQ5NTU0MDU4MjU0Nzo1MjYzNzg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjQ=
* @ValidationInfo : Timestamp         : 23 May 2017 17:26:22
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 526378
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
SUBROUTINE JBWW.V.FT.DEF.BEN
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*Date          Description        
*23-May-2017   This routine is to default BEN.CUSTOMER field from details of PAYEE.NAME
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
IF R.NEW(FT.PAYEE.NAME) NE "" THEN
COMI = R.NEW(FT.PAYEE.NAME)
END
RETURN

END
