SUBROUTINE JB.R.PP.PAYMENTREVERSAL.NOF(OUT.ARR)
*-------------------------------------------------------------------------------------
* This a NoFile enquiry to Initiate Payment reversal request based on user groups.
* Core API used to get list of eligible transactions and then to filter the transactions based on CURRENT USER ROLE.
*Attached to Enquiry JB.E.PP.REVERSALPAYMENTS.LIST  as NOFILE.JB.PP.REVERSE.PAYMENT.
*-------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------
** Date         Developer           Reference        Description
* 24-FEB-2025   Vikram Pavuluru     CBPAY-1741       This routine is used to fetch the records based on user role group.
*
* 25-APR-2025   Vikram Pavuluru     CBPAY-2524       Implemented additional logic to filter records based on company.
*-------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.COMPANY
    $INSERT I_ENQUIRY.COMMON
    
    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB CHECK.COMPANY
    GOSUB PROCESS

RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    
    Y.MNEMONIC = ''
    Y.POS = ''
    Y.ENQ.NAME = ENQ.SELECTION<1>
    Y.POS = DCOUNT(ENQ.SELECTION<2>,@VM)
    Y.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    
    IF Y.POS THEN
        Y.POS += 1
    END ELSE
        Y.POS = 1
    END
    ENQ.SELECTION<2,Y.POS> = "CompanyID"
    ENQ.SELECTION<3,Y.POS> = "EQ"
    ENQ.SELECTION<4,Y.POS> = Y.MNEMONIC

    D.LOGICAL.OPERANDS<Y.POS> = "1"
    
    
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    FV.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    FV.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
    
    OUT.ARR = '' ; Y.ENQ.DATA = '' ; OUT.POS = ''
    Y.FT.NONO = '' ; BP.POS = '' ;  PORS.ERR = ''
    R.POR.SUPPL.INFO.REC = ''
    
    CALL GET.LOC.REF('POR.SUPPLEMENTARY.INFO',LOC.REF.FLD,LOC.POS)
    
  
RETURN

*****************
GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
 
    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END
   
RETURN
 
********
PROCESS:
********
    IF ENQ.ERROR THEN RETURN

    CALL E.NOFILE.PP.REVERSE.PAYMENT(OUT.ARRAY)
    IF OUT.ARRAY THEN
        LOOP
            READNEXT Y.ENQ.DATA FROM OUT.ARRAY SETTING OUT.POS
        WHILE Y.ENQ.DATA
            Y.FT.NO = FIELD(Y.ENQ.DATA,"*",2)
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FV.POR.TRANSACTION,PORT.ERR)
            IF R.POR.TRANSACTION.REC THEN
                Y.DIRECTION = R.POR.TRANSACTION.REC<PPPTX.PaymentDirection>
                BEGIN CASE
                    CASE Y.DIRECTION MATCHES 'O' :@VM: 'B'
                        LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                            Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                            IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                                OUT.ARR<-1> = Y.ENQ.DATA
                            END
                        END
                    CASE 1
                        OUT.ARR<-1> = Y.ENQ.DATA
                END CASE
            END
        REPEAT
    END

RETURN
**************
CHECK.COMPANY:
**************

    LOCATE "CompanyID" IN D.FIELDS<1> SETTING Y.POS THEN
        IF R.COMPANY(EB.COM.MNEMONIC) NE D.RANGE.AND.VALUE<Y.POS> THEN
            ENQ.ERROR = "Please enter current company"
        END
    END

RETURN
********************************************************************************************
END

