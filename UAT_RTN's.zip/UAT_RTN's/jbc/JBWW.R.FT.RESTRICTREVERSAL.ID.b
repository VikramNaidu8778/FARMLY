* @ValidationCode : MTo1NTc1ODE3NzE6SVNPLTg4NTktMToxNDg0MjEyNzEwMTc0OjQ4MDMyNjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 12 Jan 2017 14:48:30
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 480326
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.FT.RESTRICTREVERSAL.ID
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                   Reference           Description
*-----------------------------------------------------------------------------
*6/1/2017     Batturu.Sivanandini         CR_145                 ROUTINE
*-----------------------------------------------------------------------------
*This is a ID routine used to restrict the reversal of the records through the version FUNDS.TRANSFER,JBWW.V.SC.SFADVFEES.INP
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------

    IF V$FUNCTION EQ 'R' THEN
        E='EB-JBWW.D.FT.REVERSAL.NOTALLOWED'
        RETURN
    END
