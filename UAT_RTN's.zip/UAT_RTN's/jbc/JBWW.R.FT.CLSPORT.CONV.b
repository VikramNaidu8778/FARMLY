*-------------------------------------------------------------------------   
   SUBROUTINE JBWW.R.FT.CLSPORT.CONV
*-------------------------------------------------------------------------
* Description: To Seprate the values from inputter field.
*-------------------------------------------------------------------------
* Modification History : 
*-------------------------------------------------------------------------
* Date        Developer       Reference     Description
*-------------------------------------------------------------------------
* 26/06/2019  Lakshmanan      T24-15229     Conversion routine for PORTFOLIO KEY
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_ENQUIRY.COMMON
    $INSERT  I_F.ACCOUNT
*-------------------------------------------------------------------------


    GOSUB INIT
    GOSUB PROCESS

    RETURN

*-------------------------------------------------------------------------
INIT:
*-------------------------------------------------------------------------
    Y.ACC.ID = O.DATA

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT  = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
    F.ACCOUNT.HIS = ''
    CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)
   
    R.ACC.REC = ''
    
    RETURN

*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------

    CALL F.READ(FN.ACCOUNT,Y.ACC.ID,R.ACC.REC,F.ACCOUNT,ACC.ERR)
    IF R.ACC.REC THEN
       Y.PORT.KEY = R.ACC.REC<AC.PORTFOLIO.NO,1>
    END ELSE
       R.ACC.REC = ''
       CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACC.ID,R.ACC.REC,Y.ACC.ERR)
       IF R.ACC.REC THEN
          Y.PORT.KEY = R.ACC.REC<AC.PORTFOLIO.NO,1>
       END
    END

    IF Y.PORT.KEY EQ '' AND R.ACC.REC NE '' THEN
       Y.ALT.ACC = R.ACC.REC<AC.ALT.ACCT.ID>
       Y.ALT.TYPE = R.ACC.REC<AC.ALT.ACCT.TYPE>
       LOCATE "BJB.ACCT" IN Y.ALT.TYPE<1,1> SETTING Y.FLD.POS THEN
          Y.ALT.ACCT = Y.ALT.ACC<1,Y.FLD.POS>
       END
    END

    IF Y.ALT.ACCT THEN
       Y.PORT.KEY = FIELD(Y.ALT.ACCT,'-',1,2)           
	   COMI = Y.PORT.KEY
       CALL IN2SAM('','')
       Y.PORT.KEY = COMI
    END

    IF Y.PORT.KEY THEN
     O.DATA = Y.PORT.KEY

    END

    RETURN
*-------------------------------------------------------------------------
END
*-------------------------------------------------------------------------
  

