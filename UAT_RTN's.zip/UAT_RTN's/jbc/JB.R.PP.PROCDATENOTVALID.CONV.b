* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 09 May 2024 08:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 821829
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JB.R.PP.PROCDATENOTVALID.CONV
*-------------------------------------------------------------------------
* This routine is copy of the existing FT Version Routine JBWW.R.FT.PROCDATENOTVALID.CONV and incorporated with TPH Payment order,Order Entry application Logic.
* Attached to  : Enquiry > JB.E.PP.AUTH.NAU 
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 09/05/2024    P Amala               CBPAY-356              Assign the Function based on Payment Execution Date to Amend / Authorise the transaction.
* 												
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_ENQUIRY.COMMON
*-------------------------------------------------------------------------

	GOSUB INIT
    GOSUB PROCESS
    RETURN

*--------------------------------------------------------------------------
INIT:
****

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
	
	FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********

   Y.PP.ID = '' ; Y.PROC.DATE = ''
   Y.PP.ID = O.DATA
	BEGIN CASE
	   CASE Y.PP.ID[1,2] EQ 'PI'
	   	
	      CALL F.READ(FN.PAYMENT.ORDER,Y.PP.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,PAYMENT.ORDER.ERR)
	          Y.PROC.DATE = R.PAYMENT.ORDER<PO.PAYMENT.EXECUTION.DATE>

* RLC - There is no Status with IFWD for forwarded dated Payment Order
*	Y.FT.STATUS = R.PAYMENT.ORDER<FT.STATUS>  

	     CASE Y.PP.ID[1,2] EQ 'OE'

	CALL F.READ(FN.PP.ORDER.ENTRY,Y.PP.ID,R.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY,PP.ORDER.ENTRY.ERR)
	
	Y.PROC.DATE = R.PP.ORDER.ENTRY<PP.OEYG.ProcessingDate>

* RLC - There is no Status with IFWD for forwarded dated Payment ORDER
*	Y.FT.STATUS = R.PP.ORDER.ENTRY<FT.STATUS>  
	END CASE

	IF Y.PROC.DATE LT TODAY THEN
		O.DATA = 'I'
	END ELSE
		O.DATA = 'A'
	END

    RETURN
*--------------------------------------------------------------------------
END