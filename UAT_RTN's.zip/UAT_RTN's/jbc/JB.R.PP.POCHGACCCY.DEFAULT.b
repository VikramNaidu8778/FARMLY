*-------------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.POCHGACCCY.DEFAULT
*-------------------------------------------------------------------------------------------------------
* Payment Framework defaults Debit Currency as Charge Account Currency. But there are scenarios were
* Charge Account and it's currency can be different Debit Account Currency. So this field validation 
* routine to default Charge Account Currency based on Charge Account.
*-------------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------------------
* Date              Developer               Reference                    Description
*
* 07-APR-2025       Prabhu D S              CBPAY-2123                   Initial draft
*
* 09-MAY-2025       Prabhu D S              CBPAY-2274                   Debit Charge Imposed shd be 
*                                                                        popultaed only if not provided
* 26-MAY-2025       Resmi R                 CBPAY-2945                   Fixed the logic for Override error by nullifying Debit Charge Imposed field to NULL
*
* 03-JUN-2025       Prabhu D S              CBPAY-3184                   Do not default Charge account when WAIVE.ALL.CHARGES is enabled
*
* 06-JUN-2025       Prabhu D S              CBPAY-3158                   Waive Off not enabled for Book Transfers, so default Charge Account only if it is 
*                                                                        not Nostro account.
* 17-JUN-2025       Prabhu D S              CBPAY-3225                   Updated the logic for BEN charges
*
* 27-JUN-2025      Lakshmi Priya            CBPAY-3158 &                 Included logic to nullify charge account and debit charge imposed if 
*                                           CBPAY-3499                   there is no charge bearer.
*
* 28-JUN-2025      Prabhu D S               CBPAY-2274                   Fixed the logic for charge accounting entries posting in CHF instead of debit acct currency
*
* 06-Jul-2025      u40786                   CBPAY-3028                   Default the charge account only if the debit account is valid
*                                           CBPAY-3158
*                                           CBPAY-2308
*
*-------------------------------------------------------------------------------------------------------
   $INSERT I_COMMON
   $INSERT I_EQUATE
   $INSERT I_F.ACCOUNT
   $INSERT I_F.ALTERNATE.ACCOUNT
   $INSERT I_F.PAYMENT.ORDER

   FN.ACCOUNT = 'F.ACCOUNT'
   F.ACCOUNT = ''
   CALL OPF(FN.ACCOUNT,F.ACCOUNT)

   FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
   F.ALTERNATE.ACCOUNT = ''
   CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

   IF R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES "STO":@VM:"STOMXCHATS" THEN RETURN

   IF R.NEW(PO.WAIVE.ALL.CHARGES) EQ 'YES' OR R.NEW(PO.CHARGE.BEARER) EQ "BEN" THEN
        COMI = ''
	R.NEW(PO.DEBIT.CHARGE.IMPOSED) = ''
        RETURN
   END

	IF COMI EQ '' THEN
		DB.ACCT.ID = R.NEW(PO.DEBIT.ACCOUNT)

		YR.ACCOUNT = ''
		E.ACCOUNT = ''
		CALL F.READ(FN.ACCOUNT,DB.ACCT.ID,YR.ACCOUNT,F.ACCOUNT,E.ACCOUNT)
		IF YR.ACCOUNT THEN
* Default the charge account only if the debit account is valid		
			COMI = R.NEW(PO.DEBIT.ACCOUNT)
		END
	END
   
   Y.CHG.AC = COMI
   CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.CHG.AC,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,'')

   IF R.ALTERNATE.ACCOUNT THEN
      Y.CHG.AC = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
   END

   CALL F.READ(FN.ACCOUNT,Y.CHG.AC,R.CHG.ACCT,F.ACCOUNT,'')
   IF R.CHG.ACCT AND (NOT(R.CHG.ACCT<AC.CATEGORY> GE 5000 AND R.CHG.ACCT<AC.CATEGORY> LE 5999)) THEN
      R.NEW(PO.CHARGE.ACCOUNT.CCY) = R.CHG.ACCT<AC.CURRENCY>
      IF NOT(R.NEW(PO.DEBIT.CHARGE.IMPOSED)) THEN R.NEW(PO.DEBIT.CHARGE.IMPOSED) = 'OnlyAccount'
   END
*
RETURN
*
END
*