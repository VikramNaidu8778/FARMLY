SUBROUTINE JB.R.PP.TXNTYPEDROPDOWN.NOF(LIST.ARRY)
*-----------------------------------------------------------------------------
** Description:
*-------------------------------------------------------------------------
* This is no-file enquiry routine attached to enquiry JBWW.E.FT.TXNTYPE.DROPDOWN
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: LIST.ARRY
* Dependencies:
*---------------
* NA
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer           Reference         Description
*----------------------------------------------------------------------------------------------
*30/05/2024        Hariharan T           CBPAY-52         This No-File enquiry routine is to display only the Defined PAYMENT.ORDER.PRODUCT from GPM, based on the version.
*-----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.EB.USER.ROLES
    $INSERT I_F.USER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PAYMENT.ORDER.PRODUCT
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
RETURN
*-------------------------------------------------------------------------------
INIT:
*****
 
    JBWW.GEN.PAR.FN = '' ; JBWW.GEN.PAR.FV = ''
    FT.TXN.CNT = '' ; FT.TXN.ID = ''
    FT.TXN.DESC = '' ; FV.CNT = ''
    FT.TXN.CNT = '' ; GP.ERR.MSG = ''
    R.FT.TXN = '' ; R.GEN.REC.ROLE = ''
    FT.ERR = '' ; VER.POS = ''
    VER.NAME = '' ; R.GEN.REC.CASH = ''
    R.GEN.REC.SEC = ''
 
    LOCATE "VER.NAME" IN D.FIELDS<-1> SETTING VER.POS THEN
        VER.NAME = D.RANGE.AND.VALUE<VER.POS>
        CHANGE "'" TO "" IN VER.NAME
    END
 
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
 
    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)
 
    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    FN.PAYMENT.ORDER.PRODUCT = 'F.PAYMENT.ORDER.PRODUCT'
    F.PAYMENT.ORDER.PRODUCT = ''
    CALL OPF(FN.PAYMENT.ORDER.PRODUCT,F.PAYMENT.ORDER.PRODUCT)
 
RETURN
*---------------------------------------------------------------------------------
PROCESS:
*********
    
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.GEN.REC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASHSEC.ROLES.FN = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.NAME>
 
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.AC.CASH.TXNTYPES",R.GEN.REC.CASH,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASH.TXNTYPES.FN = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.NAME>
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.SC.SEC.TXNTYPES",R.GEN.REC.SEC,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.SEC.TXNTYPES.FN = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.NAME>
 
    LOCATE "CASH.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
        Y.CASH.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
        LOCATE VER.NAME IN Y.CASH.TXNTYPES.FN<1,1> SETTING CASHTXN.POS THEN
            Y.CASH.TXNTYPES.FV = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,CASHTXN.POS>
                    END
    END
    LOCATE "SEC.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
        Y.SEC.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
        LOCATE VER.NAME IN Y.SEC.TXNTYPES.FN<1,1> SETTING SECTXN.POS THEN
            Y.SEC.TXNTYPES.FV = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.VALUE,SECTXN.POS>
                    END
    END
    GOSUB CASH.USER.ROLE.CHK
 
RETURN
 
CASH.USER.ROLE.CHK:
*******************
    Y.USER.ROLES.LIST = R.USER<EB.USE.USER.ROLES>
    LOOP
        REMOVE Y.USER.ROLES FROM Y.USER.ROLES.LIST SETTING ROLE.POS
    WHILE Y.USER.ROLES:ROLE.POS
        LOCATE Y.USER.ROLES IN Y.CASH.USER.ROLES<1,1,1> SETTING FV.CASH.ROLE.POS THEN
            LIST.ARRY = ""
            CASH.FT.TXN.CNT = DCOUNT(Y.CASH.TXNTYPES.FV,SM)
            CASH.FT.CNT = 1
            LOOP
            WHILE CASH.FT.CNT LE CASH.FT.TXN.CNT
                FTTXNTYPE.POS = ""
                CASH.PO.PRD.IDS = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,CASHTXN.POS,CASH.FT.CNT>
                GOSUB CHK.PO.PRD.FOR.USER
                CASH.FT.CNT += 1
            REPEAT
        END ELSE
            GOSUB SEC.USER.ROLE.CHK
        END
        Y.USER.ROLES = ''
    REPEAT
RETURN
 
 
****************************
SEC.USER.ROLE.CHK:
*********************************
    ROLE.POS = ""
    LOOP
        REMOVE Y.USER.ROLES FROM Y.USER.ROLES.LIST SETTING ROLE.POS
    WHILE Y.USER.ROLES:ROLE.POS
 
        LOCATE Y.USER.ROLES IN Y.SEC.USER.ROLES<1,1,1> SETTING FV.SEC.ROLE.POS THEN
            LIST.ARRY = ""
            SEC.FT.TXN.CNT = DCOUNT(Y.SEC.TXNTYPES.FV,SM)
            SEC.FT.CNT = 1
            LOOP
            WHILE SEC.FT.CNT LE SEC.FT.TXN.CNT
                FTTXNTYPE.POS = ""
                SEC.FT.TXN.ID = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.VALUE,SECTXN.POS,SEC.FT.CNT>
                GOSUB CHK.PO.PRD.FOR.USER
                SEC.FT.CNT += 1
            REPEAT
        END
        Y.USER.ROLES = ''
    REPEAT
RETURN
************************************************
CHK.PO.PRD.FOR.USER:
*********************************************8
    IF CASH.PO.PRD.IDS EQ "" THEN
        PO.PRD.IDS = SEC.FT.TXN.ID
    END ELSE
        PO.PRD.IDS = CASH.PO.PRD.IDS
    END
    LOOP
        REMOVE CASH.PO.PRD.ID FROM PO.PRD.IDS SETTING PRD.POS
    WHILE CASH.PO.PRD.ID : PRD.POS
        CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,CASH.PO.PRD.ID,R.PO.ORD.PRD.CASH,F.PAYMENT.ORDER.PRODUCT,CASH.PO.ERR)
        CASH.PO.ORD.PRD.DESC = R.PO.ORD.PRD.CASH<POP.DESCRIPTION>
        LOCATE USER.ROLE IN Y.CASH.TXNTYPES.FN<1,1> SETTING ROLE.TXN.POS THEN
            Y.ROLE.TXN.LIST = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,ROLE.TXN.POS>
            LOCATE CASH.PO.PRD.ID IN Y.ROLE.TXN.LIST<1,1,1> SETTING REST.TXN.POS ELSE
                LIST.ARRY<-1> = CASH.PO.PRD.ID:"*":CASH.PO.ORD.PRD.DESC
            END
        END ELSE
            LIST.ARRY<-1> = CASH.PO.PRD.ID:"*":CASH.PO.ORD.PRD.DESC
        END
 
    REPEAT
 
 
RETURN
***********************************************
END