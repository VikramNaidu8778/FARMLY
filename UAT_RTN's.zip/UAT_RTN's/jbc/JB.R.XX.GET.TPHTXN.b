SUBROUTINE JB.R.XX.GET.TPHTXN(TXN.REF,R.APPLN,PO.LIST)
*-----------------------------------------------------------------------------
* This is a generic routine attached to retrieve Payment Order id for Other 
* Module Application (FX, ND, MM, SW, FD, DX).
* Called by: JB.R.DE.GETTXNMSGS.BLD & JB.R.XX.GETTXNENTRIES.NOF
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date         Developer          Reference              Description
*
* 11-Feb-2025  Prabhu D S         CBPAY-1821             Initial Version
* 27-Feb-2025  Prabhu D S         CBPAY-2021             Logic included to get
*                                                        PO from history records
* 06-JUN-2025  P Amala            CBPAY-2863             Fix to exit the code when querying non-TPH impacted FT.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FD.FIDUCIARY
    $INSERT I_F.FOREX
    $INSERT I_F.MM.PAYMENT.ENTRY
    $INSERT I_F.ND.DEAL
    $INSERT I_F.DX.TRADE
    $INSERT I_F.SWAP

    Y.TEMP.TXN.REF = TXN.REF
    GOSUB GET.APPLN.DETS
    IF NOT(Y.APPLN) THEN
       RETURN
    END
    GOSUB OPEN.FILES
    GOSUB LIVE.READ
    
    CHANGE VM TO FM IN PO.LIST
    TXN.REF = Y.TEMP.TXN.REF

RETURN
***************
GET.APPLN.DETS:
***************
* Application and field name has to be decided based on first two characters of Txn Ref
    BEGIN CASE
        CASE TXN.REF[1,2] EQ 'FD'
            Y.APPLN = 'FD.FIDUCIARY'
            Y.FIELD.NO = FD.PO.REFERENCE
            Y.FIELD.CURRNO = FD.CURR.NO
        CASE TXN.REF[1,2] EQ 'FX'
            Y.APPLN = 'FOREX'
            Y.FIELD.NO = FX.PO.REFERENCE
            Y.FIELD.CURRNO = FX.CURR.NO
        CASE TXN.REF[1,2] EQ 'MM'
            Y.APPLN = 'MM.PAYMENT.ENTRY'
            Y.FIELD.NO = MM.PA.PO.REFERENCE
            Y.FIELD.CURRNO = MM.PA.CURR.NO
            TXN.REF = TXN.REF:'00'
* Getting overwritten - need to add the logic to get the history records
        CASE TXN.REF[1,2] EQ 'SW'
            Y.APPLN = 'SWAP'
            Y.FIELD.NO = SW.PO.REFERENCE
            Y.FIELD.CURRNO = SW.CURR.NO
* Getting overwritten - need to add the logic to get the history records
        CASE TXN.REF[1,2] EQ 'DX'
            Y.APPLN = 'DX.TRADE'
            Y.FIELD.NO = DX.TRA.PAYMENT.ORDER.ID
            Y.FIELD.CURRNO = DX.TRA.CURR.NO
        CASE TXN.REF[1,2] EQ 'ND'
            Y.APPLN = 'ND.DEAL'
            Y.FIELD.NO = ND.DEAL.PO.REFERENCE
            Y.FIELD.CURRNO = ND.DEAL.CURR.NO
    END CASE
*
RETURN
*
***********
OPEN.FILES:
***********
* Open Application to retrieve Payment Order ref
    FN.APPLN = 'F.':Y.APPLN
    F.APPLN = ''
    CALL OPF(FN.APPLN,F.APPLN)

    FN.APPLN.HIS = 'F.':Y.APPLN:'$HIS'
    F.APPLN.HIS = ''
    CALL OPF(FN.APPLN.HIS,F.APPLN.HIS)
    
    R.APPLN = ''
    E.APPLN = ''
    E.APPLN.HIS = ''
    PO.LISTS = ''
*
RETURN
*
**********
LIVE.READ:
**********
* Check Txn Ref in live table.
    R.APPLN = ''
    E.APPLN = ''
    CALL F.READ(FN.APPLN,TXN.REF,R.APPLN,F.APPLN,E.APPLN)
    IF R.APPLN THEN
       GOSUB READ.HIST
    END ELSE
       GOSUB HISTORY.READ
       GOSUB READ.HIST
    END
    
*
RETURN
*
*************
HISTORY.READ:
*************
* Check Txn Ref in History table if not found in Live table.
    R.APPLN = ''
    E.APPLN.HIS = ''
    HIS.ID = TXN.REF
    CALL EB.READ.HISTORY.REC(F.APPLN.HIS,HIS.ID,R.APPLN,E.APPLN.HIS)
*
RETURN
*
**********
READ.HIST:
*********** 
* Some Treasury module payments like SW, FD etc will follow lifce cycle and will create Payment Order
* in different scenarios like UNWIND, Principle Increase/Decrease, Interest change etc. So separate
* Payment Order will also be created for each activity.

    Y.CURRNO = R.APPLN<Y.FIELD.CURRNO>
    PO.LIST = R.APPLN<Y.FIELD.NO>
    IF Y.CURRNO GT 1 THEN
       Y.CNT = Y.CURRNO - 1
       FOR Y.IDX = 1 TO Y.CNT
           Y.HIS.ID = TXN.REF:';':Y.IDX
           R.APPLN.HIS = ''
           CALL F.READ(FN.APPLN.HIS,Y.HIS.ID,R.APPLN.HIS,F.APPLN.HIS,E.APPLN.HIS)
           PO.LIST<1,-1> = R.APPLN.HIS<Y.FIELD.NO>
       NEXT Y.IDX
    END

RETURN
*
END