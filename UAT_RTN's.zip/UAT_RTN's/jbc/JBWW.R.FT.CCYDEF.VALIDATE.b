* @ValidationCode : MTo5NzA5ODQ4NzA6SVNPLTg4NTktMToxNDgzMDA5Njg4NDQ1OjQyMDE0MTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 29 Dec 2016 16:38:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 420141
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.FT.CCYDEF.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*----------------------------------------------------------------------------------------------
* 12/12/2016    Rajesh.Kopparapu@cognizant.com           CR-138                version 0.3
* 17/02/2017	Balaji.Pushparaj@cognizant.com			Defect Fix - 27252     After reading the table(Account), pass values only if record is available.
*-----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    IF V$FUNCTION EQ 'I' OR V$FUNCTION EQ 'C' THEN
        GOSUB INIT
        GOSUB PROCESS
        RETURN
    END
*****
INIT:
*****
    Y.ID.OLD = ''   ; Y.DT.ACC = ''
    Y.CR.ACC = ''   ; ERR.DTACC  = ''
    R.DT.ACC = ''   ; R.CR.ACC = ''
    ERR.CRACC = ''  ; DT.CCY   = ''
    CR.CCY   = ''

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER  = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT  = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    RETURN
*--------------------------------------------------------------------------------
PROCESS:
******** 
    Y.ID.OLD = ID.OLD
    IF Y.ID.OLD EQ '' THEN
        IF AF EQ FT.DEBIT.ACCT.NO THEN
            Y.DT.ACC = COMI
            IF Y.DT.ACC EQ '' THEN
                Y.DT.ACC = R.NEW(FT.CREDIT.ACCT.NO)
            END
			R.DT.ACC = "" ; ERR.DTACC = ""
            CALL F.READ(FN.ACCOUNT,Y.DT.ACC,R.DT.ACC,F.ACCOUNT,ERR.DTACC)
			IF R.DT.ACC NE "" THEN ;*JB2A-27252
            DT.CCY = R.DT.ACC<AC.CURRENCY>
            R.NEW(FT.DEBIT.CURRENCY) = DT.CCY
			END
        END

        IF AF EQ FT.CREDIT.ACCT.NO THEN
            Y.CR.ACC = COMI
***ADDED
            R.DRACC = ''
            ACC.ERR = ''
            Y.DEBIT.ACCT = R.NEW(FT.DEBIT.ACCT.NO)
			R.DRACC = "" ; ACC.ERR = ""
            CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT,R.DRACC,F.ACCOUNT,ACC.ERR)
			IF R.DRACC NE "" THEN ;*JB2A-27252
            Y.ACC.CATEG = R.DRACC<AC.CATEGORY>
            Y.DEB.ACC.CUSTOMER = R.DRACC<AC.CUSTOMER> 
			END
            IF Y.ACC.CATEG GE '5000' AND Y.ACC.CATEG LE '5999' THEN
                R.CRACC = '' ; ACC.ERR = ""
                CALL F.READ(FN.ACCOUNT,Y.CR.ACC,R.CRACC,F.ACCOUNT,ACC.ERR)
				IF R.CRACC NE "" THEN ;*JB2A-27252
                Y.CUSTOMER = R.CRACC<AC.CUSTOMER> 
                END				
                IF NOT(Y.CUSTOMER) THEN 
                Y.CUSTOMER = Y.DEB.ACC.CUSTOMER
                END                 
				IF Y.CUSTOMER NE "" THEN ;*JB2A-27252
                R.NEW(FT.PROFIT.CENTRE.CUST) = Y.CUSTOMER 
				END
            END 
****
            IF Y.CR.ACC EQ '' THEN
                Y.CR.ACC = R.NEW(FT.DEBIT.ACCT.NO)
            END
			R.CR.ACC = "" ; ERR.CRACC = ""
            CALL F.READ(FN.ACCOUNT,Y.CR.ACC,R.CR.ACC,F.ACCOUNT,ERR.CRACC)
			IF R.CR.ACC NE "" THEN ;*JB2A-27252
            CR.CCY = R.CR.ACC<AC.CURRENCY>
            R.NEW(FT.CREDIT.CURRENCY) = CR.CCY
			END
        END
        CALL REBUILD.SCREEN()
    END
    CALL JBWW.R.FT.DEFPLACCT.CCY
    RETURN
*--------------------------------------------------------------------------------
    END
