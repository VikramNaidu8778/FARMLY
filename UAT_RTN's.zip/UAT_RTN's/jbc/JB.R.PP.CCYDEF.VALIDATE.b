SUBROUTINE JB.R.PP.CCYDEF.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------------
* Date              Developer       Reference                                   Description
*21-05-2024        Hariharan T      CBPAY-52                          Validation routine to default the CREDIT/DEBIT currency for PAYMENT.ORDER application.
*------------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.PAYMENT.ORDER
*-----------------------------------------------------------------------------
    IF V$FUNCTION EQ 'I' THEN
        GOSUB INIT
        GOSUB PROCESS
        RETURN
    END
	RETURN
*****
INIT:
*****
    Y.ID.OLD = '' ; Y.DT.ACC = ''
    Y.CR.ACC = '' ; ERR.DTACC = ''
    R.DT.ACC = '' ; R.CR.ACC = ''
    ERR.CRACC = '' ; DT.CCY = ''
    CR.CCY = ''
   
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

RETURN
*--------------------------------------------------------------------------------
PROCESS:
********
    Y.ID.OLD = ID.OLD
    IF Y.ID.OLD EQ '' THEN
        IF AF EQ PO.DEBIT.ACCOUNT THEN
            Y.DT.ACC = COMI
            IF Y.DT.ACC EQ '' THEN
                Y.DT.ACC = R.NEW(PO.CREDIT.ACCOUNT)
            END
            R.DT.ACC = "" ; ERR.DTACC = ""
            CALL F.READ(FN.ACCOUNT,Y.DT.ACC,R.DT.ACC,F.ACCOUNT,ERR.DTACC)
            IF R.DT.ACC NE "" THEN ;*JB2A-27252
                DT.CCY = R.DT.ACC<AC.CURRENCY>
                R.NEW(PO.DEBIT.CCY) = DT.CCY
            END
        END

        IF AF EQ PO.CREDIT.ACCOUNT THEN
            Y.CR.ACC = COMI
***ADDED
            R.DRACC = ''
            ACC.ERR = ''
            Y.DEBIT.ACCT = R.NEW(PO.DEBIT.ACCOUNT)
            R.DRACC = "" ; ACC.ERR = ""
            CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT,R.DRACC,F.ACCOUNT,ACC.ERR)
            IF R.DRACC NE "" THEN ;*JB2A-27252
                Y.ACC.CATEG = R.DRACC<AC.CATEGORY>
                Y.DEB.ACC.CUSTOMER = R.DRACC<AC.CUSTOMER>
            END
            IF Y.ACC.CATEG GE '5000' AND Y.ACC.CATEG LE '5999' THEN
                R.CRACC = '' ; ACC.ERR = ""
                CALL F.READ(FN.ACCOUNT,Y.CR.ACC,R.CRACC,F.ACCOUNT,ACC.ERR)
                IF R.CRACC NE "" THEN ;*JB2A-27252
                    Y.CUSTOMER = R.CRACC<AC.CUSTOMER>
                END
                IF NOT(Y.CUSTOMER) THEN
                    Y.CUSTOMER = Y.DEB.ACC.CUSTOMER
                END
*IF Y.CUSTOMER NE "" THEN ;*JB2A-27252
*   R.NEW(FT.PROFIT.CENTRE.CUST) = Y.CUSTOMER
*END
            END
****
            IF Y.CR.ACC EQ '' THEN
                Y.CR.ACC = R.NEW(PO.DEBIT.ACCOUNT)
            END
            R.CR.ACC = "" ; ERR.CRACC = ""
            CALL F.READ(FN.ACCOUNT,Y.CR.ACC,R.CR.ACC,F.ACCOUNT,ERR.CRACC)
            IF R.CR.ACC NE "" THEN ;*JB2A-27252
                CR.CCY = R.CR.ACC<AC.CURRENCY>
                R.NEW(PO.CREDIT.CURRENCY) = CR.CCY
            END
        END
        CALL REBUILD.SCREEN()
    END
    CALL JB.R.PP.DEFPLACCT.CCY
RETURN
*--------------------------------------------------------------------------------
END