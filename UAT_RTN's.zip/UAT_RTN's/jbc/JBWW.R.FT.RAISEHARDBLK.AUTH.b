SUBROUTINE JBWW.R.FT.RAISEHARDBLK.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                   Reference           Description
*-----------------------------------------------------------------------------
*30/06/2023     Ramesh K                    T24-17442           Auth routine to raise Hard-block

*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_GTS.COMMON
    
    GOSUB INIT ; *Initialize variables
    GOSUB PROCESS ; *Actual Process
*
RETURN

*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
*
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER  = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    REC.GEN.PARAM = '' ; GEN.ERR = ''
    R.SEC.MASTER  = '' ; SM.ERR  = ''
    
    LREF.APPL = 'FUNDS.TRANSFER':FM:'SEC.ACC.MASTER'
    LREF.FLDS = 'L.XX.HBBLK.REQ':FM:'L.XX.TAG.BLK.ID'
    LREF.POS = ''
    CALL MULTI.GET.LOC.REF(LREF.APPL,LREF.FLDS,LREF.POS)
    
    Y.FT.HBBLKREQ.POS = LREF.POS<1,1>
    Y.SM.BLKID.POS = LREF.POS<2,1>
*
RETURN
*** </region>

*-----------------------------------------------------------------------------
*** <region name= PROCESS>
PROCESS:
*** <desc>Actual Process </desc>

    GOSUB GET.GEN.PARAM.DETAILS

    Y.FT.TXN.TYPES = R.NEW(FT.TRANSACTION.TYPE)
    Y.FT.TXNPOS = ''
    LOCATE Y.FT.TXN.TYPES IN Y.TXN.TYPES<1,1> SETTING Y.FT.TXNPOS THEN

        IF R.NEW(FT.CURR.NO) LE Y.CURR.NO.VAL AND R.NEW(FT.LOCAL.REF)<1,Y.FT.HBBLKREQ.POS> NE 'NO' THEN
            Y.ACCT = '' ; Y.CRACCT.FLG = ''
            Y.DR.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
            Y.ACCT = Y.DR.ACCOUNT
            GOSUB READ.ACCOUNT
            IF NOT(Y.PORT.ID) THEN
                Y.CR.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
                Y.ACCT = Y.CR.ACCOUNT
                Y.CRACCT.FLG = 1
                GOSUB READ.ACCOUNT
            END
      
            R.SEC.ACC.MASTER = '' ; SM.ERR = ''
            CALL F.READ(FN.SEC.ACC.MASTER,Y.PORT.ID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,SM.ERR)
            IF R.SEC.ACC.MASTER THEN
                GOSUB RAISE.ERR.MSG
            END
        END
    END
    
*
RETURN
*** </region>

*-----------------------------------------------------------------------------
*** <region name= RAISE.ERR.MSG>
RAISE.ERR.MSG:
*** <desc>Raise error msg </desc>
    
    Y.SM.BLK.ID.ARR = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.SM.BLKID.POS>
    CHANGE VM TO FM IN Y.SM.BLK.ID.ARR
    Y.SM.BLKID.ARR.CNT = DCOUNT(Y.SM.BLK.ID.ARR,FM)
    Y.LOOP=1
    LOOP
    WHILE Y.LOOP LE Y.SM.BLKID.ARR.CNT
        Y.SM.BLK.ID = Y.SM.BLK.ID.ARR<Y.LOOP>
        Y.POS = '' ; Y.BLK.ID.VAL = ''
        LOCATE Y.SM.BLK.ID IN Y.BLK.ID.ARR<1,1> SETTING Y.POS THEN
            Y.BLK.ID.VAL = Y.BLK.ID.ARR<1,Y.POS>
            IF Y.CRACCT.FLG THEN
                AF = FT.CREDIT.ACCT.NO
            END ELSE
                AF = FT.DEBIT.ACCT.NO
            END
            E =Y.BLK.ID.VAL
            V$ERROR = 1
            MESSAGE = "ERROR"
            CALL ERR
            RETURN
        END
        Y.LOOP+=1
    REPEAT
*
RETURN
*** </region>
*-----------------------------------------------------------------------------
*** <region name= READ.ACCOUNT>
READ.ACCOUNT:
*** <desc>Read get Account details </desc>

    R.ACCOUNT = '' ; ACC.ERR = '' ; Y.PORT.ID = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT,R.ACCOUNT,F.ACCOUNT,ACC.ERR)
    IF R.ACCOUNT THEN
        Y.PORT.ID = R.ACCOUNT<AC.PORTFOLIO.NO,1>
    END
 
RETURN
*** </region>

*-----------------------------------------------------------------------------
*** <region name= GET.GEN.PARAM.DETAILS>
GET.GEN.PARAM.DETAILS:
*** <desc>Read Generic param table and extract SUB.ASSET.TYPE values </desc>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'JBWW.D.FT.AUTHHRDBLK',REC.GEN.PARAM,F.JBWW.H.EB.GENERICPARAMETER,GEN.ERR)
    IF REC.GEN.PARAM THEN
        FIELD.NAMES = REC.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        
        TXN.POS = ''
        LOCATE 'TRANSACTION.TYPE' IN FIELD.NAMES<1,1> SETTING TXN.POS THEN
            Y.TXN.TYPES = REC.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,TXN.POS>
            CHANGE SM TO VM IN Y.TXN.TYPES
        END
    
        CURR.POS = ''
        LOCATE 'CURR.NO' IN FIELD.NAMES<1,1> SETTING CURR.POS THEN
            Y.CURR.NO.VAL = REC.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,CURR.POS>
        END
    
        HBBLK.POS = ''
        LOCATE 'L.XX.HBBLK.REQ' IN FIELD.NAMES<1,1> SETTING HBBLK.POS THEN
            Y.HBBLK.VAL = REC.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,HBBLK.POS>
        END
    
        BLK.ID.POS = ''
        LOCATE 'L.XX.TAG.BLK.ID' IN FIELD.NAMES<1,1> SETTING BLK.ID.POS THEN
            Y.BLK.ID.ARR = REC.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,BLK.ID.POS>
            CHANGE SM TO VM IN Y.BLK.ID.ARR
        END
        
    END


*
RETURN
*** </region>

END
