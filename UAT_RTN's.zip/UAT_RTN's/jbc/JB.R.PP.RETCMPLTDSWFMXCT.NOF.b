SUBROUTINE JB.R.PP.RETCMPLTDSWFMXCT.NOF(OUT.ARR)
*-------------------------------------------------------------------------------------
* This a NoFile enquiry to display Completed Swift Transaction to Initiate 
* Return Transfer. Core API used to get list of eligible transactions and
* added BackOffice User Comments in the list for display.
*-------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------
** Date         Developer       Reference       Description
* 26-JUN-2024   Prabhu D S      CBPAY-64        Initial Draft
*-------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO

    GOSUB INIT
    GOSUB PROCESS

RETURN

*****
INIT:
*****

    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    FV.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)
    
    OUT.ARR = ''
    Y.ENQ.DATA = ''
    OUT.POS = ''
    Y.FT.NONO = ''
    BP.POS = ''
    PORS.ERR = ''
    R.POR.SUPPL.INFO.REC = ''
    

RETURN

********
PROCESS:
********    

    CALL E.NOFILE.PP.RETURN.COMPLETED.SWIFT.CT(OUT.ARRAY)

    IF OUT.ARRAY THEN
    
        LOOP
            READNEXT Y.ENQ.DATA FROM OUT.ARRAY SETTING OUT.POS
        WHILE Y.ENQ.DATA
            Y.FT.NO = FIELD(Y.ENQ.DATA,"*",1)
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            IF R.POR.SUPPL.INFO.REC THEN
                LOCATE "L.PP.BP.HISTCOM" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                    Y.BP.HISTCOM = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                END ELSE
                    Y.BP.HISTCOM = ''
                END
                OUT.ARR<-1> = Y.ENQ.DATA:"*":Y.BP.HISTCOM
            END
        REPEAT

    END
RETURN

END



