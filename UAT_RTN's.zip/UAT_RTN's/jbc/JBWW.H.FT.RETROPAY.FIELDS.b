* @ValidationCode : MTo5ODcxMDE5NjY6SVNPLTg4NTktMToxNDkzODAxOTUwODE3OmEzODk2MDotMTotMTowOjA6dHJ1ZTpOL0E6REVWXzIwMTYwOC4w
* @ValidationInfo : Timestamp         : 03 May 2017 16:59:10
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : true
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.H.FT.RETROPAY.FIELDS
*-----------------------------------------------------------------------------
* Table definition of JBWW.H.FT.RETROPAY
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date          who             Reference        Descrition of Change
* 
* 05-08-2016    Tony Charles    CALCULO          Fields of JBWW.H.FT.RETROPAY 
*
* 03-05-2017 - NS Enabled
* 22-12-2023    Maheswari MS    T24-19368        Field length changed from 70 to 50 for ADD.BO.REMARKS field
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
    
    C$NS.OPERATION = 'ALL' ;* Table enabled with NS Processing to capture the calculo messages trigerred while COB.
    
    ID.F = 'PAYM.ID' ;* Dynamically generated unique ID
    ID.T = 'ANY'
    ID.N = '16.1' 
    
*-----------------------------------------------------------------------------
    fieldName = 'XX.T24.TXN.REF.ID'
    fieldLength = '16'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'TECH.STATUS'
    fieldLength = '18'
    fieldType = 'A'
    neighbour = '' 
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'ADD.COMMENTS'
    fieldLength = '70'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'DATE.RECEIVED'
    fieldLength = '8'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'TIME.RECEIVED'
    fieldLength = '8'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'DATE.BOOKED'
    fieldLength = '8'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'TIME.BOOKED'
    fieldLength = '8'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'DATE.AUTH'
    fieldLength = '8'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'TIME.AUTH'
    fieldLength = '8'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field  

    fieldName = 'RECORD.TYPE'
    fieldLength = '3'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'TRN.NBR'
    fieldLength = '15'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'TRN.NBR.ORIGINAL'
    fieldLength = '15'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ENTRY.DATE'
    fieldLength = '20'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ENTRY.TIME'
    fieldLength = '20'
    fieldType = ''
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ENTRY.USER'
    fieldLength = '6'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'AMOUNT'
    fieldLength = '15'
    fieldType = 'AMT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ORDER.DATE'
    fieldLength = '8'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'VALUE.DATE'
    fieldLength = '8'
    fieldType = 'D'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'CCY'
    fieldLength = '3'
    fieldType = 'CCY'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    CALL Field.setCheckFile('CURRENCY')

    fieldName = 'T24.CCY.CODE'
    fieldLength = '5'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'BEN.NAME'
    fieldLength = '70'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'PAYMENT.TYPE'
    fieldLength = '2'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

*    fieldName = 'T24.TRN.TYPE'
*    fieldLength = '6'
*    fieldType = 'A'
*    neighbour = ''
*    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

*    fieldName = 'RETRO.PAYMENT.TEXT'
*    fieldLength = '20'
*    fieldType = 'A'
*    neighbour = ''
*    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'BOOKING.TEXT'
    fieldLength = '70'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'DOK.ID'
    fieldLength = '35'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'SWIFT.CODE'
    fieldLength = '20'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'SWIFT.T24.CUST.NO'
    fieldLength = '15'
    fieldType = 'CUS'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'BEN.ACCOUNT'
    fieldLength = '50'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'GROSS.AMOUNT'
    fieldLength = '10'
    fieldType = 'AMT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'GST.AMOUNT'
    fieldLength = '10'
    fieldType = 'AMT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'COST.CENTER'
    fieldLength = '20'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field    

    fieldName = 'PARTNER.ACCOUNT'
    fieldLength = '30'
    fieldType = 'ANT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'CREDIT.ACCOUNT'
    fieldLength = '30'
    fieldType = 'ANT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'PAY.INSTRUCTION'
    fieldLength = '70'
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ERROR.TEXT'
    fieldLength = '100'
    fieldType = 'TEXT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

*    CALL Table.addField("ERROR.TEXT", T24_Text, "", "")

    fieldName = 'PROCESSING.STATUS'
    fieldLength = '8'
    fieldType = ''
    fieldType<2> = '_CONFIRM_AMEND_CANCEL'
    fieldType<3> = ''
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'ADD.BO.REMARKS'
*T24-19368-S
    *fieldLength = '70'
    fieldLength = '50'
*T25-19368-E
    fieldType = 'A'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.10'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'RESERVED.9'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'RESERVED.8'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'RESERVED.7'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
    
    fieldName = 'RESERVED.6'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.5'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.4'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.3'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.2'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field

    fieldName = 'RESERVED.1'
    fieldLength = '35'
    fieldType = 'ANY'
    fieldType<3> = 'NOINPUT'
    neighbour = ''
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour) ;* Add a new field
      
*-----------------------------------------------------------------------------
    CALL Table.setAuditPosition ;* Poputale audit information
*-----------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
END
