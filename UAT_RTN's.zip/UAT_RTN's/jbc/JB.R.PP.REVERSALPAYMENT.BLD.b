SUBROUTINE JB.R.PP.REVERSALPAYMENT.BLD(ENQ.DATA)

*--------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 26-FEB-2025   Vikram Pavuluru                        CBPAY-1741             To Display records based on user group.
*
* 04-APR-2025   Vikram Pavuluru                        CBPAY-2247             Modified logic to display records based on company.
*
* 26-MAY-2025   Vikram Pavuluru                        CBPAY-2883&            Modified the Logic to display records based on company & user roles.
*                                                      CBPAY-2885&
*                                                      CBPAY-2937
*
* Description : Routine to List all the payments based on Reversal of payments.
* Attached to : ENQUIRY>JB.E.PP.REVERSEAUTHORREJECT
* Attached as : BUILD.ROUTINE
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    
    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS


RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **

    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)
    
RETURN


*****************
GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
 
    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END

RETURN

********
PROCESS:
********
    Y.REC.ID = ENQ.DATA<4,1>
 
    BEGIN CASE

        CASE Y.REC.ID EQ ''
            GOSUB FORM.SEL.LIST1
        CASE Y.REC.ID
            GOSUB FORM.SEL.LIST2

    END CASE
    
RETURN

***************
FORM.SEL.LIST1:
***************
*When user does not provide any FT Number in selection

    SEL.CMD1 = "SELECT ":FN.POR.TRANSACTION:" WITH StatusCode EQ '980' AND WITH CompanyID EQ ":Y.COMP.ID
    CALL EB.READLIST(SEL.CMD1,SEL.LIST1,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST1 EQ '' THEN
        ENQ.ERROR = "No records found to display"
    END ELSE
        LOOP
            REMOVE SEL.ID FROM SEL.LIST1 SETTING SEL.POS
        WHILE SEL.ID : SEL.POS
            Y.FT.NO = SEL.ID
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FV.POR.TRANSACTION,PORT.ERR)
            IF R.POR.TRANSACTION.REC THEN
                LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                    Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                    IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                        Y.FNL.SEL.LIST =  SEL.ID
                        ENQ.DATA<2,-1> = '@ID'
                        ENQ.DATA<3,-1> = 'EQ'
                        ENQ.DATA<4,-1> =  Y.FNL.SEL.LIST
                    END
                END
            END
        
        REPEAT

    END
     
RETURN

****************
FORM.SEL.LIST2:
****************

**When user provides FT Number in selection

    SEL.CMD2 = "SELECT ":FN.POR.TRANSACTION:" WITH StatusCode EQ '980' AND WITH FTNumber EQ ":Y.REC.ID:" AND WITH CompanyID EQ ":Y.COMP.ID
    CALL EB.READLIST(SEL.CMD2,SEL.LIST2,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST2 EQ '' THEN
        ENQ.ERROR = "No records found to display"
    END ELSE
        CHANGE FM TO ' ' IN SEL.LIST2
        CALL F.READ(FN.POR.SUPPL.INFO,Y.REC.ID,R.SUPP.REC,F.POR.SUPPL.INFO,'')
        CALL F.READ(FN.POR.TRANSACTION,Y.REC.ID,R.POR.TRANSACTION,F.POR.TRANSACTION,'')
        Y.LOC.FIELD.NAME = R.SUPP.REC<PORID.LOC.FIELD.NAME>
        LOCATE 'L.PO.USR.GRP' IN Y.LOC.FIELD.NAME<1,1> SETTING Y.POS THEN
            Y.LOC.FIELD.VALUE = R.SUPP.REC<PORID.LOC.FIELD.VALUE,Y.POS>
            IF Y.LOC.FIELD.VALUE EQ Y.USR.GRP THEN
                Y.FNL.SEL.LIST =  SEL.LIST2
                ENQ.DATA<2,1> = '@ID'
                ENQ.DATA<3,1> = 'EQ'
                ENQ.DATA<4,1> =  Y.FNL.SEL.LIST
            END ELSE
                ENQ.DATA<2,1> = '@ID'
                ENQ.DATA<3,1> = 'EQ'
                ENQ.DATA<4,1> =  ""
            END
        END
    END

RETURN

**********************************************************************************************
END
