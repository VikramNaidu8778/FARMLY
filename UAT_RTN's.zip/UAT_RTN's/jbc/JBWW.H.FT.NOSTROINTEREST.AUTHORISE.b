* @ValidationCode : MjoxMDQzMjg3ODc6Q3AxMjUyOjE3MTM3ODQwNzAzNDI6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 12 May 2024 16:37:50
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*--------------------------------------------------------------------------------
SUBROUTINE JBWW.H.FT.NOSTROINTEREST.AUTHORISE
*--------------------------------------------------------------------------------
**
*--------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------
* Date            Developer                      Reference                                       Description
* 04/01/2017                                    JB2A-24865                      Teena JB2A-24865 Duplicate FT is generated.
* 06/02/2017                                    JB2A-24117                      Sushmitha JB2A-24117 FT isn not displayed in veiw mode
* 04/09/2017                                    JB2A-22896                      Mahesh J JB2A-22896 IF condition used instead of BEGIN for generating OFS message.
*                                                                               Now if the transaction type credit & Debit , the FT will generate for both
* 14/05/2018                                    JB2A-52069                      Lakshmanan JB2A-52069 Credit customer obtained from account table and *                                                                               PROFIT.CENTRE.DEPT commented
* 13/05/2024      Hariharan T                   CBPAY-51                        Converted FT logic to PAYMENT.ORDER Logic.
* 18/05/2025     Lakshmi Priya                  CBPAY - 3379                    Changing the mapping from L.FT.BO.REMARK to L.PP.BO.USRCOM for the field Remark (L.FT.BO.REMARK)
*-----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_GTS.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.JBWW.H.FT.NOSTROINTEREST
    $INSERT I_F.ACCOUNT
    $INSERT I_F.PAYMENT.ORDER
    $USING PI.Contract
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
RETURN
*-------------------------------------------------------------------------------
INITIALISE:
***********

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    APPLN.NAME = "PAYMENT.ORDER"
    FLD.NAME = "L.PP.BO.USRCOM"
    FLD.POS = ''
    CALL GET.LOC.REF(APPLN.NAME,FLD.NAME,FLD.POS)

    FT.BO.RMRK.POS = FLD.POS<1,1>

    R.GEN.PR.REC=''
    GP.ERR.MSG=''
    Y.PO.REC=''
    Y.REQ=''
    Y.RES=''
    Y.D.TOT=''
    Y.PL.ACC=''
    FINAL.OFS.MSG=''

RETURN
*-------------------------------------------------------------------------------
 
PROCESS:
********

    GOSUB FETCH.GENERICPARAM
   
    OFS$SOURCE.ID=Y.OFS.SOURCE

**********Fix for JIRA 13626**************
    Y.PL.ACC = R.NEW(JB.NOSINT.L.FT.PL.ACC)

    Y.D.TOT = DCOUNT(Y.PL.ACC,VM)
    Y.D.CNT = 1

    LOOP
    WHILE Y.D.CNT LE Y.D.TOT
        Y.PO.REC = ""

*BEGIN CASE

        IF R.NEW(JB.NOSINT.L.FT.NOSINT.TYPE)<1,Y.D.CNT> EQ 'DEBIT' THEN

            Y.PO.REC<PO.PAYMENT.ORDER.PRODUCT> = "ACIN"
            Y.PO.REC<PO.CREDIT.PL> = R.NEW(JB.NOSINT.L.FT.PL.ACC)<1,Y.D.CNT>
*Y.PO.REC<PO.CREDIT.ACCOUNT> = "PL":R.NEW(JB.NOSINT.L.FT.PL.ACC)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.ACCOUNT> = R.NEW(JB.NOSINT.L.FT.NOST.ACC)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.AMOUNT> = R.NEW(JB.NOSINT.L.FT.AMOUNT)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.CCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
            Y.PO.REC<PO.ORDERING.REFERENCE> = ID.NEW
            Y.PO.REC<PO.ADDITIONAL.INFO> = Y.D.CNT
            Y.PO.REC<PO.CREDIT.CURRENCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.VALUE.DATE> = R.NEW(JB.NOSINT.L.FT.VALUE.DATE)<1,Y.D.CNT>
            Y.PO.REC<PO.CREDIT.VALUE.DATE> = R.NEW(JB.NOSINT.L.FT.VALUE.DATE)<1,Y.D.CNT>
            Y.PO.REC<PO.LOCAL.REF,FT.BO.RMRK.POS> = R.NEW(JB.NOSINT.L.FT.BO.REMARK)<1,Y.D.CNT>
            Y.PO.REC<PO.PAYMENT.AMOUNT> = R.NEW(JB.NOSINT.L.FT.AMOUNT)<1,Y.D.CNT>
            Y.PO.REC<PO.PAYMENT.CURRENCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
        
        
* Y.PO.REC<FT.PROFIT.CENTRE.DEPT> = "1"
*Y.PO.REC<FT.ORDERING.BANK> = "BNK"
*********** JB2A-23191*****************
*Y.PO.REC<FT.COMMISSION.CODE> = "WAIVE"
*Y.PO.REC<FT.CHARGE.CODE> = "WAIVE"
*********** JB2A-23191*****************
        END

        IF R.NEW(JB.NOSINT.L.FT.NOSINT.TYPE)<1,Y.D.CNT> EQ 'CREDIT' THEN

            Y.PO.REC<PO.PAYMENT.ORDER.PRODUCT> = "ACIN"
            Y.PO.REC<PO.CREDIT.ACCOUNT> = R.NEW(JB.NOSINT.L.FT.NOST.ACC)<1,Y.D.CNT>
            R.ACC.REC = ''
 Y.PO.REC<PI.Contract.PaymentOrder.PoCustomerForPL> = ''
            CALL F.READ(FN.ACCOUNT,R.NEW(JB.NOSINT.L.FT.NOST.ACC)<1,Y.D.CNT>,R.ACC.REC,F.ACCOUNT,ACC.ERR)
IF R.ACC.REC THEN
   Y.PO.REC<PI.Contract.PaymentOrder.PoCustomerForPL> = R.ACC.REC<AC.CUSTOMER>
END
            Y.PO.REC<PO.DEBIT.PL> = R.NEW(JB.NOSINT.L.FT.PL.ACC)<1,Y.D.CNT>
*Y.PO.REC<PO.DEBIT.ACCOUNT> = "PL":R.NEW(JB.NOSINT.L.FT.PL.ACC)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.AMOUNT> = R.NEW(JB.NOSINT.L.FT.AMOUNT)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.CCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
            Y.PO.REC<PO.ORDERING.REFERENCE> = ID.NEW
            Y.PO.REC<PO.ADDITIONAL.INFO> = Y.D.CNT
            Y.PO.REC<PO.CREDIT.CURRENCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
            Y.PO.REC<PO.DEBIT.VALUE.DATE> = R.NEW(JB.NOSINT.L.FT.VALUE.DATE)<1,Y.D.CNT>
            Y.PO.REC<PO.CREDIT.VALUE.DATE> = R.NEW(JB.NOSINT.L.FT.VALUE.DATE)<1,Y.D.CNT>
            Y.PO.REC<PO.LOCAL.REF,FT.BO.RMRK.POS> = R.NEW(JB.NOSINT.L.FT.BO.REMARK)<1,Y.D.CNT>
            Y.PO.REC<PO.PAYMENT.AMOUNT> = R.NEW(JB.NOSINT.L.FT.AMOUNT)<1,Y.D.CNT>
            Y.PO.REC<PO.PAYMENT.CURRENCY> = R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,Y.D.CNT>
* Y.PO.REC<FT.PROFIT.CENTRE.DEPT> = "1"
*Y.PO.REC<FT.ORDERING.BANK> = "BNK"
*********** JB2A-23191*****************
*Y.PO.REC<FT.COMMISSION.CODE> = "WAIVE"
*Y.PO.REC<FT.CHARGE.CODE> = "WAIVE"
*********** JB2A-23191*****************

        END

        Y.OFS.PROCESS = "PROCESS"
        Y.OFS.APP.NAME = "PAYMENT.ORDER"
        Y.OFS.INPUT.FUN = "I"
        Y.OFS.VERSION = Y.VERSION
        Y.TRANSACTION.ID = ""
        R.PO.REC = Y.PO.REC
       
        CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.INPUT.FUN,Y.OFS.PROCESS,Y.OFS.VERSION,'','',Y.TRANSACTION.ID,R.PO.REC,Y.OFS.RESPONSE)
*CALL OFS.POST.MESSAGE(Y.OFS.RESPONSE,Y.RET.OFS.MSG,Y.OFS.SOURCE,'')
***JB2A-24117***
        IF FINAL.OFS.MSG EQ '' THEN
            FINAL.OFS.MSG = Y.OFS.RESPONSE
        END ELSE
            FINAL.OFS.MSG = FINAL.OFS.MSG:FM:Y.OFS.RESPONSE
***JB2A-24117***
        END


        Y.D.CNT++

    REPEAT
***JB2A-24117***
  
    CALL OFS.POST.MESSAGE(FINAL.OFS.MSG,Y.RET.OFS.MSG,Y.OFS.SOURCE,'')
RETURN
*-------------------------------------------------------------------------------
FETCH.GENERICPARAM:
**********************

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.NOSTRO.INTEREST",R.GEN.PR.REC,F.JBWW.H.EB.GENERICPARAMETER,GP.ERR.MSG)

    JBWW.GEN.PAR.FN = R.GEN.PR.REC<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE "OFS.SOURCE" IN JBWW.GEN.PAR.FN<1,1> SETTING FN.POS THEN
       Y.OFS.SOURCE = R.GEN.PR.REC<JBWW.GEN.PAR.FIELD.VALUE,FN.POS,1>
    END

    LOCATE "VERSION" IN JBWW.GEN.PAR.FN<1,1> SETTING FN.POS THEN
        Y.VERSION = R.GEN.PR.REC<JBWW.GEN.PAR.FIELD.VALUE,FN.POS,1>
    END

RETURN
*-------------------------------------------------------------------------------
END
