* @ValidationCode : MToxOTE0NTk4NjA6SVNPLTg4NTktMToxNTM3MjQ2Mzc0NjYzOnU0MDc3MDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 09 Dec 2024 12:52:54
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : u40228
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JB.R.XX.RDCBGETCITY.CONV
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* Conversion routine to read RD.BIC.CONCAT and get the RD.CENTRAL.BANK.DIR Id to display city name.
*
*----------------------------------------------------------------------------------------------------------------
* Attached: Conversion routine in Enquiry > JBWW.E.FT.CIDDATAPAGE.EXTRACT
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date              Developer             Reference           Description
* 6-Jan-2025        P Amala               CBGBB-16996         Extracting BIC ID from RD.BIC.CONCAT file to display the city name.
*
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.HEADER
    $INSERT I_DFE.FRAME.WORK.COMMON
    $INSERT I_F.RD.CENTRAL.BANK.DIR
    $INSERT I_F.RD.BIC.CONCAT
	$INSERT I_ENQUIRY.COMMON
*-----------------------------------------------------------------------------

    GOSUB OPENFILES
    GOSUB PROCESS

RETURN
OPENFILES:
**********

    FN.RD.BIC.CONCAT = 'F.RD.BIC.CONCAT'
    F.RD.BIC.CONCAT = ''
    CALL OPF(FN.RD.BIC.CONCAT,F.RD.BIC.CONCAT)
    
    FN.RD.CENTRAL.BANK.DIR = 'F.RD.CENTRAL.BANK.DIR'
    F.RD.CENTRAL.BANK.DIR = ''
    CALL OPF(FN.RD.CENTRAL.BANK.DIR,F.RD.CENTRAL.BANK.DIR)
    
    R.RD.BIC.CONCAT = '' ; RD.BIC.CONCAT.ER = '' ; RD.BIC.ID = ''
    Y.RD.INST = '' ; FINAL.ARRAY = '' ; Y.INST.CNT = ''
    
RETURN
PROCESS:
********
    RD.BIC.ID = O.DATA
    IF RD.BIC.ID THEN
        CALL F.READ(FN.RD.BIC.CONCAT,RD.BIC.ID,R.RD.BIC.CONCAT,F.RD.BIC.CONCAT,RD.BIC.CONCAT.ERR)
        IF R.RD.BIC.CONCAT THEN
            BEGIN CASE
                CASE R.RD.BIC.CONCAT<RD.BC.MASTER.KEY> NE ''
                    Y.RD.BIC.ID = R.RD.BIC.CONCAT<RD.BC.MASTER.KEY>
                CASE R.RD.BIC.CONCAT<RD.BC.CUS.KEY> NE ''
                    Y.RD.BIC.ID = R.RD.BIC.CONCAT<RD.BC.CUS.KEY>
                CASE R.RD.BIC.CONCAT<RD.BC.FUT.KEY> NE ''
                    Y.RD.BIC.ID = R.RD.BIC.CONCAT<RD.BC.FUT.KEY>
            END CASE
        END
        IF Y.RD.BIC.ID THEN
            CALL F.READ (FN.RD.CENTRAL.BANK.DIR,Y.RD.BIC.ID,R.RD.BIC,F.RD.CENTRAL.BANK.DIR,RD.ERR)
            O.DATA = R.RD.BIC<RD.CBD.CITY>
        END
    END
RETURN
END