  SUBROUTINE JBWW.B.FT.BALANCETRANSFER.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 2018-11-21         Balakrishnan K          Account balance maintaining as zero for the all the accounts belongs to the category 14183.
* 2018-11-22		 Balaji 				 Parameterising the mapping values
* 2018-11-28         Balakrishnan K          DAY15-5219-Category account selected directly from account table instead of CATEG.INT.ACCT
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_BATCH.FILES
	$INSERT I_BALANCETRANSFER.COMMON
*	$INSERT I_F.CATEG.INT.ACCT
		
*-----------------------------------------------------------------------------
	
	Y.FM.CHAR = CHAR(251)
	V.FN.ACCOUNT = FN.ACCOUNT
	V.TAFJ.AC.SEL = "SELECT ORCLFILENAME FROM TAFJ_VOC WHERE RECID ='":V.FN.ACCOUNT:"'"
	
	V.TAFJ.AC.VIEW.ID = EXECSQLQUERY(1,V.TAFJ.AC.SEL)
    CONVERT Y.FM.CHAR TO FM IN V.TAFJ.AC.VIEW.ID
	
	SEL.CMD = "SELECT RECID FROM V_":V.TAFJ.AC.VIEW.ID:" WHERE CATEGORY = ":Y.CATEG.CODE
	SEL.LIST = EXECSQLQUERY(1,SEL.CMD)
    CONVERT Y.FM.CHAR TO FM IN SEL.LIST
	
	LIST.PARAMETER=''
	 
	CALL BATCH.BUILD.LIST(LIST.PARAMETER, SEL.LIST)
 
 RETURN
*----------------------------------------------------------------------------- 

END


