SUBROUTINE JB.R.PP.REMITINFO.CONV
*-----------------------------------------------------------------------------
* Attached as Conversion Routine>JB.E.PP.REMITINFO.REGREPORT
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*
*16-Apr-2025     Resmi R            CBPAY-2076         Conversion routine to fetch values for the specified fields
*16-Jun-2025     Resmi R            CBPAY-2076         Included the logic to handle additional contra payment which is booked against IT for inward cover payment return
*17-Jun-2025     Resmi R            CBPAY-3375         Linked Transaction Code should be empty for Reject Transaction (IRRJ).Also Linked Transaction ID (Return)& Link Transaction Code (Return) must be empty
*17-Jun-2025     Resmi R            CBPAY-3374         PaymentOrder Reference Mapping changed from SenderReferenceIncoming to FileReferenceIncoming
*20-Jun-2025     Prabhu D S         CBPAY-3376         Transaction Code not populated correctly
*30-Jun-2025     Lakshmi Priya      CBPAY-3465         Included logic to default Cover Flag 'Y' for outgoing and incoming cover payments.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.AC.EXPECTED.RECS
    $INSERT I_F.PP.ORDER.ENTRY

 
    GOSUB INIT
     
RETURN

******
INIT:
*****

    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)
    
    FN.POR.SUPPLEMENTARY.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, F.POR.SUPPLEMENTARY.INFO)
    
    FN.AC.EXPECTED.RECS.HIS = "F.AC.EXPECTED.RECS$HIS"
    F.AC.EXPECTED.RECS.HIS = ''
    CALL OPF(FN.AC.EXPECTED.RECS.HIS, F.AC.EXPECTED.RECS.HIS)
 
    FN.AC.EXPECTED.RECS = "F.AC.EXPECTED.RECS"
    F.AC.EXPECTED.RECS = ''
    CALL OPF(FN.AC.EXPECTED.RECS, F.AC.EXPECTED.RECS)

    FN.PP.ORDER.ENTRY = "F.PP.ORDER.ENTRY"
    F.PP.ORDER.ENTRY = ""
    CALL OPF(FN.PP.ORDER.ENTRY, F.PP.ORDER.ENTRY)

    FN.PP.ORDER.ENTRY.HIS = "F.PP.ORDER.ENTRY$HIS"
    F.PP.ORDER.ENTRY.HIS = ""
    CALL OPF(FN.PP.ORDER.ENTRY.HIS, F.PP.ORDER.ENTRY.HIS)
    

    LOC.FLD.POS = ""
    CALL MULTI.GET.LOC.REF("PP.ORDER.ENTRY","L.PP.DEF.INW.IT",LOC.FLD.POS)
 
    Y.DATA = O.DATA
    Y.FT.ID = FIELD(Y.DATA, "*",1)
    Y.DATA.VAL = FIELD(Y.DATA, "*",2)

    IF Y.FT.ID EQ '' THEN
        O.DATA = ''
    END ELSE
        GOSUB CHECK.VAL
    END
    
RETURN
 
***********
CHECK.VAL:
***********

    BEGIN CASE
              
        CASE Y.DATA.VAL EQ "POR"
            GOSUB FETCH.PAYMT.ORD.REF

        CASE Y.DATA.VAL EQ "RTID"
            GOSUB FETCH.RELATED.TXN.ID

        CASE Y.DATA.VAL EQ "ORIGRTID"
            GOSUB FETCH.ORIG.RETURN.ID
        
        CASE (Y.DATA.VAL EQ 'TC') OR (Y.DATA.VAL EQ 'RELTXNCD') OR (Y.DATA.VAL EQ 'LNKTXCD') OR (Y.DATA.VAL EQ 'LNKTXCDRJ')
            GOSUB FETCH.TXN.CODE.VALUE
                
        CASE Y.DATA.VAL EQ 'INTMBK'
            GOSUB FETCH.INTERM.BNK.BIC

        CASE Y.DATA.VAL EQ 'RCVRSNDR'
            GOSUB FETCH.RCVR.SNDR.BIC
                        
        CASE Y.DATA.VAL EQ "COVFLAG"
            GOSUB FETCH.COVER.PAYMENT
           
    END CASE


RETURN

********************
FETCH.COVER.PAYMENT:
********************

    GOSUB READ.POR.TRANSACTION
    GOSUB READ.POR.SUPPLEMENTARY.INFO
    

    LOCATE "L.PP.DEF.INW.IT" IN Y.POR.LOC.FLD.NAMES<1,1> SETTING LOC.POS THEN
        Y.LOC.VALUE = Y.POR.LOC.FLD.VALUES<1,LOC.POS>
    END

    BEGIN CASE

        CASE (Y.COVER.FLAG EQ "Y") OR (Y.VALIDATION.FLAG EQ "COV") OR (Y.SETLMTD EQ "Y")
            O.DATA = "Y"

        CASE OTHERWISE
            O.DATA = ""

    END CASE
  
RETURN

*********************
FETCH.ORIG.RETURN.ID:
*********************
    GOSUB READ.POR.TRANSACTION
    GOSUB READ.POR.SUPPLEMENTARY.INFO

    BEGIN CASE
    
        CASE Y.CLRG.TXN.TYPE EQ "RJ" OR NOT(R.POR.SUPPL.INFO)
         
            O.DATA = ''

        CASE OTHERWISE
            O.DATA = R.POR.SUPPL.INFO<PORID.ORIGINAL.OR.RETURN.ID>

    END CASE

RETURN

*********************
FETCH.PAYMT.ORD.REF:
*********************

    GOSUB READ.POR.TRANSACTION

    BEGIN CASE
       
        CASE (Y.OUT.MSG.TYPE EQ "pacs.004") AND (Y.CTRBTR.IND EQ "B")
            O.DATA = ''
      
        CASE (Y.PMT.DIR EQ "O") OR (Y.PMT.DIR EQ "B") OR (Y.PMT.DIR EQ "R")
            IF R.POR.TRANSACTION<PPPTX.FileSendersReference>[1,2] EQ 'PI' THEN
                O.DATA = R.POR.TRANSACTION<PPPTX.FileSendersReference>
            END ELSE
                O.DATA = ''
            END
    
        CASE Y.PMT.DIR EQ "I"
            O.DATA = ''

        CASE OTHERWISE
            O.DATA = ''

    END CASE

RETURN
       
*********************
FETCH.TXN.CODE.VALUE:
*********************

    GOSUB READ.POR.TRANSACTION
    GOSUB READ.POR.SUPPLEMENTARY.INFO
    IF Y.ORIG.SRC MATCHES "POA":@VM:"MXCHATS"@VM:"STO":@VM:"STOMXCHATS" THEN
       O.DATA = R.POR.TRANSACTION<PPPTX.IncomingMessageType>
    END ELSE
      LOCATE "L.PP.DEF.INW.IT" IN Y.POR.LOC.FLD.NAMES<1,1> SETTING LOC.POS THEN
          O.DATA = Y.POR.LOC.FLD.VALUES<1,LOC.POS>
      END ELSE
          IF R.POR.SUPPL.INFO<PORID.ORDER.ENTRY.ID> THEN
              OE.ID = R.POR.SUPPL.INFO<PORID.ORDER.ENTRY.ID>
              GOSUB READ.ORDER.ENTRY
          END
      END
    END

RETURN

*********************
FETCH.RELATED.TXN.ID:
*********************
DEBUG
    GOSUB READ.POR.TRANSACTION

    IF Y.OUT.MSG.TYPE EQ "pacs.004" THEN
        Y.FT.ID = Y.TRNS.REF.INC
        GOSUB READ.POR.SUPPLEMENTARY.INFO
    END ELSE
        GOSUB READ.POR.SUPPLEMENTARY.INFO
    END
    
    LOCATE "L.PP.DEF.INW.IT" IN Y.POR.LOC.FLD.NAMES<1,1> SETTING LOC.POS THEN
        Y.DEF.VAL = Y.POR.LOC.FLD.VALUES<1,LOC.POS>
    
        BEGIN CASE

            CASE (Y.DEF.VAL EQ 'ITCV') OR (Y.DEF.VAL EQ 'IT')
                Y.ACER.MATCHED.ID = R.POR.SUPPL.INFO<PORID.ACER.MATCHED.ID>
                CALL F.READ(FN.AC.EXPECTECD.RECS,Y.ACER.MATCHED.ID,R.AC.EXCEP.RECS,F.AC.EXPECTED.RECS,ERR.ACER)
                IF R.AC.EXCEP.RECS THEN
                    O.DATA = R.AC.EXCEP.RECS<AC.EXP.TRAN.REFERENCE>
                END ELSE
                    Y.ACER.MATCHED.ID = Y.ACER.MATCHED.ID:";1"
                    CALL F.READ(FN.AC.EXPECTED.RECS.HIS,Y.ACER.MATCHED.ID,R.AC.EXCEP.RECS,F.AC.EXPECTED.RECS.HIS,ERR.ACER)
                    O.DATA = R.AC.EXCEP.RECS<AC.EXP.TRAN.REFERENCE>
                END
               
            CASE OTHERWISE
                O.DATA = ''
    
        END CASE

    END ELSE

        LOCATE "L.PP.ORIG.REF" IN Y.POR.LOC.FLD.NAMES<1,1> SETTING ORIGREF.POS THEN
            O.DATA = Y.POR.LOC.FLD.VALUES<1,ORIGREF.POS>
        END ELSE
            O.DATA = ''
        END


    END
    
RETURN

**********************
FETCH.INTERM.BNK.BIC:
*********************

    GOSUB READ.POR.SUPPLEMENTARY.INFO
        
    LOCATE "INTINS" IN Y.PARTY.ROLE<1,1> SETTING INT.POS THEN
        O.DATA = R.POR.SUPPL.INFO<PORID.PARTY.IDENTIFIER.CODE,INT.POS>
    
    END ELSE
        O.DATA = ''

    END


RETURN

********************
FETCH.RCVR.SNDR.BIC:
********************
    GOSUB READ.POR.TRANSACTION
    GOSUB READ.POR.SUPPLEMENTARY.INFO
    
    BEGIN CASE
        
        CASE Y.PMT.DIR EQ 'I'
           
            LOCATE "SENDER" IN Y.PARTY.ROLE<1,1> SETTING SNDR.POS THEN
                O.DATA = R.POR.SUPPL.INFO<PORID.PARTY.IDENTIFIER.CODE,SNDR.POS>
            END ELSE
        
                LOCATE "SNDCBK" IN Y.PARTY.ROLE<1,1> SETTING CBK.POS THEN
                    O.DATA = R.POR.SUPPL.INFO<PORID.PARTY.IDENTIFIER.CODE,CBK.POS>
                END ELSE
		    O.DATA = ''
		END

            END
            
        CASE Y.PMT.DIR EQ 'O'
            
            LOCATE "RECVER" IN Y.PARTY.ROLE<1,1> SETTING RCVR.POS THEN
                O.DATA = R.POR.SUPPL.INFO<PORID.PARTY.IDENTIFIER.CODE,RCVR.POS>
            END ELSE
        
                LOCATE "BENFCY" IN Y.PARTY.ROLE<1,1> SETTING BFCY.POS THEN
                    O.DATA = R.POR.SUPPL.INFO<PORID.PARTY.IDENTIFIER.CODE,BFCY.POS>
		END ELSE
		    O.DATA = ''

                END

            END
        
        CASE OTHERWISE
         
            O.DATA = ''
    
    END CASE

RETURN


***********************
READ.POR.TRANSACTION:
***********************

    CALL F.READ(FN.POR.TRANSACTION,Y.FT.ID,R.POR.TRANSACTION,F.POR.TRANSACTION,POR.ERR)
    Y.PMT.DIR = R.POR.TRANSACTION<PPPTX.PaymentDirection>
    Y.PORT.STAT.CODE = R.POR.TRANSACTION<PPPTX.StatusCode>
    Y.IN.MSG.TYPE = R.POR.TRANSACTION<PPPTX.IncomingMessageType>
    Y.OUT.MSG.TYPE = R.POR.TRANSACTION<PPPTX.OutgoingMessageType>
    Y.TRNS.REF.INC = R.POR.TRANSACTION<PPPTX.TransactionReferenceIncoming>
    Y.CTRBTR.IND = R.POR.TRANSACTION<PPPTX.CTRBTRIndicator>
    Y.CLRG.TXN.TYPE = R.POR.TRANSACTION<PPPTX.ClearingTransactionType>
    Y.VALIDATION.FLAG = R.POR.TRANSACTION<PPPTX.ValidationFlag>
    Y.COVER.FLAG = R.POR.TRANSACTION<PPPTX.CoverFlag>
    Y.ORIG.SRC = R.POR.TRANSACTION<PPPTX.OriginatingSource>

RETURN

*****************************
READ.POR.SUPPLEMENTARY.INFO:
*****************************

    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.FT.ID,R.POR.SUPPL.INFO,F.POR.SUPPLEMENTARY.INFO,POR.ERR)
    Y.POR.LOC.FLD.NAMES = R.POR.SUPPL.INFO<PORID.LOC.FIELD.NAME>
    Y.POR.LOC.FLD.VALUES = R.POR.SUPPL.INFO<PORID.LOC.FIELD.VALUE>
    Y.PARTY.ROLE =  R.POR.SUPPL.INFO<PORID.PARTY.ROLE>
    Y.WAIT.FOR.COV = R.POR.SUPPL.INFO<PORID.WAIT.FOR.COVER.PAYMENTS>
    Y.COVPAY.RECEIVED = R.POR.SUPPL.INFO<PORID.COVER.PAYMENT.RECEIVED>
    Y.POR.SETLMTD.VALUE = R.POR.SUPPL.INFO<PORID.PI.INSTRUCTION.CODE>
    Y.SETLMTD = ''
    LOCATE "COVE" IN Y.POR.SETLMTD.VALUE<1,1> SETTING SETLMTD.POS THEN
      Y.SETLMTD = "Y"
    END

RETURN

*****************
READ.ORDER.ENTRY:
****************

    CALL F.READ(FN.PP.ORDER.ENTRY,OE.ID,R.ORDER.ENTRY,F.PP.ORDER.ENTRY,OE.RR)
    IF R.ORDER.ENTRY THEN
        O.DATA = R.ORDER.ENTRY<PP.OEYG.LOCAL.REF,LOC.FLD.POS>
    END ELSE
        CALL EB.READ.HISTORY.REC(F.PP.ORDER.ENTRY.HIS,OE.ID,R.ORD.ENTRY.HIS,OE.HERR)
        O.DATA = R.ORD.ENTRY.HIS<PP.OEYG.LOCAL.REF,LOC.FLD.POS>
    END

RETURN

************************************
END
    
