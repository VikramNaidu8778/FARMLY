* @ValidationCode : MToxOTkxNjczMTYzOklTTy04ODU5LTE6MTU0ODc2ODU0NDkwNDphNDUzMjg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 29 Jan 2019 21:29:04
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.VALUEDATE.UPD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 16-01-2019        Sakthivel S           JIRA-P3369                Routine to update Value dates
*                                                                   based on Currency holiday
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN


INIT:
* To Initialise variables and to open necessary files.
    Y.CCY.REGION = '' ; Y.CHK.DATE = ''

    RETURN

PROCESS:
* To check whether value date is on currency holiday

    Y.CCY.REGION = R.NEW(FT.DEBIT.CURRENCY)[1,2]

    Y.CHK.DATE = TODAY
    Y.RET = ''
    Y.RET.DT = ''
    Y.SUNDAY.FLAG = ''

    CALL WORKING.DAY('',Y.CHK.DATE,'+','1W','F',Y.CCY.REGION,'',Y.RET.DT,Y.RET,'')
    GOSUB CHK.HOLIDAY

    CALL WORKING.DAY('',Y.CHK.DATE,'+','1W','F',Y.CCY.REGION,'',Y.RET.DT,Y.RET,'')
    GOSUB CHK.HOLIDAY

    IF Y.SUNDAY.FLAG EQ '1' THEN
        CALL WORKING.DAY('',Y.CHK.DATE,'+','1W','F',Y.CCY.REGION,'',Y.RET.DT,Y.RET,'')
    END
    COMI = Y.RET.DT
    RETURN

CHK.HOLIDAY:
* To ensure that Final date is NOT Sunday for Transaction Currency
    Y.CHK.DATE = Y.RET.DT
    Y.RET = ''
    Y.ICONV.DAY = ''
    Y.RET.DAY = ''
    IF Y.CHK.DATE THEN
        Y.ICONV.DAY = ICONV(Y.CHK.DATE,"D2")
        Y.RET.DAY = OCONV(Y.ICONV.DAY,"DWA")
        IF Y.RET.DAY[1,2] EQ "SU" THEN
            Y.SUNDAY.FLAG = '1'
        END
    END

    RETURN
    END

