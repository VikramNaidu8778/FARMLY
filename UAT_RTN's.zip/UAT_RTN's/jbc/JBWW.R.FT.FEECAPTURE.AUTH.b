     SUBROUTINE JBWW.R.FT.FEECAPTURE.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer      Mail Id                            Reference    escription
*------------------------------------------------------------------------------------------------------
*04/11/2016    Jayanthi R     jayanthi.rallapalli@cognizant.com   RE-001       Initial Version
*------------------------------------------------------------------------------------------------------
* This routine is to update live file JBWW.H.XX.FEECAPTURE with Actual price, Standard Price and 
* Discounted Price of commission amount. 
*
* Attached to VERSION.CONTROL of FUNDS.TRANSFER as AUTH routine
*---------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.CUSTOMER.CHARGE
    $INSERT I_F.FT.GROUP.CONDITION
    $INSERT I_F.JBWW.H.XX.FEECAPTURE
    $INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB MAIN.PROCESS

    RETURN
*-----------------------------------------------------------------------------
*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>

    FN.FUNDS.TRANSFER             = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER              = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.CUSTOMER.CHARGE            = 'F.CUSTOMER.CHARGE'
    F.CUSTOMER.CHARGE             = ''
    CALL OPF(FN.CUSTOMER.CHARGE,F.CUSTOMER.CHARGE)

    FN.FT.GROUP.CONDITION         = 'F.FT.GROUP.CONDITION'
    F.FT.GROUP.CONDITION          = ''
    CALL OPF(FN.FT.GROUP.CONDITION, F.FT.GROUP.CONDITION)

    FN.JBWW.H.XX.FEECAPTURE       = 'F.JBWW.H.XX.FEECAPTURE'
    F.JBWW.H.XX.FEECAPTURE        = ''
    CALL OPF(FN.JBWW.H.XX.FEECAPTURE,F.JBWW.H.XX.FEECAPTURE)

    FN.ACCOUNT                    = 'F.ACCOUNT'
    F.ACCOUNT                     = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    Y.TXN.TYPE            = '' ; FN.POS1             = '' ; FN.POS2          = ''
    R.GENPARM             = '' ; GENPARM.ERR         = '' ; R.GENPARM.FN     = ''
    Y.IN.FT.TXN.TYPE      = '' ; Y.OTH.FT.TXN.TYPE   = '' ; IN.TYPE          = ''
    OUT.TYPE              = '' ; FV.POS1             = '' ; FV.POS2          = ''
    CUST.ID               = '' ; ACCT.NO             = '' ; CHARGE.CCY       = ''
    R.CUST.CHARGE         = '' ; CUST.APPLS          = '' ; CURR.APPLICATION = ''
    GROUP.ID              = '' ; APP.POS             = '' ; CUST.CONDITION   = ''
    PASS.DATA             = '' ; Y.FT.COMM.TYPE.ARR  = '' ; Y.FT.COMM.TYPE   = ''
    R.GRP.CONDITION       = '' ; GRP.CON.ERR         = '' ; Y.FT.COMM.TYPE.VALS = ''
    C.POS                 = '' ; COMM.F.AMT          = '' ; Y.FT.COMM.CCY.VALS = ''
    ACCT.NO               = '' ; R.ACC               = '' ; F.ACCOUNT          = ''
    ACC.ERR               = '' ; PORTF.VALS          = '' ; PORTF.VALS.CNT     = ''
    STD.COMM.VALS         = '' ; STD.COMM.VALS.CNT   = '' ; FEE.ERR            = ''
    DISCNT.COMM.VALS      = '' ; DISCNT.COMM.VALS.CNT= '' ; TRANS.CCY          = ''
    ACT.COMM.VALS         = '' ; ACT.COMM.VALS.CNT   = '' ; PS.CCY  = ''
    FROM.STD.PRICE        = '' ; FROM.DISCNT.PRICE   = '' 
	
	C.PERCENT   = '1' ; C.CURRENCY    = '2' ; C.AMOUNT       = '3' ; C.MIN.AMT     = '6'
    C.MAX.AMT   = '7' ; C.PREMIUM.AMT = '8' ; C.DISCOUNT.AMT = '9' ; C.MIN.MAX.CCY = '10'

   GOSUB INIT.ARRAY



RETURN
*** </region>
*-----------------------------------------------------------------------------
*** <region name = INIT.ARRAY>
INIT.ARRAY:
*** <desc> Initializing CUST.CONDITION and PASS.DATA arrray's </desc>

 
	CUST.CONDITION = ''
    PASS.DATA      = ''
	
	RETURN
*** </region>
*-----------------------------------------------------------------------------
*** <region name = MAIN.PROCESS>
MAIN.PROCESS:
*** <desc> Actual process </desc>

    Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'PRICE.REP.PARAM',R.GENPARM,F.JBWW.H.EB.GENERICPARAMETER,GENPARM.ERR)
    R.GENPARM.FN = R.GENPARM<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE 'IN.FT.TXN.TYPE' IN R.GENPARM.FN<1,1> SETTING FN.POS1 THEN
    Y.IN.FT.TXN.TYPE = R.GENPARM<JBWW.GEN.PAR.FIELD.VALUE,FN.POS1>
    END

    LOCATE 'OTH.FT.TXN.TYPE' IN R.GENPARM.FN<1,1> SETTING FN.POS2 THEN
    Y.OTH.FT.TXN.TYPE = R.GENPARM<JBWW.GEN.PAR.FIELD.VALUE,FN.POS2>
    END

    LOCATE Y.TXN.TYPE IN Y.IN.FT.TXN.TYPE<1,1,1> SETTING FV.POS1 THEN
    IN.TYPE ='1'
    END

    LOCATE Y.TXN.TYPE IN Y.OTH.FT.TXN.TYPE<1,1,1> SETTING FV.POS2 THEN
    OUT.TYPE ='1'
    END

** JBWW.H.XX.FEECAPTURE record for the current transaction id

    CALL F.READ(FN.JBWW.H.XX.FEECAPTURE, ID.NEW, R.FEECAPTURE, F.JBWW.H.XX.FEECAPTURE, FEE.ERR)

    PORTF.VALS     = R.FEECAPTURE<FEE.PORTFOLIO>
    PORTF.VALS.CNT = DCOUNT(PORTF.VALS,VM)
    PORTF.VALS.CNT = PORTF.VALS.CNT + 1
    BEGIN CASE

        CASE IN.TYPE EQ '1'                            ;* For Incoming transactions
            CUST.ID     = R.NEW(FT.CREDIT.CUSTOMER)
            ACCT.NO     = R.NEW(FT.CREDIT.ACCT.NO)
            CHARGE.CCY  = R.NEW(FT.CREDIT.CURRENCY)
		********
	        	GOSUB INIT.ARRAY
		
				COMM.TYPE.CNT = ''
				Y.FT.COMM.TYPE.ARR = R.NEW(FT.COMMISSION.TYPE)
				COMM.TYPE.CNT = DCOUNT(Y.FT.COMM.TYPE.ARR,VM)
				CNT.INT = '1'
				LOOP
				WHILE CNT.INT LE COMM.TYPE.CNT
	************
			
            FROM.STD.PRICE = '1'
            GOSUB PROCESS.STD.PRICE
            CALL F.READ(FN.ACCOUNT, ACCT.NO, R.ACC, F.ACCOUNT, ACC.ERR)
            Y.PORT.NO   = R.ACC<AC.PORTFOLIO.NO,1>
            GROUP.ID    = 'P-':Y.PORT.NO
            FROM.STD.PRICE = ''
            FROM.DISCNT.PRICE = '1'
            GOSUB READ.GROUP.CONDITION
			FROM.DISCNT.PRICE = ''
		
			******
				CNT.INT+=1
				REPEAT
				******
        CASE OUT.TYPE EQ '1'                         ;* For Outgoing transactions
            CUST.ID     = R.NEW(FT.DEBIT.CUSTOMER)
            ACCT.NO     = R.NEW(FT.DEBIT.ACCT.NO) 
            CHARGE.CCY  = R.NEW(FT.DEBIT.CURRENCY)
		
			GOSUB INIT.ARRAY
		
		COMM.TYPE.CNT = ''
		Y.FT.COMM.TYPE.ARR = R.NEW(FT.COMMISSION.TYPE)
		COMM.TYPE.CNT = DCOUNT(Y.FT.COMM.TYPE.ARR,VM)
		CNT.INT = '1'
		LOOP
		  WHILE CNT.INT LE COMM.TYPE.CNT
			
            FROM.STD.PRICE = '1'
            GOSUB PROCESS.STD.PRICE
            CALL F.READ(FN.ACCOUNT, ACCT.NO, R.ACC, F.ACCOUNT, ACC.ERR)
            Y.PORT.NO   = R.ACC<AC.PORTFOLIO.NO,1>
            GROUP.ID    = 'P-':Y.PORT.NO
            FROM.STD.PRICE = ''
            FROM.DISCNT.PRICE = '1'
            GOSUB READ.GROUP.CONDITION
			FROM.DISCNT.PRICE = ''
		CNT.INT+=1
		REPEAT
			

        CASE 1
            RETURN
    END CASE
		GOSUB UPDATE.FEECAPTURE
	 CALL F.WRITE(FN.JBWW.H.XX.FEECAPTURE, ID.NEW, R.FEECAPTURE)
	 
	 
    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = PROCESS.STD.PRICE>
PROCESS.STD.PRICE:
***<desc> Para to read CUSTOMER.CHARGE and calculate standard price </desc>

    CALL FIND.CHARGE.REC(CUST.ID,'',R.CUST.CHARGE)

    CUST.APPLS = R.CUST.CHARGE<EB.CCH.APPLICATION>
    CURR.APPLICATION = APPLICATION

    LOCATE CURR.APPLICATION IN CUST.APPLS<1,1> SETTING APP.POS THEN

    GROUP.ID = R.CUST.CHARGE<EB.CCH.DEFAULT.GROUP,APP.POS>
    FROM.STD.PRICE = '1'
    GOSUB READ.GROUP.CONDITION

    END


    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = READ.GROUP.CONDITION>
READ.GROUP.CONDITION:
***<desc> Para to read FT.GROUP.CONDITION </desc>

    CALL F.READ(FN.FT.GROUP.CONDITION, GROUP.ID, R.GRP.CONDITION, F.FT.GROUP.CONDITION, GRP.CON.ERR)

        Y.FT.COMM.TYPE  = R.NEW(FT.COMMISSION.TYPE)<1,CNT.INT>
        IF R.GRP.CONDITION<FT3.COMM.TYPE,1> EQ 'ALL' THEN
            CUST.CONDITION<C.PERCENT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PERCENT,1>
            GOSUB CALL.CALC.CHARGE
        END ELSE
            Y.FT.COMM.TYPE.VALS = R.GRP.CONDITION<FT3.COMM.TYPE>
            LOCATE Y.FT.COMM.TYPE IN Y.FT.COMM.TYPE.VALS<1,1> SETTING C.POS THEN
                GOSUB PROCESS.GEN.COND
                GOSUB CALL.CALC.CHARGE
            END
        END


    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = PROCESS.GEN.COND>
PROCESS.GEN.COND:
***<desc> Para to read PROCESS.GEN.COND </desc>

                
    Y.FT.COMM.CCY.VALS = R.GRP.CONDITION<FT3.COMM.CCY,C.POS>

    LOCATE CHARGE.CCY IN Y.FT.COMM.CCY.VALS<1,1,1> SETTING CCY.POS THEN

        CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT> = CHARGE.CCY
        COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,CCY.POS>
        IF COMM.F.AMT EQ '' THEN
			CUST.CONDITION<C.PERCENT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
            CUST.CONDITION<C.MIN.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.MAX.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.PREMIUM.AMT,CNT.INT>   = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT>  = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,CCY.POS>
        END ELSE
            CUST.CONDITION<C.AMOUNT,CNT.INT>        =  COMM.F.AMT
            CUST.CONDITION<C.CURRENCY,CNT.INT>      =  CHARGE.CCY
        END
		TRANS.CCY = '1'
    END ELSE
        LOCATE LCCY IN Y.FT.COMM.CCY.VALS<1,1,1> SETTING LCY.POS THEN
            CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT>= LCCY
            COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,LCY.POS>
            IF COMM.F.AMT EQ '' THEN    
			    CUST.CONDITION<C.PERCENT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
                CUST.CONDITION<C.MIN.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.MAX.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.PREMIUM.AMT,CNT.INT>   = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT>  = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,LCY.POS>
            END ELSE
                CUST.CONDITION<C.AMOUNT,CNT.INT>        =  COMM.F.AMT
                CUST.CONDITION<C.CURRENCY,CNT.INT>      =  LCCY
            END
			
        END ELSE
		                                  PS.CCY    = R.GRP.CONDITION<FT3.COMM.CCY,C.POS,1>
            CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT>   = PS.CCY
            COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,1>
            IF COMM.F.AMT EQ '' THEN
				CUST.CONDITION<C.PERCENT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
                CUST.CONDITION<C.MIN.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,1>
                CUST.CONDITION<C.MAX.AMT,CNT.INT>       = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,1>
                CUST.CONDITION<C.PREMIUM.AMT,CNT.INT>   = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,1>
                CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT>  = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,1>
            END ELSE
                CUST.CONDITION<C.AMOUNT,CNT.INT>        =  COMM.F.AMT
                CUST.CONDITION<C.CURRENCY,CNT.INT>      =  PS.CCY
            END
			
        END
    END

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = CALL.CALC.CHARGE>
CALL.CALC.CHARGE:
***<desc> Para to calculate commission / charge amount </desc>

    PASS.DATA<1,CNT.INT> = Y.FT.COMM.TYPE
    PASS.DATA<2,CNT.INT> = 'COM'
    INPUT.AMT   = R.NEW(FT.DEBIT.AMOUNT)
    COMM.CCY    = CHARGE.CCY
    GOSUB CAL.CCY.MKT
    Y.CROSS.RATE = ''
    Y.CROSS.CURRENCY = ''
	TOTAL.LOCAL.COMM.CHG = ''
	TOTAL.FOR.COMM.CHG = ''
	
    CALL CALCULATE.CHARGE(CUST.ID,INPUT.AMT,COMM.CCY,CCY.MKT,Y.CROSS.RATE,Y.CROSS.CURRENCY,CHARGE.CCY,PASS.DATA,CUST.CONDITION,TOTAL.LOCAL.COMM.CHG,TOTAL.FOR.COMM.CHG)
	
	IF TRANS.CCY EQ '1' AND CHARGE.CCY NE LCCY THEN
	
		MARKET   = BASE.CCY.MKT
		LAMT     = TOTAL.LOCAL.COMM.CHG
		FCY      = CHARGE.CCY
		CALL MIDDLE.RATE.CONV.CHECK(FAMT, FCY, RATE, MARKET, LAMT, DIF.AMT, DIF.RATE)
		TOTAL.FOR.COMM.CHG = FAMT
    END
			
    IF FROM.STD.PRICE EQ '1' THEN
        GOSUB UPDATE.STD.PRICE
    END 

    IF FROM.DISCNT.PRICE EQ '1' THEN
        GOSUB UPDATE.DISCNT.PRICE
    END

    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.STD.PRICE>
UPDATE.STD.PRICE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE with standard price </desc>

        STD.COMM.VALS       = R.FEECAPTURE<FEE.STD.COMM.CODE>
        STD.COMM.VALS.CNT   = DCOUNT(STD.COMM.VALS,SM)
        R.FEECAPTURE<FEE.STD.PRICE.LCY,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1>     = TOTAL.LOCAL.COMM.CHG
        R.FEECAPTURE<FEE.STD.PRICE,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1>         = TOTAL.FOR.COMM.CHG
		R.FEECAPTURE<FEE.STD.COMM.CODE,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1>      = Y.FT.COMM.TYPE
		R.FEECAPTURE<FEE.STD.CURRENCY,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1>       = CHARGE.CCY
   

	GOSUB UPDATE.ACTUAL.PRICE
    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.DISCNT.PRICE>
UPDATE.DISCNT.PRICE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE with Discounted price </desc>

  
        DISCNT.COMM.VALS  = R.FEECAPTURE<FEE.DISCNT.COMM.CODE>
        DISCNT.COMM.VALS.CNT   = DCOUNT(DISCNT.COMM.VALS,SM)
        R.FEECAPTURE<FEE.DISCNT.PRICE.LCY,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = TOTAL.LOCAL.COMM.CHG
        R.FEECAPTURE<FEE.DISCNT.PRICE,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = TOTAL.FOR.COMM.CHG
		R.FEECAPTURE<FEE.DISCNT.COMM.CODE,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1>  = Y.FT.COMM.TYPE
		R.FEECAPTURE<FEE.DISCNT.CURRENCY,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1>   = CHARGE.CCY




RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.ACTUAL.PRICE>
UPDATE.ACTUAL.PRICE:
***<desc>  Updation of ACTUAL.PRICE with transaction's COMMISSION AMOUNT of each COMMISSION.TYPE </desc>

    ACT.COMM.VALS       = R.FEECAPTURE<FEE.ACT.COMM.CODE>
    ACT.COMM.VALS.CNT   = DCOUNT(ACT.COMM.VALS,SM)
    ACT.COMM.AMT = ''
    ACT.COMM.AMT = R.NEW(FT.COMMISSION.AMT)<1,CNT.INT>
    ACT.COMM.AMT = ACT.COMM.AMT[4,99] 
    
    IF CHARGE.CCY NE LCCY THEN
        Y.RATE = ""
        Y.MARKET = "1"
        Y.LOC.AMT = ""
        Y.FCY = CHARGE.CCY
        Y.FORGN.AMT  = ACT.COMM.AMT
        CALL MIDDLE.RATE.CONV.CHECK(Y.FORGN.AMT,Y.FCY,Y.RATE,Y.MARKET,Y.LOC.AMT,'','')
        LCY.ACT.COMM.AMT = Y.LOC.AMT
    END ELSE
        LCY.ACT.COMM.AMT = ACT.COMM.AMT
    END
    
    R.FEECAPTURE<FEE.ACT.PRICE,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1>        = ACT.COMM.AMT
    R.FEECAPTURE<FEE.ACT.PRICE.LCY,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1>    = LCY.ACT.COMM.AMT
    R.FEECAPTURE<FEE.ACT.COMM.CODE,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1>    = Y.FT.COMM.TYPE
    R.FEECAPTURE<FEE.ACT.CURRENCY,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1>     = CHARGE.CCY

    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.FEECAPTURE>
UPDATE.FEECAPTURE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE </desc>

    R.FEECAPTURE<FEE.FEE.TYPE>          = 'FUNDS.TRANSFER'
    R.FEECAPTURE<FEE.PORTFOLIO,1>       = Y.PORT.NO
    R.FEECAPTURE<FEE.BOOKING.DATE,1>      = R.NEW(FT.PROCESSING.DATE)

    FT.REC.STATUS                       = R.NEW(FT.RECORD.STATUS)

    IF FT.REC.STATUS EQ 'INAU' OR FT.REC.STATUS EQ '' THEN
        R.FEECAPTURE<FEE.TXN.STATUS>    = 'LIVE'
    END

    IF FT.REC.STATUS EQ 'REVE' OR FT.REC.STATUS EQ 'R' OR FT.REC.STATUS EQ 'RNAU' THEN
        R.FEECAPTURE<FEE.TXN.STATUS>    = 'REVE'
    END

    RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = CAL.CCY.MKT>
CAL.CCY.MKT:
***<desc> Para to find CCY.MKT </desc>

    IF R.NEW(FT.COMMISSION.CODE)[1,1] EQ 'C' OR R.NEW(FT.CHARGE.CODE)[1,1] EQ 'C' THEN
        BASE.CCY.MKT = R.NEW(FT.CURRENCY.MKT.CR)
    END ELSE
        BASE.CCY.MKT = R.NEW(FT.CURRENCY.MKT.DR)
    END

    CALL FIND.CCY.MKT("FT" , "4" , "COMM.CHG" , CCY.MKT , BASE.CCY.MKT , RETURN.CODE , ERR.MSG)

    RETURN
***</region>
*-----------------------------------------------------------------------------
    END
