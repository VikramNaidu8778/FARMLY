*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
* @ValidationCode : MTo3MTg1Mzc0NzU6VVRGLTg6MTQ3MDkwNzc1NzQ3MToyMzMxNzk6LTE6LTE6MDowOmZhbHNlOk4vQQ==
* @ValidationInfo : Timestamp         :
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         :
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
SUBROUTINE JBWW.B.FT.BULKREFUNDFTUPLOAD.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer                     Reference            Description
*-----------------------------------------------------------------------------
* 18-Oct-2022       Madhu               P-3998      Checking the EB.FILE.UPLOAD.TYPE and send the valid version
*                                                   to post FT
* 19-Sep-2023       Madhu              FSQD-3481    Amended the routine for HK GST Bulk upload
* ----------------------------------------------------------------------------
*
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_T24.UPLOAD.PROCESS.COMMON
    $INSERT I_JBWW.B.FT.BULKREFUNDFTUPLOAD.COMMON
    $INSERT I_F.EB.FILE.UPLOAD.PARAM
    $INSERT I_F.EB.FILE.UPLOAD.TYPE
    $INSERT I_F.EB.FILE.UPLOAD
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
*-----------------------------------------------------------------------------

    FN.EB.FILE.UPLOAD.PARAM = 'F.EB.FILE.UPLOAD.PARAM'
    FV.EB.FILE.UPLOAD.PARAM = ''
    CALL OPF(FN.EB.FILE.UPLOAD.PARAM,FV.EB.FILE.UPLOAD.PARAM)

    FN.EB.FILE.UPLOAD.TYPE = 'F.EB.FILE.UPLOAD.TYPE'
    FV.EB.FILE.UPLOAD.TYPE = ''
    CALL OPF(FN.EB.FILE.UPLOAD.TYPE,FV.EB.FILE.UPLOAD.TYPE)

    FN.EB.FILE.UPLOAD = 'F.EB.FILE.UPLOAD'
    FV.EB.FILE.UPLOAD = ''
    CALL OPF(FN.EB.FILE.UPLOAD,FV.EB.FILE.UPLOAD)
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    FV.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,FV.JBWW.H.EB.GENERICPARAMETER)
    
    GOSUB READ.PARAM
    
RETURN
    
READ.PARAM:
************

    GEN.PARAM.ID = 'BULKREFUNDFTUPLOAD'
    IF ID.COMPANY[1,2] EQ 'HK' THEN
        FIELD.NAME.ARRAY = 'VERSION':FM:'FIELD.LIST':FM:'ARCHIVE.DIR':FM:'HK.GSTBULK.FTREFUND'
    END
    IF ID.COMPANY[1,2] EQ 'SG' THEN
        FIELD.NAME.ARRAY = 'VERSION':FM:'FIELD.LIST':FM:'ARCHIVE.DIR':FM:'SG.GSTBULK.FTREFUND'
    END

    FLD.VALUE = '' ; FT.FIELD.POS.LIST = '' ; Y.GST.VERSION = ''
    CALL JBWW.R.EB.GETGENPARM.VAL(GEN.PARAM.ID,FIELD.NAME.ARRAY,FLD.VALUE)

    FT.VERSION = FLD.VALUE<1>
    FT.FIELD.LIST = FLD.VALUE<2>
    ARCHIVE.DIR = FLD.VALUE<3>
    Y.GST.VERSION = FLD.VALUE<4>    
    Y.APPLICATION = 'FUNDS.TRANSFER'
    
    CALL GET.STANDARD.SELECTION.DETS(Y.APPLICATION,R.SS)
    
    LOOP
        REMOVE FLD.NAME FROM FT.FIELD.LIST SETTING Y.POS
    WHILE FLD.NAME:Y.POS
        FLD.NO = '';YAF.FLD = '';YAV.FLD = '' ; YAS.FLD = ''; DATA.TYPE.FLD ='' ; ERR.MSG.FLD = ''
        IF FLD.NAME[1,3] EQ 'LT*' THEN
            CALL FIELD.NAMES.TO.NUMBERS('LOCAL.REF',R.SS,FLD.NO,YAF.FLD,YAV.FLD,YAS.FLD,DATA.TYPE.FLD,ERR.MSG.FLD)
            Y.LRT.FIELD = FLD.NAME[4,-1]
            Y.LRT.FLDVALUE = ''
            CALL GET.LOC.REF(Y.APPLICATION,Y.LRT.FIELD,Y.LRT.FLDVALUE)
            Y.LRT.FLD = Y.LRT.FLDVALUE
            IF FT.FIELD.POS.LIST THEN
                FT.FIELD.POS.LIST<-1> = FLD.NO:',':Y.LRT.FLD
            END ELSE
                FT.FIELD.POS.LIST = FLD.NO:',':Y.LRT.FLD
            END
        END ELSE
            CALL FIELD.NAMES.TO.NUMBERS(FLD.NAME,R.SS,FLD.NO,YAF.FLD,YAV.FLD,YAS.FLD,DATA.TYPE.FLD,ERR.MSG.FLD)
            IF FT.FIELD.POS.LIST THEN
                FT.FIELD.POS.LIST<-1> = FLD.NO
            END ELSE
                FT.FIELD.POS.LIST = FLD.NO
            END
        END
    REPEAT

    CALL FIELD.NAMES.TO.NUMBERS('LOCAL.REF',R.SS,FLD.NO,YAF.FLD,YAV.FLD,YAS.FLD,DATA.TYPE.FLD,ERR.MSG.FLD)
    Y.LRT.FIELD = 'L.FT.FILEUPD.ID'
    CALL GET.LOC.REF(Y.APPLICATION,Y.LRT.FIELD,Y.LRT.FLDVALUE)
    FT.FIELD.POS.LIST<-1> = FLD.NO:',':Y.LRT.FLDVALUE

    CALL CACHE.READ(FN.EB.FILE.UPLOAD.PARAM, "SYSTEM", R.EFUP.PARAM, EFUP.ERR)
    Y.DIR = R.EFUP.PARAM<EB.UP.TC.UPLOAD.PATH>
    Y.BAT.DET = BATCH.DETAILS
    Y.PROCESS.ID = Y.BAT.DET<3,1>
    CALL F.READ(FN.EB.FILE.UPLOAD, Y.PROCESS.ID, R.EFUP, F.EB.FILE.UPLOAD.TYPE,EFUT.ERR)

    Y.UPLD.TYPE = R.EFUP<EB.UF.UPLOAD.TYPE>
    Y.UPD.POS = '' ; Y.GST.FLAG = ''
    LOCATE Y.UPLD.TYPE IN FIELD.NAME.ARRAY<1> SETTING Y.UPD.POS THEN
        FT.VERSION = '';ARCHIVE.DIR = ''
        CHANGE SM TO VM IN Y.GST.VERSION
        FT.VERSION =  FIELD(Y.GST.VERSION,VM,1)
        ARCHIVE.DIR = FIELD(Y.GST.VERSION,VM,2)
    END
    Y.CSV.NAME = R.EFUP<EB.UF.FILE.NAME>

    CALL F.READ(FN.EB.FILE.UPLOAD.TYPE, Y.UPLD.TYPE, R.EFUT, F.EB.FILE.UPLOAD.TYPE, EFUT.ERR)

    UPLOAD.DIR = R.EFUT<EB.UT.UPLOAD.DIR>
    EXTENSION = R.EFUT<EB.UT.EXTENSION>
    HDR.UPD.APPL = R.EFUT<EB.UT.HDR.UPD.APPL>
    HDR.UPD.VERSION = R.EFUT<EB.UT.HDR.UPD.VERSION>
    SEPARATOR = R.EFUT<EB.UT.SEPARATOR>
    ITEMS.UPD.APPL = R.EFUT<EB.UT.ITEMS.UPD.APPL>
    ITEMS.UPD.VERSION = R.EFUT<EB.UT.ITEMS.UPD.VERSION>

*Y.UPLD.TYPE = 'SG.BULK.FTREFUND'
*Y.PROCESS.ID = 'UPLD1809205060'
*Y.CSV.NAME = 'FTTEST.csv'
*UPLOAD.DIR = 'SGD/SG.BULK.FTREFUND/in'
*EXTENSION = '.csv'
*SEPARATOR = ','
    
RETURN
*-----------------------------------------------------------------------------

END