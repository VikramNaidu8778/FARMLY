* @ValidationCode : MToyNDU0NDQ5NjE6SVNPLTg4NTktMToxNTMyMDc0MjEwNDQ1OjMxMTg0OTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNw==
* @ValidationInfo : Timestamp         : 20 Jul 2018 13:40:10
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.CIDACCESS.NOF(OUT.ARRAY)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
*
* This Nofile routine attached to the enquiry JBWW.E.FT.CIDACCESS.EXTRACT
* and it is triggered from EC to extract ID DATA from T24 / CID
*
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY
*
* Dependencies:
*---------------
*
* Revision History:
*-------------------------------------------------------------------------
* Date        Developer         Reference             Description
*-------------------------------------------------------------------------
*
* 10/08/2018  Lakshmanan         CID Data Access      Initial Version
*
*-------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COMPANY
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.MNEMONIC.CUSTOMER

    GOSUB INIT
    GOSUB PROCESS

*
    RETURN
*
*-------------------------------------------------------------------------
INIT:
*-------------------------------------------------------------------------

    OUT.ARRAY = ''
    Y.FILTER = ''

    SQL.AC.DELIM = "','"
    Y.FM.CHAR = CHAR(251)
    ACCOUNT.SQL = ''
    CO.ID = R.COMPANY(EB.COM.MNEMONIC)

    Y.ERR = ''
    Y.T24.FILE =  'FUNDS.TRANSFER'
    CALL JBWW.R.XX.GETORACLE.FILENAME(Y.T24.FILE,Y.ORACLE.FILE,Y.ERR)
    Y.ORACLE.LIVE = Y.ORACLE.FILE
    Y.T24.FILE = 'FUNDS.TRANSFER$HIS'
    CALL JBWW.R.XX.GETORACLE.FILENAME(Y.T24.FILE,Y.ORACLE.FILE,Y.ERR)
    Y.ORACLE.HIS = Y.ORACLE.FILE

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)


    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    FN.CUSTOMER.ACCOUNT = 'F.CUSTOMER.ACCOUNT'
    F.CUSTOMER.ACCOUNT = ''
    CALL OPF(FN.CUSTOMER.ACCOUNT,F.CUSTOMER.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)

    FN.MNEMONIC.CUSTOMER = 'F.MNEMONIC.CUSTOMER'
    F.MNEMONIC.CUSTOMER = ''
    CALL OPF(FN.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER)

    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING REF.POS THEN
    Y.TXN.REF = D.RANGE.AND.VALUE<REF.POS>
    Y.TXN.REF = TRIM(Y.TXN.REF)
    GOSUB GET.FT.TXN.REF
    END

    LOCATE 'PORTFOLIO.NO' IN D.FIELDS<1> SETTING PORT.POS THEN
    Y.PORTFOLIO = D.RANGE.AND.VALUE<PORT.POS>
    Y.PORTFOLIO = TRIM(Y.PORTFOLIO)
    END

    LOCATE 'PROCESSING.DATE' IN D.FIELDS<1> SETTING PDATE.POS THEN
    Y.PR.DATE = D.RANGE.AND.VALUE<PDATE.POS>
    Y.PR.DATE = TRIM(Y.PR.DATE)
    GOSUB GET.PROCESSING.DATE
    END

    LOCATE 'DEBIT.VALUE.DATE' IN D.FIELDS<1> SETTING DV.POS THEN
    Y.DV.DATE = D.RANGE.AND.VALUE<DV.POS>
    Y.DV.DATE = TRIM(Y.DV.DATE)
    GOSUB GET.DEBIT.VALUE.DATE
    END

    LOCATE 'TRANSACTION.TYPE' IN D.FIELDS<1> SETTING TXN.POS THEN
    Y.TXN.TYPE = D.RANGE.AND.VALUE<TXN.POS>
    Y.TXN.TYPE = TRIM(Y.TXN.TYPE)
    GOSUB GET.TXN.TYPE
    END

*
    RETURN
*
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------

    IF Y.PORTFOLIO THEN
        GOSUB GET.CUSTOMER.ACCOUNT
    END

    GOSUB EXTRACT.ALL.FT

*
    RETURN
*-------------------------------------------------------------------------
GET.TXN.TYPE:
*-------------------------------------------------------------------------

    IF Y.TXN.TYPE THEN
        IF NOT(Y.FILTER) THEN
            Y.FILTER = " TRANSACTION_TYPE = '":Y.TXN.TYPE:"'"
        END ELSE
            Y.FILTER := " AND TRANSACTION_TYPE = '":Y.TXN.TYPE:"'"
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.PROCESSING.DATE:
*-------------------------------------------------------------------------

    IF Y.PR.DATE THEN
        TO.PR.DATE = ''
        CONVERT SM TO VM IN Y.PR.DATE
        TOTL.PR.DATE = DCOUNT(Y.PR.DATE,VM)

        I = 1
        LOOP
        WHILE I LE TOTL.PR.DATE

            Y.DATE = Y.PR.DATE<1,I>
            Y.DATE = TRIM(Y.DATE)
            IF Y.DATE THEN
                Y.PR.DATES<1,-1> = Y.DATE
            END

            I += 1
        REPEAT

        TOTL.PR.DATES = DCOUNT(Y.PR.DATES,VM)
        IF TOTL.PR.DATES EQ '1' THEN
            FROM.PR.DATE = Y.PR.DATES<1,1>
            GOSUB PV.DATE.FILTER.FORM
        END ELSE
            FROM.PR.DATE = Y.PR.DATES<1,1>
            TO.PR.DATE = Y.PR.DATES<1,2>
            GOSUB PV.DATE.FILTER.FORM
        END

    END
*
    RETURN
*
*-------------------------------------------------------------------------
PV.DATE.FILTER.FORM:
*-------------------------------------------------------------------------

    IF Y.FILTER THEN
        IF TO.PR.DATE THEN
            Y.FILTER := " AND PROCESSING_DATE >= ":SQUOTE(FROM.PR.DATE):" AND PROCESSING_DATE <= ":SQUOTE(TO.PR.DATE):" "
        END ELSE
            Y.FILTER := " AND PROCESSING_DATE = ":SQUOTE(FROM.PR.DATE)
        END
    END ELSE
        IF TO.PR.DATE THEN
            Y.FILTER := " PROCESSING_DATE >= ":SQUOTE(FROM.PR.DATE):" AND PROCESSING_DATE <= ":SQUOTE(TO.PR.DATE):" "
        END ELSE
            Y.FILTER := " PROCESSING_DATE = ":SQUOTE(FROM.PR.DATE)
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.DEBIT.VALUE.DATE:
*-------------------------------------------------------------------------

    IF Y.DV.DATE THEN
        TO.DV.DATE = ''
        CONVERT SM TO VM IN Y.DV.DATE
        TOTL.DV.DATE = DCOUNT(Y.DV.DATE,VM)

        I = 1
        LOOP
        WHILE I LE TOTL.DV.DATE
            Y.DATE = Y.DV.DATE<1,I>
            Y.DATE = TRIM(Y.DATE)
            IF Y.DATE THEN
                Y.DV.DATES<1,-1> = Y.DATE
            END
            I += 1
        REPEAT

        TOTL.DV.DATES = DCOUNT(Y.DV.DATES,VM)
        IF TOTL.DV.DATES EQ '1' THEN
            FROM.DV.DATE = Y.DV.DATES<1,1>
            GOSUB DV.DATE.FILTER.FORM
        END ELSE
            FROM.DV.DATE = Y.DV.DATES<1,1>
            TO.DV.DATE = Y.DV.DATES<1,2>
            GOSUB DV.DATE.FILTER.FORM
        END

    END
*
    RETURN
*
*-------------------------------------------------------------------------
DV.DATE.FILTER.FORM:
*-------------------------------------------------------------------------

    IF Y.FILTER THEN
        IF TO.DV.DATE THEN
            Y.FILTER := " AND DEBIT_VALUE_DATE >= ":SQUOTE(FROM.DV.DATE):" AND DEBIT_VALUE_DATE <= ":SQUOTE(TO.DV.DATE):" "
        END ELSE
            Y.FILTER := " AND DEBIT_VALUE_DATE = ":SQUOTE(FROM.DV.DATE)
        END
    END ELSE
        IF TO.DV.DATE THEN
            Y.FILTER = " DEBIT_VALUE_DATE >= ":SQUOTE(FROM.DV.DATE):" AND DEBIT_VALUE_DATE <= ":SQUOTE(TO.DV.DATE):" "
        END ELSE
            Y.FILTER = " DEBIT_VALUE_DATE = ":SQUOTE(FROM.DV.DATE)
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.CUSTOMER.ACCOUNT:
*-------------------------------------------------------------------------

    IF Y.PORTFOLIO THEN
        Y.PORTFOLIO = TRIM(Y.PORTFOLIO)
        CONVERT SM TO VM IN Y.PORTFOLIO
        TOT.PORTFOLIO = DCOUNT(Y.PORTFOLIO,VM)
        LOOP
            REMOVE Y.PORT.ID FROM Y.PORTFOLIO SETTING PORT.POS
        WHILE Y.PORT.ID:PORT.POS

            CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.PORT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
            IF R.SAM.ALT.REC THEN
                Y.SAMALT.DATA = R.SAM.ALT.REC
                Y.SAM.ID = FIELD(Y.SAMALT.DATA,'*',2)
            END
            CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,ERR.SAM)
            Y.SAMACC.NOS = R.SAM<SC.SAM.ACCOUNT.NOS>

            IF Y.SAMACC.NOS THEN
                Y.SAMACCT.CNT = DCOUNT(Y.SAMACC.NOS,VM)
                AC.CNT = 1
                LOOP
                WHILE AC.CNT LE Y.SAMACCT.CNT
                    Y.ACCT = Y.SAMACC.NOS<1,AC.CNT>
                    IF Y.ACCT THEN
                        IF Y.SAMACCT.LIST THEN
                            Y.SAMACCT.LIST := SQL.AC.DELIM : Y.ACCT
                        END ELSE
                            Y.SAMACCT.LIST = "('":Y.ACCT
                        END
                    END
                    AC.CNT += 1
                REPEAT
            END
        REPEAT
        IF Y.SAMACCT.LIST THEN
            ACCOUNT.SQL = Y.SAMACCT.LIST:"')"     ;* This AC List value passed to SQL query
        END
    END
    IF ACCOUNT.SQL THEN

        IF Y.FILTER THEN
            Y.FILTER := " AND ((DEBIT_ACCT_NO IN ":ACCOUNT.SQL:") OR (CREDIT_ACCT_NO IN ":ACCOUNT.SQL:" ))"
        END ELSE
            Y.FILTER = " ((DEBIT_ACCT_NO IN ":ACCOUNT.SQL:") OR (CREDIT_ACCT_NO IN ":ACCOUNT.SQL:" ))"
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.FT.TXN.REF:
*-------------------------------------------------------------------------

    Y.TXN.REF = TRIM(Y.TXN.REF)
    CONVERT SM TO VM IN Y.TXN.REF
    TOT.TXN.REF = DCOUNT(Y.TXN.REF,VM)
    Y.FT.LIST = ''
    FT.SQL = ''
    I = 1
    LOOP
    WHILE I LE TOT.TXN.REF
        FT.ID = Y.TXN.REF<1,I>
        IF TRIM(FT.ID) THEN
            FT.ID = TRIM(FT.ID)
            IF Y.FT.LIST THEN
                Y.FT.LIST := SQL.AC.DELIM : FT.ID
            END ELSE
                Y.FT.LIST = "('":FT.ID
            END
        END
        I += 1
    REPEAT
    IF Y.FT.LIST THEN
        FT.SQL = Y.FT.LIST:"')"

        IF Y.FILTER THEN
            Y.FILTER := " AND RECID IN ":FT.SQL
        END ELSE
            Y.FILTER = "RECID IN ":FT.SQL
        END

    END

*
    RETURN
*
*-------------------------------------------------------------------------
EXTRACT.ALL.FT:
*-------------------------------------------------------------------------

    IF NOT(Y.FILTER) THEN
        SQL.L.FILTER = ''
        SQL.H.FILTER = " WHERE RECORD_STATUS IN ('REVE', 'MAT')"
    END ELSE
        SQL.L.FILTER = " WHERE ":Y.FILTER
        SQL.H.FILTER = " WHERE RECORD_STATUS IN ('REVE', 'MAT')":" AND ":Y.FILTER
    END



SQL.FT.LIVE ="SELECT RECID,'FUNDS.TRANSFER',TRANSACTION_TYPE,PROCESSING_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY,L_XX_BLK_CATEG,AMOUNT_CREDITED,AMOUNT_DEBITED FROM V_":Y.ORACLE.LIVE:"":SQL.L.FILTER

    SQL.FT.LIVE = EXECSQLQUERY(1,SQL.FT.LIVE)
    CONVERT FM TO '*' IN SQL.FT.LIVE
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.LIVE


SQL.FT.HIS = "SELECT RECID,'FUNDS.TRANSFER',TRANSACTION_TYPE,PROCESSING_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY,L_XX_BLK_CATEG,AMOUNT_CREDITED,AMOUNT_DEBITED FROM V_":Y.ORACLE.HIS:"":SQL.H.FILTER

    SQL.FT.HIS = EXECSQLQUERY(1,SQL.FT.HIS)
    CONVERT FM TO '*' IN SQL.FT.HIS
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.HIS

    IF SQL.FT.HIS THEN
        SQL.FT.LIVE<-1> = SQL.FT.HIS
    END

    IF SQL.FT.LIVE THEN
        OUT.ARRAY = SQL.FT.LIVE
    END

*
    RETURN
*
*-------------------------------------------------------------------------
    END

