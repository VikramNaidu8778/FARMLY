SUBROUTINE JBWW.R.STO.LOC.FLDS.VAL
*-------------------------------------------------------------------------
* Description: This is a Validation routine attached to STO versions to validate FT.LOC.REF.NO and FT.LOC.REF.DATA fields.
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
* Dependencies:
*---------------
* Revision History:
*------------------
* Date               who                  Reference                 Description
* 24-03-2017         Balaji Pushparaj     JB2A-22802 & JB2A-25133   Initial Version
* 25-04-2017		 Balaji Pushparaj     JB2A-22802                Modified Error Message
*------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.STANDING.ORDER

	GOSUB PROCESS
	RETURN

*-------
PROCESS:
*-------
 Y.LOC.REF.NO.LIST = R.NEW(STO.FT.LOC.REF.NO)
 Y.LOC.REF.DATA.LIST = R.NEW(STO.FT.LOC.REF.DATA)
	LOCATE "21" IN Y.LOC.REF.NO.LIST<1,1> SETTING REF.NO.POS THEN
	  Y.COMM.MODE.POS = Y.LOC.REF.DATA.LIST<1,REF.NO.POS>
	  IF Y.COMM.MODE.POS EQ "" THEN
	     AF = STO.FT.LOC.REF.DATA
	   	 AV = REF.NO.POS
	     ETEXT = 'FT-COMM.MODE.MISSING'
	     CALL STORE.END.ERROR
	  END
	END ELSE
	 AF = STO.FT.LOC.REF.NO
	 AV = 1
	 ETEXT = 'FT-COMM.MODE.MISSING'
	 CALL STORE.END.ERROR
   END
	RETURN
END
		
