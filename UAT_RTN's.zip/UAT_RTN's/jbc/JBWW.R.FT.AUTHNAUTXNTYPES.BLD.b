* @ValidationCode : MTo4NjA1MzcxOklTTy04ODU5LTE6MTU0Mjk1MTQyODgwNDo1MzQ0NjI6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjQ=
* @ValidationInfo : Timestamp         : 23 Nov 2018 11:07:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 534462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.AUTHNAUTXNTYPES.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
** Description:
*-------------------------------------------------------------------------
* This is build routine attached to enquiry JBWW.E.FT.AUTH.NAU.ENQ
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output: 
*--------------
* IN: NA
* OUT: LIST.ARRAY
* Dependencies:
*---------------
* NA
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer                Reference               Description
*----------------------------------------------------------------------------------------------
* 15-Oct-2018      Rajagopalan R       DAY15-4245 & DAY15-4482      Initial Draft
* 22-Nov-2018      Kalyani L K         DAY15-4878                   Modified selection to consider the FT given in selection criteria
* 06-Dec-2018      Lakshmanan          DAY15-4878                   Filter condition for the selection corrected
*                                                                   accordingly as per cash and sec roles
*
* 21-Dec-2018      Balakrishnan K      DAY15-4878                   USER roles assigned correctly as per the role access  given by company specific .
*   
*----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.EB.USER.ROLES
    $INSERT I_F.USER
    $INSERT I_F.FUNDS.TRANSFER
    
    GOSUB INIT
    GOSUB PROCESS
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------
*****
INIT:
*****
* In this para of the program, the files are initialised
**    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)
    
    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)
    
    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)
    
    SECTXN.POS = '' ; CASHTXN.POS = ''
    FV.CASHROLE.POS = '' ; ROLE.POS = ''
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------
********
PROCESS:
********
* In this para of the program, the final FT array is passed to enquiry
**
    LOCATE "@ID" IN ENQ.DATA<2,1> SETTING ID.POS THEN
        FT.ID = ENQ.DATA<4,ID.POS>
    END
 
    GOSUB GET.USER.ROLES
    GOSUB GET.GEN.PARAM.DETAILS
    GOSUB CASH.USER.ROLE.CHK
    GOSUB GET.FIXED.SELECTION.DETAILS
    
    CONVERT FM TO ' ' IN SEL.LIST
    ENQ.DATA<2,ID.POS> = '@ID'
    ENQ.DATA<3,ID.POS> = 'EQ'
    ENQ.DATA<4,ID.POS> = SEL.LIST

    RETURN
*-----------------------------------------------------------------------------------------------------------------
***************
GET.USER.ROLES:
***************
* In this para of the program, the user role is fetched
**        
    Y.LOGIN.USER = OPERATOR
    CALL F.READ(FN.USER,Y.LOGIN.USER,R.LOGIN.USER,F.USER,LOG.USR.ERR)
    EB.ROLE.COMPANY.RESTR = R.LOGIN.USER<EB.USE.ROLE.COMPANY.RESTR>
	LOCATE ID.COMPANY IN EB.ROLE.COMPANY.RESTR<1,1> SETTING COM.POS THEN
		Y.USERROLES.LIST = R.LOGIN.USER<EB.USE.USER.ROLES , COM.POS >
	END
    CHANGE SM TO FM IN Y.USERROLES.LIST
     
    RETURN
*-----------------------------------------------------------------------------------------------------------------    
**********************
GET.GEN.PARAM.DETAILS:
**********************
* In this para of the program, the GPM details are fetched
** 
 
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.CASHSEC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,USERROLE.ERR)
    USERROLES.FN = R.CASHSEC.ROLE<JBWW.GEN.PAR.FIELD.NAME>
    USERROLES.FV = R.CASHSEC.ROLE<JBWW.GEN.PAR.FIELD.VALUE>
        
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.AC.CASHROLE.TXNTYPES",R.CASHROLE.TXN,F.JBWW.H.EB.GENERICPARAMETER,CASHROLE.ERR)
    Y.CASHROLES.FN = R.CASHROLE.TXN<JBWW.GEN.PAR.FIELD.NAME>
    Y.CASHROLES.TXNTYPES.FV = R.CASHROLE.TXN<JBWW.GEN.PAR.FIELD.VALUE>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.SC.SECROLE.TXNTYPES",R.SECROLE.TXN,F.JBWW.H.EB.GENERICPARAMETER,SECROLE.ERR)
    Y.SECROLES.FN = R.SECROLE.TXN<JBWW.GEN.PAR.FIELD.NAME>
    Y.SECROLES.TXNTYPES.FV = R.SECROLE.TXN<JBWW.GEN.PAR.FIELD.VALUE>
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------    
*******************
CASH.USER.ROLE.CHK:
*******************
* In this para of the program, the User role is checked against cash users
**
    USER.COUNT = DCOUNT(Y.USERROLES.LIST,FM)
    USER.CNT = 1

    TXNTYPES = ''
    LOCATE 'CASH.USER.ROLES' IN USERROLES.FN<1,1> SETTING USERROLE.POS THEN
        LOOP
*           REMOVE Y.USER.ROLES FROM Y.USERROLES.LIST SETTING ROLE.POS
*        WHILE Y.USER.ROLES : ROLE.POS
        WHILE USER.CNT LE USER.COUNT
           Y.USER.ROLES = Y.USERROLES.LIST<USER.CNT>
           LOCATE Y.USER.ROLES IN USERROLES.FV<1,USERROLE.POS,1> SETTING FV.USERROLE.POS THEN
              LOCATE 'CASH' IN Y.CASHROLES.FN<1,1> SETTING CASHROLE.POS THEN
                 TXNTYPES = Y.CASHROLES.TXNTYPES.FV<1,CASHROLE.POS>
*                 CHANGE SM TO ' ' IN TXNTYPES
              END 
           END
           USER.CNT += 1
        REPEAT
    END
   
    IF TXNTYPES EQ '' THEN
        SEC.ROLE.IND = 'Y'
        GOSUB SEC.USER.ROLE.CHK
    END
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------        
******************
SEC.USER.ROLE.CHK:
******************
* In this para of the program, the user role is checked against security users
**
    USER.COUNT = DCOUNT(Y.USERROLES.LIST,FM)
    USER.CNT = 1
    LOCATE 'SEC.USER.ROLES' IN USERROLES.FN<1,1> SETTING USERROLE.POS THEN
       LOOP
*          REMOVE Y.USER.ROLES FROM Y.USERROLES.LIST SETTING ROLE.POS
*       WHILE Y.USER.ROLES : ROLE.POS
       WHILE USER.CNT LE USER.COUNT
         Y.USER.ROLES = Y.USERROLES.LIST<USER.CNT>   
         LOCATE Y.USER.ROLES IN USERROLES.FV<1,USERROLE.POS,1> SETTING FV.USERROLE.POS THEN
             LOCATE 'SEC' IN Y.SECROLES.FN<1,1> SETTING SECROLE.POS THEN
                TXNTYPES = Y.SECROLES.TXNTYPES.FV<1,SECROLE.POS>
*                CHANGE SM TO ' ' IN TXNTYPES
             END
         END
       USER.CNT += 1
       REPEAT
    END         

    RETURN 
*-----------------------------------------------------------------------------------------------------------------    
****************************    
GET.FIXED.SELECTION.DETAILS:
****************************
* In this para of the program, the fixed selection details are fetched
**    

    IF SEC.ROLE.IND EQ 'Y' THEN
       LOCATE 'FIXED.CRITERIA.AUTH' IN Y.SECROLES.FN<1,1> SETTING CRT.POS1 THEN
          Y.FX.CRT.UNAUTHVALS = FIELD(Y.SECROLES.TXNTYPES.FV,VM,CRT.POS1)
          CHANGE SM TO FM IN Y.FX.CRT.UNAUTHVALS
       END
    END ELSE
       LOCATE 'FIXED.CRITERIA.AUTH' IN Y.CASHROLES.FN<1,1> SETTING CRT.POS THEN
          Y.FX.CRT.UNAUTHVALS = FIELD(Y.CASHROLES.TXNTYPES.FV,VM,CRT.POS)
          CHANGE SM TO FM IN Y.FX.CRT.UNAUTHVALS
       END
    END
    
    GOSUB GET.FT.DETAILS
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------    
***************
GET.FT.DETAILS:
***************
* In this para of the program, FT records are selected
**

    IF FT.ID EQ '' THEN
        SB.SEL = "SELECT ":FN.FUNDS.TRANSFER.NAU
    END ELSE
        ID.IND = 'Y'
        SB.SEL = "SELECT ":FN.FUNDS.TRANSFER.NAU: " WITH @ID EQ '":FT.ID:"'"
    END

     CONVERT SM TO FM IN TXNTYPES
     CONVERT VM TO FM IN TXNTYPES
     TXNTYPES.CNT = DCOUNT(TXNTYPES,FM)

     I = 1
     LOOP
     WHILE I LE TXNTYPES.CNT
        IF TXNTYPES<I> NE '' THEN
           IF I EQ '1' AND ID.IND NE 'Y' THEN
              SB.SEL := " WITH TRANSACTION.TYPE NE '":TXNTYPES<I>:"' "
           END ELSE
              SB.SEL := " AND TRANSACTION.TYPE NE '":TXNTYPES<I>:"' "
           END
        END
        I += 1
     REPEAT
    Y.FXD.CRT.CNT = DCOUNT(Y.FX.CRT.UNAUTHVALS,FM)
    FOR I = 1 TO Y.FXD.CRT.CNT
            IF TXNTYPES EQ '' AND I EQ '1' THEN
             SB.SEL := " WITH ":Y.FX.CRT.UNAUTHVALS<I>
            END ELSE
            SB.SEL := " AND ":Y.FX.CRT.UNAUTHVALS<I>
            END
    NEXT I
     
    CALL EB.READLIST(SB.SEL,SEL.LIST,'',SB.SEL.CNT,SB.ERR)

    RETURN
*-----------------------------------------------------------------------------------------------------------------
END
