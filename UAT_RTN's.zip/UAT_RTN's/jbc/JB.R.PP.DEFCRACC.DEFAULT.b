SUBROUTINE JB.R.PP.DEFCRACC.DEFAULT
*-------------------------------------------------------------------------------------------------------
* This is a check rec Rtn to default Credit Account for incoming pacs004, if incoming pacs004 did not have
* sufficient details to derive credit account.
* Attached in PP.ORDER.ENTRY,JB.V.PP.ISO.AMEND as Check Rec Rtn
*
*-------------------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Resource           JIRA Ref           Remarks
* 08-APR-2025   Prabhu D S         CBPAY-1820         Initial draft
*-------------------------------------------------------------------------------------------------------
   $INSERT I_COMMON
   $INSERT I_EQUATE
   $INSERT I_F.PP.ORDER.ENTRY
   $INSERT I_F.POR.TRANSACTION

   FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
   F.POR.TRANSACTION = ''
   CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)

   IF R.NEW(PP.OEYG.IncomingMessageType) EQ 'pacs.004' AND R.NEW(PP.OEYG.CreditAccountNumber) EQ '' THEN
      ORIG.TXN.REF = R.NEW(PP.OEYG.OriginalTransactionRef)
      CALL F.READ(FN.POR.TRANSACTION,ORIG.TXN.REF,R.POR.TRANSACTION,F.POR.TRANSACTION,'')
      IF R.POR.TRANSACTION THEN
         R.NEW(PP.OEYG.CreditAccountNumber) = R.POR.TRANSACTION<PPPTX.DebitMainAccount>
      END
   END

RETURN
END
