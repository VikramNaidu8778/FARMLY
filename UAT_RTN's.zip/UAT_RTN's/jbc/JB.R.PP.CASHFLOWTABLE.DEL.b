*-----------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
*-----------------------------------------------------------------------------------
* Description:
* The purpose of the routine is to DELETE the payment details from the local table
* JB.L.PP.CASHFLOWDATA when delete/authorise the payment.
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date                Developer           Reference           Description
*-----------------------------------------------------------------------------------
* 25/03/2025          P Amala             CBPAY-65          Initial Version
*-----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JB.L.PP.CASHFLOWDATA

    GOSUB INIT.FILES
    GOSUB PROCESS

RETURN

*------------------------------------------------------------------------------
INIT.FILES:
***********
       
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA)
	
	PP.ID.POS = '' ; R.PP.CASHFLOWDATA = '' ; Y.PP.CSHFLW.ERR = ''
	PP.IDS.CNT = '' ; Y.PP.TRANS.IDS = ''
	
RETURN
*------------------------------------------------------------------------------
PROCESS:
********

    CALL F.READ(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA,Y.PP.CSHFLW.ERR)
    IF R.PP.CASHFLOWDATA NE '' THEN
        PP.IDS.CNT = DCOUNT(R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF>,VM)
        Y.PP.TRANS.IDS = R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF>

        IF PP.IDS.CNT EQ '1' THEN
            CALL F.DELETE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT)
            R.PP.CASHFLOWDATA = ''
        END ELSE
	        LOCATE FTNo IN Y.PP.TRANS.IDS<1,1> SETTING PP.ID.POS THEN
			
                DEL R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF,PP.ID.POS>
                DEL R.PP.CASHFLOWDATA<JB.PPCASH.PROC.DATE,PP.ID.POS>
                DEL R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.AMOUNT,PP.ID.POS>
                CALL F.WRITE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA)
                R.PP.CASHFLOWDATA = ''
            END ELSE
                LOCATE Y.PP.ID IN Y.PP.TRANS.IDS<1,1> SETTING PP.ID.POS THEN
                    DEL R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF,PP.ID.POS>
                    DEL R.PP.CASHFLOWDATA<JB.PPCASH.PROC.DATE,PP.ID.POS>
                    DEL R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.AMOUNT,PP.ID.POS>
                    CALL F.WRITE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA)
                    R.PP.CASHFLOWDATA = ''
                END
            END
        END
	END
RETURN
