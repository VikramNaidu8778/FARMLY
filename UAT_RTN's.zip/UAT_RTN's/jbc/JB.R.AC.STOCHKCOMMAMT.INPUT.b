SUBROUTINE JB.R.AC.STOCHKCOMMAMT.INPUT
*-----------------------------------------------------------------------------------------------
* This is an Input Routine to check user inputted commission amount against
* configured amount in FT.COMMISSION.TYPE for FTOTPAY0000 and raise override
* if user inputted amount is greater then configured amount.
*-----------------------------------------------------------------------------------------------
* Modification History :
** Date              Developer               Reference           Description
*-----------------------------------------------------------------------------------------------
* 23-JUL-2024        Prabhu D S              CBPAY-650           Inital Draft
*
* 07-APR-2025       Lakshmi Priya            CBPAY-1971    Included logic to default STO Commission Type, and to default 
*                                                           Charge amount from FT.CHARGE.TYPE table based on debit Currency . 
*
* 22-APR-2025       Lakshmi Priya            CBPAY-2558    Included logic to default Charge amount only if Charge Currency is 
*                                                            Present in FT.CHARGE.TYPE Table .
* 28/06/25          Prabhu D S              CBPAY-2677     Included logic to handle Value date.
*
* 01/07/2025        Lakshmi Priya            CBPAY-3498    Included logic to only default corr bank fees if debit account 
*                                                               currency matches with payment currency .
*-----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.FT.COMMISSION.TYPE
    $INSERT I_F.FT.CHARGE.TYPE

    GOSUB INIT
    GOSUB READ.ACCOUNT
    GOSUB PROCESS
    GOSUB CHK.COMMISSION.AMT

RETURN
*****
INIT:
*****
    FN.FT.COMMISSION.TYPE = "F.FT.COMMISSION.TYPE"
    F.FT.COMMISSION.TYPE = ""
    CALL OPF(FN.FT.COMMISSION.TYPE,F.FT.COMMISSION.TYPE)

    FN.FT.CHARGE.TYPE = "F.FT.CHARGE.TYPE"
    F.FT.CHARGE.TYPE = ""
    CALL OPF(FN.FT.CHARGE.TYPE,F.FT.CHARGE.TYPE)

    FN.ACCOUNT = "F.ACCOUNT"
    F.ACCOUNT = ""
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","OUT.CLCHG.TYPE",Y.COMM.ID)
    CURR.NO = R.NEW(STO.CURR.NO)
    Y.STO.COM.CCY = R.NEW(STO.COMMISSION.AMT)[1,3]
    Y.STO.COM.AMT = R.NEW(STO.COMMISSION.AMT)[4,99]
    Y.STO.CR.CCY = R.NEW(STO.CURRENCY)

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","FT.CHARGE.TYPE",Y.CHG.TYPE)	
    Y.STO.CHG.CCY = R.NEW(STO.CURRENCY)
    Y.COMMISSION.CODE = R.NEW(STO.COMMISSION.CODE)
    Y.DEBIT.ACC = FIELD(ID.NEW,".",1)

    R.FT.COMM.TYPE = ''

RETURN

**************
READ.ACCOUNT:
**************
    
    CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACC,R.DEBIT.ACC,F.ACCOUNT,F.ERR)
    IF R.DEBIT.ACC THEN
       Y.DEBIT.CURR = R.DEBIT.ACC<AC.CURRENCY>
    END

    CALL F.READ(FN.FT.COMMISSION.TYPE,Y.COMM.ID,R.FT.COMM.TYPE,F.FT.COMMISSION.TYPE,'')
    IF R.FT.COMM.TYPE THEN
       FT.COMM.AMT = R.FT.COMM.TYPE<FT4.FLAT.AMT>
       FT.COMM.CCY = R.FT.COMM.TYPE<FT4.CURRENCY>
    END

   Y.STO.CHG.AMT = ''
   IF Y.CHG.TYPE THEN
      CALL F.READ(FN.FT.CHARGE.TYPE,Y.CHG.TYPE,R.CHG.TYPE,F.FT.CHARGE.TYPE,FT.CHG.ERR)
      Y.FT.CHARGE.TYPES.CURR = R.CHG.TYPE<FT5.CURRENCY>
      Y.FT.CHARGE.TYPES.VAL = R.CHG.TYPE<FT5.FLAT.AMT>
      IF Y.STO.CHG.CCY THEN
         LOCATE Y.STO.CHG.CCY IN Y.FT.CHARGE.TYPES.CURR<1,1> SETTING Y.CHG.POS THEN
	        Y.STO.CHG.AMT = Y.FT.CHARGE.TYPES.VAL<1,Y.CHG.POS>
         END
      END
   END

RETURN 

********
PROCESS:
*********

   IF Y.COMMISSION.CODE EQ "WAIVE" THEN
       R.NEW(STO.COMMISSION.TYPE) = ''
       R.NEW(STO.COMMISSION.AMT) = ''
       R.NEW(STO.CHARGE.AMT) =  ''
       R.NEW(STO.BEN.OUR.CHARGES) = ''
       R.NEW(STO.CHARGE.TYPE) = ''
   END ELSE
       BEGIN CASE
         CASE R.NEW(STO.BEN.OUR.CHARGES) MATCHES "BEN":@VM:"SHA"
             R.NEW(STO.COMMISSION.TYPE) = Y.COMM.ID
             IF NOT(R.NEW(STO.COMMISSION.AMT)) THEN
                GOSUB GET.EXCH.RATE
                R.NEW(STO.COMMISSION.AMT) = Y.STO.CR.CCY:" ":SELL.AMT
             END

         CASE R.NEW(STO.BEN.OUR.CHARGES) EQ "OUR" AND (Y.STO.CHG.CCY EQ Y.DEBIT.CURR )
             R.NEW(STO.COMMISSION.TYPE) = Y.COMM.ID
             IF NOT(R.NEW(STO.COMMISSION.AMT)) THEN
               GOSUB GET.EXCH.RATE
               R.NEW(STO.COMMISSION.AMT) = Y.STO.CR.CCY:" ":SELL.AMT
             END
             R.NEW(STO.CHARGE.TYPE) = Y.CHG.TYPE
             IF Y.STO.CHG.AMT THEN
                R.NEW(STO.CHARGE.AMT) = Y.STO.CHG.CCY:" ":Y.STO.CHG.AMT
             END ELSE
                R.NEW(STO.CHARGE.AMT) = Y.STO.CHG.CCY:" 0.00"
             END
          
       END CASE
   END

RETURN

*******************
CHK.COMMISSION.AMT:
*******************

    IF R.FT.COMM.TYPE THEN       
        GOSUB GET.EXCH.RATE
        STO.CHK.AMT = R.NEW(STO.COMMISSION.AMT)[4,99]
        IF STO.CHK.AMT GT SELL.AMT THEN
            TEXT = "EB-JB.AC.CHK.COMMAMT":@FM:R.NEW(STO.COMMISSION.AMT):@VM:SELL.CCY:' ':SELL.AMT
            CURR.NO += 1
            CALL STORE.OVERRIDE(CURR.NO)
        END
    END

RETURN

**************
GET.EXCH.RATE:
**************

   CCY.MKT = "1"
   BUY.CCY = FT.COMM.CCY
   SELL.CCY = Y.STO.CR.CCY
   BUY.AMT = FT.COMM.AMT
   SELL.AMT = ""
   EXCH.RATE = ""
   DIFFERENCE = ""
   LCY.AMT = ""
   RETURN.CODE = ""
   CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCH.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)


RETURN
END
