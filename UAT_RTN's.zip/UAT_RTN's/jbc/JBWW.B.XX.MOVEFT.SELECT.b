*----------------------------------------------------------------------------------------------------------------
	SUBROUTINE JBWW.B.XX.MOVEFT.SELECT
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the select routine of the multi thread job that moves the few application
* records placed in INAU and with processing date less than today
*----------------------------------------------------------------------------------------------------------------
* Attached: to 
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date               who              Reference            Description
* 05-07-2018        Smitha             Day15-1072        Initial Version
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_JBWW.B.XX.MOVEFT.COMMON
*-----------------------------------------------------------------------------------------------------------------
	
        Y.DAY = TODAY
	SEL.CMD = "SELECT ":FN.FUNDS.TRANSFER$NAU:" WITH RECORD.STATUS EQ 'INAU' AND STATUS EQ 'IFWD' AND PROCESSING.DATE LE ":Y.DAY  
        CALL EB.READLIST(SEL.CMD,SEL.LIST,NO.OF.REC,"",SEL.ERR)
	CALL BATCH.BUILD.LIST("",SEL.LIST)
	
	RETURN

*-----------------------------------------------------------------------------------------------------------------
END