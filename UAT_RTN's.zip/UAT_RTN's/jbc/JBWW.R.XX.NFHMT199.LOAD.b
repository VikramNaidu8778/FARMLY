* @ValidationCode : MToxMDkxNjY4MjkzOklTTy04ODU5LTE6MTYwMzM0MTA3MTA5MzphNDA3NzA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 22 Oct 2020 12:31:11
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40770
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.XX.NFHMT199.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.DE.HEADER
	$INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.SFCONF.CONFIRMATION.TRACKER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.ACCOUNT
	$INSERT I_F.CUSTOMER
	$INSERT I_F.DEPT.ACCT.OFFICER
	$INSERT I_F.USER
	$INSERT I_F.DATES
	$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
	$INSERT I_F.JBWW.L.XX.DOHREF.CONCAT
	$INSERT I_JBWW.R.XX.NFHMT199.COMMON
*-----------------------------------------------------------------------------

    FN.DE.O.HEADER = 'F.DE.O.HEADER'
    F.DE.O.HEADER = ''
    CALL OPF(FN.DE.O.HEADER,F.DE.O.HEADER)
    
    FN.DE.I.HEADER = 'F.DE.I.HEADER'
    F.DE.I.HEADER = ''
    CALL OPF(FN.DE.I.HEADER,F.DE.I.HEADER)
    
    FN.JBWW.L.XX.DOHREF.CONCAT = 'F.JBWW.L.XX.DOHREF.CONCAT'
    F.JBWW.L.XX.DOHREF.CONCAT = ''
    CALL OPF(FN.JBWW.L.XX.DOHREF.CONCAT,F.JBWW.L.XX.DOHREF.CONCAT)
    
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
    
    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)
    
    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)
    
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    
    FN.DEPT.ACCT.OFFICER = 'F.DEPT.ACCT.OFFICER'
    F.DEPT.ACCT.OFFICER = ''
    CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)
    
    FN.JBWW.L.XX.NOTIFICATION.REQUEST = 'F.JBWW.L.XX.NOTIFICATION.REQUEST'
    F.JBWW.L.XX.NOTIFICATION.REQUEST = ''
    CALL OPF(FN.JBWW.L.XX.NOTIFICATION.REQUEST,F.JBWW.L.XX.NOTIFICATION.REQUEST)
    
    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)
       
    INC.TIME.VALS = BATCH.DETAILS<3>

RETURN    
END
