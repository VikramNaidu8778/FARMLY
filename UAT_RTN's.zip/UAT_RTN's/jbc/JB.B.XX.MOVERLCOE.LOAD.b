*----------------------------------------------------------------------------------------------------------------
SUBROUTINE JB.B.XX.MOVERLCOE.LOAD
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the load routine of the multi thread job that moves Order Entry application
* records placed for authorization
*----------------------------------------------------------------------------------------------------------------
*----------------------------------------------------------------------------------------------------------------
* Attached: to
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date           Developer           Reference             Description
* 04-Jun-2025    Prabhu D S          CBPAY-2933            Initial Draft
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_BATCH.FILES
    $INSERT I_JB.B.XX.MOVEOE.COMMON

    FN.PP.ORDER.ENTRY.NAU = "F.PP.ORDER.ENTRY$NAU"
    F.PP.ORDER.ENTRY.NAU = ""
    CALL OPF(FN.PP.ORDER.ENTRY.NAU, F.PP.ORDER.ENTRY.NAU)

    CALL GET.LOC.REF("PP.ORDER.ENTRY","L.XX.BLK.CODE",L.BLK.CODE)

    RETURN
END

