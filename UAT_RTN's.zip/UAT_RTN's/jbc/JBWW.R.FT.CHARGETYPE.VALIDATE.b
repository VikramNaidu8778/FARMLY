
*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.CHARGETYPE.VALIDATE
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------

* 19/05/2017	SUSHMITHA B		 JB2A-30320                   Attached as validation routine to CHARGE.TYPE in version
*                                                            FUNDS.TRANSFER,JBWW.V.FT.OT103.INP,FUNDS.TRANSFER,JBWW.V.FT.OT103COVER.INP and FUNDS.TRANSFER,JBWW.V.FT.OT60.INP
* 12/07/2017    Balaji Pushparaj JB2A-36905                  Additional condition check to default CHARGE.FOR field.     
* 31/08/2017    Balaji Pushparaj JB2A-37794                  Converted as Validation routine to handle charge type validations    
* 06/11/2017    Parameshwari	 JB2A_44754					 Additional validation has been added to default the value in CHARGE.FOR field.  
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.FUNDS.TRANSFER
*-------------------------------------------------------------------------

    GOSUB PROCESS

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********
*Y.CHARGE.TYPE = R.NEW(FT.CHARGE.TYPE) ;*JB2A-37794
	Y.CHARGE.TYPE = COMI ;*JB2A-37794
	IF Y.CHARGE.TYPE EQ 'CORRBKCHG' AND R.NEW(FT.BEN.OUR.CHARGES) EQ 'OUR' THEN  ;*JB2A-36905
		IF R.NEW(FT.SEND.PAYMENT.Y.N) EQ 'Y' THEN								 ;*JB2A_44754
			R.NEW(FT.CHARGE.FOR) = "RECEIVER"
		END ELSE
			R.NEW(FT.CHARGE.FOR) = ''
		END
	END
	RETURN
*--------------------------------------------------------------------------
    END