    SUBROUTINE JBWW.R.FT.VALUEDATE.VALIDATE 
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the validation routine attached to the field CREDIT.VALUE.DATE in FT Draft versions.
* It is used to default the CREDIT.VALUE.DATE field with DEBIT.VALUE.DATE value.
*---------------------------------------------------------------------------------------------
* Attached: to versions FUNDS.TRANSFER,JBWW.V.FT.ODFCY.INP ,FUNDS.TRANSFER,JBWW.V.FT.OD110.INP 
* ,FUNDS.TRANSFER,JBWW.V.FT.OD103.INP, FUNDS.TRANSFER,JBWW.V.FT.OT102.INP  
* ,FUNDS.TRANSFER,JBWW.V.FT.OT103.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT103PLUS.INP 
* ,FUNDS.TRANSFER,JBWW.V.FT.OT103REMIT.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT103COVER.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT400.INP 
* ,FUNDS.TRANSFER,JBWW.V.FT.OT400202.INP ,FUNDS.TRANSFER,JBWW.V.FT.ITLCYVOST.INP ,FUNDS.TRANSFER,JBWW.V.FT.ITFCYNOST.INP 
* FUNDS.TRANSFER,JBWW.V.FT.ACTR.INP and FUNDS.TRANSFER,JBWW.V.FT.INW.INP 
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*-------------------------------------------------------------------------------------------
* Date               who               Reference          Description
* 26-04-2016        Rekha M             PMT-005         Initial Version
* 10-10-2017		Balaji 			   JB2A-42349		To Update ORD.CUST.ACCT field with DEBIT.ACCT.NO field
*-------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
	
    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
******************************************************************
INITIALISE:
***********
    Y.DRVAL.DATE = ''
    Y.DRVAL.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
	
*S-JB2A-42349
	FN.JBWW.H.EB.GENERICPARAMETER = "F.JBWW.H.EB.GENERICPARAMETER"
	F.JBWW.H.EB.GENERICPARAMETER = ""
	CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
*E-JB2A-42349

    RETURN
******************************************************************
PROCESS:
***********
    IF Y.DRVAL.DATE THEN
      COMI = Y.DRVAL.DATE 
    END

*S-JB2A-42349
	R.JBWW.H.EB.GENERICPARAMETER = "" ; JBWW.H.EB.GENERICPARAMETER.ERR = ""
	CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.FT.SWIFT.VERSION",R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,JBWW.H.EB.GENERICPARAMETER.ERR)
		IF R.JBWW.H.EB.GENERICPARAMETER NE "" THEN
			Y.FIELD.NAME.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
			Y.FIELD.VALUE.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE>
				LOCATE "TAG50.VERSION.LIST" IN Y.FIELD.NAME.LIST<1,1> SETTING TAG50.VERS.POS THEN
					Y.TAG50.VERSION.LIST = Y.FIELD.VALUE.LIST<1,TAG50.VERS.POS>
					CHANGE SM TO VM IN Y.TAG50.VERSION.LIST
				END
				Y.CURRENT.VERSION = APPLICATION:PGM.VERSION
				LOCATE Y.CURRENT.VERSION IN Y.TAG50.VERSION.LIST<1,1> SETTING CURR.VERS.POS THEN
					R.NEW(FT.ORD.CUST.ACCT) = R.NEW(FT.DEBIT.ACCT.NO)
				END
		END
*E-JB2A-42349

    RETURN	
********************************************************************
END	



