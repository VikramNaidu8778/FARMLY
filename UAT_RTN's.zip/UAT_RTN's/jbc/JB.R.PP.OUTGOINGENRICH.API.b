SUBROUTINE JB.R.PP.OUTGOINGENRICH.API(iPaymentDets,iIFEmitDets,oUpdatePaymentObject,oEnrichIFDets,oChangeHistory,iOReserved1, iOReserved2, iOReserved3, iOReserved4, iOReserved5)
*------------------------------------------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------------------------------------------
* This is an Enrichment API attached in PP.CLEARING>SWIFTMX for below scenarios:
* 1. To replace T24 Account with Alternate Account for TAG <Dbtr>
*---------------------------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: iPaymentDets,iIFEmitDets
* OUT: oUpdatePaymentObject,oEnrichIFDets,oChangeHistory,iOReserved1, iOReserved2, iOReserved3, iOReserved4, iOReserved5
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------------
*6-04-2024         vikram pavuluru    CBPAY-321          This routine is to fetch the alternate account(BJB.ACCT) account and
*                                                          displays in the 50K TAG as requested by the client. This routine is attached in
*                                                          PP.CLEARING > SWIFTMX record as a Enrichoutmessageapi.
*
*03-01-2024        vikram pavuluru    CBPAY-1483         Added Logic for replacing Beneficiary bank for HKCHATS for outgoing pacs.008, Pacs.009 , Pacs.009 COV.
*
*14-02-2025        Resmi R            CBPAY-1913         Updated the logic to include Alternate Account number in the DbtrAcct tag in pacs.009cov
*
*28-01-2025        Resmi.R            CBPAY-1639         Included the logic to suppress the TAG72 in the Outgoing Message
*
*30-01-2025        Lakshmi priya      CBPAY-1727         Included logic to update TAG22 in FD/SWAP.
*
*13-02-2025        Resmi.R            CBPAY-1639         Included logic to suppress TAG52A when the Party Identifier code is same as value parameterised in the JBWW.H.EB.GENERICPARAMETER>JBWW.D.XX.BICCODE
*
*28-02-2025        Prabhu D S         CBPAY-2004         Round Off done for Exchange Rate if total lenght has more than 12 digit to maintain ISO standard
*
*20-03-2025        vikram pavuluru    CBPAY-1742         Added Logic for replacing Beneficiary bank for HKCHATS for outgoing pacs.004.
*05-04-2025        Prabhu D S         CBPAY-2349         Incase Debtor is Nostro, then Debtor Account should be External reference of Creditor Settlement
*                                                        Account (Only for Bank Transfers).
*10-04-2025        Prabhu D S         CBPAY-2395         Debtor Account should be alternate account(BJB.ACCT) account for CHATSMX as well.
*
*14-05-2025        Prabhu D S         CBPAY-2768         Logic handled to update external account for Debtor Account
*17-05-2025        Kandan.K           CBPAY-2765         Logic handled to update external account for Debtor Account for OTKI / OTOP / OT22
*25-05-2025		   Kandan.K           CBPAY-2935         Logic handled to update alternate account for all MT103/202 , fixed XSD validation. 
*21-06-2025        Prabhu D S         CBPAY-3182         DebtorBIC should be as same as OrderingBIC for OT22 in camt.057 message
*26-06-2025        Prabhu D S         CBPAY-3508         DebtorAccount in pacs009cov displays mnemonic value
*28-06-2025        Prabhu D S         CBPAY-3358         Logic included for handling DebtorAccount in pacs.009 messages
*03-07-2025        Prabhu D S         CBPAY-2653         Logic included for handling DebtorAccount in pacs.009 messages
*--------------------------------------------------------------------------------------------------------------------------------------


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.POR.TRANSACTION
    $USING PP.CreditPartyDeterminationService
    $USING PP.DebitPartyDeterminationService
    $USING PP.OutboundCodeWordService
    $USING PP.OutwardInterfaceService
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB INIT
    GOSUB UPDATE.HKCHATS.BENBANK
    GOSUB UPDATE.TAG72
    GOSUB UPDATE.TAG22
    GOSUB UPDATE.TAG52A
    GOSUB PROCESS.TAG.50K

    iIFEmitDets<3> = LOWER(iPorTransactionDets)
    iIFEmitDets<4> = LOWER(iCreditPartyDets)
    iIFEmitDets<5> = LOWER(iOrderingPartyDetails)
    iIFEmitDets<8> = LOWER(iAccountInfo)
    iIFEmitDets<15> = LOWER(iRemitInfo)
        
    oEnrichIFDets = iIFEmitDets
   
RETURN

*****
INIT:
*****

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)
    
    FN.JBWW.T.XX.UPDUNIQUE.REF = "F.JBWW.T.XX.UPDUNIQUE.REF"
    F.JBWW.T.XX.UPDUNIQUE.REF = ""
    CALL OPF(FN.JBWW.T.XX.UPDUNIQUE.REF,F.JBWW.T.XX.UPDUNIQUE.REF)
    
     
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","HKCHATS.ACWINS.BIC",Y.GPM.VALUE)
       
    Y.AC.ID = ''
    Y.AC.ALT.ACCT.TYPE = ''
    Y.AC.ALT.ACCT.ID = ''
    YY.ALT.ACCT.ID = ''
    
    iPaymentID = FIELD(iPaymentDets, "*",2)
    iPorTransactionDets = RAISE(iIFEmitDets<3>)
    iCreditPartyDets = RAISE(iIFEmitDets<4>)
    iRemitInfo = RAISE(iIFEmitDets<15>)
    iAccountInfo = RAISE(iIFEmitDets<8>)
    iOrderingPartyDetails = RAISE(iIFEmitDets<5>)

    CALL F.READ(FN.POR.TRANSACTION,iPaymentID,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)
        
    OutputChannel = iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.clearingChannel>
    TxnCcy = iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.transactionCurrencyCode>
    iTxnRef = iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.messageUserReference>
    
RETURN

****************
PROCESS.TAG.50K:
****************
* This para should be called as last, since we are replacing Original Account Number with Alternate id.
* We perform all our checks and validations based on Original Account Number and then we replace.

    iChrgActype = '' ; iIncomingMsgType = '' ;
    iChrgActype = iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.mainOrChargeAccType>
    iIncomingMsgType =  iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.incomingMsgType>
    iOutgoingMsgType = iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.outgoingMessageType>
    Y.AC.ID = '' ; ChrgActPos = '' ; CreditAccPos = '' ;
* DbtrAcct Tag should not be populate for Outgoing pacs.009 originated from POA and OE.
    IF (iOutgoingMsgType EQ 'pacs.009') OR (iOutgoingMsgType EQ 'pacs.009AD') THEN
* pacs.009 orginiates from POA
        LOCATE "ORDPTY" IN iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyRole,1> SETTING ExtActPos THEN
           Y.AC.ID = iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyAccountLine,ExtActPos>
           CHANGE Y.AC.ID TO '' IN iOrderingPartyDetails
        END ELSE
* pacs.009 originates from OE
           LOCATE 'D' IN iChrgActype<1,1> SETTING ChrgActPos THEN
             Y.AC.ID = iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.accountNumber,ChrgActPos>
             CHANGE Y.AC.ID TO '' IN iAccountInfo
           END
        END
    END ELSE
        GOSUB FETCH.ALT.ACCT.ID
  *      iIFEmitDets = EREPLACE(iIFEmitDets,Y.AC.ID,Y.ALT.ACCT.ID)
    END

    IF iIncomingMsgType EQ 'OT22' THEN
       LOCATE "ORDPTY" IN iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyRole,1> SETTING DrPtyPos THEN
          OrdPtyBIC = iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyIdentifierCode,DrPtyPos>
          iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.identifierCode,ChrgActPos> = OrdPtyBIC
       END
    END
        
RETURN

******************
FETCH.ALT.ACCT.ID:
******************
* If Debit Account is Client account, then enrich Alternate reference (ACCOUNT>BJB.ACCT) in DbtrAcct tag

    LOCATE "ORDPTY" IN iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyRole,1> SETTING ExtActPos THEN
      Y.AC.ID = iOrderingPartyDetails<PP.DebitPartyDeterminationService.PartyDebitDetails.debitPartyAccountLine,ExtActPos>
      CALL F.READ(FN.ACCOUNT,Y.AC.ID,R.ACCT,F.ACCOUNT,AC.ERR)

      IF R.ACCT NE '' THEN
          Y.AC.ALT.ACCT.TYPES = R.ACCT<AC.ALT.ACCT.TYPE>
          Y.AC.ALT.ACCT.IDS = R.ACCT<AC.ALT.ACCT.ID>
* For pacs.008 , for internal account , same has to be sent.
          LOCATE "BJB.ACCT" IN Y.AC.ALT.ACCT.TYPES<1,1> SETTING AltPos THEN
               Y.ALT.ACCT.ID = Y.AC.ALT.ACCT.IDS<1,AltPos>
           END
	   IF Y.ALT.ACCT.ID THEN
              CHANGE Y.AC.ID TO Y.ALT.ACCT.ID IN iOrderingPartyDetails
           END
      END
    END

RETURN
    
*********************
UPDATE.HKCHATS.BENBANK:
*********************
*If crPartyRoleIndic matches 'G' or 'D' applicable for outgoing Pacs.008, Pacs.009 , Pacs.009 COV
*If crPartyRoleIndic matches 'G' or 'D' or 'R' applicable for outgoing Pacs.004

    IF OutputChannel EQ 'CHATSMX' AND TxnCcy MATCHES 'CNY' :@VM: 'CNH' THEN
        LOCATE "RECVER" IN iCreditPartyDets<PP.CreditPartyDeterminationService.CreditPartyDetails.crPartyRole,1> SETTING AltPos THEN
            IF iCreditPartyDets<PP.CreditPartyDeterminationService.CreditPartyDetails.crPartyRoleIndic,AltPos> MATCHES  'G' :@VM: 'D' :@VM: 'R' THEN
                IF iCreditPartyDets<PP.CreditPartyDeterminationService.CreditPartyDetails.crPartyIdentifCode,AltPos>[5,2] NE 'HK' THEN
                    iCreditPartyDets<PP.CreditPartyDeterminationService.CreditPartyDetails.crPartyIdentifCode,AltPos> = Y.GPM.VALUE
                END
            END
        END
    END
    
RETURN

************
UPDATE.TAG72:
************

    IF iTxnRef[1,2] EQ "FD" THEN

        CALL JBWW.R.EB.GETGENPARM.VAL("FD.SWIFT.PARAM", "BANK.TO.BANK", GPM.FLD.VALUES)
        CHANGE FM TO VM IN GPM.FLD.VALUES
   
        iInfoCode = iRemitInfo<PP.OutboundCodeWordService.OutboundInfDetails.informationCode>
    
        yInfoCode.cnt = DCOUNT(iInfoCode,@VM)
    
        yinit = 1

        LOOP
        WHILE yinit LE yInfoCode.cnt
    
            yInfoCode = iInfoCode<1,yinit>
       
            IF yInfoCode EQ 'INSSDR' THEN
    
                iInfline = iRemitInfo<PP.OutboundCodeWordService.OutboundInfDetails.informationLine,yinit>
         
                IF iInfline MATCHES GPM.FLD.VALUES THEN
    
                    iRemitInfo<PP.OutboundCodeWordService.OutboundInfDetails.informationLine,yinit> = ''
                    iRemitInfo<PP.OutboundCodeWordService.OutboundInfDetails.informationCode,yinit> = ''

                END
            END
    
            yinit +=1

        REPEAT
        
    END
    
RETURN

*************
UPDATE.TAG22:
*************
* CBPAY-2964      
*    IF iTxnRef[1,2] MATCHES 'FD':@VM:'SW' THEN
*        GOSUB READ.UPDUNIQUE.REF
*        iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.messageUserReference> = R.UPDUNIQUE
*    END

* Rounding Off Exchange Rate if it has more than 12 digit to comply with ISO standard.

    yExchangeRate = iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.exchangeRate>

    IF LEN(yExchangeRate) GT 12 THEN
        iPorTransactionDets<PP.OutwardInterfaceService.PorTransactionRTGS.exchangeRate> = DROUND(yExchangeRate,8)
    END
    
RETURN
    
******************
READ.UPDUNIQUE.REF:
******************

    CALL F.READ(FN.JBWW.T.XX.UPDUNIQUE.REF,iTxnRef,R.UPDUNIQUE,F.JBWW.T.XX.UPDUNIQUE.REF,Y.UPD.ERR)
    IF R.UPDUNIQUE THEN
        Y.SEQ = R.UPDUNIQUE<1>
        Y.SEQ = FIELD(Y.SEQ,'-',2)
        Y.SEQ = Y.SEQ + 1
        IF Y.SEQ EQ '1000' THEN
            Y.SEQ = '1'
        END
        Y.SEQ = FMT(Y.SEQ,"R%3")
    END ELSE
        Y.SEQ = '1'
        Y.SEQ = FMT(Y.SEQ,"R%3")
    
    END
    R.UPDUNIQUE = iTxnRef:'-':Y.SEQ
    CALL F.WRITE(FN.JBWW.T.XX.UPDUNIQUE.REF,iTxnRef,R.UPDUNIQUE)
    
    
RETURN
 
**************
UPDATE.TAG52A:
**************
 
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.D.XX.BICCODE",ID.COMPANY,Y.GPM.VALUES)
    CHANGE FM TO VM IN Y.GPM.VALUES
    
    iChrgActype = iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.mainOrChargeAccType>
        
    LOCATE 'D' IN iChrgActype<1,1> SETTING ChrgActPos THEN
        Y.PRTY.IDF.CODE = iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.identifierCode,ChrgActPos>
        IF Y.PRTY.IDF.CODE MATCHES Y.GPM.VALUES THEN
            iAccountInfo<PP.OutwardInterfaceService.PorAccountInfo.identifierCode,ChrgActPos> = ''
        END
    END
 
RETURN

***************************************************************************
END
