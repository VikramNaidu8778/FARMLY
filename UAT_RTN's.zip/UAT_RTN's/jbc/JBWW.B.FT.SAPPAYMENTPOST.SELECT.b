* @ValidationCode : MTozMjA2MDIxNDA6SVNPLTg4NTktMToxNTM5MjYxNTgyNjU5OmE0NTMyODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 11 Oct 2018 20:39:42
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.B.FT.SAPPAYMENTPOST.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 01-10-2018        Sakthivel S           P3369-249                Interface Multi threaded routine to POST FT entries
*                                                                   which was sent from SAP
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_JBWW.B.FT.SAPPAYMENTPOST.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.COMPANY    
*-----------------------------------------------------------------------------
    SEL.FILE.PATH = '' ; SEL.FILE.LIST = '' ; NO.OF.FILES = "" ; SEL.FILE.ERR = '' ;

* To select the file from SAP which was placed inside T24
    IF CONTROL.LIST<1,1> EQ '' THEN
        SEL.FILE.PATH = "SELECT ":FN.FILE.PATH
        CALL EB.READLIST(SEL.FILE.PATH,SEL.FILE.LIST,'',NO.OF.FILES,SEL.FILE.ERR)

        IF SEL.FILE.LIST NE '' THEN
            CONTROL.LIST<-1> = SEL.FILE.LIST
        END
    END
    IF CONTROL.LIST<1,1> NE '' THEN
        FILE.PRFX = "FT_":R.COMPANY(EB.COM.MNEMONIC)
        Y.CUR.FILE.NAME = CONTROL.LIST<1,1>
        R.FILE.OFS.MSGS = '' ; FILE.READ.ERR = ''
        CALL F.READ(FN.FILE.PATH,Y.CUR.FILE.NAME,R.FILE.OFS.MSGS,F.FILE.PATH,FILE.READ.ERR)
        * To filter the unnecessary files
        IF Y.CUR.FILE.NAME[1,6] NE FILE.PRFX THEN
            R.FILE.OFS.MSGS = ''
        END ELSE
            GOSUB MOVE.FILES
        END
    END

    CALL BATCH.BUILD.LIST('',R.FILE.OFS.MSGS)

    RETURN

MOVE.FILES:
* To move the processed files from 'in' folder to 'done' folder
    MOVE.CMD = "SH -c mv ":FN.FILE.PATH:"/":Y.CUR.FILE.NAME:" ":FN.ARC.PATH
    EXECUTE MOVE.CMD

    RETURN
    END
