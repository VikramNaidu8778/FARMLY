*-----------------------------------------------------------------------------
* <Rating>-42</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.CALCGSTAMT.INPUT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 21/12/2016    priyadarshni.priyanka@cognizant.com     CR-162                  Initial Version
* 17/02/2017    Balaji.Pushparaj@cognizant.com          Defect Fix - 27252      Trigger routine Only if Debit or Credit has "PL"
* 04/04/2017    Vidya A                                 JB2A-29009              Changes in Looping condition
* 08/06/2017    Lokesh B                                JB2A-34263              Populate the correct GST amount
* 20/02/2018    MaheshKumar                             JB2A-48744              Removed Generice parameter setting to calculate the GST.AMT and used core GST table for calcuating the GST.AMT
* 24/04/2018    Ashwin                                  JB2A-51559              Applied round off logic for GST.
* 09/07/2018    Rajagopalan R                           DAY15-771               Finance GST Enabling the Reversal Marker for CR-162 FT Version
* 09/09/2022    Madhu                                   P-3998                  Added the processing date as out argument in call routine
* 16/11/2022    D Suresh                                P.3948                  ACU DBU Decommission
* 07/08/2023    Madhu                                  FSQD-3481                Amended the routine to cater HK GST
* 14/03/2024    Jeeva/Madhu                            L1TAXGST                 Modified the routine as part of L1TAXGST 
*--------------------------------------------------------------------------------------------
* Description : This is new input routine to be attached to lst of versions.
*               The routine will check the internal account and generate GSTAMOUNT.
*                If the internal account is not existing then raise an error message.
* Attached as : Input Routine
**----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.AU.RULE
    $INSERT I_F.AU.APP.RULE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
**----------------------------------------------------------------------------------------------
* DAY15-771 Changes Start
    IF V$FUNCTION EQ 'I' THEN
            
        GOSUB INIT
        GOSUB GET.LOCAL.FIELD
        Y.BK.FLAG = ''
        IF R.NEW(FT.DEBIT.ACCT.NO)[1,3] EQ 'PL5' OR R.NEW(FT.CREDIT.ACCT.NO)[1,3] EQ 'PL5' THEN ;*JB2A-27252
            IF ID.COMPANY[1,2] EQ 'HK' AND R.NEW(FT.DEBIT.VALUE.DATE) GE Y.BK.DATE THEN
                GOSUB PROCESS
                Y.BK.FLAG = '1'
            END
            IF ID.COMPANY[1,2] EQ 'SG' THEN
                GOSUB PROCESS
            END
        END

        IF (ID.COMPANY[1,2] EQ 'HK' AND R.NEW(FT.DEBIT.VALUE.DATE) LT Y.BK.DATE) AND Y.BK.FLAG EQ '' THEN
            GOSUB READ.CUSTOMER.REC
            IF Y.BK.BELONG.FLAG EQ 'Y' THEN
                R.NEW(FT.TAX.AMT)<1,1> = R.NEW(FT.DEBIT.CURRENCY):"0.00"
				R.NEW(FT.TAX.TYPE)<1,1> = "6100"
            END
        END
    END
    
*DAY15-771 Changes End
RETURN
**----------------------------------------------------------------------------------------------
INIT:
*----
* Initialise the variables !!

    R.JBWW.H.EB.GENERICPARAMETER = ''          ; REC.ACC = ''
    ERR.GPM = ''          ; ERR.ACC = ''
    REC.FT = ''           ; REC.GST = ''
    ERR.FT = ''           ; R.GST.GROUP.RULES = ''
    R.CUSTOMER = ''       ; ERR.GST.GRP = ''
    ERR.CUS = ''          ; REC.AURULE = ''
    ERR.AURULE =''        ; REC.AUAPP = ''
    ERR.AUAPP  = ''

    FN.JBWW.H.EB.GENERICPARAMETER   = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER    = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.FUNDS.TRANSFER   = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER    = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.AU.RULE       = 'F.AU.RULE'
    F.AU.RULE        = ''
    CALL OPF(FN.AU.RULE,F.AU.RULE)

    FN.AU.APP.RULE = 'F.AU.APP.RULE'
    F.AU.APP.RULE = ''
    CALL OPF(FN.AU.APP.RULE,F.AU.APP.RULE)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

RETURN
**----------------------------------------------------------------------------------------------
GET.LOCAL.FIELD:
*---------------

	Y.APP = 'CUSTOMER'
	Y.FLD = 'BELONG.STATUS'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
    Y.BK.BEL.STAT.POS = Y.POS<1,1>
   
* Get the generic parameter details
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'JB.R.XX.FT.GST',R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,ERR.GPM)

    Y.FIELD.NAME = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
   
    LOCATE "BACKDATED" IN Y.FIELD.NAME<1,1> SETTING Y.BK.DT.POS THEN
        Y.BK.DATE = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.BK.DT.POS>
    END
	
	LOCATE "GST.CATEGORY" IN Y.FIELD.NAME<1,1> SETTING Y.GC.POS THEN
        GST.CATEG = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.GC.POS>
    END

RETURN
**----------------------------------------------------------------------------------------------
READ.CUSTOMER.REC:
*----------------
    IF R.NEW(FT.DEBIT.ACCT.NO)[1,3] NE 'PL5' OR R.NEW(FT.CREDIT.ACCT.NO)[1,3] NE 'PL5' THEN
        Y.DEBIT.ACC = R.NEW(FT.DEBIT.ACCT.NO)
        Y.CREDIT.ACC = R.NEW(FT.CREDIT.ACCT.NO)
        IF ISDIGIT(Y.DEBIT.ACC) THEN
            Y.ACC.ID = Y.DEBIT.ACC
        END ELSE
            Y.ACC.ID = Y.CREDIT.ACC
        END
        R.ACC = ''; ERR.ACC = ''
        CALL F.READ(FN.ACCOUNT, Y.ACC.ID, R.ACC,F.ACCOUNT,ERR.ACC)
        IF R.ACC NE '' THEN
            Y.CUST.ID = R.ACC<AC.CUSTOMER>
            Y.CATEG = R.ACC<AC.CATEGORY>
            IF Y.CATEG GE '5000' AND Y.CATEG LE '5999' THEN
                R.ACC = '' ; ERR.ACC = ''
                CALL F.READ(FN.ACCOUNT, Y.CREDIT.ACC, R.ACC, F.ACCOUNT, ERR.ACC)
                IF R.ACC NE '' THEN
                    Y.CUST.ID = R.ACC<AC.CUSTOMER>
                END
            END
    
            R.CUS = '' ; ERR.CUS = '' ; Y.BK.BELONG.FLAG = ''
            CALL F.READ(FN.CUSTOMER, Y.CUST.ID, R.CUS, F.CUSTOMER, ERR.CUS)
            IF R.CUS NE '' THEN
                Y.BK.BELONG.FLAG = R.CUS<EB.CUS.LOCAL.REF,Y.BK.BEL.STAT.POS>
            END
        END

    END
RETURN

*----------------------------------------------------------------------------------------------
PROCESS:
*-------
    Y.COMP.ID = ID.COMPANY
    Y.HK.COMP = Y.COMP.ID[1,2]
    IF Y.COMP.ID[1,2] EQ 'SG' THEN
        GOSUB DETAILED.PROCESS
    END
    IF Y.HK.COMP EQ 'HK' THEN
        GOSUB HK.DETALIED.PROCESS
    END

RETURN
**----------------------------------------------------------------------------------------------
DETAILED.PROCESS:
*----------------
    GOSUB CHECK.INTACCT
    IF INT.ACFLG NE "FALSE" THEN
        GOSUB GST.RULE
    END
RETURN
**----------------------------------------------------------------------------------------------
HK.DETALIED.PROCESS:
*-------------------
    GOSUB GST.RULE
    
RETURN
**----------------------------------------------------------------------------------------------
GST.RULE:
*--------
    Y.CREDIT.ACC.NO = R.NEW(FT.CREDIT.ACCT.NO)
    Y.DEBIT.ACC.NO = R.NEW(FT.DEBIT.ACCT.NO)

    IF Y.CREDIT.ACC.NO[1,3] EQ 'PL5' THEN
        Y.CR.AC.LEN = LEN(Y.CREDIT.ACC.NO)
        AC.CAT = Y.CREDIT.ACC.NO[3,Y.CR.AC.LEN]
    END ELSE
        IF Y.DEBIT.ACC.NO[1,3] EQ 'PL5' THEN
            Y.DR.AC.LEN = LEN(Y.DEBIT.ACC.NO)
            AC.CAT = Y.DEBIT.ACC.NO[3,Y.DR.AC.LEN]
        END
    END
    Y.PROCESSING.DATE = R.NEW(FT.PROCESSING.DATE) ;* ADDED TO CHECK PROCESSING DATE TO CALC 8% GST
    GOSUB CHECK.REFUND.BOOKING

RETURN
**----------------------------------------------------------------------------------------------
CHECK.REFUND.BOOKING:
*--------------------

    IF Y.CREDIT.ACC.NO[1,3] NE 'PL5' THEN
*JB2A-34263 -S
        COMM.AMT = R.NEW(FT.AMOUNT.CREDITED)
        COMM.AMT = COMM.AMT[4,-1]
*JB2A-34263 -E
        GOSUB REFUND.COMM
    END ELSE
        IF Y.DEBIT.ACC.NO[1,3] NE 'PL5' THEN
*JB2A-34263 -S
            COMM.AMT = R.NEW(FT.AMOUNT.DEBITED)
            COMM.AMT = COMM.AMT[4,-1]
*JB2A-34263 -E
            GOSUB BOOK.COMM
        END
    END

RETURN
**----------------------------------------------------------------------------------------------
REFUND.COMM:
*------------
    CALL F.READ(FN.ACCOUNT,Y.CREDIT.ACC.NO,REC.ACC,F.ACCOUNT,ERR.ACC)
    Y.AC.CUSTOMER = REC.ACC<AC.CUSTOMER>
    GST.RATE = 0; Y.GST.TYPE = ''
    CALL JBWW.R.FT.GET.GST.RATE(Y.AC.CUSTOMER,AC.CAT,R.JBWW.H.EB.GENERICPARAMETER,Y.PROCESSING.DATE,GST.RATE,Y.GST.TYPE)
    GST.AMT = (COMM.AMT * GST.RATE)/100
    
    Y.SELL.CCY = R.NEW(FT.CREDIT.CURRENCY)
    Y.SELL.AMT = GST.AMT
    CALL EB.ROUND.AMOUNT(Y.SELL.CCY,Y.SELL.AMT,'','')
    GST.AMT = Y.SELL.AMT
    IF Y.GST.TYPE NE '' THEN
        R.NEW(FT.TAX.AMT)<1,1> = R.NEW(FT.DEBIT.CURRENCY):GST.AMT
        R.NEW(FT.TAX.TYPE)<1,1> = Y.GST.TYPE
    END
RETURN
**----------------------------------------------------------------------------------------------
BOOK.COMM:
*---------
    CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACC.NO,REC.ACC,F.ACCOUNT,ERR.ACC)
    Y.AC.CUSTOMER = REC.ACC<AC.CUSTOMER>
    GST.RATE = 0; Y.GST.TYPE = ''
    CALL JBWW.R.FT.GET.GST.RATE(Y.AC.CUSTOMER,AC.CAT,R.JBWW.H.EB.GENERICPARAMETER,Y.PROCESSING.DATE,GST.RATE,Y.GST.TYPE)
    
    GST.AMT = (COMM.AMT * GST.RATE)/100
    
    Y.SELL.CCY = R.NEW(FT.DEBIT.CURRENCY)
    Y.SELL.AMT = GST.AMT
    CALL EB.ROUND.AMOUNT(Y.SELL.CCY,Y.SELL.AMT,'','')
    GST.AMT = Y.SELL.AMT
    IF Y.GST.TYPE NE '' THEN
        R.NEW(FT.TAX.AMT)<1,1> = R.NEW(FT.DEBIT.CURRENCY):GST.AMT
        R.NEW(FT.TAX.TYPE)<1,1> = Y.GST.TYPE
    END

RETURN
**----------------------------------------------------------------------------------------------
CHECK.INTACCT:
*-------------
    LOCATE 'DEBIT.CURRENCY' IN Y.FIELD.NAME<1,1> SETTING Y.DC.POS THEN
        DR.AURULE.ID = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.DC.POS>
        CALL F.READ(FN.AU.RULE,DR.AURULE.ID,REC.AURULE,F.AU.RULE,ERR.AURULE)
        DR.CCY = REC.AURULE<AU.RUL.VALUE>
        CHANGE SM TO FM IN DR.CCY
    END

    LOCATE 'CREDIT.CURRENCY' IN Y.FIELD.NAME<1,1> SETTING Y.CC.POS THEN
        CR.AURULE.ID = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.CC.POS>
        CALL F.READ(FN.AU.RULE,CR.AURULE.ID,REC.AURULE,F.AU.RULE,ERR.AURULE)
        CR.CCY = REC.AURULE<AU.RUL.VALUE>
        CHANGE SM TO FM IN CR.CCY
    END

    TOTCCY.ARR = DR.CCY:FM:CR.CCY

    CALL F.READ(FN.AU.APP.RULE,'FUNDS.TRANSFER',REC.AUAPP,F.AU.APP.RULE,ERR.AUAPP)
    Y.APP.RULE.ID = REC.AUAPP<AU.APP.RULE.ID>
    Y.APP.ACCT.CO = REC.AUAPP<AU.APP.ACCT.CO>
    Y.DEFAULT.ACCT.CO = REC.AUAPP<AU.APP.DEFAULT.ACCT.CO>

    LOCATE R.NEW(FT.DEBIT.CURRENCY) IN TOTCCY.ARR SETTING Y.DR.CURR.POS THEN
        MATCH.CCY.FLG = "TRUE"
    END ELSE

        LOCATE R.NEW(FT.CREDIT.CURRENCY) IN TOTCCY.ARR SETTING Y.CR.CURR.POS THEN
            MATCH.CCY.FLG = "TRUE"
        END
    END
    GOSUB CHECK.FLAG

RETURN
**----------------------------------------------------------------------------------------------
CHECK.FLAG:
*-----------
    IF MATCH.CCY.FLG NE '' THEN
        GOSUB SET.DBU
    END
    IF MATCH.CCY.FLG EQ 'TRUE' AND DBU.COMPANY NE '' THEN
        GOSUB GET.INT.ACCOUNT
    END
    IF MATCH.CCY.FLG EQ '' THEN
        GOSUB GET.INT.ACC
    END
    GOSUB READ.INT.ACCOUNT

RETURN
**----------------------------------------------------------------------------------------------
SET.DBU:
*-------
    LOCATE DR.AURULE.ID IN Y.APP.RULE.ID<1,1> SETTING DR.AU.POS THEN
        DBU.COMPANY.DR = REC.AUAPP<AU.APP.ACCT.CO,DR.AU.POS>
    END
    LOCATE CR.AURULE.ID IN Y.APP.RULE.ID<1,1> SETTING CR.AU.POS THEN
        DBU.COMPANY.CR= REC.AUAPP<AU.APP.ACCT.CO,CR.AU.POS>
    END
    IF DBU.COMPANY.DR EQ DBU.COMPANY.CR THEN
        DBU.COMPANY = DBU.COMPANY.CR
    END

RETURN
**----------------------------------------------------------------------------------------------
GET.INT.ACCOUNT:
*---------------
    LAST.STR.DBUCOMP = DBU.COMPANY[4,2]:DBU.COMPANY[8,2]

* ACUDCU Decommission change/S
    ACUDCU.MIG.DAT = ''
    CALL JBWW.R.XX.ACUDCU.MIGDATECHK(ACUDCU.MIG.DAT)
    IF TODAY GT ACUDCU.MIG.DAT THEN
        LAST.STR.DBUCOMP = ID.COMPANY[4,2]:ID.COMPANY[8,2]
    END
* ACUDCU Decommission change/E

    FT.CRCCY = R.NEW(FT.CREDIT.CURRENCY)
    FT.DRCCY = R.NEW(FT.DEBIT.CURRENCY)

    IF R.NEW(FT.CREDIT.ACCT.NO)[1,3] EQ 'PL5' THEN
        GST.CR.ACCT = FT.CRCCY:GST.CATEG:"0001":LAST.STR.DBUCOMP
        INT.ACCT = GST.CR.ACCT
    END ELSE

        IF R.NEW(FT.DEBIT.ACCT.NO)[1,3] EQ 'PL5' THEN
            GST.DR.ACCT = FT.DRCCY:GST.CATEG:"0001":LAST.STR.DBUCOMP
            INT.ACCT = GST.DR.ACCT
        END
    END

RETURN
**----------------------------------------------------------------------------------------------
GET.INT.ACC:
*-----------
    DEFAULT.COMPANY =  REC.AUAPP<AU.APP.DEFAULT.ACCT.CO>
    LAST.STR.DEFCOMP = DEFAULT.COMPANY[4,2]:DEFAULT.COMPANY[8,2]
    FT.DRCCY = R.NEW(FT.DEBIT.CURRENCY)
    FT.CRCCY = R.NEW(FT.CREDIT.CURRENCY)

* ACUDCU Decommission change/S
    ACUDCU.MIG.DAT = ''
    CALL JBWW.R.XX.ACUDCU.MIGDATECHK(ACUDCU.MIG.DAT)
    IF TODAY GT ACUDCU.MIG.DAT THEN
        LAST.STR.DEFCOMP = ID.COMPANY[4,2]:ID.COMPANY[8,2]
    END
* ACUDCU Decommission change/E

    IF R.NEW(FT.DEBIT.ACCT.NO)[1,3] EQ 'PL5' THEN
        GST.DR.ACCT = FT.DRCCY:GST.CATEG:"0001":LAST.STR.DEFCOMP
        INT.ACCT = GST.DR.ACCT ;*JB2A-27252
    END ELSE
        IF R.NEW(FT.CREDIT.ACCT.NO)[1,3] EQ 'PL5' THEN
            GST.CR.ACCT = FT.CRCCY:GST.CATEG:"0001":LAST.STR.DEFCOMP
            INT.ACCT = GST.CR.ACCT
        END
    END
RETURN
**----------------------------------------------------------------------------------------------
READ.INT.ACCOUNT:
*----------------
    CALL F.READ(FN.ACCOUNT,INT.ACCT,REC.ACC,F.ACCOUNT,ERR.ACC)
    IF NOT(REC.ACC) THEN
        INT.ACFLG = "FALSE"
        AV = FT.PROCESSING.DATE
        ETEXT = 'EB-JBWW.D.FT.NOTAVAILABLE.ACCT':FM:INT.ACCT
        CALL STORE.END.ERROR
    END

RETURN
**----------------------------------------------------------------------------------------------
END
