SUBROUTINE JB.R.PP.B2BINFO
*-----------------------------------------------------------------------------------
*  This routine is attached to VERSION.CONTROL>PAYMENT.ORDER as field validation rtn
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date            Developer         Reference           Description
*-----------------------------------------------------------------------------------
* 06-06-2025      u40616           CBPAY-2288         User will provide the BANK.TO.BANK.INFO
*                                                     in local field L.PO.B2B.INFO and Routine will default
*                                                     back to BANK.TO.BANK.INFO field in PAYMENT.ORDER
*
*------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    
    IF MESSAGE EQ 'VAL' THEN
        GOSUB PO.INIT
        GOSUB PO.PROCESS
    END
            
RETURN
*------------------------------------------------------------------------------------
PO.INIT:
*-------
    Y.APP = '' ; Y.LOCFIELD = '' ; Y.LOCPOS = ''
    Y.APP = 'PAYMENT.ORDER'
    Y.LOCFIELD = 'L.PO.B2B.INFO'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.B2B.INFO.POS = Y.LOCPOS<1,1>
    
RETURN
*------------------------------------------------------------------------------------
PO.PROCESS:
*----------
    Y.B2B.INFO = '' ; Y.B2B.CNT = '' ; Y.I=''
    Y.B2B.INFO = R.NEW(PO.LOCAL.REF)<1,Y.B2B.INFO.POS>
    IF Y.B2B.INFO NE '' THEN
        Y.B2B.CNT = DCOUNT(Y.B2B.INFO,SM)
        IF Y.B2B.CNT GT '6' THEN
            AF = PO.LOCAL.REF
            AV = Y.B2B.INFO.POS
            ETEXT = "PI-BANK.TO.BANK.INFO":FM:"6"
            CALL STORE.END.ERROR
            Y.ERROR.FLAG = '1'
        END
    
        IF Y.B2B.CNT GT '1' AND Y.ERROR.FLAG EQ '' THEN
            CHANGE SM TO VM IN Y.B2B.INFO
            FOR Y.I = 1 TO Y.B2B.CNT
                R.NEW(PO.BANK.TO.BANK.INFO)<1,Y.I> = Y.B2B.INFO<1,Y.I>
            NEXT Y.I
        END ELSE
            R.NEW(PO.BANK.TO.BANK.INFO) = Y.B2B.INFO
        END
    END
RETURN
*------------------------------------------------------------------------------------
END
