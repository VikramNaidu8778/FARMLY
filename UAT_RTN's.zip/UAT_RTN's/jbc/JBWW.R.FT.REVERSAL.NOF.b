*-----------------------------------------------------------------------------
* <Rating>-114</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.REVERSAL.NOF(FINAL.ARRAY)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is no-file enquiry routine attached to enquiry JBWW.E.FT.REVERSE
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY(Result Array)
* Dependencies:
*---------------
* NA
* Revision History:
*------------------
* Defect Reference      Modified By         Date of Change      Change Details 
* JB2A_35488		   Parameshwari	     19-07-2017	  Routine written to reverse LIVE and HISTORY FT record.
* JB2A-38449            Rajesh Kumar K        28-07-2017        Corrected the record variable in READ.HIS.FILE gosub   
*-----------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER


    GOSUB OPEN.FILES

    RETURN

*-----------------------------------------------------------------------------------------------
OPEN.FILES:
*----------

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
	
	FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    APP.NAME  = "FUNDS.TRANSFER"
    FLD.NAME  = "L.FT.FREQ.PMT":VM:"L.XX.CID.DATA"
    FLD.POS   = ''
    CALL MULTI.GET.LOC.REF(APP.NAME,FLD.NAME,FLD.POS)
    Y.FREQ.PMT.POS = FLD.POS<1,1>
    Y.CID.DATA.POS = FLD.POS<1,2>

    GOSUB LOCATE.DETAILS

    RETURN

*-----------------------------------------------------------------------------------------------
LOCATE.DETAILS:
*--------------

    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING TXN.POS THEN
		Y.FT.ID = D.RANGE.AND.VALUE<TXN.POS>
	END

	Y.TXN.TYPE.LIST = "ACAC":FM:"ACPM":FM:"ODDL":FM:"ODDF":FM:"OTDA":FM:"OT03":FM:"OT12":FM:"OT60":FM:"ACCL":FM:"ACCF":FM:"IT":FM:"ITPM"
	GOSUB CHECK.FT.REC

    RETURN
	
*-----------------------------------------------------------------------------------------------
CHECK.FT.REC:
*-----------

	CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,FT.ERR)
	IF R.FUNDS.TRANSFER NE '' THEN
		Y.TXN.TYPE.VAL = R.FUNDS.TRANSFER<FT.TRANSACTION.TYPE>
		LOCATE Y.TXN.TYPE.VAL IN Y.TXN.TYPE.LIST<1> SETTING TXN.POS THEN
			GOSUB READ.LIVE.FILE
		END
	END ELSE	
		GOSUB READ.HIS.FILE
	END
	
	RETURN		

*-----------------------------------------------------------------------------------------------	
READ.LIVE.FILE:
*--------------

	Y.TXN.ID = Y.FT.ID
	Y.TXN.TYPE = R.FUNDS.TRANSFER<FT.TRANSACTION.TYPE>
	Y.DR.AC.NO = R.FUNDS.TRANSFER<FT.DEBIT.ACCT.NO>
	
	Y.ALT.AC.ID = Y.DR.AC.NO
	GOSUB GET.ALT.ACC.ID
	Y.DR.ALT.AC = Y.AC.ALT.ID
	
	Y.DR.CCY = R.FUNDS.TRANSFER<FT.DEBIT.CURRENCY>
	Y.DR.AMT = R.FUNDS.TRANSFER<FT.DEBIT.AMOUNT>
	Y.CR.AC.NO = R.FUNDS.TRANSFER<FT.CREDIT.ACCT.NO>
	Y.CR.CCY = R.FUNDS.TRANSFER<FT.CREDIT.CURRENCY>
	Y.CR.AMT = R.FUNDS.TRANSFER<FT.CREDIT.AMOUNT>
	Y.FREQ.PMT = R.FUNDS.TRANSFER<FT.LOCAL.REF,Y.FREQ.PMT.POS>
	
	Y.CID.DATA = R.FUNDS.TRANSFER<FT.LOCAL.REF,Y.CID.DATA.POS>
	GOSUB EDGEURL.CONV
	
	Y.REC.STATUS = R.FUNDS.TRANSFER<FT.RECORD.STATUS>
	Y.INPUTTER.VAL = R.FUNDS.TRANSFER<FT.INPUTTER>
	Y.INPUTTER = FIELD(Y.INPUTTER.VAL,'_',2,1)
	
	Y.ALT.AC.ID = ''
	Y.ALT.AC.ID = Y.CR.AC.NO
	GOSUB GET.ALT.ACC.ID
	Y.CR.ALT.AC = Y.AC.ALT.ID
	
	Y.INW.PAY.TYPE = R.FUNDS.TRANSFER<FT.INWARD.PAY.TYPE>
	CHANGE '-' TO '.' IN Y.INW.PAY.TYPE
	
	FINAL.ARRAY<-1> = Y.TXN.ID:"*":Y.TXN.TYPE:"*":Y.DR.AC.NO:"*":Y.DR.ALT.AC :"*":Y.DR.CCY:"*":Y.DR.AMT:"*":Y.CR.AC.NO:"*":Y.CR.CCY:"*":Y.CR.AMT:"*":Y.FREQ.PMT:"*":Y.FINAL.URL:"*":Y.REC.STATUS:"*":Y.INPUTTER:"*":Y.CR.ALT.AC:"*":Y.INW.PAY.TYPE
	
	RETURN
	
*-----------------------------------------------------------------------------------------------	
READ.HIS.FILE:
*--------------

	CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS,Y.FT.ID,R.FUNDS.TRANSFER.HIS, '')
	
	IF R.FUNDS.TRANSFER.HIS NE '' THEN
		Y.TXN.TYPE.VAL = R.FUNDS.TRANSFER.HIS<FT.TRANSACTION.TYPE>                      ;* JB2A-38449 /S /E
		LOCATE Y.TXN.TYPE.VAL IN Y.TXN.TYPE.LIST<1> SETTING TXN.POS THEN
			GOSUB FETCH.HIS.FILE
		END
	END
	
	RETURN
	
*-----------------------------------------------------------------------------------------------
FETCH.HIS.FILE:
*--------------
	
	Y.TXN.ID = Y.FT.ID
	Y.TXN.TYPE = R.FUNDS.TRANSFER.HIS<FT.TRANSACTION.TYPE>
	Y.DR.AC.NO = R.FUNDS.TRANSFER.HIS<FT.DEBIT.ACCT.NO>
	
	Y.ALT.AC.ID = Y.DR.AC.NO
	GOSUB GET.ALT.ACC.ID
	Y.DR.ALT.AC = Y.AC.ALT.ID
	
	Y.DR.CCY = R.FUNDS.TRANSFER.HIS<FT.DEBIT.CURRENCY>
	Y.DR.AMT = R.FUNDS.TRANSFER.HIS<FT.DEBIT.AMOUNT>
	Y.CR.AC.NO = R.FUNDS.TRANSFER.HIS<FT.CREDIT.ACCT.NO>
	Y.CR.CCY = R.FUNDS.TRANSFER.HIS<FT.CREDIT.CURRENCY>
	Y.CR.AMT = R.FUNDS.TRANSFER.HIS<FT.CREDIT.AMOUNT>
	Y.FREQ.PMT = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,Y.FREQ.PMT.POS>
	
	Y.CID.DATA = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,Y.CID.DATA.POS>
	GOSUB EDGEURL.CONV
	
	Y.REC.STATUS = R.FUNDS.TRANSFER.HIS<FT.RECORD.STATUS>
	Y.INPUTTER.VAL = R.FUNDS.TRANSFER.HIS<FT.INPUTTER>
	Y.INPUTTER = FIELD(Y.INPUTTER.VAL,'_',2,1)
	
	Y.ALT.AC.ID = ''
	Y.ALT.AC.ID = Y.CR.AC.NO
	GOSUB GET.ALT.ACC.ID
	Y.CR.ALT.AC = Y.AC.ALT.ID
	
	Y.INW.PAY.TYPE = R.FUNDS.TRANSFER.HIS<FT.INWARD.PAY.TYPE>
	CHANGE '-' TO '.' IN Y.INW.PAY.TYPE
	
	FINAL.ARRAY<-1> = Y.TXN.ID:"*":Y.TXN.TYPE:"*":Y.DR.AC.NO:"*":Y.DR.ALT.AC :"*":Y.DR.CCY:"*":Y.DR.AMT:"*":Y.CR.AC.NO:"*":Y.CR.CCY:"*":Y.CR.AMT:"*":Y.FREQ.PMT:"*":Y.FINAL.URL:"*":Y.REC.STATUS:"*":Y.INPUTTER:"*":Y.CR.ALT.AC:"*":Y.INW.PAY.TYPE
	
	RETURN
	
*-----------------------------------------------------------------------------------------------
GET.ALT.ACC.ID:
*--------------
	
	CALL F.READ(FN.ACCOUNT,Y.ALT.AC.ID,R.ACC.REC,F.ACCOUNT,AC.ERR)

    ALT.ACCT.TYPE = R.ACC.REC<AC.ALT.ACCT.TYPE>
    ALT.ACCT.IDS = R.ACC.REC<AC.ALT.ACCT.ID>

    LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
		Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
    END ELSE
		Y.AC.ALT.ID = ''
    END
	
	RETURN

*-----------------------------------------------------------------------------------------------
EDGEURL.CONV:
*------------

	Y.FT.ID.DATA = Y.FT.ID
    ENQR.NAME = ENQ.SELECTION<1>
    Y.COMP = ID.COMPANY

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'PAYMENT.EDGE.URL',R.GEN.PAR,F.JBWW.H.EB.GENERICPARAMETER,PAR.ERR)    
    Y.GENPAR.NAME = R.GEN.PAR<JBWW.GEN.PAR.FIELD.NAME>
    Y.GENPAR.VALUE = R.GEN.PAR<JBWW.GEN.PAR.FIELD.VALUE> 
	
	ENQ.POS = ''
    LOCATE ENQR.NAME IN Y.GENPAR.NAME<1,1> SETTING ENQ.POS THEN
    	Y.KEY = Y.GENPAR.VALUE<1,ENQ.POS>
    END
	
    IP.POS = ''
    LOCATE "IP.PORT" IN Y.GENPAR.NAME<1,1> SETTING IP.POS THEN
    	Y.IP = Y.GENPAR.VALUE<1,IP.POS>
    END
	
    SERVICE.POS = ''
    LOCATE "SERVICE.LINK" IN Y.GENPAR.NAME<1,1> SETTING SERVICE.POS THEN
    	Y.SERVICE = Y.GENPAR.VALUE<1,SERVICE.POS>
    END
	
    Y.FLAG = 'Flag=':Y.KEY:'&'
	Y.MENU = 'MnuTyp=':Y.FT.ID:'&'
	Y.CO.CODE = 'CoCode=':Y.COMP
	
	Y.FINAL.URL = Y.IP:Y.SERVICE:Y.FLAG:Y.MENU:Y.CO.CODE

    RETURN
*-----------------------------------------------------------------------------------------------	
END