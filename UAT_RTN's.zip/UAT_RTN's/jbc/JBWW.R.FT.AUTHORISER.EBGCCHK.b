    SUBROUTINE JBWW.R.FT.AUTHORISER.EBGCCHK
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              who             Reference           Description
* 2021-06-21		Ramesh K		T24-15342			Intial version
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    
	Y.COMI = "" 
	Y.RECORD.STATUS = ""
	Y.COMI = COMI
	Y.RECORD.STATUS = R.NEW(FT.RECORD.STATUS)
	
	IF Y.RECORD.STATUS EQ "INA2" AND Y.COMI THEN
		COMI = ""
	END
    RETURN

    END

