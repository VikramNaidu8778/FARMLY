$PACKAGE PP.RoutingAndSettlementService
SUBROUTINE JB.R.PP.CHKPREFCORRBIC.DPDHOOK(iTransactionContext,iAdditionalContext,oHookResponse)
*-----------------------------------------------------------------------------
* Routine attached in PP.COMPONENT.HOOK.API>DebitPartyDetermination
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 16/06/2025   Lakshmi Priya    CBPAY-3200     Hook Api used to raise warning when the SenderBic is not matching the PrefCorr Bic
* 02/07/2025   Prabhu D S       CBPAY-3519     warning restricted only for incoming serial pacs.008
*-----------------------------------------------------------------------------

    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.DebitPartyDeterminationService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $USING PP.RoutingAndSettlementService
    $USING PP.PaymentWorkflowGUI
    $INSERT I_F.POR.SUPPLEMENTARY.INFO

    GOSUB INIT

    IF ((oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ctrBtrIndicator>="C") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.paymentDirection>="I") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.repairFlag>='') AND (settlementMethod NE "COVE") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.originatingChannel>="SWIFTMX")) THEN
         GOSUB PROCESS
    END
    
RETURN

INIT:
****
        
    iPaymentID=iTransactionContext<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
    PP.PaymentWorkflowDASService.getPaymentRecord(iPaymentID, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)

    indicator = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ctrBtrIndicator>
    direction = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.paymentDirection>
    repairflag = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.repairFlag>
    originating = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.originatingChannel>

    settlementMethod = ''
    PP.PaymentWorkflowGUI.ppGetExtendedInfo(iPaymentID, oextPaymentRecord, oextReadErr)
*  Getting settlement method for Original FT number from POR.EXTENDED.INFO table
    IF oextReadErr EQ '' THEN
       settlementMethod = oextPaymentRecord<PP.PaymentWorkflowGUI.porExtendedInfo.PorexSettlementMethod>
    END

RETURN


PROCESS:
*******
      
    yCompanyID = iTransactionContext<PP.PaymentFrameworkService.PORPrimaryKey.companyID>
    yPaymentCurrency = iAdditionalContext<PP.DebitPartyDeterminationService.AccountInfo.accountCurrency>    
    ySenderCorrBic = iAdditionalContext<PP.DebitPartyDeterminationService.DpdAdditionalContext.senderAddress>
             
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.companyID> = yCompanyID
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.destinationCountryCode> = ySenderCorrBic[5,2]
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.transactionCurrency> = yPaymentCurrency
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.routingProduct> = "LEDGER"
    
    PP.RoutingAndSettlementService.findPPLPreferredCorrespondent(iPrefRequest, oPrefDetails, oPrefError)
    IF oPrefDetails NE '' THEN
    
        yPrefCorrBic = oPrefDetails<PP.RoutingAndSettlementService.PrefDetails.prefCorrespondentID>

        IF ySenderCorrBic[1,8] NE yPrefCorrBic[1,8] THEN

            iErrorTableKey<PP.PaymentFrameworkService.ErrorTableKey.errorCode> = 'DPD90001'
            PP.PaymentFrameworkService.getErrorDetails(iErrorTableKey, oErrorDetails, oGetErrTypeError)
            yErrorDetails = oErrorDetails<PP.PaymentFrameworkService.ErrorDetails.errorText>

            IF oErrorDetails THEN
                IF oHookResponse THEN
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode , -1> = "DPD90001"
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "WAR"
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = yErrorDetails
                END ELSE
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode , -1> = "DPD90001"
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType> = "WAR"
                    oHookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText> = yErrorDetails
                END
            END

        END
    
    END

RETURN

*********************************************************************
END
