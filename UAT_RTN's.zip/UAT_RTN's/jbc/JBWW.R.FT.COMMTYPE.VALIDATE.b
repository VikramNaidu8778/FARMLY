    SUBROUTINE JBWW.R.FT.COMMTYPE.VALIDATE
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the validation Routine attached to the VERSION.CONTROL of FUNDS.TRANSFER.
* To default the commission type from FTTC.
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               Developer            Reference       Description
* 27-Feb-2018		 Balaji				  JB2A-48828      Changes on defaulting Commission type
* 05-Mar-2018		 Balaji				  JB2A-50676	  Charges not showing up in authorise queue
*------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.FT.TXN.TYPE.CONDITION
	
    GOSUB INIT
    GOSUB PROCESS
	
    RETURN
	
*****
INIT:
*****
     
	 Y.TXN.TYPE = ''
	 Y.COMM.TYPE = ''
	 R.FTTC = ''
	 
	 FN.FTTC = 'F.FT.TXN.TYPE.CONDITION'
	 F.FTTC = ''
	 CALL OPF(FN.FTTC,F.FTTC)
	 

    RETURN
	
*********
PROCESS:
********

	Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)
    Y.COMM.CODE = COMI	
	CALL F.READ(FN.FTTC,Y.TXN.TYPE,R.FTTC,F.FTTC,FT.ERR)
	 
*S - JB2A-48828	- JB2A-50676
	IF Y.TXN.TYPE NE 'OTDA' AND Y.TXN.TYPE NE 'OT03' AND Y.TXN.TYPE NE 'OT12' AND Y.TXN.TYPE NE 'OT60' THEN
		IF Y.COMM.CODE NE 'WAIVE' THEN
			Y.COMM.TYPE = R.FTTC<FT6.COMM.TYPES,1>
			R.NEW(FT.COMMISSION.TYPE)<1,1> = Y.COMM.TYPE
		END
	END
*E - JB2A-48828 - JB2A-50676
	
  RETURN
END