* @ValidationCode : MjotNjk3ODIyODpDcDEyNTI6MTczMjExMzIyMDI1OToyMjg1MTQxOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjI0X0FNUi4wOi0xOi0x
* @ValidationInfo : Timestamp         : 20 Nov 2024 20:03:40
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2285141
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R24_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
SUBROUTINE JB.R.PP.STMT.NARR (PaymentReference,reservedt,reserved2,NarrativeValue, reserveds)
*-----------------------------------------------------------------------------
* Routine attached in PP.STMT.FORMAT FOR NARRATIVE CUSTOMIZATION 
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 20-11-2024 - Ragupathy.k@cognization.com      Narrative.1 Bank Credit Standard // Swift Payment FX2432437364
*                                               Narrative.2 Account Credit // Transaction Number SGD24324FD0CHJC0 <<FT_Number>> 
*-----------------------------------------------------------------------------
    $USING PP.PaymentWorkflowDASService
**Initialise

    PaymentRecord = ''
    FxReference =''
    CreditChargeAccount = ''
    NarrativeValue = ''
**Fetch the Payment Details
    PP.PaymentWorkflowDASService.getPaymentRecord (PaymentReference,PaymentRecord, PaymentAdditionalRecord, PaymentReadError) ; * Get22134415
**Debit Leg-To Obtain the charge Account on which charge is debited and Debit Charge Account is precedence to the Debit Main Acco:
    FxReference = PaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.messageUserReference> ;* Get the Fx reference from messageUserReference 

    NarrativeValue = FxReference  ;* Set the Narrative Details
RETURN
