SUBROUTINE JB.R.PP.GETCOMPORTABLE.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*This Build Routine is attached to Enquiry JB.E.PP.SAPFITODAY.LIST.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*03-09-24    Prabhu D S      CBPAY-135        Build Routine to display the POR Table records based on Company.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    
    ENQ.DATA<2,-1> = 'CompanyID'
    ENQ.DATA<3,-1> = 'EQ'
    ENQ.DATA<4,-1> = R.COMPANY(EB.COM.MNEMONIC)
                           
RETURN
********************************
END