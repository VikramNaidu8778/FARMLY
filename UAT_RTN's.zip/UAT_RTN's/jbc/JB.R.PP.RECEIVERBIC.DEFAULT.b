SUBROUTINE JB.R.PP.RECEIVERBIC.DEFAULT
*-----------------------------------------------------------------------------
* This subroutine attached as the Validation routine to the versions
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.INP
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.API.1.0.0
* This routine to default the L.XX.BIC.CODE in ReceiverInstitutionBIC (Intructed Agent BIC) in OE
* Attached to the field OE>CreditAccountNumber
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 15-Apr-2025 u40786             CBPAY-2086        Initial Version
*
* 08-May-2025 u40786             CBPAY-2696        Fetch the details from PP.LORO.NOSTRO.ACCOUNT to avoid the test bic dependency in test areas
*                                                  like SIT, UAT, TST, etc.,
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COMPANY
    $INSERT I_LoroNostroAccountService_LoroNostroAccRequest
    $INSERT I_LoroNostroAccountService_LoroNostroAccList
    $INSERT I_LoroNostroAccountService_AccHldBankDet
    $INSERT I_LoroNostroAccountService_DASError
    $INSERT I_LoroNostroAccountService_AccHldBankRequest
        
    COMP.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    
    I.LORONOSTRO.REQ<LoroNostroAccRequest.companyID> = COMP.MNEMONIC
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountType> = 'N'
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountNumberCompanyID> = COMP.MNEMONIC
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountNumber> = R.NEW(PP.OEYG.CreditAccountNumber)
    
    O.LORONOSTRO.DETS = ''
    O.LORONOSTRO.ERR = ''
    
    CALL LoroNostroAccountService.getLoroNostroOwningBICList(I.LORONOSTRO.REQ,O.LORONOSTRO.DETS,O.LORONOSTRO.ERR)
    
    BIC.CODE = O.LORONOSTRO.DETS<LoroNostroAccList.bicCode>
    
    R.NEW(PP.OEYG.ReceiverInstitutionBIC) = BIC.CODE<1,1>
*
RETURN
*
END
*