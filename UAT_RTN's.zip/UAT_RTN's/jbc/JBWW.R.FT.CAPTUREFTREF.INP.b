* @ValidationCode : MTotMTY5MTQwNDUwNTpVVEYtODoxNDY5NjEwMDk5NTcyOmEzODI5MTotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 27 Jul 2016 17:01:39
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : a38291
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false

    SUBROUTINE JBWW.R.FT.CAPTUREFTREF.INP
    
*------------------------------------------------------------------------------------------------------------------------------------
*
*** <region name= Description>
*** <desc>Task of the sub-routine</desc>
*
*Development Details:
*-------------------*
*
* Company Name : Bank Julius Baer
* Developed by : Venkat.S
* Development  : OTC Equity Options
* Project Code : P2955
*
*Program Description:
*-------------------*
* T24 Version input routine to capture the FT Reference raised for Counterparty and Customer Trade Inception.  
*             
*                                            
*              
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name = Modification History>
*** <desc>Modification Summary</desc>
*
* Modification History:
*---------------------*
*
*
*
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Inserts>
*** <desc>Inclue the required Libraries</desc>
*------------------------------------------------------------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    
    GOSUB INIT.AND.OPEN
    GOSUB UPDATE.FT.REFERENCE
    
    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= INIT.AND.OPEN>
*** <desc>Init and Open</desc>
*------------------------------------------------------------------------------------------------------------------------------------
   
INIT.AND.OPEN:
   
    FN.JBWW.OTC.ALT.INDEX = 'F.JBWW.OTC.ALT.INDEX'
    F.JBWW.OTC.ALT.INDEX = ''
    CALL OPF(FN.JBWW.OTC.ALT.INDEX,F.JBWW.OTC.ALT.INDEX)
    
    LREF.APPL = 'FUNDS.TRANSFER'
    LREF.FLDS = 'L.XX.FO.REF'
    LREF.POS = ''
    CALL MULTI.GET.LOC.REF(LREF.APPL,LREF.FLDS,LREF.POS)
    
    OTC.REF.POS = LREF.POS<1,1>
    
    RETURN    
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= UPDATE.FT.REFERENCE>
*** <desc>Update FT Reference.</desc>
*------------------------------------------------------------------------------------------------------------------------------------
    
UPDATE.FT.REFERENCE:
    
    OTC.REF.VALUE = R.NEW(FT.LOCAL.REF)<1,OTC.REF.POS>
    ALT.INDEX.ID = 'ARENAREF.':OTC.REF.VALUE
    
    CALL F.READ(FN.JBWW.OTC.ALT.INDEX,ALT.INDEX.ID,R.RECORD.ARR,F.JBWW.OTC.ALT.INDEX,ERR.ALT.INDEX)
    
    R.RECORD.ARR<-1> = ID.NEW
*CALL F.WRITE (FN.JBWW.OTC.ALT.INDEX,ALT.INDEX.ID,R.RECORD.ARR)
    
    WRITE R.RECORD.ARR TO F.JBWW.OTC.ALT.INDEX,ALT.INDEX.ID
    
    RETURN    
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------

END