* @ValidationCode : MToyMDExNjM1NTQ3OklTTy04ODU5LTE6MTQ3NTY1MDczOTU5MzphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 05 Oct 2016 14:58:59
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.H.FT.RETROPAY
*-----------------------------------------------------------------------------
* Template to store the Payments received from CALCULO interface
*-----------------------------------------------------------------------------
* Modification History :
* ----------------------
* Date          who             Reference        Descrition of Change
* 
* 05-10-2016    Tony Charles    CALCULO          New Template  
*-----------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_Table
* </region>
*-----------------------------------------------------------------------------
    Table.name = 'JBWW.H.FT.RETROPAY'        ;* Full application name including product prefix
    Table.title = 'Calculo Retrocession Payment'       ;* Screen title
    Table.stereotype = 'H'    ;* H, U, L, W or T
    Table.product = 'FT'      ;* Must be on EB.PRODUCT
    Table.subProduct = ''     ;* Must be on EB.SUB.PRODUCT
    Table.classification = 'FIN'        ;* As per FILE.CONTROL
    Table.systemClearFile = 'Y'         ;* As per FILE.CONTROL
    Table.relatedFiles = ''   ;* As per FILE.CONTROL
    Table.isPostClosingFile = ''        ;* As per FILE.CONTROL
    Table.equatePrefix = 'RTR.PAY'        ;* Use to create I_F.EB.LOG.PARAMETER 
*-----------------------------------------------------------------------------
    Table.idPrefix = ''       ;* Used by EB.FORMAT.ID if set
    Table.blockedFunctions = ''         ;* Space delimeted list of blocked functions
    Table.trigger = ''        ;* Trigger field used for OPERATION style fields 
*-----------------------------------------------------------------------------
    
    RETURN

END
