* @ValidationCode : MToxMTY4NDg3NTYyOklTTy04ODU5LTE6MTU0NjU3OTY5NDc4NjphNDUzMjg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 04 Jan 2019 13:28:14
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.SAPDASHBOARD.VIEW(OUT.ARRAY)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 08-10-2018        Sakthivel S           P3369-249                 Enquiry routine to provide dashboard for FT entries
*                                                                   which was sent from SAP. Attached to enquiry JBWW.E.FT.SAPDASHBOARD.VIEW
*
* 23-10-2018        Sakthivel S           P3369-282                 To fix the issue by changing the History Read for FT 
*
* 06-12-2018        Sakthivel S           P3369-531                 To fix the issue for multiple selection criteria 
*
* 24-12-2018        Sakthivel S           P3369-665                 To include the RECORD.STATUS as per Tranche 1.2 
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.XX.FINANCELOG
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_ENQUIRY.COMMON

*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS

    RETURN


INIT:
* To Initialise variables and to open necessary files.

    DELIM = "*"
    SEL.CMD = '' ; SEL.ID.LIST = '' ;
    NO.OF.IDS = '' ; SEL.FILE.ERR = ''
    FILE.NAME.POS = '' ; Y.FILE.ID = ''
    Y.TRIM.FILE.NAME2 = '' ; Y.TRIM.FILE.NAME = ''
    Y.DATE.POS = '' ; Y.DATE = ''
    Y.FLAG.POS = '' ; Y.FLAG = ''
    R.JBWW.H.XX.FINANCELOG = '' ; LOG.READ.ERR = ''
    Y.LOG.POS = '' ; Y.LOG.ID = '' ; OUT.ARRAY = ''
    
    APPS.NAME = "FUNDS.TRANSFER"
    FLDS.NAME = "L.XX.ORIG.REF"
    FLDS.POS = ''
    CALL MULTI.GET.LOC.REF(APPS.NAME,FLDS.NAME,FLDS.POS)
    Y.ORIG.REF.POS = FLDS.POS<1,1>

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)

    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)

    FN.JBWW.H.XX.FINANCELOG = 'F.JBWW.H.XX.FINANCELOG'
    F.JBWW.H.XX.FINANCELOG = ''
    CALL OPF(FN.JBWW.H.XX.FINANCELOG,F.JBWW.H.XX.FINANCELOG)

    RETURN

PROCESS:
* To select and frame the array for FT Dashboard.

    GOSUB FORM.SELECT

    LOOP
        REMOVE Y.LOG.ID FROM SEL.ID.LIST SETTING Y.LOG.POS
    WHILE Y.LOG.ID:Y.LOG.POS
        CALL F.READ(FN.JBWW.H.XX.FINANCELOG,Y.LOG.ID,R.JBWW.H.XX.FINANCELOG,F.JBWW.H.XX.FINANCELOG,LOG.READ.ERR)
        IF R.JBWW.H.XX.FINANCELOG THEN
            GOSUB FORM.ARRAY
        END
    REPEAT

    RETURN

FORM.SELECT:
* To form the select statement based on user query
    SEL.CMD = "SELECT ":FN.JBWW.H.XX.FINANCELOG

    LOCATE "FILE.NAME" IN D.FIELDS<1> SETTING FILE.NAME.POS THEN
    Y.FILE.ID = D.RANGE.AND.VALUE<FILE.NAME.POS>
    END

    IF Y.FILE.ID NE '' THEN
        Y.TRIM.FILE.NAME2 = TRIM(Y.FILE.ID,"_","A")
        Y.TRIM.FILE.NAME = FIELD(Y.TRIM.FILE.NAME2,".",1)
        SEL.CMD := " WITH @ID LIKE 'SAP-":Y.TRIM.FILE.NAME:"...'"
    END


    LOCATE "DATE" IN D.FIELDS<1> SETTING Y.DATE.POS THEN
    Y.DATE = D.RANGE.AND.VALUE<Y.DATE.POS>
    END

    IF Y.FILE.ID EQ '' AND Y.DATE NE '' THEN
        SEL.CMD := " WITH @ID LIKE 'SAP-FT..."
    END

    IF Y.DATE NE '' THEN
        Y.TRIM.DATE = TRIM(Y.DATE,".","A")
        Y.TRIM.DATE = TRIM(Y.TRIM.DATE,"'","A")
        SEL.CMD = TRIM(SEL.CMD,"'","T")
        SEL.CMD := Y.TRIM.DATE:"...'"
    END

    LOCATE "FLAG" IN D.FIELDS<1> SETTING Y.FLAG.POS THEN
    Y.FLAG = D.RANGE.AND.VALUE<Y.FLAG.POS>
    END

    Y.FLAG = UPCASE(Y.FLAG)

    BEGIN CASE
        CASE Y.FLAG EQ "SUCCESS"
            Y.FLAG = "PROCESSED"
        CASE Y.FLAG EQ "FAIL"
            Y.FLAG = "ERROR"
    END CASE

    IF Y.FILE.ID NE '' OR Y.DATE NE '' THEN
        SEL.CMD := " AND"
    END
    IF Y.FLAG NE '' THEN
        SEL.CMD := " WITH STATUS EQ ":Y.FLAG
    END

    CALL EB.READLIST(SEL.CMD,SEL.ID.LIST,'',NO.OF.IDS,SEL.FILE.ERR)

    RETURN

FORM.ARRAY:
* To form the Output array for FT's

    Y.TRANS.ID = '' ; Y.STATUS = '' ; Y.ERR.MSG = ''
    Y.TRANS.CODE = '' ; Y.DR.ACC.NO = '' ; Y.DR.AMT = '' ; Y.DR.CCY = ''
    Y.SIGN =  '' ; Y.CR.CCY = '' ; Y.AMT.FCY = '' ; Y.CR.ACC.NO = '' ; Y.CR.AMT = ''
    Y.AMT.LCY = '' ; Y.ACCT.COMP = '' ; Y.NARR = ''
    Y.THEIR.REF = '' ; R.FUNDS.TRANSFER = '' ; FT.READ.ERR = '' ; FT.HIS.READ.ERR = ''
    FT.NAU.READ.ERR = ''

    Y.TRANS.ID = FIELD(Y.LOG.ID,"-",4)
    Y.STATUS = R.JBWW.H.XX.FINANCELOG<FIN.ERR.STATUS>
    BEGIN CASE
        CASE Y.STATUS EQ "ERROR"
            Y.STATUS = "FAILED"
            IF Y.ERR.MSG[1,2] EQ "FT" THEN
                Y.ERR.MSG = FIELD(R.JBWW.H.XX.FINANCELOG<FIN.ERR.ERR.MSG>,",",2)
            END ELSE
                Y.ERR.MSG = R.JBWW.H.XX.FINANCELOG<FIN.ERR.ERR.MSG>
            END
        CASE Y.STATUS EQ "DELETED"
            Y.STATUS = "FAILED"
            Y.ERR.MSG = R.JBWW.H.XX.FINANCELOG<FIN.ERR.ERR.MSG>
        CASE Y.STATUS EQ "MODIFIED"
            Y.STATUS = "SUCCESS"
            Y.ERR.MSG = R.JBWW.H.XX.FINANCELOG<FIN.ERR.ERR.MSG>
        CASE 1
            Y.STATUS = "SUCCESS"
    END CASE



    CALL F.READ(FN.FUNDS.TRANSFER,Y.TRANS.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,FT.READ.ERR)
    IF FT.READ.ERR THEN
        Y.FT.HIS.ID = Y.TRANS.ID
        CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS, Y.FT.HIS.ID, R.FUNDS.TRANSFER, FT.HIS.READ.ERR)
        IF FT.HIS.READ.ERR THEN
            CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.TRANS.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER.NAU,FT.NAU.READ.ERR)
        END
    END


    IF R.FUNDS.TRANSFER THEN
        Y.TRANS.CODE = R.FUNDS.TRANSFER<FT.TRANSACTION.TYPE>
        Y.DR.ACC.NO = R.FUNDS.TRANSFER<FT.DEBIT.ACCT.NO>
        Y.DR.CCY = R.FUNDS.TRANSFER<FT.DEBIT.CURRENCY>
        Y.DR.AMT = R.FUNDS.TRANSFER<FT.DEBIT.AMOUNT>
        Y.CR.ACC.NO = R.FUNDS.TRANSFER<FT.CREDIT.ACCT.NO>
        Y.CR.CCY = R.FUNDS.TRANSFER<FT.CREDIT.CURRENCY>
        Y.CR.AMT = R.FUNDS.TRANSFER<FT.CREDIT.AMOUNT>
        Y.ORIG.REF = R.FUNDS.TRANSFER<FT.LOCAL.REF><1,Y.ORIG.REF.POS>
        Y.REC.STATUS = R.FUNDS.TRANSFER<FT.RECORD.STATUS>
    END
    OUT.ARRAY<-1> = Y.TRANS.ID:DELIM:Y.TRANS.CODE:DELIM:Y.DR.ACC.NO:DELIM:Y.DR.CCY:DELIM:Y.DR.AMT:DELIM:Y.CR.ACC.NO:DELIM:Y.CR.CCY:DELIM:Y.CR.AMT:DELIM:Y.STATUS:DELIM:Y.ERR.MSG:DELIM:Y.LOG.ID:DELIM:Y.ORIG.REF:DELIM:Y.REC.STATUS
    RETURN

    END