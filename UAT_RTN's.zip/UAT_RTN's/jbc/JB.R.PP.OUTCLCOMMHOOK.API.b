SUBROUTINE JB.R.PP.OUTCLCOMMHOOK.API(iAPIInputParameter,oFeeAmount)
*---------------------------------------------------------------------------------------------------------------
* This is a Fee Determination API attached in PP.FEETYPE>FTOTPAY0000 to consider Client Charges configured at
* Portfolio level in FT.GROUP.CONDITION. If portfolio level charge not found then consider flat amount given in
* FT.COMMISSION.TYPE for charge calculation.
*---------------------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------
** Date              Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------------------
* 19-JUN-2024        Hariharan T             CBPAY - 110         Fee Determination API attached in PP.FEETYPE to
*                                                                consider Client Charge in PO.
* 15-JUL-2024        Resmi R                 CBPAY-  659         Introduced the logic to consider the Client charge that is given at run time
*
* 17-JUN-2025       Prabhu D S              CBPAY-3225           Updated the logic for BEN charges
*--------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FT.GROUP.CONDITION
    $INSERT I_F.FT.COMMISSION.TYPE
    $USING PP.FeeDeterminationService
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentWorkflowDASService
    
    GOSUB INIT
    GOSUB GET.VALUES
    GOSUB PROCESS
    
RETURN
   
*****
INIT:
*****

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    FV.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, FV.POR.SUPPLEMENTARY.INFO)

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    FV.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, FV.POR.TRANSACTION)
    
    FN.FT.GROUP.CONDITION = 'F.FT.GROUP.CONDITION'
    FV.FT.GROUP.CONDITION = ''
    CALL OPF(FN.FT.GROUP.CONDITION, FV.FT.GROUP.CONDITION)
    
    FN.FT.COMM.TYPE = 'F.FT.COMMISSION.TYPE'
    FV.FT.COMM.TYPE = ''
    CALL OPF(FN.FT.COMM.TYPE, FV.FT.COMM.TYPE)
    
    
    CALL GET.LOC.REF("PAYMENT.ORDER","L.PO.CLNT.CHG",Y.CLNT.CHG)
    
       
RETURN

***********
GET.VALUES:
***********
;* Fetching the values from POR.TRANSACTION, POR.SUPPLEMENTARY.INFO & the incoming argument
    CONVERT @VM TO @FM IN iAPIInputParameter
    
    Y.FT.NO = iAPIInputParameter<PP.FeeDeterminationService.APIInputParameter.ftNumber>
    Y.CHG.CCY = iAPIInputParameter<PP.FeeDeterminationService.APIInputParameter.feeCurrency>
    Y.FEETYPE = iAPIInputParameter<PP.FeeDeterminationService.APIInputParameter.feeType>
    Y.TXN.AMOUNT = iAPIInputParameter<PP.FeeDeterminationService.APIInputParameter.transactionAmt>
    
    CALL F.READ(FN.POR.TRANSACTION, Y.FT.NO, R.POR.TRANSACTION, FV.POR.TRANSACTION, POR.ERR)
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPLEMENTARY.INFO,POR.ERR)
    
    Y.ACCT.NO = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxDebitmainaccount>
    Y.CUST.ID = R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdCustomerId>
 
    
    Y.L.PO.CLNT.CHG = R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdLocFieldName>

    LOCATE 'L.PO.CLNT.CHG' IN Y.L.PO.CLNT.CHG<1,1> SETTING Y.CLNT.CHG.POS THEN
        Y.PO.CLNT.CHG = R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdLocFieldValue,Y.CLNT.CHG.POS>
    END
 
        
RETURN


********
PROCESS:
********
;* Based on the Client Charge type value the FeeAmount is fetched
    BEGIN CASE

        CASE Y.PO.CLNT.CHG EQ ''     
            GOSUB MAIN.PROCESS

        CASE OTHERWISE
            oFeeAmount = Y.PO.CLNT.CHG

    END CASE


RETURN

MAIN.PROCESS:
*************
;* When there is no Client Charge then we are fetching the portfolio number of the account and checking the FT.GRP.CONDITION record
    CALL JB.R.PP.GETSAMACC.RTN(Y.ACCT.NO,Y.PORTFOLIO.NO)

    GOSUB CHECK.FT.GRP.CONDITION
    
    IF Y.CUST.CONDITION THEN
        GOSUB CALC.CHG         ;*Charge calculation done based on the Commission Percent
    END ELSE
        GOSUB GET.FT.FLAT.AMT  ;*Retrieving the Flat Amount when there is no Commission Percent
    END
    
RETURN

*********
CALC.CHG:
*********
;* Calculating the Charge based on the FeeType

    Y.PASS.DATA<1> = Y.FEETYPE
    Y.PASS.DATA<2> = 'COM'
    Y.CCY.MKT = '1'
    Y.CROSS.RATE = ''
    Y.CROSS.CURRENCY = ''
    Y.TOTAL.LOCAL.COMM.CHG = ''
    Y.TOTAL.FOR.COMM.CHG = ''

    CALL CALCULATE.CHARGE(Y.CUST.ID,Y.TXN.AMOUNT,Y.CHG.CCY,Y.CCY.MKT,Y.CROSS.RATE,Y.CROSS.CURRENCY,Y.CHG.CCY,Y.PASS.DATA,Y.CUST.CONDITION,Y.TOTAL.LOCAL.COMM.CHG,Y.TOTAL.FOR.COMM.CHG)
    oFeeAmount = Y.TOTAL.LOCAL.COMM.CHG


RETURN

***********************
CHECK.FT.GRP.CONDITION:
***********************
;*Fetching the Commission Percent value from the FT.GRP.CONDITION record
    Y.FT.GRP.ID = "P-":Y.PORTFOLIO.NO
    Y.CUST.CONDITION = ''
    R.FT.GRP.COND.REC = ''
     
    CALL F.READ(FN.FT.GROUP.CONDITION,Y.FT.GRP.ID,R.FT.GRP.COND.REC,FV.FT.GROUP.CONDITION,FT.GRP.ERR)
    IF R.FT.GRP.COND.REC THEN
        LOCATE Y.FEETYPE IN R.FT.GRP.COND.REC<FT3.COMM.TYPE,1> SETTING FT.GRP.POS THEN
            Y.CUST.CONDITION = R.FT.GRP.COND.REC<FT3.COMM.PERCENT,FT.GRP.POS>
        END
    END
    
RETURN

****************
GET.FT.FLAT.AMT:
****************
;*Fetching the Flat amount from FT.COMMISSION.TYPE record
    R.FT.COMM.TYPE.REC = ''
    CALL F.READ(FN.FT.COMM.TYPE,Y.FEETYPE,R.FT.COMM.TYPE.REC,FV.FT.COMM.TYPE,FT.COMM.ERR)
    IF R.FT.COMM.TYPE.REC THEN
        CHG.AMT = R.FT.COMM.TYPE.REC<FT4.FLAT.AMT>
        GOSUB GET.EXCH.RATE
        oFeeAmount = SELL.AMT
    END

RETURN

**************
GET.EXCH.RATE:
**************

   CCY.MKT = "1"
   BUY.CCY = LCCY
   SELL.CCY = Y.CHG.CCY
   BUY.AMT = CHG.AMT
   SELL.AMT = ""
   EXCH.RATE = ""
   DIFFERENCE = ""
   LCY.AMT = ""
   RETURN.CODE = ""
   CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCH.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)


RETURN
************************************************
END

