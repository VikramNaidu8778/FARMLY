* @ValidationCode : MjoxNjM5Njg4MTEwOkNwMTI1MjoxNzEyNjYzNjQxNjgwOjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 20 May 2024 17:24:01
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.DA.R.ENRICH.MASK.FIELDS(USER.ACCESS,ENRICHMENT.FIELDS)
*-----------------------------------------------------------------------------------------------
*Masking the Enrichment details for Non-Privileged User in the TPH Applications
*-----------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                             Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*21/05/2024	Resmi R			              CBPAY-395	      		Initial Draft							                     
*									 
*-------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENCRYPT.COMMON
    $INSERT I_GTS.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    GOSUB INIT
    CALL EB.IDENTIFY.USER.PRIVILEGE(IsUserPrivilege)
    
    IF IsUserPrivilege THEN
        ENRICHMENT.FIELDS = FIELD(ENRICHMENT.FIELDS,@TM,1,1)
	RETURN        
    END
  
    GOSUB PROCESS

RETURN

INIT:
****

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER, F.JBWW.H.EB.GENERICPARAMETER)

    Y.APP.FLD.NAME = FIELD(ENRICHMENT.FIELDS,@TM,4,1)
    USER.ACCESS = 1
    Y.GP.FLD.NAME = '' ; FLD.NAME.POS = '' ; Y.ENRICH.FLD = ''
    Y.GPM.FLD.LIST = ''


RETURN

PROCESS:
********

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.CID.ENRICH.WHITE.LIST",R.GEN.REC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.GP.FLD.NAME = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.NAME> 
    LOCATE APPLICATION IN Y.GP.FLD.NAME<1,1> SETTING FLD.NAME.POS THEN
        Y.GPM.FLD.LIST = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,FLD.NAME.POS>
        IF Y.APP.FLD.NAME MATCHES Y.GPM.FLD.LIST THEN
            USER.ACCESS = ''                        
        END ELSE
            USER.ACCESS = '1'
            ENRICHMENT.FIELDS = FIELD(ENRICHMENT.FIELDS,@TM,1,1)
            
        END
    END

RETURN

*----------------------------------------------------------------------------------
END

