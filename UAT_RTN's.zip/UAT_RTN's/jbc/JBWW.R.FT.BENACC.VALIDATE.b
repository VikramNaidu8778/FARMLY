
*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.BENACC.VALIDATE
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------

* 19/05/2017	SUSHMITHA B		 JB2A-35281                  Attached as validation routine to BEN.ACCT.NO in version  FUNDS.TRANSFER,JBWW.V.FT.OT103.INP
*******
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.FUNDS.TRANSFER
*-------------------------------------------------------------------------
    
    GOSUB PROCESS

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********
    Y.INST.CODE = R.NEW(FT.INSTRCTN.CODE)
	IF Y.INST.CODE EQ 'CHQB' THEN
	
        IF R.NEW(FT.BEN.ACCT.NO) NE "" THEN 
	     ETEXT = "Instruction Code is Pay Beneficiary by Cheque.Beneficiary Account No should not be entered"
         CALL STORE.END.ERROR 
	    END   
	END 
	RETURN
*--------------------------------------------------------------------------
    END
