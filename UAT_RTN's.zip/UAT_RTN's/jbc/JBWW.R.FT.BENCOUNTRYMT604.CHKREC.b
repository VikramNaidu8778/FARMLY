* @ValidationCode : MToxMjAwNDU1MDAzOklTTy04ODU5LTE6MTYzNzgwOTI4MDA1MzphNDA3NzA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 25 Nov 2021 11:01:20
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40770
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.FT.BENCOUNTRYMT604.CHKREC
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 24/11/2021        Suresh D          T24-17783     To update ben country for MT604
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER
$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
RETURN
INIT:
*****

    FN.JBWW.GEN.PARAM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.GEN.PARAM = ''
    CALL OPF(FN.JBWW.GEN.PARAM,F.JBWW.GEN.PARAM)
    
    GENERIC.PARAM = 'JBWW.D.XX.COUNTRY.CODE'
    CALL F.READ(FN.JBWW.GEN.PARAM,GENERIC.PARAM,R.GENERIC.PARAM,F.JBWW.GEN.PARAM,ADV.ERR)
    PARAM.FLD.NAMES = R.GENERIC.PARAM<JBWW.GEN.PAR.FIELD.NAME>

    COUNTRY.CODE.VAL = 'COUNTRY.CODE'
    LOCATE COUNTRY.CODE.VAL IN PARAM.FLD.NAMES<1,1> SETTING CC.POS THEN
    COUNTRY.CODE.VALS = R.GENERIC.PARAM<JBWW.GEN.PAR.FIELD.VALUE><1,CC.POS>
    END

RETURN
PROCESS:
********

    R.NEW(FT.BEN.COUNTRY) = COUNTRY.CODE.VALS
    
RETURN
END
