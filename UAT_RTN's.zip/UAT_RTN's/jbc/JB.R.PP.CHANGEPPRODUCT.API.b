SUBROUTINE JB.R.PP.CHANGEPPRODUCT.API(APPLNNAME,CONTRACTID,R.CONTRACT,PAYORDPRDCODE,ERROR)
*------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------
** Date              Developer               Reference             Description
*------------------------------------------------------------------------------------------------------------------
*04-06-2024         Hariharan T                CBPAY-81            This routine is to change the product from ACAC
*                                                                  to ACIA when one of the Debit or credit side is
*                                                                  Income account and to revert back to ACAC when
*                                                                  that account is changed back to Cash acct.
*19-Apr-2025        Kandan.K                   CBPAY-2535          Income Account check is applicable only if Field Debit
*                                                                  and Credit Account is entered.
*------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
   
    GOSUB INIT
    GOSUB PROCESS

RETURN
   
*-----
INIT:
*-----

    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
   
RETURN
*-------
PROCESS:
*-------

    APPLNNAME = "PAYMENT.ORDER"
    CONTRACTID = ID.NEW
  
    Y.INC.FLAG = ''
    Y.PO.PRD = R.CONTRACT<PO.PAYMENT.ORDER.PRODUCT>
    
    Y.DR.INC.FLAG = '' ; Y.DR.ACCOUNT = '' ;
    Y.DR.ACCOUNT = R.CONTRACT<PO.DEBIT.ACCOUNT>
    IF Y.DR.ACCOUNT THEN
        Y.ACCOUNT = Y.DR.ACCOUNT
        GOSUB CHECK.ACCOUNT.SAM
        Y.DR.INC.FLAG = Y.INC.FLAG
    END

    Y.CR.INC.FLAG = '' ;  Y.CR.ACCOUNT = '' ;
    Y.CR.ACCOUNT = R.CONTRACT<PO.CREDIT.ACCOUNT>
    IF Y.CR.ACCOUNT THEN
        Y.ACCOUNT = Y.CR.ACCOUNT
        GOSUB CHECK.ACCOUNT.SAM
        Y.CR.INC.FLAG = Y.INC.FLAG
    END

    IF Y.DR.INC.FLAG EQ '1' OR Y.CR.INC.FLAG EQ '1' THEN
        PAYORDPRDCODE = 'ACIA'
    END ELSE
        IF R.OLD(PO.PAYMENT.ORDER.PRODUCT) AND (R.OLD(PO.PAYMENT.ORDER.PRODUCT) NE Y.PO.PRD) THEN
            PAYORDPRDCODE = R.OLD(PO.PAYMENT.ORDER.PRODUCT)
        END
    END

RETURN
*------------------
CHECK.ACCOUNT.SAM:
*------------------
   
    CALL JB.R.PP.GETSAMACC.RTN(Y.ACCOUNT,Y.SAM.ID)
    R.SAM = '' ; SAM.ERR = '' ; Y.INC.FLAG = ''
    CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
    IF R.SAM NE '' THEN
        Y.CASH.ACCT.LIST = R.SAM<SC.SAM.INC.ACCOUNT.NO>
        INC.POS = ''
        LOCATE Y.ACCOUNT IN Y.CASH.ACCT.LIST<1,1> SETTING INC.POS THEN
            Y.INC.FLAG = '1'
        END
    END
*-------------------------------------------------------------------------------------------------
RETURN
