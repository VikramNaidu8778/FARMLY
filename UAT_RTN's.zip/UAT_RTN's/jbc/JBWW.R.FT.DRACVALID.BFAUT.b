* @ValidationCode : MTo0MTEwMzY1MDU6VVRGLTg6MTQ4NTg1NzI5MzI5NjoyMzMxNjM6LTE6LTE6MDowOmZhbHNlOk4vQQ==
* @ValidationInfo : Timestamp         : 31 Jan 2017 15:38:13
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.DRACVALID.BFAUT
*-----------------------------------------------------------------------------
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*--------------------------------------------------------------------------------------------------------
* Date          Developer                Mail Id                            Reference      Description
*--------------------------------------------------------------------------------------------------------
* 12/10/2016   Francis Xavier Raj P    francis.xavierraj@cognizant.com      CR-154       Initial Version
*--------------------------------------------------------------------------------------------------------
* This is a before auth routine  attached to listed version of FUNDS.TRANSFER to use to Validate whether
* Debit Account no is Internal or PL account and default the Value "BJB" if the field ORDERING.CUST and
* ORDERING.BANK are NULL .
*
* FUNDS.TRANSFER,JBWW.V.FT.REFUNDS.INP
* FUNDS.TRANSFER,JBWW.V.FT.FEECHRG.INP
* FUNDS.TRANSFER,JBWW.V.FT.INTERNAL.INP
* FUNDS.TRANSFER,JBWW.V.FT.CASH.INP
* FUNDS.TRANSFER,JBWW.V.FT.FXTRD.REV
*
*
*--------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT

*-----------------------------------------------------------------------------
    IF R.NEW(FT.TRANSACTION.TYPE) EQ 'ACPM' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
    RETURN


*------------------------------------------------------------------------------
INIT:
*------------------------------------------------------------------------------

    FT.DR.AC.ID = ''
    REC.DR.ACC = ''
    REC.DR.ACCT = ''
    ERR.REC = ''


    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    APP.NAME = 'FUNDS.TRANSFER'
    FLD.NAME = 'L.FT.ORDER.BANK'
    FLD.POS  = ''
    CALL MULTI.GET.LOC.REF(APP.NAME,FLD.NAME,FLD.POS)
    L.ORD.BANK.POS  = FLD.POS<1,1>
    L.ORD.BANK = ''

    RETURN

*----------------------------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------------------------

    FT.DR.AC.ID = R.NEW(FT.DEBIT.ACCT.NO)
    L.ORD.BANK  = R.NEW(FT.LOCAL.REF)<1,L.ORD.BANK.POS>

    CALL F.READ(FN.ACCOUNT,FT.DR.AC.ID,REC.DR.ACCT,F.ACCOUNT,ERR.REC)

    IF REC.DR.ACCT THEN
        IF NOT(REC.DR.ACCT<AC.CUSTOMER>) THEN
            IF  R.NEW(FT.ORDERING.CUST) EQ "" AND L.ORD.BANK  EQ "" THEN
                R.NEW(FT.ORDERING.BANK) = 'BJB'
                R.NEW(FT.LOCAL.REF)<1,L.ORD.BANK.POS> = 'BJB'
            END ELSE
                R.NEW(FT.ORDERING.BANK) = L.ORD.BANK
            END
        END ELSE
            R.NEW(FT.ORDERING.BANK) = ""
        END
    END ELSE
        IF FT.DR.AC.ID[1,2] = 'PL' AND NUM(FT.DR.AC.ID[3,5]) THEN
            Y.CATEGORY = FT.DR.AC.ID[3,5]
            IF Y.CATEGORY GT 50000 OR Y.CATEGORY LT 69999 THEN
                IF  R.NEW(FT.ORDERING.CUST) EQ "" AND L.ORD.BANK  EQ "" THEN
                    R.NEW(FT.ORDERING.BANK) = 'BJB'
                    R.NEW(FT.LOCAL.REF)<1,L.ORD.BANK.POS> = 'BJB'
                END ELSE
                    R.NEW(FT.ORDERING.BANK) = L.ORD.BANK
                END
            END
        END
    END

    RETURN

*---------------------------------------------------------------------------------------------
