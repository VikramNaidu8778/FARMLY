* @ValidationCode : MTotMTM5NDk0MzI6SVNPLTg4NTktMToxNTQ2NTgwMDU1NTUyOmE0NTMyODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 04 Jan 2019 13:34:15
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.B.FT.SAPPAYMENTPOST.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* Date               who                  Reference                 Description
* 01-10-2018        Sakthivel S           P3369-249                Interface Multi threaded routine to POST FT entries
*                                                                   which was sent from SAP
*
* 24-12-2018        Sakthivel S           P3369-665                For placing Asian currency FT's in INAU as per Tranche 1.2 
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_JBWW.B.FT.SAPPAYMENTPOST.COMMON
*-----------------------------------------------------------------------------


    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
* To Initialise variables and to open necessary files.
    GEN.PAR.ID = '' ; R.GEN.RECORD = '' ; ERROR.COM = ''
    GEN.FIELD.NAME = '' ; Y.FILE.PATH = '' ; PATH.POS = ''
    Y.ARC.PATH = '' ; ARC.POS = '' ; FN.FILE.PATH = ''
    F.FILE.PATH = '' ; FN.ARC.PATH = '' ; F.ARC.PATH = ''

    Y.OFS.SRC.ID = 'JBWW.D.XX.SAP.OFS'
    Y.COMP.MNEM = R.COMPANY(EB.COM.MNEMONIC)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.JBWW.H.XX.FINANCELOG = 'F.JBWW.H.XX.FINANCELOG'
    F.JBWW.H.XX.FINANCELOG = ''
    CALL OPF(FN.JBWW.H.XX.FINANCELOG,F.JBWW.H.XX.FINANCELOG)

    FN.JBWW.T.XX.SAPFINLOG = 'F.JBWW.T.XX.SAPFINLOG'
    F.JBWW.T.XX.SAPFINLOG = ''
    CALL OPF(FN.JBWW.T.XX.SAPFINLOG,F.JBWW.T.XX.SAPFINLOG)

    RETURN

PROCESS:
* To read JBWW.H.EB.GENERICPARAMETER to get the incoming file path and archiving file path
    GEN.PAR.ID = "SAP*DC*FT*":Y.COMP.MNEM

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GEN.PAR.ID,R.GEN.RECORD,F.JBWW.H.EB.GENERICPARAMETER,ERROR.COM)
    GEN.FIELD.NAME = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.NAME>


    LOCATE "FILE.PATH" IN GEN.FIELD.NAME<1,1> SETTING PATH.POS THEN
    Y.FILE.PATH = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.VALUE,PATH.POS>
    FN.FILE.PATH = Y.FILE.PATH
    F.FILE.PATH = ''
    CALL OPF(FN.FILE.PATH,F.FILE.PATH)
    END

    LOCATE "ARC.PATH" IN GEN.FIELD.NAME<1,1> SETTING ARC.POS THEN
    Y.ARC.PATH = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.VALUE,ARC.POS>
    FN.ARC.PATH = Y.ARC.PATH
    F.ARC.PATH = ''
    CALL OPF(FN.ARC.PATH,F.ARC.PATH)
    END
    
    R.GEN.RECORD = '' ; ERROR.COM = '' ; GEN.FIELD.NAME = '' ; ASN.CCY.POS = ''
    Y.ASN.CCY.LIST = ''
    
    GEN.PAR.ID = "JBWW.D.FT.ASN.CCY"

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GEN.PAR.ID,R.GEN.RECORD,F.JBWW.H.EB.GENERICPARAMETER,ERROR.COM)
    GEN.FIELD.NAME = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.NAME>
    
    LOCATE "ASIAN.CURRENCY" IN GEN.FIELD.NAME<1,1> SETTING ASN.CCY.POS THEN
    Y.ASN.CCY.LIST = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.VALUE,ASN.CCY.POS>
    CHANGE SM TO VM IN Y.ASN.CCY.LIST
    END

    RETURN

    END
