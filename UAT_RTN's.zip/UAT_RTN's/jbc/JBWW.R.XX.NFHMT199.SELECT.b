* @ValidationCode : MToyODgyMzA0NjQ6SVNPLTg4NTktMToxNjAzMjAxMjE5OTcyOmE0MDc3MDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 20 Oct 2020 21:40:19
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40770
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.XX.NFHMT199.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_JBWW.R.XX.NFHMT199.COMMON
*-----------------------------------------------------------------------------

    SEL.CMD = "SELECT ":FN.JBWW.L.XX.DOHREF.CONCAT
    
    CALL EB.READLIST(SEL.CMD,SEL.LIST,NO.OF.REC,"",SEL.ERR)
    
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN   
END
