SUBROUTINE JB.R.PP.ENRICHMENT.VAL
*---------------------------------------------------------------------------------------------------------------------------------
* This is a validation routine for Debit account field of applications Payment Order & Order Entry to enrich Short Title from
* account table.
* Called via JB.R.PP.ORDCUST.DEFAULT
*---------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------------------------
* Date         Resource         JIRA Ref
*
* 01-Mar-2025  u40786           CBPAY-2085     Initial Version
*
* 01-Apr-2025  Prabhu D S       CBPAY-2161     Enrichment not populated when user enters CRM reference instead of T24 reference.
*
* 03-May-2025  u40786           CBPAY-2266     Enchanced to support 2 pattern of GPM definition
*                                              Pattern.1 PrimaryApplicationFieldNo*AlternateApplicationName*SecondaryApplicationName*SecondaryApplicationField
*                                              Pattern.2 PrimaryApplicationFieldNo**SecondaryApplicationName*SecondaryApplicationField
*
* 26-Jun-2025 Vikram Pavuluru   CBPAY-3480 &   Enrichment for Beneficiary ID for PAYMENT.ORDER.
*                               CBPAY-3481

*---------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.STANDARD.SELECTION      ; * CBPAY-2266 - S/E
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.BENEFICIARY
    

    IF (V$FUNCTION EQ 'I' OR MESSAGE EQ 'XVAL') AND GTSACTIVE AND OFS$SOURCE.REC<OFS.SRC.SOURCE.TYPE> EQ 'SESSION' THEN
        GOSUB INIT
        GOSUB PROCESS
*Enhacement for Enrichment of BENEFICIARY.ID for PAYMENT.ORDER --- CBPAY-3480 & CBPAY-3481
        IF APPLICATION EQ 'PAYMENT.ORDER' THEN
            Y.BEN.ID = R.NEW<PO.BENEFICIARY.ID>
            FN.BENEFICIARY = "F.BENEFICIARY"
            FV.BENEFICIARY = ""
            IF Y.BEN.ID NE '' THEN
                CALL OPF(FN.BENEFICIARY,FV.BENEFICIARY)
                CALL F.READ(FN.BENEFICIARY,Y.BEN.ID,R.BENEFICIARY.REC,FV.BENEFICIARY,BENEFICIARY.ERR)
                IF R.BENEFICIARY.REC THEN
                    OFS$ENRI<PO.BENEFICIARY.ID> =R.BENEFICIARY.REC<ARC.BEN.NICKNAME>
                END
            END
        END
*------------------------------------------------------
    END

*
RETURN
*
*****
INIT:
*****

    GPM.PARAM.NAME = APPLICATION
    GPM.PARAM.VALUE = ''
    CALL JBWW.R.EB.GETGENPARM.VAL('JB.D.PP.TPH.ENRICH',GPM.PARAM.NAME,GPM.PARAM.VALUE)
    
    CONVERT @VM TO "#" IN GPM.PARAM.VALUE       ; * CBPAY-2266 - S
    GPM.PARAM.VALUE = EREPLACE(GPM.PARAM.VALUE,"|#","")
    CONVERT "#" TO @VM IN GPM.PARAM.VALUE
    
    Y.APPLICATION = APPLICATION
    R.SS = ''
    CALL GET.STANDARD.SELECTION.DETS(Y.APPLICATION,R.SS)
    Y.LOGICAL.ORDER = R.SS<SSL.LOGICAL.ORDER>
    CHANGE " " TO @VM IN Y.LOGICAL.ORDER        ; * CBPAY-2266 - E

    PREVIOUS.ALTERNATE.APPL = ''
*
RETURN
*
********
PROCESS:
********

    FLD.COUNT = DCOUNT(GPM.PARAM.VALUE,@VM)

    FOR CNT = 1 TO FLD.COUNT

        FLD.NAME = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',1)
        ALTERNATE.APPL = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',2)
        ENRICH.APPL = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',3)
        ENRICH.FLD = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',4)

        FLD.ERR = ''
        APPLN.NAME = GPM.PARAM.NAME
        FLD.POS = ''
        CALL JBWW.B.XX.GET.FIELDPOS(APPLN.NAME,FLD.NAME,FLD.POS,FLD.ERR)

        FLD.VALUE = R.NEW(FLD.POS)
            
        IF (APPLICATION EQ "PP.ORDER.ENTRY" OR APPLICATION EQ "POR.POSTING.REVERSAL") AND FLD.VALUE[1,2] EQ "PL" AND ENRICH.APPL THEN
            Y.GPM.PARAM.NAME = FLD.VALUE[1,2]
            Y.GPM.PARAM.VALUE = ''
            CALL JBWW.R.EB.GETGENPARM.VAL('JB.D.PP.TPH.ENRICH',Y.GPM.PARAM.NAME,Y.GPM.PARAM.VALUE)
            FLD.VALUE = FLD.VALUE[3,LEN(FLD.VALUE)]
            ALTERNATE.APPL = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',2)
            ENRICH.APPL = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',3)
            ENRICH.FLD = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',4)
        END      ; * CBPAY-2266 - E


        BEGIN CASE
*CASE ALTERNATE.APPL        ; * CBPAY-2266 - S
            CASE ALTERNATE.APPL AND FLD.VALUE; * CBPAY-2266 - E
                GOSUB ENRICH.PATTERN.1
*CASE NOT(ALTERNATE.APPL)       ; * CBPAY-2266 - S
            CASE NOT(ALTERNATE.APPL) AND FLD.VALUE      ; * CBPAY-2266 - E
                GOSUB ENRICH.PATTERN.2
        END CASE
    NEXT CNT
*
RETURN
*
*****************
ENRICH.PATTERN.1:
*****************

*IF ALTERNATE.APPL NE PREVIOUS.ALTERNATE.APPL THEN      ; * CBPAY-2266 - S/E
    FN.ALTERNATE.APPL = 'F.':ALTERNATE.APPL
    F.ALTERNATE.APPL = ''
    CALL OPF(FN.ALTERNATE.APPL,F.ALTERNATE.APPL)
    CALL F.READ(FN.ALTERNATE.APPL,FLD.VALUE,YR.ENRICH.APPL,F.ALTERNATE.APPL,E.ENRICH.APPL)
    IF YR.ENRICH.APPL THEN
        FLD.VALUE = YR.ENRICH.APPL<1>
    END
*END      ; * CBPAY-2266 - S/E

    GOSUB ENRICH.PATTERN.2

    PREVIOUS.ALTERNATE.APPL = ALTERNATE.APPL
*
RETURN
*
*****************
ENRICH.PATTERN.2:
*****************

    FN.ENRICH.APPL = 'F.':ENRICH.APPL
    F.ENRICH.APPL = ''
    CALL OPF(FN.ENRICH.APPL,F.ENRICH.APPL)

    YR.ENRICH.APPL = ''
    E.ENRICH.APPL = ''
    CALL F.READ(FN.ENRICH.APPL,FLD.VALUE,YR.ENRICH.APPL,F.ENRICH.APPL,E.ENRICH.APPL)

    FLD.ERR = ''
    APPLN.NAME = ENRICH.APPL
    ENRICH.FLD.POS = ''
    CALL JBWW.B.XX.GET.FIELDPOS(APPLN.NAME,ENRICH.FLD,ENRICH.FLD.POS,FLD.ERR)
    LOCATE FLD.POS IN Y.LOGICAL.ORDER<1,1> SETTING LOGIC.FLD.POS THEN       ; * CBPAY-2266 - S/E
        OFS$ENRI<LOGIC.FLD.POS> = YR.ENRICH.APPL<ENRICH.FLD.POS>
    END     ; * CBPAY-2266 - S/E
*
RETURN
************************************************************************************************************************************
END
*