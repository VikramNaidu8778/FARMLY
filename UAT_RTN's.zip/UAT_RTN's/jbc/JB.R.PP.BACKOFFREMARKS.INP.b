SUBROUTINE JB.R.PP.BACKOFFREMARKS.INP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 30-May-2024   CTS                                    CBPAY_20_38_40
*
* Description : Routine to populate the latest BO Remarks comments in local field L.PP.BO.USRCOM
*               InOrder to display the latest comments in Enquiry the field L.PP.BO.USRCOM will be always populated with Values
* Attached to : All Versions of PAYMENT.ORDER & PP.ORDER.ENTRY
* Attached as : Input Routine

*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
   

    GOSUB INIT
    GOSUB PROCESS
    
RETURN
*----
INIT:
*----

    BEGIN CASE
    
        CASE APPLICATION EQ 'PAYMENT.ORDER'
            APPL = 'PAYMENT.ORDER'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PO.LOCAL.REF
    
        CASE APPLICATION EQ 'PP.ORDER.ENTRY'
            APPL = 'PP.ORDER.ENTRY'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PP.OEYG.LOCAL.REF
    
    END CASE

RETURN
*-------
PROCESS:
*-------

Y.TST = R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
  IF R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS> EQ '' AND R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS> THEN
        R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,-1> = R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
	Y.CHK = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>

   END


RETURN
*-----------------------------------------------------------------------------
END

