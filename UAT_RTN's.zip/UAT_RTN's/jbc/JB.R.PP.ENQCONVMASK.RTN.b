* @ValidationCode : MjoxNjM5Njg4MTEwOkNwMTI1MjoxNzEyNjYzNjQxNjgwOjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 09 Apr 2024 17:24:01
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 670909
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.
SUBROUTINE JB.R.PP.ENQCONVMASK.RTN
*---------------------------------------------------------------------------------------------------------------------------------
*Attached to the enquiries JB.E.PP.PAYOUT.MSG, JB.E.PP.PAYPRM.BLOB & JB.E.PP.PAYOUTMSG.PCR
*Routine to mask the CID fields in the Outgoing & Incoming message tags configured in the JBWW.H.EB.GENERICPARAMETER>JB.D.PP.CIDMASK.PARAM
*----------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*27/08/2024	Resmi R			                CBPAY-425	        Masking the CID fields in the message content field of Outgoing and incoming tags									        enquiryfor Non-Privileged User
*
*-------------------------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_ENCRYPT.COMMON
    $INSERT I_F.EB.ENC.PARAMETER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
        
    CALL EB.IDENTIFY.USER.PRIVILEGE(IS.USER.PRIVILEGE)
    
    IF IS.USER.PRIVILEGE THEN
        RETURN
    END
           
    GOSUB INIT
   
    O.DATA = Y.DATA
    
RETURN

INIT:
**** 
  
    Y.DATA = O.DATA    
    Y.DATA = TRIM(Y.DATA, "", "A")
    
    R.EB.ENC.REC = ENC$R.EB.ENC.PARAM
    Y.ENQ.MASK.CHARS = R.EB.ENC.REC<EB.ENC.ENQ.MSK.CHARS>
    

    Y.OT.FM.POS = '' ; Y.OT.VM.POS = '' ; Y.OT.SM.POS = ''
    Y.CT.FM.POS = '' ; Y.CT.VM.POS = '' ; Y.CT.SM.POS = ''
    
    AC.ERR.MSG = ''

    Y.FRMT.POS1 = '' ; Y.FRMT.POS2 = '' ; Y.FRMT.POS3 = ''
        
    FINDSTR 'MX' IN Y.DATA SETTING Y.FRMT.POS1,Y.FRMT.POS2, Y.FRMT.POS3 THEN
        GOSUB MX.PROCESS
    END ELSE
        GOSUB MT.PROCESS
    END
  
RETURN
 
MX.PROCESS:
**********

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.CIDMASK.PARAM","ENQUIRY.MASK",Y.GPM.FLD.LIST)
    
    CHANGE @SM TO @VM IN Y.GPM.FLD.LIST
    CHANGE @VM TO @FM IN Y.GPM.FLD.LIST

  
    Y.FLD.CNT = DCOUNT(Y.GPM.FLD.LIST,@FM)
    
    Y.INIT = '1'
    
    LOOP
    
    WHILE Y.INIT LE Y.FLD.CNT
       
        GOSUB GET.FIELD.VALUES
    
        FIND Y.OPEN.TAG IN Y.DATA SETTING Y.OT.FM.POS,Y.OT.VM.POS,Y.OT.SM.POS THEN

            FIND Y.CLOSE.TAG IN Y.DATA SETTING Y.CT.FM.POS,Y.CT.VM.POS,Y.CT.SM.POS THEN
                CHANGE @VM  TO "#" IN Y.DATA
                Y.DIFF.POS = Y.CT.VM.POS-Y.OT.VM.POS
                Y.VM.VAL = FIELD(Y.DATA, "#",Y.OT.VM.POS,Y.DIFF.POS)
                Y.APPND.CLOSE.TAG = Y.VM.VAL:"#":Y.CLOSE.TAG
                Y.MASK.VAL = Y.OPEN.TAG:Y.ENQ.MASK.CHARS:Y.CLOSE.TAG
                Y.DATA = EREPLACE(Y.DATA,Y.APPND.CLOSE.TAG,Y.MASK.VAL)
                CHANGE "#" TO @VM IN Y.DATA

            END
        
        END
     
        Y.INIT += 1
        
    REPEAT
     
RETURN

GET.FIELD.VALUES:
*****************

    Y.GPM.FLD = Y.GPM.FLD.LIST<Y.INIT>
    Y.OPEN.TAG = FIELD(Y.GPM.FLD, "_", 1)
    Y.CLOSE.TAG = FIELD(Y.GPM.FLD, "_", 2)

RETURN


MT.PROCESS:
***********

    CHANGE "/" TO "#" IN Y.DATA

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.CIDMASK.PARAM","MTTAG.MASK",Y.GPM.FLD.VALUES)

    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES

    Y.TAG.CNT = DCOUNT(Y.GPM.FLD.VALUES,@VM)

    FOR Y.TAG.IDX = 1 TO Y.TAG.CNT
       
    Y.TAG.VAL = Y.GPM.FLD.VALUES<1,Y.TAG.IDX>
    Y.TAG.START = FIELD(Y.TAG.VAL,'_',1)
    Y.TAG.END = FIELD(Y.TAG.VAL,'_',2)
       
    FINDSTR Y.TAG.START IN Y.DATA SETTING Y.FM,Y.TAG.START.POS, Y.SM THEN
        CHANGE Y.TAG.START TO "50" IN Y.DATA<1,Y.TAG.START.POS>
        FINDSTR Y.TAG.END IN Y.DATA SETTING Y.FM, Y.TAG.END.POS, Y.SM THEN
           Y.TAG.POS.CNT = Y.TAG.END.POS - Y.TAG.START.POS
           Y.TAG.TEMP = Y.TAG.START.POS
           FOR Y.IDX = 1 TO Y.TAG.POS.CNT
              IF Y.IDX EQ 1 THEN
                 Y.DATA<1,Y.TAG.TEMP>[5,LEN(Y.DATA<1,Y.TAG.TEMP>)] = Y.ENQ.MASK.CHARS
              END ELSE
                 Y.DATA<1,Y.TAG.TEMP> = Y.ENQ.MASK.CHARS
              END
              ++Y.TAG.TEMP
           NEXT Y.IDX
        END
        CHANGE "50" TO Y.TAG.START IN Y.DATA<1,Y.TAG.START.POS>
    END
    NEXT Y.TAG.IDX
    CHANGE "#" TO "/" IN Y.DATA
    CHANGE "/" TO @VM IN Y.DATA
   
RETURN

*-----------------------------------------------------------------------------------------------------------
END



