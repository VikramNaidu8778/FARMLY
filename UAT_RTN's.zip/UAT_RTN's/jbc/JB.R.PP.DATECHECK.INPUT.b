* @ValidationCode : MTo5NjQ0Mzc3MjM6SVNPLTg4NTktMToxNTM3OTUyNzY4ODg4OjUzNDQ2MjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNA==
* @ValidationInfo : Timestamp         : 26 Sep 2018 14:36:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 534462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------------------------
* <Rating>-44</Rating>
*-----------------------------------------------------------------------------------------------
   SUBROUTINE JB.R.PP.DATECHECK.INPUT
*------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------------
* Date          Developer               Reference               Description
*13-DEC-2024     RESMI                 CBPAY-1426          Routine is used to update the field L.FT.VALDT.CHKD                                                      
*--------------------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------------------
* Description : Routine is used to update the field L.FT.VALDT.CHKD.
* Attached to : VERSION>PAYMENT.ORDER,JB.V.PP.VALUEDATECHECK.AMEND
* Attached as : Input routine
**----------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB GET.LOCAL.FIELDS
    GOSUB PROCESS

    RETURN

INIT:
*****
* !! Initialise and open the necessary files ;

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    RETURN

GET.LOCAL.FIELDS:
****************
* !! Fetch local field positions.

    Y.APPL = 'PAYMENT.ORDER'
    Y.FLD = 'L.FT.BO.REMARK':VM:'L.FT.VALDT.CHKD'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.FLD,Y.FLD.POS)
    Y.BO.REMARK.STAT.POS = Y.FLD.POS<1,1>
    Y.VALDT.CHKD.POS = Y.FLD.POS<1,2>

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","VALDTE.AMND.TXN.CODES",Y.FIELD.VALUE)
	CHANGE ',' TO VM IN Y.FIELD.VALUE
    CHANGE FM TO VM IN Y.FIELD.VALUE


    RETURN

PROCESS:
*******
* !! Main Process starts here.

    Y.BO.REMARK.STATUS = R.NEW(PO.LOCAL.REF)<1,Y.BO.REMARK.STAT.POS>
    Y.VALDT.CHKD = R.NEW(PO.LOCAL.REF)<1,Y.VALDT.CHKD.POS>
    Y.RECORD.STATUS = R.NEW(PO.RECORD.STATUS)
    Y.TXN.TYPE = R.NEW(PO.PAYMENT.ORDER.PRODUCT)


    IF Y.RECORD.STATUS EQ 'INAU' OR Y.RECORD.STATUS EQ 'INA2' THEN
         R.NEW(PO.LOCAL.REF)<1,Y.VALDT.CHKD.POS> = "MAKER"
    END

    RETURN


**********************

END
