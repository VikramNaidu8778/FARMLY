$PACKAGE PP.RoutingAndSettlementService
SUBROUTINE JB.R.PP.CHKSNDRCORBNK.CPDHOOK(iTransactionDetails,iCreditPartyDetails,HookResponse)
*------------------------------------------------------------------------------
* Description :
* Routine attached in PP.COMPONENT.HOOK.API>CreditPartyDetermination
* API routine tocheck Send Corr Bk field value with the Pref correspondent ID & raise warning if there is mismatch.
* with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date              Developer        Reference          Description

*12/03/2025         Resmi R          CBPAY-1940         Included logic to check Send Corr Bk.1 field value with the Pref correspondent ID & raise warning if there is mismatch.
*
*09/05/2025        Lakshmi Priya     CBPAY-2787         Included logic to locate SenderCorrBic from party Role 'SENDER' .
*------------------------------------------------------------------------------------------------------------------------------------------------------

*-------------------------------------------------------------------------------------------------------------------------------------------------------
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $USING PP.StaticDataGUI
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentLifecycleHook

    iPaymentID=iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
    PP.PaymentWorkflowDASService.getPaymentRecord(iPaymentID, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)
    GOSUB INIT
    IF ((oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ctrBtrIndicator>="C") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.paymentDirection>="I") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.repairFlag>='')) THEN
        GOSUB PROCESS
        RETURN
    END
RETURN
   
*****
INIT:
*****
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    EB.DataAccess.Opf(FN.POR.TRANSACTION, F.POR.TRANSACTION)
    
    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    EB.DataAccess.Opf(FN.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO)
    yCompanyID = iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.companyID>

RETURN
*********
PROCESS:
*********

    EB.DataAccess.FRead(FN.POR.TRANSACTION,iPaymentID,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)
    
    yPaymentCcy = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxTransactioncurrencycode>
    yOrginatingChannel = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxOriginatingchannel>
    
    EB.DataAccess.FRead(FN.POR.SUPPLEMENTARY.INFO,iPaymentID,R.POR.GET.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO,ERR.PORS)
      
    yPiInfCode = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INFORMATIONCODE>
       
    LOCATE 'SETLMTD' IN yPiInfCode<1,1> SETTING Infocdepos THEN
        yInstrCode = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INSTRUCTION.CODE,Infocdepos>
    END
               
    IF yOrginatingChannel EQ 'SWIFTMX' AND yInstrCode NE 'COVE' THEN
        yPartyRole = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PARTY.ROLE>

        LOCATE 'SENDER' IN yPartyRole<1,1> SETTING Role.pos THEN
            ySenderCorrBic = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PARTY.IDENTIFIER.CODE,Role.pos>
        END ELSE
        LOCATE 'SNDCBK' IN yPartyRole<1,1> SETTING Role.pos THEN
            ySenderCorrBic = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PARTY.IDENTIFIER.CODE,Role.pos>
        END
        iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.companyID> = yCompanyID
        iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.destinationCountryCode> = ySenderCorrBic[5,2]
        iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.transactionCurrency> = yPaymentCcy
        iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.routingProduct> = "LEDGER"
        PP.RoutingAndSettlementService.findPPLPreferredCorrespondent(iPrefRequest, oPrefDetails, oPrefError)

        IF oPrefDetails NE '' THEN
            yPrefCorrBic = oPrefDetails<PP.RoutingAndSettlementService.PrefDetails.prefCorrespondentID>
            IF ySenderCorrBic[1,8] NE yPrefCorrBic[1,8] THEN
                iErrorTableKey<PP.PaymentFrameworkService.ErrorTableKey.errorCode> = 'CPD90003'
                PP.PaymentFrameworkService.getErrorDetails(iErrorTableKey, oErrorDetails, oGetErrTypeError)
                yErrorDetails = oErrorDetails<PP.PaymentFrameworkService.ErrorDetails.errorText>
                IF oErrorDetails THEN
                    IF HookResponse THEN
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode , -1> = "CPD90003"
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "WAR"
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = yErrorDetails
                    END ELSE
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode , -1> = "CPD90003"
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType> = "WAR"
                        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText> = yErrorDetails
                    END
                END
            END
        END
    END
  RETURN

*--------------------------------------------------------------------------------------------------------
END
    
