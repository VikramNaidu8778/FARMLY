* @ValidationCode : MToxMzQ2NTcyNjM1OklTTy04ODU5LTE6MTQ5MjY4Nzc2Njg5Njo2MTg1MzM6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjQ=
* @ValidationInfo : Timestamp         : 20 Apr 2017 16:59:26
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 618533
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
    SUBROUTINE JBWW.R.FT.CREDITVAL.OR.INP
*-----------------------------------------------------------------------------------------
* Description: This routine checks the whether VALUE.DATE is more than 7 working days
*              forwarded or backdated to raise override message in the version
*-----------------------------------------------------------------------------------------
* Attached: This is the input routine attached to FUNDS.TRANSFER versions.
*           FUNDS.TRANSFER,JBWW.V.FT.POSTCLOSE.INP and FUNDS.TRANSFER,JBWW.V.FT.NORTRANS.INP
*-----------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* Revision History:
*------------------
*    Date             who              Reference                     Description
* 08-08-2016        Shathish JP        FIN-CR-40/JB2A-31129             Initial Version
*----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.VERSION
    $INSERT I_F.FUNDS.TRANSFER

    GOSUB INIT
    GOSUB PROCESS

    RETURN
*----------------------------------------------------------------------------------------
INIT:
*****

    Y.DR.VDATE = '' ; Y.CR.VDATE = ''

    RETURN
*----------------------------------------------------------------------------------------
PROCESS:
********
    
    Y.DR.VDATE = R.NEW(FT.DEBIT.VALUE.DATE)
    Y.CR.VDATE = R.NEW(FT.CREDIT.VALUE.DATE)

    NO.FDAYS = '+7W'
    NO.BDAYS = '-7W'

    Y.VDATE.TODAY = TODAY

    Y.DBDATE = Y.VDATE.TODAY
    Y.DFDATE = Y.VDATE.TODAY

    Y.CFDATE = Y.VDATE.TODAY
    Y.CBDATE = Y.VDATE.TODAY

    CALL CDT('',Y.DFDATE,NO.FDAYS)
    CALL CDT('',Y.DBDATE,NO.BDAYS)

    CALL CDT('',Y.CFDATE,NO.FDAYS)
    CALL CDT('',Y.CBDATE,NO.BDAYS)


    IF Y.DR.VDATE THEN
        IF (Y.DR.VDATE LT Y.DBDATE) OR (Y.DR.VDATE GT Y.DFDATE) THEN
            AF = FT.DEBIT.VALUE.DATE
            FLAG1 = 1
*            GOSUB VAL.OVERRIDE
        END
    END
    IF Y.CR.VDATE THEN
        IF (Y.CR.VDATE LT Y.CBDATE) OR (Y.CR.VDATE GT Y.CFDATE) THEN
            AF = FT.CREDIT.VALUE.DATE
            FLAG2 = 2
*            GOSUB VAL.OVERRIDE
        END
    END
    BEGIN CASE
    CASE FLAG1 EQ "1" OR FLAG2 EQ "2"
    GOSUB VAL.OVERRIDE
    CASE FLAG1 EQ "1" AND FLAG2 EQ "2"
    GOSUB VAL.OVERRIDE
    END CASE

    RETURN
*----------------------------------------------------------------------------------------
VAL.OVERRIDE:
************

    Y.DC.CURR.NO = R.NEW(DC.DC.CURR.NO)
    CUR.NO = DCOUNT(Y.DC.CURR.NO,VM)+1
    TEXT = 'EB-VAL.DATE.LT.7WORKDAY'
    CALL STORE.OVERRIDE(CUR.NO)
    RETURN

    END
