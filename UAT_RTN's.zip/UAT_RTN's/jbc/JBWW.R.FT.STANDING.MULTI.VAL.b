SUBROUTINE JBWW.R.FT.STANDING.MULTI.VAL
*--------------------------------------------------------------------------------------------------------
*Modification History :
*--------------------------------------------------------------------------------------------------------
* Date               who                  Reference                Description
*19-09-2017		Rajagopalan R   		  JB2A-42245        Validation for Multivalue field restriction
*--------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.FT.STANDINGINSTR
	
    GOSUB CHECK.FIELDS.COUNT
	RETURN

*******************
CHECK.FIELDS.COUNT:
*******************
		Y.BEN.CUST.LIST = R.NEW(JB.FT.STNG.BEN.CUSTOMER)
		Y.ACCT.WITH.BANK.LIST = R.NEW(JB.FT.STNG.ACCT.WITH.BANK)
		TOTAL.FLD.CNT = DCOUNT(Y.BEN.CUST.LIST,VM)
 
		Y.ROT.CNT = 0
		LOOP
			Y.ROT.CNT += 1
			WHILE Y.ROT.CNT LE TOTAL.FLD.CNT
			Y.BEN.CUST.LIST.SM = FIELD(Y.BEN.CUST.LIST,VM,Y.ROT.CNT)
			Y.BEN.CUST.CNT = DCOUNT(Y.BEN.CUST.LIST.SM,SM)
			Y.ACCT.WITH.BANK.LIST.SM = FIELD(Y.ACCT.WITH.BANK.LIST,VM,Y.ROT.CNT)
			Y.ACCT.BANK.CNT = DCOUNT(Y.ACCT.WITH.BANK.LIST.SM,SM)
			IF Y.BEN.CUST.CNT GT 4 THEN
				AF = JB.FT.STNG.BEN.CUSTOMER
				AV = Y.ROT.CNT
				AS = Y.BEN.CUST.CNT
				ETEXT = "EB-MULT.LINES.NOT.ALLOWED"
				CALL STORE.END.ERROR
			END
	
			IF Y.ACCT.BANK.CNT GT 4 THEN
				AF = JB.FT.STNG.ACCT.WITH.BANK
				AV = Y.ROT.CNT
				AS =  Y.ACCT.BANK.CNT 
				ETEXT = "EB-MULT.LINES.NOT.ALLOWED"
				CALL STORE.END.ERROR
			END
	    REPEAT
	    RETURN
		
END