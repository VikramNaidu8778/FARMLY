SUBROUTINE JB.R.PP.FORMAT.FILE

*--------------------------------------------------------------------------------------------
* Description:
*--------------------------------------------------------------------------------------------
* This is the routine attached to BATCH>SGD/JB.D.PP.CRMCID.MIG & BATCH>HKD/JB.D.PP.CRMCID.MIG
* to format the file before uploading the CRM file
* 
*-------------------------------------------------------------------------------------------
* Attached: -NA-
*----------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: -NA-
* OUT:-NA-
*
* Dependencies:
*---------------
* CALLS:-NA-
* CALLED BY:-NA-
*
* Revision History:
*------------------
* Date               who                  Reference                 Description
* 05-05-2025         Raghunandan          CRM Upload               Initial Version
*-------------------------------------------------------------------------------------

$INSERT I_COMMON
$INSERT I_EQUATE

GOSUB INIT
GOSUB READ.SG
GOSUB READ.HK

RETURN

*****
INIT:
*****
FN.FILE.PATH = '/u01/data/share/awa/BNK/BIC'
F.FILE.PATH = ""
CALL OPF(FN.FILE.PATH,F.FILE.PATH)
	
FN.SAVEDLISTS = '/u01/data/share/awa/BNK/BIC'
F.SAVEDLISTS = ''
CALL OPF(FN.SAVEDLISTS,F.SAVEDLISTS)
	
CR = CHARX(13)
LF = CHARX(10)
CRLF = CR:LF	

RETURN

********
READ.SG:
********
R.REC = ''
CALL F.READ(FN.FILE.PATH,'SGD_CRM.csv',R.REC,F.FILE.PATH,ERR)
IF R.REC NE '' THEN 
	GOSUB PROCESS
	GOSUB WRITE.FINAL.FILE.SG
END 
RETURN

********
READ.HK:
********
R.REC = ''
CALL F.READ(FN.FILE.PATH,'HKD_CRM.csv',R.REC,F.FILE.PATH,ERR)

IF R.REC NE '' THEN 
	GOSUB PROCESS
	GOSUB WRITE.FINAL.FILE.HK
END 
RETURN

*********
PROCESS:
*********
Y.FINAL.ARRAY = ''
Y.LINE.DETAIL = ''
Y.HEADER = R.REC<1>
DEL R.REC<1>

R.REC = TRIM(R.REC,'"','L')
R.REC = TRIM(R.REC,'"','T')

CHANGE CRLF TO '' IN R.REC
CHANGE FM TO '' IN R.REC
CHANGE '""' TO '~' IN R.REC

Y.COUNT = DCOUNT(R.REC,'~')

FOR I =1 TO Y.COUNT

	Y.LINE.DETAIL = FIELD(R.REC,'~',I)
	!Y.LINE.DETAIL = QUOTE(Y.LINE.DETAIL)
	Y.FINAL.ARRAY<-1> = Y.LINE.DETAIL 

NEXT I

RETURN

*******************
WRITE.FINAL.FILE.SG:
*******************
Y.SAVEDLIST.ID = 'SGD_CRM_TPH.csv'

WRITE Y.FINAL.ARRAY TO F.SAVEDLISTS,Y.SAVEDLIST.ID
X.COPY.CMD = "SH -c mv ":FN.SAVEDLISTS:"/SGD_CRM.csv " :FN.SAVEDLISTS:"/SGD_CRM_ORIGINAL.csv"
EXECUTE X.COPY.CMD

RETURN


*******************
WRITE.FINAL.FILE.HK:
*******************
Y.SAVEDLIST.ID = 'HKD_CRM_TPH.csv'

WRITE Y.FINAL.ARRAY TO F.SAVEDLISTS,Y.SAVEDLIST.ID
Y.COPY.CMD = "SH -c mv ":FN.SAVEDLISTS:"/HKD_CRM.csv " :FN.SAVEDLISTS:"/HKD_CRM_ORIGINAL.csv"
EXECUTE Y.COPY.CMD

RETURN

END
