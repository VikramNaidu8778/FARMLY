*----------------------------------------------------------------------------------------------------------------
SUBROUTINE JB.B.XX.MOVEOE.SELECT
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the select routine of the multi thread job that moves the few application
* records placed in INAU and with processing date less than today
*----------------------------------------------------------------------------------------------------------------
* Attached: to 
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date           Developer           Reference             Description
* 28-May-2025    Prabhu D S          CBPAY-3091            Initial Draft
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_F.COMPANY
    $INSERT I_JB.B.XX.MOVEOE.COMMON

    COMP.MNE = R.COMPANY(EB.COM.MNEMONIC)

    SEL.CMD = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH ProcessCompany EQ '":COMP.MNE:"' AND (Status EQ '235' OR Status EQ '135' OR Status EQ '516') AND RejectDescription LIKE '...COB...'"
    CALL EB.READLIST(SEL.CMD,SEL.LIST,NO.OF.REC,"",SEL.ERR)
    CALL BATCH.BUILD.LIST("",SEL.LIST)

    RETURN
END

