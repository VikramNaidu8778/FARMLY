SUBROUTINE JB.R.DE.GETCAMT057.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*This Build Routine is attached to Enquiries JB.E.DE.MMTXN.DELIVERY,
*JB.E.DE.NDFTXN.DELIVERY, JB.E.DE.SWAPTXN.DELIVERY & JB.E.DE.FXTXN.DELIVERY.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*30-07-24    Hariharan T      CBPAY-334        Build Routine to display the CAMT.057 Deliver Message reference along with MM,
*                                              FX,SWAP $ NDF Delivery Messages.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.DELIVERY.REQUEST.LISTENER
    $INSERT I_F.DE.HEADER
    $USING EB.Reports

    GOSUB INIT
    GOSUB PROCESS

RETURN
******
INIT:
******

    FN.DE.O.HEADER = "F.DE.O.HEADER"
    F.DE.O.HEADER = ""
    CALL OPF(FN.DE.O.HEADER,F.DE.O.HEADER)

    FN.DE.DELIVERY.REQUEST.LISTENER = "F.DE.DELIVERY.REQUEST.LISTENER"
    F.DE.DELIVERY.REQUEST.LISTENER = ""
    CALL OPF(FN.DE.DELIVERY.REQUEST.LISTENER,F.DE.DELIVERY.REQUEST.LISTENER)

RETURN


***********
PROCESS:
***********

    LOCATE 'TRANSACTION.REF' IN ENQ.DATA<2,1> SETTING TXN.POS THEN
        Y.OPER = ENQ.DATA<3,TXN.POS>
        TXN.ID = ENQ.DATA<4,TXN.POS>
      
        BEGIN CASE
            CASE Y.OPER MATCHES "EQ":@VM:"NE"
                SEL.FILTER = TXN.ID
          
            CASE OTHERWISE
                SEL.FILTER = "...":TXN.ID:"..."

        END CASE
        SEL.DEOH = "SELECT ":FN.DE.O.HEADER:" WITH TRANSACTION.REF ":Y.OPER:" ":SEL.FILTER

                     
        CALL EB.READLIST(SEL.DEOH,DEOH.IDS.LIST,"",NO.OF.DEOH.IDS,DEOH.ERR)
               
        
        LOOP
            REMOVE DELV.ID FROM DEOH.IDS.LIST SETTING DEL.POS
        WHILE DELV.ID : DEL.POS
        
            CALL F.READ(FN.DE.O.HEADER, DELV.ID, R.DE.O.HEADER.REC, F.DE.O.HEADER, DE.O.HEAD.ERR)
            
            Y.MSG.TYPE = R.DE.O.HEADER.REC<DE.HDR.MESSAGE.TYPE>
            
            IF Y.MSG.TYPE EQ "210" THEN
                        
                Y.CARRIER.SEQ.NO = R.DE.O.HEADER.REC<DE.HDR.CAR.SEQ.NO>
                                                       
                SEL.CMD = "SELECT ":FN.DE.DELIVERY.REQUEST.LISTENER:" WITH SOURCE.UNIQUE.ID EQ ":Y.CARRIER.SEQ.NO
                               
                CALL EB.READLIST(SEL.CMD,DEL.ID,"",NO.OF.DEL.IDS,DEL.ERR)

                R.DEL.REQ.LIST.REC = ""
                CALL F.READ(FN.DE.DELIVERY.REQUEST.LISTENER, DEL.ID, R.DEL.REQ.LIST.REC, F.DE.DELIVERY.REQUEST.LISTENER, R.DEL.REQ.LIST.ERR)
                IF R.DEL.REQ.LIST.REC THEN
                    DEL.CAMT057.LIST<-1> = R.DEL.REQ.LIST.REC<DE.DERL.DELIVERY.OUT.HEADER.ID>
                END
            END ELSE
                DLVRY.IDS.LIST<-1> = DELV.ID
            END
        REPEAT
        DLVRY.IDS.LIST<-1> = DEL.CAMT057.LIST
                
        CHANGE FM TO ' ' IN DLVRY.IDS.LIST
        
        EB.Reports.setEnqSkipSelect('1')
        
        ENQ.DATA<2,TXN.POS> = '@ID'
        ENQ.DATA<3,TXN.POS> = 'EQ'
        ENQ.DATA<4,TXN.POS> = DLVRY.IDS.LIST
    END
RETURN
*********************************
END



