SUBROUTINE JB.R.PP.ACCOUNTINFO.NOF(Y.OUTPUT)
*-----------------------------------------------------------------------------
* This routine is a nofile enquiry routine to fetch customer details from
* JB.XX.PARTY.DETAILS table for First Name, Middle Name & Last Name
* Attached in ENQUIRY>JB.E.PP.ACCOUNTINFO
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date        JIRA Ref         Resource            Description
* 17/01/2025  CBPAY-1590       Prabhu D S          Initial draft
*
* 15/04/2025  CBPAY-2362       Prabhu D S          Customer details are fetched from local table
*                                                  JB.XX.PARTY.DETAILS instead of CUSTOMER.
*------------------------------------------------------------------------------------------------------

    $INSERT I_EQUATE
    $INSERT I_COMMON
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.JB.XX.PARTY.DETAILS

    GOSUB INIT
    GOSUB PROCESS

RETURN
******
INIT:
*****

    Y.DELIM = "|"
    Y.AC.NO = ''
    R.ALTERNATE.ACCOUNT = ''
    R.ACCOUNT.REC = ''
    Y.PORTFOLIO.NAME = ''
    R.SEC.ACC.MASTER = ''

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''

    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''

    FN.JB.XX.PARTY.DETAILS = 'F.JB.XX.PARTY.DETAILS'
    F.JB.XX.PARTY.DETAILS = ''

    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    CALL OPF(FN.JB.XX.PARTY.DETAILS,F.JB.XX.PARTY.DETAILS)

    LOCATE "ACCOUNT.NUMBER" IN D.FIELDS<1> SETTING AC.NO.POS THEN
        Y.AC.NO = D.RANGE.AND.VALUE<AC.NO.POS>
    END

RETURN
********
PROCESS:
********

    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.AC.NO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,'')
    IF R.ALTERNATE.ACCOUNT THEN
        Y.AC.NO = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
    END

    CALL F.READ(FN.ACCOUNT,Y.AC.NO,R.ACCOUNT.REC,F.ACCOUNT,'')
    IF R.ACCOUNT.REC THEN
        Y.AC.CUS = R.ACCOUNT.REC<AC.CUSTOMER>
        Y.PORT.NO = R.ACCOUNT.REC<AC.PORTFOLIO.NO>
        GOSUB GET.ALT.ACCT
        GOSUB GET.CUST.DETAILS
        GOSUB GET.PORTFOLIO
        GOSUB GET.PARTY.DETAILS
        GOSUB FORM.ARRAY
    END

RETURN
*************
GET.ALT.ACCT:
*************

    Y.CUS.NAME = ''
    LOCATE "BJB.ACCT" IN R.ACCOUNT.REC<AC.ALT.ACCT.TYPE,1> SETTING Y.POS THEN
        Y.CUS.NAME = R.ACCOUNT.REC<AC.ALT.ACCT.ID,Y.POS>
    END


RETURN
*****************
GET.CUST.DETAILS:
*****************

    CALL F.READ(FN.CUSTOMER,Y.AC.CUS,R.CUSTOMER.REC,F.CUSTOMER,'')
    Y.CUS.TARGET = R.CUSTOMER.REC<EB.CUS.TARGET>

RETURN
**************
GET.PORTFOLIO:
**************

    CALL F.READ(FN.SEC.ACC.MASTER,Y.PORT.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,'')
    IF R.SEC.ACC.MASTER THEN
        Y.PARTY.ID = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
    END

RETURN
******************
GET.PARTY.DETAILS:
******************

    CALL F.READ(FN.JB.XX.PARTY.DETAILS,Y.PARTY.ID,R.JB.XX.PARTY.DETAILS,F.JB.XX.PARTY.DETAILS,'')
    IF R.JB.XX.PARTY.DETAILS THEN
        Y.PORTFOLIO.NAME = R.JB.XX.PARTY.DETAILS<PART.DET.PORT.NAME>
        Y.FIRST.NAME = R.JB.XX.PARTY.DETAILS<PART.DET.PART.F.NAME>
        Y.MID.NAME = R.JB.XX.PARTY.DETAILS<PART.DET.PART.M.NAME>
        Y.LAST.NAME = R.JB.XX.PARTY.DETAILS<PART.DET.PART.L.NAME>
        Y.CUS.ADDR.1 = R.JB.XX.PARTY.DETAILS<PART.DET.PART.ADDR.TYPE>
        Y.CUS.ADDR.2 = R.JB.XX.PARTY.DETAILS<PART.DET.PART.ADDRESS>
        Y.CUS.ADDR.3 = R.JB.XX.PARTY.DETAILS<PART.DET.PART.POST.CODE>:" ":R.JB.XX.PARTY.DETAILS<PART.DET.PART.CITY>
        Y.CUS.RESIDENCE = R.JB.XX.PARTY.DETAILS<PART.DET.PART.COUNTRY>

        Y.NAME.CNT = DCOUNT(Y.FIRST.NAME,@VM)

        FOR Y.IDX = 1 TO Y.NAME.CNT
            Y.PARTY.NAME<Y.IDX> = "Account Holder Name ":Y.IDX:"*":Y.FIRST.NAME<1,Y.IDX>:" ":Y.MID.NAME<1,Y.IDX>:" ":Y.LAST.NAME<1,Y.IDX>
        NEXT Y.IDX
    END

RETURN
***********
FORM.ARRAY:
***********

    Y.AC.CUS         = "Customer ID*":Y.AC.CUS
    Y.AC.NO          = "Account*":Y.AC.NO
    Y.CUS.NAME       = "Name 1*":Y.CUS.NAME
    Y.CUS.ADDR.1     = "Address Line 1*":Y.CUS.ADDR.1
    Y.CUS.ADDR.2     = "Address Line 2*":Y.CUS.ADDR.2
    Y.CUS.ADDR.3     = "Address Line 3*":Y.CUS.ADDR.3
    Y.CUS.RESIDENCE  = "Residency*":Y.CUS.RESIDENCE
    Y.CUS.TARGET     = "Business Line*":Y.CUS.TARGET
    Y.PORTFOLIO.NAME = "Portfolio Name*":Y.PORTFOLIO.NAME

    Y.OUTPUT<-1> = Y.AC.CUS:Y.DELIM:Y.AC.NO:Y.DELIM:Y.CUS.NAME:Y.DELIM:Y.CUS.ADDR.1:Y.DELIM:Y.CUS.ADDR.2:Y.DELIM:Y.CUS.ADDR.3:Y.DELIM:Y.CUS.RESIDENCE
    Y.OUTPUT := Y.DELIM:Y.CUS.TARGET:Y.DELIM:Y.PORTFOLIO.NAME:Y.DELIM:Y.PARTY.NAME

RETURN

END
