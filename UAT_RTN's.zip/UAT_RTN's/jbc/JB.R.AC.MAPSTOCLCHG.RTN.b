SUBROUTINE JB.R.AC.MAPSTOCLCHG.RTN(R.PAYMENTORDER,OERROR)
*------------------------------------------------------------------------------------------------------------
*------------------------------------------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* This Routine is attached in Field Ft Routine , in VERSION "STANDING.ORDER,JB.V.AC.STOOT03OT12" to
* Default user inputted Charges .
*-------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: N/A
* OUT: N/A
* Revision History:
*--------------------------------------------------------------------------------------------------------------
* Date               Developer         Reference                      Description
*
*19-JUL-2024       Lakshmi Priya       CBPAY-100          This routine is to set to default user inputted charges.
*
*07-08-2024          Prabhu            CBPAY-439          This Routine is updated to default Order Initiation Type
*                                                             based on Payment Currency and Payment Channel .
*20-12-2024        Lakshmi Priya       CBPAY-1487         This routine is to get Delivery address from DE.ADDRESS if
*                                                         STO>RECEIVER.BANK is inputted and Default in PO>RECEIVER.BIC .
*07-04-2025        Lakshmi Priya       CBPAY - 1971       Included mapping for Correspondent Bank Charges and Charge Account,
*                                                         From STO to PO .
*06-05-2025        Lakshmi Priya       CBPAY - 2677       Included mapping for Last Run Date from STO to Credit Value date of PO.
*
*28-05-2025        Vikram Pavuluru     CBPAY-2207         Removed mapping of receiver BIC from STO to PO for OT12
*22-06-2025        Prabhu D S          CBPAY-3457         Charges are to be mapped from STO to PO as CheckTransparency not working
*                                                         for Payments initiated from external system.
* 28/06/25         Prabhu D S          CBPAY-2677         Included logic to handle Value date
*--------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.DE.ADDRESS

    GOSUB INIT
    GOSUB PROCESS

RETURN
*****
INIT:
*****
    Y.ORDREFERENCE = ''
    FN.STANDING.ORDER = 'F.STANDING.ORDER'
    F.STANDING.ORDER = ''
    CALL OPF(FN.STANDING.ORDER,F.STANDING.ORDER)
    FN.DE.ADDRESS = 'F.DE.ADDRESS'
    F.DE.ADDRESS = ''
    CALL OPF(FN.DE.ADDRESS,F.DE.ADDRESS)

RETURN
*******
PROCESS:
*******
    Y.STOID = R.PAYMENTORDER<PO.ORDERING.REFERENCE>

    CALL F.READ(FN.STANDING.ORDER,Y.STOID,R.STO.REC,F.STANDING.ORDER,STO.ERR)
    APPL = "STANDING.ORDER":@FM:"PAYMENT.ORDER"
    APPL.LOC.FLDS = 'L.PO.HKPAY.CHNL':@FM:'L.PO.CLNT.CHG':@VM:'L.PO.HKPAY.CHNL':@VM:'L.PO.CORR.BANK'
    CALL MULTI.GET.LOC.REF(APPL,APPL.LOC.FLDS,Y.POS)
    Y.STO.PYMTCHNL.FLD.POS = Y.POS<1,1>
    Y.PO.COMM.FLD.POS = Y.POS<2,1>
    Y.PO.PYMTCHNL.FLD.POS = Y.POS<2,2>
    Y.PO.CORR.BNK.POS = Y.POS<2,3>

    PO.CHG.TYPES = R.PAYMENTORDER<PO.CHARGE.TYPE>
    LOCATE "CORRBKCHG" IN PO.CHG.TYPES<1,1> SETTING CHG.TYP.POS THEN
       R.PAYMENTORDER<PO.CHARGE.TYPE,CHG.TYP.POS> = "OUTBOUNDOURCHARGE"
    END

    Y.STO.HKPAY.CHNL = R.STO.REC<STO.LOCAL.REF,Y.STO.PYMTCHNL.FLD.POS>

    R.PAYMENTORDER<PO.LOCAL.REF,Y.PO.PYMTCHNL.FLD.POS> = Y.STO.HKPAY.CHNL
    R.PAYMENTORDER<PO.ORDER.INITIATION.TYPE> = ''

    IF Y.STO.HKPAY.CHNL EQ 'HKCHATS' THEN
        R.PAYMENTORDER<PO.ORDER.INITIATION.TYPE> = 'STOMXCHATS'
    END ELSE
        R.PAYMENTORDER<PO.ORDER.INITIATION.TYPE> = 'STO'
    END
  
RETURN
*************************************************************************************************
END
