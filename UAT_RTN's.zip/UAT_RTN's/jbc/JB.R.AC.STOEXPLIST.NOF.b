SUBROUTINE JB.R.AC.STOEXPLIST.NOF(Y.FINAL.ARRAY)
*-----------------------------------------------------------------------------------------
* Attached in Enquiry > JB.E.AC.STO.EXPPYMTLIST as nofile Enquiry 
*-----------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------
*  Date          Developer          Reference         Description
* 20-03-2025   Lakshmi Priya       CBPAY - 1903   Nofile Routine to select all the STO�s with the End Date
*                                                   less than Today + Reversed + Inactive marker is set . 
* 25-03-2025    Lakshmi Priya      CBPAY - 1903   Modified the selction command by including logic to select STO Payments 
*                                                  with end date not equal to null and end date lesser than today. 
*-----------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.STANDING.ORDER
*------------------------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS.STO.LIV
    GOSUB PROCESS.STO.HIS

RETURN

*****
INIT:
*****
    FN.STANDING.ORDER = "F.STANDING.ORDER"
    F.STANDING.ORDER = ""
    CALL OPF(FN.STANDING.ORDER, F.STANDING.ORDER)

    FN.STANDING.ORDER.HIS = "F.STANDING.ORDER$HIS"
    F.STANDING.ORDER.HIS = ""
    CALL OPF(FN.STANDING.ORDER.HIS, F.STANDING.ORDER.HIS)

    
    Y.STO.LIST = ""

    

RETURN
***************
PROCESS.STO.LIV:
***************

   SEL.CMD.HIS = ""

    SEL.CMD.LIV = "SELECT ":FN.STANDING.ORDER:" WITH CURRENT.END.DATE NE '' AND CURRENT.END.DATE LT ":TODAY:" OR INACTIVE EQ YES"
    GOSUB FORM.SEL.CMD
    IF Y.PORT.VALUE THEN   
        SEL.CMD.LIV := Y.SEL.OPER
    END
    CALL EB.READLIST(SEL.CMD.LIV,Y.SEL.LIST.LIV,'',Y.SEL.CNT1,'')
    LOOP
        REMOVE Y.STO.ID.LIV FROM Y.SEL.LIST.LIV SETTING Y.STO.POS1
    WHILE Y.STO.ID.LIV : Y.STO.POS1
        CALL F.READ(FN.STANDING.ORDER,Y.STO.ID.LIV,R.STO.REC.LIV,F.STANDING.ORDER,STO.ERR)
        IF R.STO.REC.LIV THEN
             Y.PAY.METHOD = R.STO.REC.LIV<STO.PAY.METHOD>
             Y.ACCT.NUMBER = FIELD(Y.STO.ID.LIV,".",1)
             Y.CURR.FREQ = R.STO.REC.LIV<STO.CURRENT.FREQUENCY>
             Y.DEBIT.CUST = R.STO.REC.LIV<STO.DEBIT.CUSTOMER>
             Y.DEBIT.AMT  = R.STO.REC.LIV<STO.CURRENT.AMOUNT.BAL>
             Y.CREDIT.CUST = R.STO.REC.LIV<STO.CREDIT.CUSTOMER>
             Y.STO.CURRENCY  = R.STO.REC.LIV<STO.CURRENCY>
             Y.PAY.REF = R.STO.REC.LIV<STO.PAYMENT.REFERENCE>
             CALL GET.LOC.REF("STANDING.ORDER","L.PP.BO.USRCOM",Y.POS)
             Y.BO.USRCOM = R.STO.REC.LIV<STO.LOCAL.REF,Y.POS>         
            Y.FINAL.ARRAY<-1> = Y.STO.ID.LIV:"*":Y.PAY.METHOD:"*":Y.ACCT.NUMBER:"*":Y.CURR.FREQ:"*":Y.DEBIT.CUST:"*":Y.DEBIT.AMT:"*":Y.CREDIT.CUST:"*":Y.STO.CURRENCY:"*":Y.PAY.REF:"*":Y.BO.USRCOM

        END
    REPEAT
   
RETURN
****************
PROCESS.STO.HIS:
****************
    Y.SEL.OPER = ''
    SEL.CMD.HIS = "SELECT ":FN.STANDING.ORDER.HIS:" WITH RECORD.STATUS EQ REVE"
    GOSUB FORM.SEL.CMD
    IF Y.PORT.VALUE THEN  
        SEL.CMD.HIS := Y.SEL.OPER
    END
    CALL EB.READLIST(SEL.CMD.HIS,Y.SEL.LIST.HIS,'',Y.SEL.CNT2,'')
    LOOP
        REMOVE Y.STO.ID.HIS FROM Y.SEL.LIST.HIS SETTING Y.STO.POS2
    WHILE Y.STO.ID.HIS : Y.STO.POS2
        CALL F.READ(FN.STANDING.ORDER.HIS,Y.STO.ID.HIS,R.STO.REC.HIS,F.STANDING.ORDER.HIS,STO.ERR)
        IF R.STO.REC.HIS THEN
            Y.PAY.METHOD = R.STO.REC.HIS<STO.PAY.METHOD>
             Y.ACCT.NUMBER = FIELD(Y.STO.ID.LIV,".",1)
             Y.CURR.FREQ = R.STO.REC.HIS<STO.CURRENT.FREQUENCY>
             Y.DEBIT.CUST = R.STO.REC.HIS<STO.DEBIT.CUSTOMER>
             Y.DEBIT.AMT  = R.STO.REC.HIS<STO.CURRENT.AMOUNT.BAL>
             Y.CREDIT.CUST = R.STO.REC.HIS<STO.CREDIT.CUSTOMER>
             Y.CREDIT.AMT  = R.STO.REC.HIS<STO.CURRENCY>
             Y.ID.HIS = FIELD(Y.STO.ID.HIS,";",1)
             Y.PAY.REF = R.STO.REC.LIV<STO.PAYMENT.REFERENCE>
             CALL GET.LOC.REF("STANDING.ORDER","L.PP.BO.USRCOM",Y.POS)
             Y.BO.USRCOM = R.STO.REC.LIV<STO.LOCAL.REF,Y.POS> 
            
            Y.FINAL.ARRAY<-1> = Y.ID.HIS:"*":Y.PAY.METHOD:"*":Y.ACCT.NUMBER:"*":Y.CURR.FREQ:"*":Y.DEBIT.CUST:"*":Y.DEBIT.AMT:"*":Y.CREDIT.CUST:"*":Y.STO.CURRENCY:"*":Y.PAY.REF:"*":Y.BO.USRCOM

        END

    REPEAT

RETURN
************
FORM.SEL.CMD:
*************
    LOCATE '@ID' IN D.FIELDS<1> SETTING ID.POS THEN
        Y.PORT.VALUE = D.RANGE.AND.VALUE<ID.POS>
        IF SEL.CMD.HIS THEN
           Y.SEL.OPER := " AND @ID LIKE ...":Y.PORT.VALUE:"..."
        END ELSE
           Y.SEL.OPER := " AND @ID EQ ":Y.PORT.VALUE
        END
    END
RETURN

END    
