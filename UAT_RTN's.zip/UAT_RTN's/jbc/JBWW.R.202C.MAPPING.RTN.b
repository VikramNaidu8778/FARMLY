* @ValidationCode : MToxMDkxNzU5NDcwOklTTy04ODU5LTE6MTUxMTI2MTUwNTkzMjo1NDYxMDc6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4Ljc=
* @ValidationInfo : Timestamp         : 21 Nov 2017 16:21:45
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 546107
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
SUBROUTINE JBWW.R.202C.MAPPING.RTN(MAT DE.O.HANDOFF,ERR.MSG)
*------------------------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                  Reference               Description
*-------------------------------------------------------------------------------------------
* 20/11/2017	Lavanya K                  JB2A-45680              The tag57 should be neglected if the receiver and corr bank are same
* 04/12/2020    Senthil K                  P3636-5615              Updates for P3636-5615: CNYCNH - Retrofit
*--------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.MAPPING
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
RETURN
*-----------------------------------------------------------------------------

********
INIT:
********
    FN.DE.MAPPING = 'F.DE.MAPPING'
    F.DE.MAPPING = ''
    CALL OPF(FN.DE.MAPPING,F.DE.MAPPING)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
*
RETURN
********
PROCESS:
********

    IF R.NEW(FT.RECEIVER.BANK) EQ R.NEW(FT.REC.CORR.BANK) THEN
        DE.O.HANDOFF(2)<51> = ""
    END

*  CALL SGMB.CHG.SWF.CCY.OUT(MAT DE.O.HANDOFF,ERR.MSG) ;*P3636-5615
*
RETURN

END
