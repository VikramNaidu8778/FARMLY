*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.MSGMAP.ENRICH.API(ioPaymentObject, ioAuditTrailLog)
*-----------------------------------------------------------------------------
* This routine attached as EnrichAPI in the below records,
* PP.MSGMAPPINGPARAMETER>PayOrder.OT03
* PP.MSGMAPPINGPARAMETER>PayOrder.OT12
* PP.MSGMAPPINGPARAMETER>PayOrder.OT12
* PP.MSGMAPPINGPARAMETER>SWIFTMX.pacs.008
* PP.MSGMAPPINGPARAMETER>SWIFTMX.pacs.009
* PP.MSGMAPPINGPARAMETER>CHATSMX.pacs.008
* PP.MSGMAPPINGPARAMETER>CHATSMX.pacs.009
*
* This is to do the following activities
* 1) To calculate the PED = RCVD - 2W (based on payment currency holiday)
* 2) To calculate & set the different TPH dates
*    a) RED = TODAY - This is to raise the forward entries for future value dated transactions
*    b) PED = RCVD - 2W - as mentioned in Point.1. This is applicable only for Non-STO transactions
*    c) CVD based on RCVD (considering the settlement shift defined in PP.CHANNEL.CUTOFF & PED).
*       This is applicable only when the SEND.PAYMENT set to YES and for Non-STO transactions
*    d) DVD = CVD
* Caveat - As agreed with payment Ops users - Cut-off will not considered.
* It will be defined in PP.CHANNEL.CUTOFF with maximum time as 23:59 Server Zurich Time
* 3) For Incoming messages, Inter Bank Settlement to be honored for DVD & CVD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 01-Mar-2025 u40786             CBPAY-1617        Initial Version
*
* 21-Mar-2025 prabhu             CBPAY-1903        Added logic to impose processing date as
*                                                  credit and debit value date for STO Payments
*
* 01-Apr-2025 P Amala            CBPAY-65          RequestedExecutionDate should be updated as Today
*                                                  for the forward dated Book Payment.
*
* 25-Apr-2025 u40786             CBPAY-2494        To cater the back-value date to be traversed from PO to TPH
*
* 03-Jun-2025 u40786             CBPAY-1617        Payment Direction hardcoded as 'O' as the transaction types
*                                                  appliable for this functionality is OT03, OT12.
*                                                  Payment Direction value not available at this stage.
*
* 19-Jun-2025 PRABHU D S         CBPAY-2677        Defaulting RCVD as CVD fot STO payments.
*
* 28-Jun-2025 Prabhu D S         CBPAY-2677        Included logic to handle Value date
*
* 30-Jun-2025 u40786             CBPAY-3118        Payment Direction not set for incoming pacs.008. But set for pacs.004
*                                                  Hence incomingMessageType argument being used to identify the incoming
*                                                  pacs.008, pacs.009, pacs.004 instead of direction.
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.MessageMappingService
    $USING PP.PaymentFrameworkService
    $USING PP.RoutingAndSettlementService
    $USING PI.Contract
    $INSERT I_F.JBWW.H.XX.CCYCUTOFF.RULE
    $INSERT I_F.PAYMENT.ORDER

    GOSUB INIT
    
    BEGIN CASE
        CASE Y.TXN.TYPE EQ 'pacs.008' OR Y.TXN.TYPE EQ 'pacs.009' OR Y.TXN.TYPE EQ 'pacs.004'
            GOSUB SET.INTERBNKSETT.DATES
            
        CASE OTHERWISE
            IF Y.TXN.TYPE MATCHES Y.GPM.VALUE THEN
* For Book Payments
                GOSUB UPD.REDDATE.BOOKPYMNT
                RETURN
            END

            GOSUB PROCESS
    END CASE
*
RETURN
*
*****
INIT:
*****
    
    ORIG.SOURCE = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.originatingSource>
    TXN.CCY = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.transactionCurrencyCode>
    RCVD = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.requestedCreditValueDate>
    PROCESSING.DATE = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.processingDate>
    Y.TXN.TYPE = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.incomingMessageType>
    PAYMENT.DIRECTION = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.paymentDirection>
    DVD = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.debitValueDate>
    CVD = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.creditValueDate>
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    Y.GPM.VALUE = '' ; Y.BOOKPYMT.FWD = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","NOSTCASHFLOW.FWDPYMT",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE
*
RETURN
*
********
PROCESS:
********

    GOSUB GET.CHANNEL.CUTOFF.DETS
    GOSUB GET.MSG.SUPPRESS.FLAG

    BEGIN CASE

        CASE NOT(ORIG.SOURCE MATCHES 'STO':@VM:'STOMXCHATS')
            GOSUB CALC.PD
            IF RCVD AND Y.SEND.PYMT NE 'NO' THEN
                GOSUB CALC.CVD
            END ELSE
                CVD = RCVD
            END

        CASE ORIG.SOURCE MATCHES 'STO':@VM:'STOMXCHATS'
            IF NOT(CVD) THEN
                CVD = DVD
            END

    END CASE
    
    GOSUB SET.TPH.DATES
*
RETURN
*
************************
GET.CHANNEL.CUTOFF.DETS:
************************

    O.CHANNEL.DETS = ''
    O.CHANNEL.FXSHIFT.DETS = ''
    O.CHANNEL.RESP = ''
    
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.channelName> = 'NOSTRO'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.currencyCode> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.transactionCurrencyCode>
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.ctrbtrIndicator> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.ctrBtrIndicator>
*    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.paymentDirection> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.paymentDirection>
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.paymentDirection> = 'O'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.priority> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.messagePriority>
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.messageType> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.incomingMessageType>
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.source> = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.originatingSource>
    
    CALL PP.FIND.CHANNEL.CUTOFF(I.CHANNEL.NAME,O.CHANNEL.DETS,O.CHANNEL.FXSHIFT.DETS,O.CHANNEL.RESP)

    SS = ''
    IF O.CHANNEL.RESP EQ '' THEN
        SS = O.CHANNEL.DETS<PP.RoutingAndSettlementService.ChannelCutoffDetails.settlementShift>
    END
*
RETURN
*
**********************
GET.MSG.SUPPRESS.FLAG:
**********************

    Y.SEND.PYMT = ''
    CNT = 1
    LOOP
    WHILE ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,CNT,PP.MessageMappingService.PORPmtFlowDetailsList.localFieldName> NE ''
        IF ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,CNT,PP.MessageMappingService.PORPmtFlowDetailsList.localFieldName> EQ 'L.PP.SEND.PYMT' THEN
            Y.SEND.PYMT = ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,CNT,PP.MessageMappingService.PORPmtFlowDetailsList.localFieldValue>
        END
        CNT = CNT + 1
    REPEAT
*
RETURN
*
********
CALC.PD:
********

* Calculate the Processing Date by reducing 2W from RCVD
* If calculated date is less than TODAY, reset to TODAY

    Y.REGION = TXN.CCY[1,2]:'00'
    Y.DATE = RCVD
    Y.DAYS = '-2W'
    CALL CDT(Y.REGION,Y.DATE,Y.DAYS)

    Y.REGION = ''
    Y.DAY.TYPE = ''
    CALL AWD('',Y.DATE,Y.DAY.TYPE)

    IF Y.DAY.TYPE NE 'W' THEN
        Y.REGION = ''
        CALL CDT(Y.REGION,Y.DATE,'-1W')
    END

    IF Y.DATE LT TODAY THEN
        PD = TODAY
    END ELSE
        PD = Y.DATE
    END
*
RETURN
*
*********
CALC.CVD:
*********

    Y.REGION = TXN.CCY[1,2]:'00'
    Y.DATE.2 = RCVD
    Y.DATE.1 = TODAY
    DIFF.DAYS = 'W'
    CALL CDD(Y.REGION,Y.DATE.1,Y.DATE.2,DIFF.DAYS)
    IF DIFF.DAYS GT 2 THEN
* If RCVD is greater than 2 days, set CVD as RCVD
        CVD = RCVD ; * Ignore SS
    END ELSE
* If RCVD is less than or equal to 2 days, consider the Setttlement Shift defined in PP.CHANNEL.CUTOFF to calculate CVD
        Y.REGION = TXN.CCY[1,2]:'00'
        Y.DATE = PD
        Y.DAYS = SS:'W'
        CALL CDT(Y.REGION,Y.DATE,Y.DAYS)
        CVD = Y.DATE

        IF CVD LT RCVD THEN
* If calculated CVD is less than RCVD, reset the CVD to RCVD
            CVD = RCVD
        END
    END
*
RETURN
*
**************
SET.TPH.DATES:
**************

    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.requestedExecutionDate> = TODAY
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.processingDate> = PD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.processingDateImposedFlag> = 'Y'
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.creditValueDate> = CVD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.creditValueImposedFlag> = 'Y'
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.debitValueDate> = CVD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.debitValueImposedFlag> = 'Y'
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.requestedCreditValueDate> = CVD
*
RETURN
*
**********************
UPD.REDDATE.BOOKPYMNT:
**********************

* This is to cater the back-value date to be traversed from PO to TPH
    GOSUB SET.INTERBNKSETT.DATES
    IF PROCESSING.DATE GT TODAY THEN
* This is to cater the F-Entry for the Future Value Date payments
        ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.requestedExecutionDate> = TODAY
    END
*
RETURN
*
***********************
SET.INTERBNKSETT.DATES:
***********************

* This is to set the IntrBkSttlmDt Tag value to both CVD & DVD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.creditValueDate> = RCVD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.creditValueImposedFlag> = 'Y'
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.debitValueDate> = RCVD
    ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.debitValueImposedFlag> = 'Y'
*
RETURN
*
END
*