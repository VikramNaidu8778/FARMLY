SUBROUTINE JB.R.PP.OETRHTRADES.INP
*-----------------------------------------------------------------------------------------
* This is an Input routine to update JBWW.L.XX.TRH.TRADES & JBWW.H.XX.TRH.TRADES tables
* with Credit details for manual Outgoing pacs.004 payments via Order Entry.
* This is a copy of existing routine JBWW.R.FT.TRHTRADES.CALL and modified for OE
*-----------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  15-JUL-2024   Prabhu D S         CBPAY-549         Initial Draft
*  26-APR-2025   Resmi R            CBPAY-2660        Fetched the Transaction Currency value from CreditAccountCurrency field of PP.ORDER.ENTRY
*  13-May-2025	 Resmi R            CBPAY-2826        Included logic to update trades tables when return is initiated for the original payment
*  27-May-2025   Prabhu D S         CBPAY-2826        Fixed the logic to update Status field as Incepetion instead of Unauth in INAU stage while returning the payment
*  28-May-2025   Prabhu D S         CBPAY-2826        Fixed the logic to update Transaction amount.
*  16-Jun-2025   Prabhu D S         CBPAY-2896        Fixed the logic to update the completed transactions are not sent to UCCE during SOD
*-----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_TPH.TRHTRADES.COMMON
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.ACCOUNT
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.PAYMENT.ORDER.PRODUCT
    $INSERT I_F.JBWW.L.XX.TRH.TRADES
    $INSERT I_F.JBWW.H.XX.TRH.TRADES
    $INSERT I_GTS.COMMON
    $INSERT I_F.DATES

*------------------------------------------------------------------------------
    
    GOSUB INIT
    GOSUB PROCESS

RETURN

*****
INIT:
*****

    UNAUTH.FLAG = 0
    CC.REMV.FLAG = ''

    FUNCTION.VAL = V$FUNCTION
    STATUS.VAL = R.NEW(PP.OEYG.RECORD.STATUS)
    CURR.NO.VAL = R.NEW(PP.OEYG.CURR.NO)
    NO.AUTH.VAL = R.VERSION(EB.VER.NO.OF.AUTH)
    PROCESSING.DATE = R.NEW(PP.OEYG.ProcessingDate)
    OE.TXN.TYPE = R.NEW(PP.OEYG.IncomingMessageType)
    FT.NO = R.NEW(PP.OEYG.TransactionReferenceNumber)
    LOC.REF.FLD = 'L.PP.DEF.INW.IT'
    Y.OE.DIR = R.NEW(PP.OEYG.Direction)
    Y.CLR.TXN.TYP = R.NEW(PP.OEYG.ClearingTransactionType)
    
    CALL GET.LOC.REF(APPLICATION,LOC.REF.FLD,LOC.POS)
    TRANSACTION.TYPE = R.NEW(PP.OEYG.LOCAL.REF)<1,LOC.POS>    
    CALL JB.R.PP.TRHTRADES.OPENFILES
    
RETURN

********
PROCESS:
********
    
    IF Y.OE.DIR EQ 'O' AND Y.CLR.TXN.TYP EQ 'RT' THEN
            
        LOCATE TRANSACTION.TYPE IN FTTXNCODE.PAYOUT.VALS<1,1> SETTING FTTXN.POS THEN
            ACCT.NO = R.NEW(PP.OEYG.DebitAccountNumber)

            GOSUB CR.CHECK.CUSTOMER           
            GOSUB DEBIT.LINE.PROCESS
        END
       
    END ELSE
          
        LOCATE TRANSACTION.TYPE IN FTTXNCODE.PAYIN.VALS<1,1> SETTING FTTXN.POS THEN
            ACCT.NO = R.NEW(PP.OEYG.CreditAccountNumber)
            GOSUB CR.CHECK.CUSTOMER
            GOSUB CREDIT.LINE.PROCESS
        END

      
    END

RETURN

******************
CR.CHECK.CUSTOMER:
******************

    GOSUB CHECK.CLIENT.CUST

    CR.FLAG = ''
    LOCATE Y.SECTOR IN INCLUDE.SECTOR.VALS<1,1> SETTING SECT.POS THEN
        CR.FLAG = '1'
    END
    CR.INCLUDE.ACCT = ''
    LOCATE CATEGORY.VAL IN INCLUDE.CATEGORY.VALS<1,1> SETTING CATEGORY.POS THEN
        CR.INCLUDE.ACCT = '1'
    END

RETURN

******************
CHECK.CLIENT.CUST:
******************
    R.ACCOUNT = '' ; ACCT.ERR = ''
    CALL F.READ(FN.ACCOUNT,ACCT.NO,R.ACCOUNT,FV.ACCOUNT,ACCT.ERR)
    CUSTOMER.ID = R.ACCOUNT<AC.CUSTOMER>
    PORTFOLIO.ID = R.ACCOUNT<AC.PORTFOLIO.NO>
    CATEGORY.VAL = R.ACCOUNT<AC.CATEGORY>
    R.CUSTOMER = '' ; CUSTOMER.ERR = ''
    CALL F.READ(FN.CUSTOMER,CUSTOMER.ID,R.CUSTOMER,FV.CUSTOMER,CUSTOMER.ERR)
    Y.SECTOR = R.CUSTOMER<EB.CUS.SECTOR>

RETURN

********************
CREDIT.LINE.PROCESS:
********************
    ACCT.NO = R.NEW(PP.OEYG.CreditAccountNumber)
    TXN.AMT = R.NEW(PP.OEYG.CreditAmount)
    TXN.CCY = R.NEW(PP.OEYG.CreditAccountCurrency)
    TXN.TYPE = 'PAYIN'
    OE.VALUE.DATE = R.NEW(PP.OEYG.ProcessingDate)
    IF CR.FLAG AND CR.INCLUDE.ACCT THEN
        GOSUB UPDATE.CONCAT.AND.TRADE.TABLES
    END

RETURN

********************
DEBIT.LINE.PROCESS:
********************
    ACCT.NO = R.NEW(PP.OEYG.DebitAccountNumber)
    TXN.AMT = R.NEW(PP.OEYG.TransactionAmount)* -1
    TXN.CCY = R.NEW(PP.OEYG.DebitAccountCurrency)
    TXN.TYPE = 'PAYOUT'
    OE.VALUE.DATE = R.NEW(PP.OEYG.ProcessingDate)

    IF CR.FLAG AND CR.INCLUDE.ACCT THEN
        GOSUB UPDATE.CONCAT.AND.TRADE.TABLES
    END

RETURN

*******************************
UPDATE.CONCAT.AND.TRADE.TABLES:
*******************************

    R.TRADE.RECORD.ARRAY = ''

    R.PO.PRD.ORD = ''; PO.PRD.ERR = ''
    CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,TRANSACTION.TYPE,R.PO.PRD.ORD,FV.PAYMENT.ORDER.PRODUCT,PO.PRD.ERR)
    NARRATIVE = R.PO.PRD.ORD<POP.DESCRIPTION>

    R.TRADE.RECORD.ARRAY<JB.TRHTRD.is.Batch> = 'False'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.src.System> = 'T24-FT'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.client.Nbr> = R.CUSTOMER<EB.CUS.MNEMONIC>

 
    SEC.ACC.MASTER.ERR = '' ; SEC.ACC.MASTER.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,PORTFOLIO.ID, R.SEC.ACC.MASTER, FV.SEC.ACC.MASTER,SEC.ACC.MASTER.ERR)
    ACCOUNT.NAME = ''

    IF NOT(SEC.ACC.MASTER.ERR) THEN
        ACCOUNT.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
    END ELSE
        CALL JB.R.PP.GETSAMACC.RTN(ACCT.NO,PORTFOLIO.NUMBER.VAL)
        GOSUB GET.PORTFOLIO.DETAILS
        ACCOUNT.NAME = PORTFOLIO.NAME
    END


    R.TRADE.RECORD.ARRAY<JB.TRHTRD.portfolio.Nbr> = ACCOUNT.NAME
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Type> = TXN.TYPE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.inst.Identifier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.underlying> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sub.Asset.Type> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Amt> = TXN.AMT
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.txn.Ccy> = TXN.CCY
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.ref.Nbr> = FT.NO
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.value.Date> = OE.VALUE.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.quantity> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.strike.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.spot.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.run.Notional> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.short.Notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Size> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta.Structure> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.number.Of.Settl.Dates> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.multiplier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.nbr.Of.Options> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trans.Desc> = NARRATIVE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.tenor> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.option.Desc> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.dlv.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.link.Reference> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.processing.Date> = PROCESSING.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.buy.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.base.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'False'
    R.ORDER.ENTRY = ''
    PO.ERR = ''
    CALL F.READ(FN.PP.ORDER.ENTRY, ID.NEW, R.ORDER.ENTRY, FV.PP.ORDER.ENTRY, OE.ERR)

    R.JBWW.L.XX.TRH.TRADES = ''
    TRH.TRADES.ERR = ''
    CALL F.READ(FN.JBWW.L.XX.TRH.TRADES, FT.NO, R.JBWW.L.XX.TRH.TRADES, FV.JBWW.L.XX.TRH.TRADES, TRH.TRADES.ERR)

    R.JBWW.H.XX.TRH.TRADES = ''
    TRADES.ERR = ''
    CALL F.READ(FN.JBWW.H.XX.TRH.TRADES, FT.NO, R.JBWW.H.XX.TRH.TRADES, FV.JBWW.H.XX.TRH.TRADES, TRADES.ERR)

    IF (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND CURR.NO.VAL GE 1) OR (FUNCTION.VAL EQ 'A' AND CURR.NO.VAL GT 1) THEN
        AMENDMENT.FLAG = 1
    END

    DUP.INCEP.FLAG = 0
*    IF UNAUTH.FLAG = 1 THEN


    BEGIN CASE
        CASE (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND NOT(R.JBWW.H.XX.TRH.TRADES)) OR (FUNCTION.VAL EQ 'A' AND NOT(R.JBWW.H.XX.TRH.TRADES)) OR (FUNCTION.VAL EQ 'A' AND NO.AUTH.VAL EQ 1)
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'

        CASE (FUNCTION.VAL EQ 'D' AND NOT(R.ORDER.ENTRY)) OR R.NEW(PP.OEYG.RejectDescription) NE '' AND NO.AUTH.VAL EQ 0
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Closed'

        CASE (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL GE 1)
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Unauth'

*            CASE (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND NOT(R.ORDER.ENTRY) AND CURR.NO.VAL)
*                DUP.INCEP.FLAG = 1
*                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'

*        CASE (FUNCTION.VAL EQ 'A' AND NOT(R.ORDER.ENTRY)) OR (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND NOT(R.ORDER.ENTRY))
*            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'

*        CASE FUNCTION.VAL EQ 'A' AND NOT(R.JBWW.H.XX.TRH.TRADES)
*            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'
	
*        CASE (R.JBWW.H.XX.TRH.TRADES AND NOT(TRADES.ERR)) OR CC.REMV.FLAG = 1 OR AMENDMENT.FLAG = 1
*            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Amendment'
    END CASE

    IF DUP.INCEP.FLAG = 1 THEN
        CALL OCOMO("Write duplicate check":R.TRADE.RECORD.ARRAY:" ":CURR.NO.VAL)
    END

*    END ELSE

*        BEGIN CASE
*            CASE FUNCTION.VAL EQ 'D' AND NOT(R.ORDER.ENTRY)
*                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status> = 'Closed'
*            CASE (R.JBWW.H.XX.TRH.TRADES AND NOT(TRADES.ERR)) OR CC.REMV.FLAG = 1
*                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status> = 'Amendment'
*            CASE 1
*                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status> = 'Inception'
*                R.TRADE.RECORD.ARRAY<JB.TRHTRD.org.Trx.Datetime> = TRX.DATE.TIME.VAL
*        END CASE
*
*    END

    GOSUB UPDATE.AUDIT
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''
  
    CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,FT.NO,R.TRADE.RECORD.ARRAY)

**** To update H table to maintain history ******
    APP.ID = FT.NO
    R.APP.RECORD.ARRAY = R.TRADE.RECORD.ARRAY
    GOSUB WRITE.DATA.IN.H.TABLE
**** To update H table to maintain history ******

*RET.FLAG = ''
*CALL JBWW.R.XX.TRH.DUPLICATE.CHECK(FT.ID, R.TRADE.RECORD.ARRAY, RET.FLAG)
*IF RET.FLAG EQ 1 THEN
    CALL OCOMO("TRH Record updated":R.TRADE.RECORD.ARRAY:" ":FT.NO)
    Y.ID = FT.NO
    FLOW.CATALOG.ID = 'TRH-JbwwLXxTrhTrades'
    FLOWNAME = 'JBWW.L.XX.TRH.TRADES'
    APPLICATIONNAME = 'JBWW.L.XX.TRH.TRADES'
    CALL JBWW.R.IF.TRHTRADES.CAPTURE(FLOWNAME , FLOW.CATALOG.ID , APPLICATIONNAME , Y.ID)
*END


RETURN

*************
UPDATE.AUDIT:
*************

    TRX.DATE.TIME.VAL = ''
    CALL JBWW.R.XX.TRH.TRXDATETIME.UPD(TRX.DATE.TIME.VAL)
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Datetime> = TRX.DATE.TIME.VAL

    IF FUNCTION.VAL EQ 'A' OR (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0) THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status> = ''
    END ELSE
        IF NOT(R.ORDER.ENTRY) THEN
            IF NOT(STATUS.VAL) OR STATUS.VAL EQ 'IHLD' THEN
                STATUS.VAL = 'INAU'
            END
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status> = STATUS.VAL
        END
    END

    R.TRADE.RECORD.ARRAY<JB.TRHTRD.curr.Number> = CURR.NO.VAL

RETURN

**********************
WRITE.DATA.IN.H.TABLE:
**********************

    R.JBWW.H.XX.TRH.TRADES.OLD = '' ; TRADES.ERR = ''
    CALL F.READ(FN.JBWW.H.XX.TRH.TRADES, APP.ID, R.JBWW.H.XX.TRH.TRADES.OLD, FV.JBWW.H.XX.TRH.TRADES, TRADES.ERR)

    IF R.JBWW.H.XX.TRH.TRADES.OLD THEN
        APP.HIS.ID = APP.ID:';':CURR.NO.VAL

        R.JBWW.H.XX.TRH.TRADES.HIS = '' ; TRADES.HIS.ERR = ''
        CALL F.READ(FN.JBWW.H.XX.TRH.TRADES.HIS, APP.HIS.ID, R.JBWW.H.XX.TRH.TRADES.HIS, FV.JBWW.H.XX.TRH.TRADES.HIS, TRADES.HIS.ERR)

        R.JBWW.H.XX.TRH.TRADES.HIS = R.JBWW.H.XX.TRH.TRADES.OLD

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES.HIS,APP.HIS.ID,R.JBWW.H.XX.TRH.TRADES.HIS)

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,APP.ID,R.APP.RECORD.ARRAY)

    END ELSE

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,APP.ID,R.APP.RECORD.ARRAY)
    END


RETURN

**********************
GET.PORTFOLIO.DETAILS:
**********************
    R.SEC.ACC.MASTER = '' ; SEC.ACC.MASTER.ERR = '' ; PORTFOLIO.NAME = ''
    CALL F.READ(FN.SEC.ACC.MASTER, PORTFOLIO.NUMBER.VAL, R.SEC.ACC.MASTER, FV.SEC.ACC.MASTER, SEC.ACC.MASTER.ERR)
    IF NOT(SEC.ACC.MASTER.ERR) THEN
        PORTFOLIO.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
        INC.ACCOUNT.NO.VAL = R.SEC.ACC.MASTER<SC.SAM.INC.ACCOUNT.NO>
    END

RETURN
    
END
