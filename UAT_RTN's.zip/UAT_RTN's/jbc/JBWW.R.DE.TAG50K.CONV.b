*----------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.DE.TAG50K.CONV(FORMAT.SWIFT.REC,MESSAGE.REC,SWIFT.FIELD.VALUE,PASS.VALUE,ERR.MSG)
*----------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------
* This is a conversion routine attached to CONVERSION field.
* DE.FORMAT.SWIFT -> 103.1.1 on TAG50K
*----------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: FORMAT.SWIFT.REC, MESSAGE.REC,SWIFT.FIELD.VALUE
* OUT: PASS.VALUE ,ERR.MSG
* Revision History:
*----------------------------------------------------------------------------------
* Date               who               Reference          Description
* 20-03-2017        Parameshwari       JB2A-28945   	  This routine is to fetch the alternate account(BJB.ACCT) account and 
*														  displays in the 50K TAG as requested by the client. This routine is attached in
*														  DE.FORMAT.SWIFT>103.1.1 record as a conversion routine.
*12-04-2017         Sushmitha.B        JB2A-28428
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------------

	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	Y.AC.ID = '' 
	Y.AC.ALT.ACCT.TYPE = ''
	Y.AC.ALT.ACCT.ID = ''
	YY.ALT.ACCT.ID = ''
	
	
	Y.AC.ID = FIELD(SWIFT.FIELD.VALUE, '/',2)
	
	CALL F.READ(FN.ACCOUNT,Y.AC.ID,R.ACCT,F.ACCOUNT,AC.ERR)
	IF R.ACCT NE '' THEN
		Y.AC.ALT.ACCT.TYPE = R.ACCT<AC.ALT.ACCT.TYPE>
		Y.AC.ALT.ACCT.ID = R.ACCT<AC.ALT.ACCT.ID>
		
		LOCATE "BJB.ACCT" IN Y.AC.ALT.ACCT.TYPE<1,1> SETTING ALT.POS THEN
			YY.ALT.ACCT.ID = Y.AC.ALT.ACCT.ID<1,ALT.POS>
		END
		
	END
	***JB2A-28424 START
	IF YY.ALT.ACCT.ID NE '' THEN

          SWIFT.FIELD.VALUE = '/':YY.ALT.ACCT.ID

        END
		
	***JB2A-28428 END
	
   RETURN

END
