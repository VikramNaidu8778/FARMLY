    SUBROUTINE JBWW.R.FT.REVSTOP.ID
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* Date          Developer             Reference      Description
*-----------------------------------------------------------------------------
* 01/09/2017    Venkat JC             JB2A-40660     If GST amt is null or debit and credit account not nostro,FT reversal proceeded.
* 23/10/2017    Venkat JC             JB2A-44020     Inculded OPF
* 11/05/2018    Samy                  JB2A-51988     [PROD] Regression_CASH_Payments_Non CID_Reversal of historical �Refund� transactions are not allowed for SG book from menu Reverse FT 
*                                    
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
    $INSERT I_GTS.COMMON

        GOSUB INIT
        GOSUB PROCESS
 

    RETURN
*-----------------------------------------------------------------------------
INIT:
*****

    Y.FT.ID = COMI

    FN.ACCOUNT = "F.ACCOUNT"
    F.ACCOUNT = ""
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER = "F.FUNDS.TRANSFER" ;*JB2A-44020(S)
    F.FUNDS.TRANSFER = ""
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER) ;*JB2A-44020(E)

* Fetching the local field
    APPLN.NAME = "FUNDS.TRANSFER"
    FLD.NAME = "GST.AMOUNT"
    FLD.POS = ''
    CALL MULTI.GET.LOC.REF(APPLN.NAME,FLD.NAME,FLD.POS)
    FT.GST.POS = FLD.POS<1,1>

    RETURN

*-----------------------------------------------------------------------------
PROCESS:
********

    BEGIN CASE	
		CASE V$FUNCTION EQ 'R'
		     GOSUB VALIDATE.TO.REVERSE
	    CASE OFS$GET.SEE.LOCK EQ 'ALL'
		    GOSUB VALIDATE.TO.REVERSE
    END CASE
	
 RETURN
 
*------------------------------------------
VALIDATE.TO.REVERSE:
********************

	CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FT.REC,F.FUNDS.TRANSFER,FT.ERR)
	IF R.FT.REC EQ '' THEN
		FN.FT.HIS = 'F.FUNDS.TRANSFER$HIS'
		F.FT.HIS = ''
		CALL OPF(FN.FT.HIS,F.FT.HIS)
		Y.FT.ID = FIELD(Y.FT.ID,';',1)
		CALL EB.READ.HISTORY.REC(F.FT.HIS,Y.FT.ID,R.FT.REC,ERR.FT.HIS)
	END
	
    Y.GST.AMT = R.FT.REC<FT.LOCAL.REF,FT.GST.POS>
    Y.DEBIT.ACC = R.FT.REC<FT.DEBIT.ACCT.NO>
    Y.CREDIT.ACC = R.FT.REC<FT.CREDIT.ACCT.NO>
	
    IF Y.GST.AMT NE '' AND Y.GST.AMT GT '0' THEN
        GOSUB RAISE.ERROR
    END ELSE
        Y.ACC.ID = Y.DEBIT.ACC
        GOSUB READ.ACC
        Y.DEBIT.LMT.REF = Y.LMT.REF
        IF Y.DEBIT.LMT.REF EQ 'NOSTRO' THEN
            GOSUB RAISE.ERROR
        END
    
        Y.ACC.ID = Y.CREDIT.ACC
        GOSUB READ.ACC
        Y.CREDIT.LMT.REF = Y.LMT.REF
        IF Y.CREDIT.LMT.REF EQ 'NOSTRO' THEN
            GOSUB RAISE.ERROR
        END
    END
    
    RETURN

*-----------------------------------------------------------------------------
RAISE.ERROR:
************

    MESSAGE = 'REPEAT'
    E = 'EB-JBWW.D.FT.REVERSAL.NOTALLOWED'
    CALL ERR
    V$ERROR =  1

    RETURN

*-----------------------------------------------------------------------------
READ.ACC:
*--------

    CALL F.READ(FN.ACCOUNT,Y.ACC.ID ,R.ACC,F.ACCOUNT,DEBIT.ERR)
    Y.LMT.REF = R.ACC<AC.LIMIT.REF>
    
    RETURN

*-----------------------------------------------------------------------------
    END