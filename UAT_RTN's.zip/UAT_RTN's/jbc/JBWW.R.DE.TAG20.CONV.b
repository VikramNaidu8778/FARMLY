*----------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.DE.TAG20.CONV(FORMAT.SWIFT.REC,MESSAGE.REC,SWIFT.FIELD.VALUE,PASS.VALUE,ERR.MSG)
*----------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------
* This is the conversion routine to add STO reference along with FT reference attached as conversion to below records,
* DE.FORMAT.SWIFT -> 103.1.1 on TAG20
* DE.FORMAT.SWIFT -> 202.1.1 on TAG20
* DE.FORMAT.SWIFT -> 604.1.1 on TAG20
*----------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: FORMAT.SWIFT.REC, MESSAGE.REC,SWIFT.FIELD.VALUE
* OUT: PASS.VALUE ,ERR.MSG
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------
* Date               who               Reference          Description
* 02-03-2017        Balaji             JB2A-23356         Initial Version
* 03-07-2017		Balaji			   JB2A-36172		  Modified to read History records.
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.STANDING.ORDER
                
    GOSUB OPEN.FILES
    GOSUB PROCESS
    RETURN

*=================
OPEN.FILES:
*===============

  FN.FUNDS.TRANSFER = "F.FUNDS.TRANSFER"
  F.FUNDS.TRANSFER = ""
  CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
  
  FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
  F.FUNDS.TRANSFER.HIS = ''
  CALL OPF(FN.FUNDS.TRANSFER.HIS, F.FUNDS.TRANSFER.HIS)
  
  FN.STANDING.ORDER = "F.STANDING.ORDER"
  F.STANDING.ORDER = ""
  CALL OPF(FN.STANDING.ORDER,F.STANDING.ORDER)
  
  FN.STANDING.ORDER.HIS = "F.STANDING.ORDER$HIS"
  F.STANDING.ORDER.HIS = ""
  CALL OPF(FN.STANDING.ORDER.HIS,F.STANDING.ORDER.HIS)
  RETURN
  
 *===============
 PROCESS:
*===========

   IF SWIFT.FIELD.VALUE[1,2] EQ "FT" THEN
    Y.FT.ID = SWIFT.FIELD.VALUE
   END ELSE
   Y.FT.ID = SWIFT.FIELD.VALUE[2,-1]
   END
   
  R.FUNDS.TRANSFER = "" ; FUNDS.TRANSFER.ERR = ""
  CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,FUNDS.TRANSFER.ERR)
  
*S - JB2A-36172
  IF R.FUNDS.TRANSFER EQ "" THEN
	R.FT.HIST.REC = "" ; Y.FT.ERR = ""
	CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS,Y.FT.ID,R.FT.HIST.REC,Y.FT.ERR)
	R.FUNDS.TRANSFER = R.FT.HIST.REC
  END
*E - JB2A-36172
  
  IF R.FUNDS.TRANSFER NE "" THEN
   Y.INWARD.PAY.TYPE = R.FUNDS.TRANSFER<FT.INWARD.PAY.TYPE>
   Y.STO.IDN = FIELD(Y.INWARD.PAY.TYPE,"-",1)
   Y.STO.ACC = FIELD(Y.INWARD.PAY.TYPE,"-",3)
   Y.STO.SEQ = FIELD(Y.INWARD.PAY.TYPE,"-",4)
     IF (Y.STO.IDN EQ "STO") OR (Y.STO.IDN EQ "BULK.STO") THEN
		Y.STO.ID = Y.STO.ACC:".":Y.STO.SEQ
		R.STANDING.ORDER = "" ; STANDING.ORDER = ""
		CALL F.READ(FN.STANDING.ORDER,Y.STO.ID,R.STANDING.ORDER,F.STANDING.ORDER,STANDING.ORDER.ERR)
	  
*S - JB2A-36172  
		IF R.STANDING.ORDER EQ "" THEN
			R.STO.HIST.REC = "" ; Y.STO.ERR = ""
			CALL EB.READ.HISTORY.REC(F.STANDING.ORDER.HIS,Y.STO.ID,R.STO.HIST.REC,Y.STO.ERR)
			R.STANDING.ORDER = R.STO.HIST.REC
			Y.STO.ID = FIELD(Y.STO.ID,";",1)
		END
*E - JB2A-36172

	    IF R.STANDING.ORDER NE "" THEN
         SWIFT.FIELD.VALUE = SWIFT.FIELD.VALUE:",":Y.STO.ID
        END
		
	  END
	END
  RETURN
 
END


