 
 SUBROUTINE JBWW.R.FT.CLRCHGCODE.INPUT
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is a version control routine attached in FUNDS.TRANSFER
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               who                  Reference                 Description
* 25-01-2019         Ramesh K       T24-14390                Initial Version
* 22-03-2019         Subbu J        T24-14390                Set CHARGE.CODE as WAIVE
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
	
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
	
	GEN.PA.ID = 'JBWW.D.FT.CLRCHGCODE'
    R.JBWW.H.EB.GENERICPARAMETER = ''
    ERR.GEN.PARAM = ''

	CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GEN.PA.ID,R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,ERR.GEN.PARAM)
	IF R.JBWW.H.EB.GENERICPARAMETER THEN
		GEN.FLD.NAME = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
		GEN.FLD.VAL = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE>	
		Y.FT.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)
		Y.FT.TXN.TYPE.POS = ""
		LOCATE Y.FT.TXN.TYPE IN GEN.FLD.VAL<1,1> SETTING Y.FT.TXN.TYPE.POS THEN
			R.NEW(FT.CHARGE.CODE) = "WAIVE"
			R.NEW(FT.CHARGE.TYPE) = ""
			R.NEW(FT.CHARGE.AMT) = ""
			R.NEW(FT.CHARGE.FOR) = ""
		    R.NEW(FT.TOTAL.CHARGE.AMOUNT) = ""
		END
	END
    
	RETURN
	
END