* @ValidationCode : MTo2NjA3Mzk0MjU6SVNPLTg4NTktMToxNTM5MjU3NDA0NjkyOmEzOTkyMjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 11 Oct 2018 19:30:04
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a39922
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.MT202.52A.MAPPING(MAT HANDOFF.REC,ERR.MSG)
*-----------------------------------------------------------------------------
* Modification History :
* Date              Author                  Description
* 01-10-2018       Charan Prasad KS         JIRA DAY15-310 passing null value to MT202 tag 52A, if the odering bank also the sender bank
* 04/12/2020          Senthil K             P3636-5615       Updates for P3636-5615: CNYCNH - Retrofit
*-----------------------------------------------------------------------------
* Company Name                             : BJB

* Developed By                 : srsenthilkumar@temenos.com
*-----------------------------------------------------------------------------
* Description                  : Mapping routine to nullify TAG 52A if sender bank and ordering bank is same - JB2A-34419
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DE.ADDRESS
    $INSERT I_F.ACCOUNT

    ORD.BANK = '' ; DR.ACCT = '' ;

    GOSUB INIT
    GOSUB PROCESS

RETURN

*-----------------------------------------------------------------------------
INIT:
*-----------------------------------------------------------------------------
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.DEADDRESS = 'F.DE.ADDRESS'
    F.DEADDRESS = ''
    CALL OPF(FN.DEADDRESS,F.DEADDRESS)

    FN.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.GENERICPARAMETER = ''
    CALL OPF(FN.GENERICPARAMETER, F.GENERICPARAMETER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
    DR.ACCT = HANDOFF.REC(1)<2>

    ORD.BANK = HANDOFF.REC(2)<17>

    Y.COMPAY = HANDOFF.REC (1)<82>

    Y.FT.ORD.BANK = HANDOFF.REC(1)<21>


    IF Y.FT.ORD.BANK EQ '' THEN
*IF ORD.BANK THEN
;*if DEBIT.ACCOUNT is NOSTRO and ORDERING.BANK is blank, then tag 52A in MT202 should be blank
        GOSUB CHK.NOSTRO.ACCT
;*commented -routine should check sender bank and ordering bank value, not debit customer and ordering bank - Jira day15-310
;* R.ACC.DEBT = '' ;* AC.ERR = '' ; DR.AC.CUS = '' ;
*        CALL F.READ(FN.ACCOUNT,DR.ACCT,R.ACC.DEBT,F.ACCOUNT,AC.ERR)
*        IF R.ACC.DEBT THEN
*            DR.AC.CUS = R.ACC.DEBT<AC.CUSTOMER>
*        END
*        IF DR.AC.CUS EQ ORD.BANK THEN
*            HANDOFF.REC(2)<17> = '' ; *Clear ordering bank if it is same as sender bank
*        END
    END ELSE
        GOSUB CHECK.ORD.BANK    ;*jira DAY15-310
    END

* CALL SGMB.CHG.SWF.CCY.OUT(MAT HANDOFF.REC,ERR.MSG) ; *L2 rtn for CNY/CNH ;*P3636-5615
RETURN

*-----------------------------------------------------------------------------
CHK.NOSTRO.ACCT:
*-----------------------------------------------------------------------------

    CALL F.READ(FN.ACCOUNT,DR.ACCT,R.ACCT.REC,F.ACCOUNT,E.ACCT.ERR)

    Y.AC.CATEGORY = R.ACCT.REC<AC.CATEGORY>

    IF Y.AC.CATEGORY GE '5000' AND Y.AC.CATEGORY LE '5999' THEN

        HANDOFF.REC(2)<17> = ''
    END

RETURN

*-----------------------------------------------------------------------------
CHECK.ORD.BANK:
*-----------------------------------------------------------------------------
*GENERICPARAMETER table created to store the country code with their specific BIC code, which is later used to compare with orering bank value

    Y.GPM.ID = 'JBWW.D.XX.BICCODE'
    CALL F.READ(FN.GENERICPARAMETER,Y.GPM.ID,R.GPM.REC,F.GENERICPARAMETER,E.GPM.ERR)
    Y.COMP.CODE = R.GPM.REC<JBWW.GEN.PAR.FIELD.NAME>
    Y.BIC.CODE = R.GPM.REC<JBWW.GEN.PAR.FIELD.VALUE>

    CHANGE VM TO FM IN Y.COMP.CODE
    CHANGE VM TO FM IN Y.BIC.CODE
    Y.LEN = LEN(ORD.BANK)
    IF Y.LEN GT '11' THEN
        ORD.BANK = FIELD(ORD.BANK,'-',2)
    END
    LOCATE Y.COMPAY IN Y.COMP.CODE SETTING Y.POS THEN
        Y.BIC.VAL = Y.BIC.CODE<Y.POS>
    END

    IF ORD.BANK NE '' THEN
        CALL F.READ(FN.CUSTOMER,ORD.BANK,R.CUS.REC,F.CUSTOMER,E.CUS.ERR)
        IF R.CUS.REC EQ '' THEN
            IF ORD.BANK EQ Y.BIC.VAL THEN
                HANDOFF.REC(2)<17> = ''
            END
        END ELSE
            GOSUB CHK.CUS.DEADD
        END
    END
RETURN
*-----------------------------------------------------------------------------
CHK.CUS.DEADD:
*-----------------------------------------------------------------------------
*checking DE.ADDRESS BIC value, if the customer having internal account and compare with the specified contry BIC code
    Y.DEADDRESS.ID = Y.COMPAY:'.C-':ORD.BANK:'.SWIFT.1'
    CALL F.READ(FN.DEADDRESS,Y.DEADDRESS.ID,R.DE.REC,F.DEADDRESS,E.DR.ERR)

    IF R.DE.REC THEN
        Y.DE.BIC = R.DE.REC<DE.ADD.DELIVERY.ADDRESS>
        IF Y.DE.BIC EQ Y.BIC.VAL THEN
            HANDOFF.REC(2)<17> = ''
        END
    END
RETURN

END
