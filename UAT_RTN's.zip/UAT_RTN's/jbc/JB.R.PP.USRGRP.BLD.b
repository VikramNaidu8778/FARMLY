SUBROUTINE JB.R.PP.USRGRP.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*Attached in : ENQUIRY>JB.E.PP.PAYPENPROCESS.LIST
*Attached as : Build Routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer       Reference        Description
*------------------------------------------------------------------------------
* 28-01-2025     Lakshmi Priya     CBPAY-1725 &     The Build Routine is to display transactions
*                                   CBPAY - 1779            based on user role .
* 24-03-2025     Prabhu D S        CBPAY-2251       Outward pacs.004 not listed along with original
*                                                   payments
* 05-05-2025     Lakshmi Priya     CBPAY-2677       Updated the operands logic in selection 
*                                                     command,changed operator 'LK' to 'LIKE' .
*
* 19-05-2025     Resmi R           CBPAY-2931      Updated the logic to display unmatched incoming pacs.004 payments in the queue
*-----------------------------------------------------------------------------

   
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON

    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS


RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
   
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)
RETURN


*****************
GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
 
    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END
    
    
RETURN


PROCESS:
********

    GOSUB CHECK.TXN.COMPANY
    IF ENQ.ERROR THEN RETURN
     Y.SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ '":Y.COMP.ID:"'"
    IF ENQ.DATA<2,1> THEN
       GOSUB FORM.SEL.CMD
       Y.SEL.CMD := Y.SEL.OPER
    END
    CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST.1,'',Y.SEL.CNT,'')

    IF Y.SEL.LIST.1 THEN
        LOOP
            REMOVE Y.REC.ID FROM Y.SEL.LIST.1 SETTING Y.ROLE.POS
        WHILE Y.REC.ID:Y.ROLE.POS
            CALL F.READ(FN.POR.TRANSACTION,Y.REC.ID,R.POR.TRANSACTION,F.POR.TRANSACTION,'')
            BEGIN CASE
                CASE R.POR.TRANSACTION<PPPTX.PaymentDirection> EQ 'I'
                   IF R.POR.TRANSACTION<PPPTX.IncomingMessageType> MATCHES 'pacs.004':VM:'pacs.002' THEN
                        Y.ORIG.ID = Y.REC.ID
                        CALL F.READ(FN.POR.SUPPL.INFO,Y.REC.ID,R.SUPP.REC,F.POR.SUPPL.INFO,'')
                        Y.REC.ID = R.SUPP.REC<PORID.ORIGINAL.OR.RETURN.ID>
			IF Y.REC.ID THEN
                        GOSUB CHECK.USER.GROUP
			END ELSE
			Y.REC.ID = Y.ORIG.ID
		        GOSUB CHECK.USER.GROUP	
			END
                        IF FLAG THEN
                           Y.SEL.LIST<-1> = Y.ORIG.ID
                        END
                   END ELSE
                       Y.SEL.LIST<-1> = Y.REC.ID
                   END
            
                CASE R.POR.TRANSACTION<PPPTX.PaymentDirection> EQ 'B'
                   IF R.POR.TRANSACTION<PPPTX.IncomingMessageType> MATCHES 'pacs.004':VM:'pacs.002' THEN
                        Y.ORIG.ID = Y.REC.ID
                        Y.REC.ID = R.POR.TRANSACTION<PPPTX.TransactionReferenceIncoming>
                        GOSUB CHECK.USER.GROUP
                        IF FLAG THEN
                          Y.SEL.LIST<-1> = Y.ORIG.ID
                        END
                   END ELSE
                       GOSUB CHECK.USER.GROUP
                        IF FLAG THEN
                          Y.SEL.LIST<-1> = Y.REC.ID
                        END
                   END

                CASE R.POR.TRANSACTION<PPPTX.PaymentDirection> EQ 'O'
                    IF R.POR.TRANSACTION<PPPTX.OutgoingMessageType> MATCHES 'pacs.004':VM:'pacs.002' THEN
                         FLAG = 1
                    END ELSE
                         GOSUB CHECK.USER.GROUP
                    END
                    IF FLAG THEN
                       Y.SEL.LIST<-1> = Y.REC.ID
                    END

             END CASE
        REPEAT
    END

    Y.TEMP.CNT = DCOUNT(Y.SEL.LIST,FM)
    CONVERT FM TO ' ' IN Y.SEL.LIST

    ENQ.DATA<2,1> = '@ID'
    ENQ.DATA<3,1> = 'EQ'
    ENQ.DATA<4,1> = Y.SEL.LIST
    ENQ$SKIP.FLAG = 1


RETURN
CHECK.USER.GROUP:

     FLAG = 0
     CALL F.READ(FN.POR.SUPPL.INFO,Y.REC.ID,R.SUPP.REC,F.POR.SUPPL.INFO,'')
     Y.LOC.FIELD.NAME = R.SUPP.REC<PORID.LOC.FIELD.NAME>
     LOCATE 'L.PO.USR.GRP' IN Y.LOC.FIELD.NAME<1,1> SETTING Y.POS THEN
          Y.LOC.FIELD.VALUE = R.SUPP.REC<PORID.LOC.FIELD.VALUE,Y.POS>
          IF Y.LOC.FIELD.VALUE EQ Y.USR.GRP THEN
             FLAG = 1
          END
     END

RETURN
FORM.SEL.CMD:

   Y.CNT = DCOUNT(ENQ.DATA<2>,VM)
   FOR I = 1 TO Y.CNT
   
    Y.SEL.OPERAND = ENQ.DATA<3,I>
    BEGIN CASE
         CASE Y.SEL.OPERAND EQ "BW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "EW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "CT"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ...":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNBW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UNLIKE ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNEW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UNLIKE ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND MATCHES "EQ":VM:"NE":VM:"GT":VM:"GE":VM:"LT":VM:"LE"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" ":Y.SEL.OPERAND:" ":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "RG"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" GE ":Y.TEMP.DATA<1,1>:" AND ":ENQ.DATA<2,I>:" LE ":Y.TEMP.DATA<1,2>:")"
         CASE Y.SEL.OPERAND EQ "NR"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" LT ":Y.TEMP.DATA<1,1>:" OR ":ENQ.DATA<2,I>:" GT ":Y.TEMP.DATA<1,2>:")"

    END CASE
   NEXT I
    

RETURN
CHECK.TXN.COMPANY:

    LOCATE "CompanyID" IN ENQ.DATA<2> SETTING Y.POS THEN
        IF ENQ.DATA<4,Y.POS> NE Y.COMP.ID THEN
           ENQ.ERROR = "No records found to display"
        END
    END

RETURN
        
END
