SUBROUTINE JB.R.PP.DEFPLACCT.CCY
*-----------------------------------------------------------------------------
* Description:
* Attached as an validation routine(to both DB ACCT/CR ACCT) to default the customer account currency in PL side for versions
*---------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------------------------------------
* Initial Creation
*--------------------------------------------------------------------------------------------------------------------------------------------
* Date            who            Reference                                 Description
*21-05-2024     Hariharan T      CBPAY-52              Validation routine attached to default the customer account currency in PL Side.
*-------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.PAYMENT.ORDER
*----------------------------------------------------------------------------
    IF MESSAGE NE 'VAL' THEN
        IF V$FUNCTION EQ 'I' THEN
            GOSUB INIT
            GOSUB PROCESS
        END
    END
RETURN
*-----------------------------------------------------------------------------
*****
INIT:
*****
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
RETURN
*--------------------------------------------------------------------------------
PROCESS:
********
    Y.ACC.ID = ''
    BEGIN CASE
        CASE AF EQ PO.CREDIT.ACCOUNT
            IF COMI NE '' THEN
                Y.ACC.ID = COMI
            END ELSE
                Y.ACC.ID = R.NEW(PO.CREDIT.ACCOUNT)
            END
            GOSUB READ.ACCOUNT
            GOSUB POPULATE.CCY
            IF R.NEW(PO.DEBIT.PL) NE "" OR R.NEW(PO.CREDIT.PL) NE "" AND R.NEW(PO.DEBIT.CCY) NE "" THEN
                R.NEW(PO.CREDIT.CURRENCY) = R.NEW(PO.DEBIT.CCY)
            END
        CASE AF EQ PO.DEBIT.ACCOUNT
            IF COMI NE '' THEN
                Y.ACC.ID = COMI
            END ELSE
                Y.ACC.ID = R.NEW(PO.DEBIT.ACCOUNT)
            END
            GOSUB READ.ACCOUNT
            GOSUB POPULATE.CCY
            IF R.NEW(PO.DEBIT.PL) NE "" OR R.NEW(PO.CREDIT.PL) NE "" AND R.NEW(PO.CREDIT.CURRENCY) NE "" THEN
                R.NEW(PO.DEBIT.CCY) = R.NEW(PO.CREDIT.CURRENCY)
            END
    END CASE
RETURN
*--------------------------------------------------------------------------------
READ.ACCOUNT:
************
    IF Y.ACC.ID THEN
        R.ACC = '' ; Y.ACC.ERR = ''
        CALL F.READ(FN.ACCOUNT,Y.ACC.ID,R.ACC,F.ACCOUNT,Y.ACC.ERR)
        IF R.ACC THEN
            Y.ACC.CCY = R.ACC<AC.CURRENCY>
        END
    END
RETURN
*--------------------------------------------------------------------------------
POPULATE.CCY:
*************
    IF Y.ACC.CCY THEN
        BEGIN CASE
            CASE AF EQ PO.CREDIT.ACCOUNT
                IF R.NEW(PO.DEBIT.PL) NE "" THEN
                    R.NEW(PO.CREDIT.CURRENCY) = Y.ACC.CCY
                    R.NEW(PO.DEBIT.CCY) = Y.ACC.CCY
                END ELSE
                    R.NEW(PO.CREDIT.CURRENCY) = Y.ACC.CCY
                END
            CASE AF EQ PO.DEBIT.ACCOUNT
                IF R.NEW(PO.CREDIT.PL) NE "" THEN
                    R.NEW(PO.CREDIT.CURRENCY) = Y.ACC.CCY
                    R.NEW(PO.DEBIT.CCY) = Y.ACC.CCY
                END ELSE
                    R.NEW(PO.DEBIT.CCY) = Y.ACC.CCY
                END
        END CASE
        CALL REBUILD.SCREEN()
    END
RETURN
*--------------------------------------------------------------------------------
END