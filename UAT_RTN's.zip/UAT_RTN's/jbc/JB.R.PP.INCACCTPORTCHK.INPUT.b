* @ValidationCode : MjoxMDQzMjg3ODc6Q3AxMjUyOjE3MTM3ODQwNzAzNDI6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 16:37:50
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
**************************************************************************************************
SUBROUTINE JB.R.PP.INCACCTPORTCHK.INPUT
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This routine is copy of the existing FT Version Routine JBWW.R.FT.INC.ACCT.PORT.CHK and incorporated with TPH Payment order application Logic.
*-------------------------------------------------------------------------
* Attached: As input routine to ACIA, ACME, ACMI & ACFX FT Versions
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN:NA
* OUT:NA
*
* Dependencies:
*---------------
*
* RevisionHistory:
*---------------------------------------------------------------------------------------------------------------------------
* Date          Developer        Reference                                        Description
* 12/04/2024    Hariharan T      CBPAY-209,210,211,212,213              This is input routine to block FT-ACIA type based on account/portfolio check in payment order versions
*                                                                       PO,JB.V.PP.FEECHRG.INP,PO,JB.V.PP.REFUNDS.INP, PO,JB.V.PP.GSTREFUNDS.INP, PO,JB.V.PP.GSTFEECHG.INP & PO,JB.V.PP.INTERNAL.INP
*----------------------------------------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
 
    INCLUDE.ASSET.VALS=''
    TXN.FLD.NAMES=''
    ADV.ERR=''
    R.TXN.TYPE=''
    SUB.ASSET.POS=''
    TXN.TYPE.CHECK = 'JBWW.PP.PAYMENT.PRODUCT.PARAM'
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,TXN.TYPE.CHECK,R.TXN.TYPE.CHECK,F.JBWW.H.EB.GENERICPARAMETER,ADV.ERR)
    TXN.FLD.NAMES = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.NAME>
    LOCATE 'PAYMENT.PRODUCT' IN TXN.FLD.NAMES<1,1> SETTING SUB.ASSET.POS THEN
        INCLUDE.ASSET.VALS = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.VALUE><1,SUB.ASSET.POS>
    END
    
    CHANGE SM TO FM IN INCLUDE.ASSET.VALS
    CHANGE ',' TO FM IN INCLUDE.ASSET.VALS
    
    PAYMENT.PROD1 =INCLUDE.ASSET.VALS<1,1>
    PAYMENT.PROD2 =INCLUDE.ASSET.VALS<2,1>
    PAYMENT.PROD3 =INCLUDE.ASSET.VALS<3,1>
    

    IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES PAYMENT.PROD1:@VM:PAYMENT.PROD2:@VM:PAYMENT.PROD3 THEN
        Y.PROCESS.FLAG = 1
    
    END
 
    IF Y.PROCESS.FLAG THEN
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END
 
RETURN
 
*==========
OPEN.FILES:
*==========
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
 
    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)
 
    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)

    FN.PAYMENT.ORDER = "F.PAYMENT.ORDER"
    F.PAYMENT.ORDER = ""
    CALL OPF(FN.PAYMENT.ORDER, F.PAYMENT.ORDER)
RETURN
 
*=======
PROCESS:
*=======

    Y.INC.FLAG = ''
    Y.DR.INC.FLAG = ''
    Y.CR.INC.FLAG = ''
    Y.DR.ACNO = R.NEW(PO.DEBIT.ACCOUNT)
    Y.CR.ACNO = R.NEW(PO.CREDIT.ACCOUNT)
    Y.PO.DEBIT.PL = R.NEW(PO.DEBIT.PL)
    Y.PO.CREDIT.PL = R.NEW(PO.CREDIT.PL)
    
    IF Y.DR.ACNO EQ "" THEN    ;*To Manage the LOCATE statement in GOSUB CHECK.SAM.INC.ACCNT & CHECK.SAM.PORT.ACCNT
        Y.DR.ACNO = Y.PO.DEBIT.PL
    END
    IF Y.CR.ACNO EQ "" THEN    ;*To Manage the LOCATE statement in GOSUB CHECK.SAM.INC.ACCNT & CHECK.SAM.PORT.ACCNT
        Y.CR.ACNO = Y.PO.CREDIT.PL
    END

 
    BEGIN CASE
    
        CASE R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ PAYMENT.PROD1
          
            IF Y.PO.DEBIT.PL EQ "" THEN
                Y.ACCOUNT = R.NEW(PO.DEBIT.ACCOUNT)
                GOSUB PROCESS.FETCH.ACCNT
            END
        
            IF Y.PO.CREDIT.PL EQ "" AND NOT(Y.INC.FLAG) THEN
                Y.ACCOUNT = R.NEW(PO.CREDIT.ACCOUNT)
                GOSUB PROCESS.FETCH.ACCNT
            END
 
            IF NOT(Y.PORT.FLAG) THEN
                GOSUB CHECK.SAM.PORT.ACCNT
            END
        
 
       
        CASE Y.PO.DEBIT.PL EQ "" AND Y.DR.ACNO NE '' AND R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES PAYMENT.PROD2:@VM:PAYMENT.PROD3


            Y.ACCOUNT = R.NEW(PO.DEBIT.ACCOUNT)
            GOSUB PROCESS.FETCH.ACCNT
 
            IF Y.PO.CREDIT.PL NE "" THEN
                Y.PORT.FLAG = 1
            END ELSE
                IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
                    GOSUB CHECK.SAM.PORT.ACCNT
                END
            END
            
            IF NOT(Y.INC.FLAG) OR NOT(Y.PORT.FLAG) THEN
                Y.ACCOUNT = R.NEW(PO.CREDIT.ACCOUNT)
                GOSUB PROCESS.FETCH.ACCNT
            END
 
        
        CASE Y.PO.CREDIT.PL EQ "" AND Y.CR.ACNO NE '' AND R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES PAYMENT.PROD2:@VM:PAYMENT.PROD3
 
            Y.ACCOUNT = R.NEW(PO.CREDIT.ACCOUNT)
            GOSUB PROCESS.FETCH.ACCNT
            
            
            IF Y.PO.DEBIT.PL NE "" THEN
                Y.PORT.FLAG = 1
            END ELSE
                IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
                    GOSUB CHECK.SAM.PORT.ACCNT
                END
            END
            
                
            IF NOT(Y.INC.FLAG) OR NOT(Y.PORT.FLAG) THEN
                Y.ACCOUNT = R.NEW(PO.DEBIT.ACCOUNT)
                GOSUB PROCESS.FETCH.ACCNT
            END


 
    END CASE
 
    IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
        AF = Y.FIELD
        ETEXT = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        CALL STORE.END.ERROR
    END
 
 
RETURN
 
*===================
PROCESS.FETCH.ACCNT:
*===================
 
    R.ACCOUNT = ''; ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE "" THEN
        Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        IF R.ACCOUNT<AC.CATEGORY> GE 5000 AND R.ACCOUNT<AC.CATEGORY> LE 5999 THEN
            Y.PORT.FLAG = 1
            RETURN
        END
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.POS THEN
            Y.SAM.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,ALT.POS>
            Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
            GOSUB CHECK.ACCOUNT.SAM
        END ELSE
            Y.PORT.FLAG = 1
        END
    END
 
RETURN
    
*=================
CHECK.ACCOUNT.SAM:
*=================
 
    R.SAM.ALT.REC = ''; SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC NE'' THEN
        Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        R.SAM = ''; SAM.ERR = ''
        CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
        IF R.SAM THEN
            GOSUB CHECK.SAM.INC.ACCNT
        END
    END ELSE
        Y.PORT.FLAG = 1
    END
 
RETURN
 
*==================
CHECK.SAM.INC.ACCNT:
*==================
 
*To check at least one of the account(DR/CRacct)is an income account
    INC.POS = ''

    LOCATE Y.DR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
        Y.DR.INC.FLAG = 1
        Y.FIELD = PO.DEBIT.ACCOUNT
    END
 
    INC.POS = ''
    


    LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
        Y.CR.INC.FLAG = 1
        Y.FIELD = PO.CREDIT.ACCOUNT
    END

 
    IF Y.DR.INC.FLAG AND Y.CR.INC.FLAG THEN
        Y.PORT.FLAG = 1
    END
 
    IF Y.DR.INC.FLAG OR Y.CR.INC.FLAG THEN
        Y.INC.FLAG = 1
    END
 
RETURN
 
*===================
CHECK.SAM.PORT.ACCNT:
*===================
 
*To check whether CR account belongs to the same portfolio
    IF NOT(Y.CR.INC.FLAG) THEN
        PORT.POS = ''
        LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.ACCOUNT.NOS,1> SETTING PORT.POS THEN
            Y.PORT.FLAG = 1
        END
    END

 
*To check whether DR account belongs to the same portfolio
    IF NOT(Y.DR.INC.FLAG) THEN
        PORT.POS = ''
        LOCATE Y.DR.ACNO IN R.SAM<SC.SAM.ACCOUNT.NOS,1> SETTING PORT.POS THEN
            Y.PORT.FLAG = 1
        END
    END

 
RETURN
 
END

