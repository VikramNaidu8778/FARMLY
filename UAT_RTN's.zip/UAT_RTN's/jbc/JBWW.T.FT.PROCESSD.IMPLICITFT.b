*-----------------------------------------------------------------------------
* <Rating>-25</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.T.FT.PROCESSD.IMPLICITFT 
*-----------------------------------------------------------------------------
* Description :  A new template JBWW.T.FT.PROCESSD.IMPLICITFT to record the FT RECORD ID when the FT is processed on AUTH date
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA

* Revision History:
*------------------
* Date               who                      Reference                 Desc
* 12/07/2018        MAHESHKUMAR                       JB2A-52369               Initial Version
**--------------------------------------------------------------------------

* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_Table
* </region>
*-----------------------------------------------------------------------------
    Table.name = 'JBWW.T.FT.PROCESSD.IMPLICITFT'      ;* Full application name including product prefix
    Table.title = 'JBWW.T.FT.PROCESSD.IMPLICITFT'     ;* Screen title
    Table.stereotype = 'T'    ;* H, U, L, W or T
    Table.product = 'EB'      ;* Must be on EB.PRODUCT
    Table.subProduct = ''     ;* Must be on EB.SUB.PRODUCT
    Table.classification = 'FIN'        ;* As per FILE.CONTROL
    Table.systemClearFile = 'Y'         ;* As per FILE.CONTROL
    Table.relatedFiles = ''   ;* As per FILE.CONTROL
    Table.isPostClosingFile = ''        ;* As per FILE.CONTROL
    Table.equatePrefix = 'IMP.FT'   ;* Use to create I_F.EB.LOG.PARAMETER
*-----------------------------------------------------------------------------
    Table.idPrefix = ''       ;* Used by EB.FORMAT.ID if set
    Table.blockedFunctions = ''         ;* Space delimeted list of blocked functions
    Table.trigger = ''        ;* Trigger field used for OPERATION style fields
*-----------------------------------------------------------------------------

    RETURN
    END
