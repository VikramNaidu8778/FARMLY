SUBROUTINE JB.B.PP.PAINFILE.TRANSFER
*-----------------------------------------------------------------------------
* This subroutine attached as single threaded batch job.
* This routine will move the all the pain files transferred from awa path
* to TPH camel layer path
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 20-Apr-2025 u40786             CBPAY-135         Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES

    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*
*****
INIT:
*****
    
    ID.GPM = BATCH.DETAILS<3,1,1>
    GPM.FIELD.NAMES = "PAIN.FROM.PATH":@FM:"PAIN.TO.PATH"
    GPM.FIELD.VALUES = ''
    CALL JBWW.R.EB.GETGENPARM.VAL(ID.GPM,GPM.FIELD.NAMES,GPM.FIELD.VALUES)
    Y.SOURCE.PATH = GPM.FIELD.VALUES<1>:'/*'
    Y.DESTINATION.PATH = GPM.FIELD.VALUES<2>
*
RETURN
*
********
PROCESS:
********
    
    MOVE.CMD ="SH -c 'mv ":Y.SOURCE.PATH:" ":Y.DESTINATION.PATH:"'"
    EXECUTE MOVE.CMD
*
RETURN
*
END
*
