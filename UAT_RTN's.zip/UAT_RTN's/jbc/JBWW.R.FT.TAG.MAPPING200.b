SUBROUTINE JBWW.R.FT.TAG.MAPPING200(MAT HANDOFF.REC,ERR.MSG)

*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is the MAPPING routine, attached to DE.MAPPING>200.FT.1 ROUTINE field.
* BK.TO.BK.INFO values map to Tag72
*
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: HANDOFF.REC
* OUT: MAT HANDOFF.REC, ERR.MSG
*
* Revision History:
*------------------
* Date                Developer            Reference        Description
* 05/MAY/2017         Mahesh J             JB2A-32163       Tag72 values is not getting displayed.
* 28/09/2017		  Balaji               JB2A-43313		Uncommented core api for CNH to CNY conversion
* 04/12/2020          Senthil K            P3636-5615       Updates for P3636-5615: CNYCNH - Retrofit
* 29.12.2023          Hazirah              GBLBB-157        R23.10 upgrade - compilation errors
*-------------------------------------------------------------------------

	$INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
	
  	
* CALL SGMB.CHG.SWF.CCY.OUT(MAT HANDOFF.REC,ERR.MSG)  ;*JB2A-43313 ;*P3636-5615
	
    BK.TO.BK.VAL = R.NEW(FT.BK.TO.BK.INFO)
    HANDOFF.REC(2)<76> = BK.TO.BK.VAL
	

RETURN
END             ;*GBLBB-157