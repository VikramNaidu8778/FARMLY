	SUBROUTINE JBWW.R.FT.INC.ACCT.CHK
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is input routine to default transaction type based on income account check
*-------------------------------------------------------------------------
* Attached: As input routine to FUNDS.TRANSFER,JBWW.V.FT.ACAC.INP
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               Developer                 Reference                 Description
*
* 07/08/2018         Balaji                    DAY15-3134               This is input routine to default transaction type based on income account check
*
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.ACCOUNT
	$INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.STANDING.ORDER
	
	GOSUB OPEN.FILES
	GOSUB PROCESS
	
	RETURN
	
*=================
OPEN.FILES:
*============
	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)

	FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)
	
	FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
	RETURN

*==================
PROCESS:
*==============
	Y.INC.FLAG = ''
	
	BEGIN CASE
	
	 CASE APPLICATION EQ 'FUNDS.TRANSFER'
		Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
		Y.ACCOUNT = Y.DR.ACNO
		GOSUB CHECK.ACCOUNT.SAM
		Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)
		Y.ACCOUNT = Y.CR.ACNO
		GOSUB CHECK.ACCOUNT.SAM
			IF Y.INC.FLAG EQ '1' THEN
				R.NEW(FT.TRANSACTION.TYPE) = 'ACIA'
			END ELSE
				R.NEW(FT.TRANSACTION.TYPE) = 'ACAC'
			END
			
	  CASE APPLICATION EQ 'STANDING.ORDER'
		Y.DR.ACNO = FIELD(ID.NEW,'.',1)
		Y.ACCOUNT = Y.DR.ACNO
		GOSUB CHECK.ACCOUNT.SAM
		Y.CR.ACNO = R.NEW(STO.CPTY.ACCT.NO)
		Y.ACCOUNT = Y.CR.ACNO
		GOSUB CHECK.ACCOUNT.SAM
			IF Y.INC.FLAG EQ '1' THEN
				R.NEW(STO.PAY.METHOD) = 'ACIA'
			END ELSE
				R.NEW(STO.PAY.METHOD) = 'ACAC'
			END
	  
	END CASE
	RETURN
	
*=================
CHECK.ACCOUNT.SAM:
*================
	R.ACCOUNT = '' ; ACCOUNT.ERR = ''
	CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
	IF R.ACCOUNT NE "" THEN
		Y.ALT.ACCT.TYPE = R.ACCOUNT<AC.ALT.ACCT.TYPE>
		Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
		ALT.POS = ''
		LOCATE "BJB.ACCT" IN Y.ALT.ACCT.TYPE<1,1> SETTING ALT.POS THEN
		    Y.SAM.ALT.ID = Y.ALT.ACCT.IDS<1,ALT.POS>
			Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
			R.SAM.ALT.REC = '' ; SAM.ALT.ERR = ''
			CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
			IF R.SAM.ALT.REC NE '' THEN
				Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
				R.SAM = '' ; SAM.ERR = ''
				CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
				IF R.SAM NE '' THEN
					Y.INC.ACCT.LIST = R.SAM<SC.SAM.INC.ACCOUNT.NO>
					INC.POS = ''
					LOCATE Y.ACCOUNT IN Y.INC.ACCT.LIST<1,1> SETTING INC.POS THEN
						Y.INC.FLAG = '1'
					END
				END
            END
		END
	END

	RETURN


	END