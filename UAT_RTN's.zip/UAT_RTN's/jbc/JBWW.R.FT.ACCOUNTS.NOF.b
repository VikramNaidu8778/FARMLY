*---------------------------------------------------	
	SUBROUTINE JBWW.R.FT.ACCOUNTS.NOF(Y.CS.DET)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is a Nofile routine attached to the enquiry JBWW.E.FT.ACCOUNTS.LIST. 
* this will give the accounts with appropriate label for BJB
* input formatt is CUSTOMER-PORTFOLIO-CURRENCY
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: Y.CS.DET
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               Developer                 Reference                 Description
*
*  06/08/2018        Bala                       DAY15-3268               flag will be raised if Input account is interest account.
*
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
	$INSERT I_F.ALTERNATE.ACCOUNT
        
*-----------------------------------------------------------------------------
    
    GOSUB INIT
    GOSUB PROCESS
	
    RETURN
    
*-------------------------------------------
INIT:
*****
	
	Y.SAM.ID = ''
	Y.CS.DET = ''
	Y.INC.FLAG = ''
	
    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
	
	FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
	F.SEC.ACC.MASTER.ALT = ''
	CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
	F.ALTERNATE.ACCOUNT = ''
	CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
    

    LOCATE "PORT.CURR" IN D.FIELDS<1> SETTING CON.POS THEN
		Y.FILTER = D.RANGE.AND.VALUE<CON.POS>
    END	
	
Y.CUST = FIELDS(Y.FILTER,"-",1)
Y.SAM.SEQ = FIELDS(Y.FILTER,"-",2)
Y.CCY = FIELDS(Y.FILTER,"-",3)
*ACCOUNT.VAL=FIELDS(Y.FILTER,"-",4)

Y.SAM.ID = Y.CUST:'-':Y.SAM.SEQ
ACCOUNT.VAL=Y.CUST:'-':Y.SAM.SEQ:'-':Y.CCY

	LOCATE "PORT.ACCOUNT" IN D.FIELDS<1> SETTING CON.POS THEN
		PORT.ACCOUNT.VAL = D.RANGE.AND.VALUE<CON.POS>
		
		IF PORT.ACCOUNT.VAL THEN
				R.ALT.AC.REC=''
			CALL F.READ(FN.ALTERNATE.ACCOUNT, PORT.ACCOUNT.VAL , R.ALT.AC.REC, F.ALTERNATE.ACCOUNT , ERR.ALT.ACC )
			IF R.ALT.AC.REC THEN
				PORT.ACCOUNT.VAL = R.ALT.AC.REC<1>
			END 
		END 
    	END ELSE
		PORT.ACCOUNT.VAL  = ACCOUNT.VAL
		IF PORT.ACCOUNT.VAL THEN
				R.ALT.AC.REC=''
			CALL F.READ(FN.ALTERNATE.ACCOUNT, PORT.ACCOUNT.VAL , R.ALT.AC.REC, F.ALTERNATE.ACCOUNT , ERR.ALT.ACC )
			IF R.ALT.AC.REC THEN
				PORT.ACCOUNT.VAL = R.ALT.AC.REC<1>
			END 
		END 
	END 
	
	
	RETURN

*----------------------------------------------------------------
PROCESS:
********
	
    CALL F.READ(FN.SAM,Y.SAM.ID,REC.SAM,F.SAM,ERR.SAM)
	
	IF REC.SAM EQ '' THEN
	  GOSUB COVERT.PORT
	  CALL F.READ(FN.SAM,Y.SAM.ID,REC.SAM,F.SAM,ERR.SAM)
	END
	
***	Y.SAM.ACCTNO = REC.SAM<SC.SAM.ACCOUNT.NOS>
	Y.SAM.INACCT = REC.SAM<SC.SAM.INC.ACCOUNT.NO>
 	
	Y.ACCOUNT.LIST = Y.SAM.INACCT
    CHANGE VM TO FM IN Y.ACCOUNT.LIST
    CHANGE VM TO FM IN Y.SAM.INACCT	
	IF PORT.ACCOUNT.VAL  THEN
		CALL F.READ(FN.ACCOUNT,PORT.ACCOUNT.VAL ,REC.ACCOUNT , F.ACCOUNT , ERR.ACCOUNT)
			 Y.INC.FLAG =''	
		IF REC.ACCOUNT THEN
			LOCATE PORT.ACCOUNT.VAL IN Y.SAM.INACCT SETTING INCACC.POS THEN
				Y.INC.FLAG = 'YES'
			END
			Y.ACCT.TYPE = REC.ACCOUNT<AC.ALT.ACCT.TYPE>
			Y.ACCT.CCY =  REC.ACCOUNT<AC.CURRENCY>
			IF Y.ACCT.CCY EQ Y.CCY[1,3] THEN
				LOCATE 'BJB.ACCT' IN Y.ACCT.TYPE<1,1> SETTING BJB.POS THEN
					Y.BJB.ACCT = REC.ACCOUNT<AC.ALT.ACCT.ID,BJB.POS>
				END        			            
				IF Y.CS.DET THEN 
					Y.CS.DET<-1> = Y.BJB.ACCT:'*':PORT.ACCOUNT.VAL:'*':Y.INC.FLAG
				END ELSE
					Y.CS.DET = Y.BJB.ACCT:'*':PORT.ACCOUNT.VAL:'*':Y.INC.FLAG
				END			
			END
		END
	END ELSE
	
		LOOP 
			REMOVE Y.ACT.ID FROM Y.ACCOUNT.LIST SETTING AC.POS
			WHILE Y.ACT.ID:AC.POS
			
				CALL F.READ(FN.ACCOUNT,Y.ACT.ID,REC.ACCOUNT,F.ACCOUNT,ERR.ACCOUNT)
				
				IF REC.ACCOUNT THEN
					
					LOCATE Y.ACT.ID IN Y.SAM.INACCT SETTING INCACC.POS THEN
						Y.INC.FLAG = 'YES'
					END
				
					Y.ACCT.TYPE = REC.ACCOUNT<AC.ALT.ACCT.TYPE>
					Y.ACCT.CCY =  REC.ACCOUNT<AC.CURRENCY>
					IF Y.ACCT.CCY EQ Y.CCY[1,3] THEN
						LOCATE 'BJB.ACCT' IN Y.ACCT.TYPE<1,1> SETTING BJB.POS THEN
							Y.BJB.ACCT = REC.ACCOUNT<AC.ALT.ACCT.ID,BJB.POS>
						END        			            
						IF Y.CS.DET THEN 
							Y.CS.DET<-1> = Y.BJB.ACCT:'*':Y.ACT.ID:'*':Y.INC.FLAG
						END ELSE
							Y.CS.DET = Y.BJB.ACCT:'*':Y.ACT.ID:'*':Y.INC.FLAG
						END			
					END ELSE
					Y.CS.DET = Y.BJB.ACCT:'*':Y.ACT.ID:'*':Y.INC.FLAG
					END 
				END			
		REPEAT
	END
    
 RETURN
 
*---------------------------------------------------------
COVERT.PORT:
************

	CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC THEN
        Y.ALT.DATA = R.SAM.ALT.REC
        Y.SAM.ID = FIELD(Y.ALT.DATA,'*',2)
	END

RETURN
*----------------------------------------------------------------------
END


