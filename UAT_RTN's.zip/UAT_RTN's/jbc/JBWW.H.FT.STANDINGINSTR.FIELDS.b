* @ValidationCode : MToxMTQwMTA1MzY4OklTTy04ODU5LTE6MTUwMTY2NTU3MDg2Mzo1MjUzNTA6LTE6LTE6MDowOnRydWU6Ti9BOkRFVl8yMDE2MDguNA==
* @ValidationInfo : Timestamp         : 02 Aug 2017 14:49:30
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 525350
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : true
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------
* <Rating>-16</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.H.FT.STANDINGINSTR.FIELDS 
*-----------------------------------------------------------------------------
*<doc>
* Template for field definitions routine JBWW.H.FT.STANDINGINSTR.FIELDS
*
* @author tcoleman@temenos.com
* @stereotype fields template
* @uses Table
* @public Table Creation
* @package infra.eb
* </doc>
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date               who                     Reference                 Desc
* 17-09-2016        Priyadarshni Priyanka      PMT-058             Modification
* 18-JUL-2017       Mahesh J                   JB2A-37042          @ID of the template changed to ID.COMPANY
* 27-07-2017        Batturu Sivanandini        JB2A-38125          Change of BE.CUSTOMER field TYPE
* 02-08-2017        Jeeva Kumari               JB2A-38347          Changes to BEN.CUSTOMER field type and removal of CUSTOMER file from dropdown
* 22-08-2017        Rajesh Kumar    		   JB2A-40647          Changes to BEN.ACCT.NO field type and removal of check file and also the field
*                                                                  ACCT.WITH.BANK.ACC made as non mandatory field.  
* 29-08-2017       	Rajesh Kumar	           JB2A-40647          Changes to BEN.ACCT.NO field type and made as non mandatory field.
* 21-09-2017        Balaji Pushparaj		   JB2A-42245		   Sub-Value set added for BEN.CUSTOMER & ACCT.WITH.BANK fields.
*-----------------------------------------------------------------------------
*** <region name= Header>
*** <desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE 
    $INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
    ID.F = "PARAM.ID"
    ID.N = "12"
    ID.T = "A"
    ID.CHECKFILE = "COMPANY"    
*-----------------------------------------------------------------------------
*JB2A-38125
    fieldName = "XX<XX.BEN.CUSTOMER"
***JB2A-38347 - S/    
**    fieldLength = "20.3"
**    fieldType = "TEXT"
      fieldLength = "35.3"
      fieldType = "A"
***JB2A-38347 - /E      
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
**    CALL Field.setCheckFile("CUSTOMER"); *JB2A-38347 
*JB2A-38125    
    fieldName = "XX-DESCRIPTION"
    fieldLength = "35"
    fieldType = "A"
    neighbour = ""
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour)
   
    fieldName = "XX-CREDIT.ACCT.NO"
    fieldLength = "36.3"
    fieldType = "A"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    CALL Field.setCheckFile("ACCOUNT")
    
    fieldName = "XX-BEN.ACCT.NO"
    fieldLength = "34"
***JB2A-40647 - S/	
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
**    CALL Field.setCheckFile("ACCOUNT")
***JB2A-40647 - /E        

    fieldName = "XX-XX.ACCT.WITH.BANK"
    fieldLength = "35.3"
    fieldType = "A"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "XX>ACCT.WITH.BANK.ACC"
    fieldLength = "34"
    fieldType = "A"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field

    fieldName = "RESERVED.10"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field

    fieldName = "RESERVED.9"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.8"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.7"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.6"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.5"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.4"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.3"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.2"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    fieldName = "RESERVED.1"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field

    fieldName = "XX.OVERRIDE"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')
    
   
*-----------------------------------------------------------------------------
    CALL Table.setAuditPosition ;* Poputale audit information
*-----------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
END
