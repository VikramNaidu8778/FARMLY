* @ValidationCode : MTotODk1NDc0MDQxOklTTy04ODU5LTE6MTY2MDEwNDE2ODM5ODp1NDg5MzE6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 10 Aug 2022 12:02:48
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : u48931
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.FT.TRHTRADES.CALL
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 19-May-2021      J Murali         UCCE-2858             New requirement, include processing date, base and buy currency
* 28-May-2021      J Muali          UCCE-2954             New requirement changes
* 30-May-2021      Suresh D         UCCE-3023             Call REVE Local API routine added to send close msg for sameday reversal
* 11-Jul-2021      Muralidharan S   UCCE-3287             Portfolio number missing for set of income accounts     
* 24-Oct-2021      Muralidharan S   P3737-6808            Incorrect description displayed in OESA for FX Range Tarf Payout
* 01-Aug-2022      Muralidharan S   UCCE-3759             INAU status to be send to TCA
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JBWW.L.XX.TRH.TRADES
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.JBWW.H.XX.TRH.TRADES
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_F.TRANSACTION
    $INSERT I_GTS.COMMON
    $INSERT I_F.DATES
*-----------------------------------------------------------------------------

    GOSUB INIT.AND.OPEN
    GOSUB PROCESS

    RETURN

*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Initialise and Open>
*** <desc>Do the required OPF</desc>
*------------------------------------------------------------------------------------------------------------------------------------
INIT.AND.OPEN:
**************
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER  = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS  = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)

    FN.JBWW.L.XX.TRH.TRADES = 'F.JBWW.L.XX.TRH.TRADES'
    F.JBWW.L.XX.TRH.TRADES  = ''
    CALL OPF(FN.JBWW.L.XX.TRH.TRADES,F.JBWW.L.XX.TRH.TRADES)

    FN.JBWW.H.XX.TRH.TRADES = 'F.JBWW.H.XX.TRH.TRADES'
    F.JBWW.H.XX.TRH.TRADES  = ''
    CALL OPF(FN.JBWW.H.XX.TRH.TRADES,F.JBWW.H.XX.TRH.TRADES)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.TRANSACTION = 'F.TRANSACTION'
    F.TRANSACTION = ''
    CALL OPF(FN.TRANSACTION,F.TRANSACTION)

    FN.FT.TXN.TYPE.CONDITION = 'F.FT.TXN.TYPE.CONDITION'
    F.FT.TXN.TYPE.CONDITION = ''
    CALL OPF(FN.FT.TXN.TYPE.CONDITION,F.FT.TXN.TYPE.CONDITION)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER, F.SEC.ACC.MASTER)

    FN.JBWW.GEN.PARAM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.GEN.PARAM = ''
    CALL OPF(FN.JBWW.GEN.PARAM,F.JBWW.GEN.PARAM)

    ADVRECON.PARAM = 'JBWW.D.XX.TCA.RELEVANTCCY'
    CALL F.READ(FN.JBWW.GEN.PARAM,ADVRECON.PARAM,R.ADVRECON.PARAM,F.JBWW.GEN.PARAM,ADV.ERR)
    PARAM.FLD.NAMES = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.NAME>

    CUSTOMER.SECTOR.VAL = 'CUSTOMER.SECTOR'
    LOCATE CUSTOMER.SECTOR.VAL IN PARAM.FLD.NAMES<1,1> SETTING CUST.POS THEN
    INCLUDE.SECTOR.VALS = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.VALUE><1,CUST.POS>
    END

    INCLUDE.CATEGORY.VAL = 'FT.INCLUDE.CATEGORY'
    LOCATE INCLUDE.CATEGORY.VAL IN PARAM.FLD.NAMES<1,1> SETTING CATE.POS THEN
    INCLUDE.CATEGORY.VALS = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.VALUE><1,CATE.POS>
    END

    CHANGE ',' TO VM IN INCLUDE.CATEGORY.VALS
    CHANGE ',' TO VM IN INCLUDE.SECTOR.VALS

    TRX.TYPE.VAL = ''
    TRX.TYPE.CHECK = ''
    TXN.TYPE.CHECK = "JBWW.D.XX.TRH.TRADES"
    CALL F.READ(FN.JBWW.GEN.PARAM,TXN.TYPE.CHECK,R.TXN.TYPE.CHECK,F.JBWW.GEN.PARAM,ADV.ERR)
    TXN.FLD.NAMES = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE 'FTTXNCODE.PAYOUT' IN TXN.FLD.NAMES<1,1> SETTING PAYOUT.POS THEN
    FTTXNCODE.PAYOUT.VALS = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.VALUE><1,PAYOUT.POS>
    FTTXNCODE.PAYOUT = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.NAME><1,PAYOUT.POS>
    END

    LOCATE 'FTTXNCODE.PAYIN' IN TXN.FLD.NAMES<1,1> SETTING PAYIN.POS THEN
    FTTXNCODE.PAYIN.VALS = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.VALUE><1,PAYIN.POS>
    FTTXNCODE.PAYIN = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.NAME><1,PAYIN.POS>
    END

    LOCATE 'CCFTCODE.PAYOUT' IN TXN.FLD.NAMES<1,1> SETTING CCFT.POS THEN
    CCFTCODE.PAYOUT.VALS = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.VALUE><1,CCFT.POS>
    CCFTCODE.PAYOUT = R.TXN.TYPE.CHECK<JBWW.GEN.PAR.FIELD.NAME><1,CCFT.POS>
    END

    CHANGE ',' TO VM IN FTTXNCODE.PAYOUT.VALS
    CHANGE SM TO VM IN FTTXNCODE.PAYOUT.VALS
    CHANGE ',' TO VM IN FTTXNCODE.PAYIN.VALS
    CHANGE SM TO VM IN FTTXNCODE.PAYIN.VALS
    CHANGE ',' TO VM IN CCFTCODE.PAYOUT.VALS
    CHANGE SM TO VM IN CCFTCODE.PAYOUT.VALS

    UNAUTH.TYPE.VAL = ''
    UNAUTH.TYPE.CHECK = ''
    UNAUTH.FLD.NAMES    = ''
    UNAUTH.FLAG = 0
    UNAUTH.TYPE.CHECK = "JBWW.D.XX.TRH.REV.UNAUTH"
    CALL F.READ(FN.JBWW.GEN.PARAM,UNAUTH.TYPE.CHECK,R.TXN.TYPE.CHECK.UNAUTH,F.JBWW.GEN.PARAM,ADV.ERR)
    UNAUTH.FLD.NAMES = R.TXN.TYPE.CHECK.UNAUTH<JBWW.GEN.PAR.FIELD.NAME>

    FUNCTION.VAL  = V$FUNCTION
    STATUS.VAL    = R.NEW(FT.RECORD.STATUS)
    CURR.NO.VAL   = R.NEW(FT.CURR.NO)
    NO.AUTH.VAL   = R.VERSION(EB.VER.NO.OF.AUTH)
    PROCING.DATE     = R.NEW(FT.PROCESSING.DATE) ;* UCCE-2858 S/E
    CC.REMV.FLAG  = ''
*

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= UPDATE.CONCAT.AND.TRADE.TABLES>
*** <desc>Checking the transaction code process</desc>
*------------------------------------------------------------------------------------------------------------------------------------
PROCESS:
*********
    DESC.FLAG = ''

    TRANSACTION.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    LOCATE TRANSACTION.TYPE IN CCFTCODE.PAYOUT.VALS<1,1> SETTING CCFT.POS THEN
    ACCT.NO = R.NEW(FT.CHARGES.ACCT.NO)
    GOSUB CC.CHECK.CUSTOMER
    END

    ACCT.NO = R.NEW(FT.DEBIT.ACCT.NO)
    GOSUB DR.CHECK.CUSTOMER
    ACCT.NO = R.NEW(FT.CREDIT.ACCT.NO)
    GOSUB CR.CHECK.CUSTOMER

* Check the current record changed with commission details than the previously committed record
    IF FUNCTION.VAL EQ 'I' AND (STATUS.VAL EQ 'IHLD' OR STATUS.VAL EQ 'INAU') THEN
        * IF R.NEW(FT.COMMISSION.AMT)[4,99] GT 0 OR R.NEW(FT.CHARGE.AMT)[4,99] GT 0 THEN
        GOSUB CHECK.PREVIOUS.RECORDS
    END

    BEGIN CASE
        CASE DR.FLAG EQ '1' AND CC.FLAG EQ '1' AND DR.INCLUDE.ACCT EQ '1' AND CC.INCLUDE.ACCT EQ '1'
            GOSUB COMMISSION.CHARGE.PROCESS
        CASE DR.FLAG EQ '1' AND CR.FLAG EQ '1' AND CC.FLAG NE '1' AND DR.INCLUDE.ACCT EQ '1' AND CR.INCLUDE.ACCT EQ '1' AND CC.INCLUDE.ACCT NE '1'
            IF R.NEW(FT.DEBIT.ACCT.NO) THEN
                FT.ID = ID.NEW:'-D'
                GOSUB DEBIT.LINE.PROCESS
            END
            IF R.NEW(FT.CREDIT.ACCT.NO) THEN
                FT.ID = ID.NEW:'-C'
                GOSUB CREDIT.LINE.PROCESS
            END
        CASE DR.FLAG EQ '1' AND CR.FLAG NE '1' AND CC.FLAG NE '1' AND DR.INCLUDE.ACCT EQ '1' AND CR.INCLUDE.ACCT NE '1' AND CC.INCLUDE.ACCT NE '1'
            FT.ID = ID.NEW
            *            IF CC.REMV.FLAG EQ 1 OR TRANSACTION.TYPE[1,2] EQ 'OT' THEN
            IF TRANSACTION.TYPE[1,2] EQ 'OT' THEN
                FT.ID = ID.NEW:'-1'
            END
            GOSUB DEBIT.LINE.PROCESS
        CASE CR.FLAG EQ '1' AND DR.FLAG NE '1' AND CC.FLAG NE '1' AND DR.INCLUDE.ACCT NE '1' AND CR.INCLUDE.ACCT EQ '1' AND CC.INCLUDE.ACCT NE '1'
            FT.ID = ID.NEW
            GOSUB CREDIT.LINE.PROCESS
        CASE DR.FLAG EQ '1' AND CR.FLAG EQ '1' AND CC.FLAG NE '1' AND DR.INCLUDE.ACCT EQ '1' AND CR.INCLUDE.ACCT NE '1' AND CC.INCLUDE.ACCT NE '1'
            FT.ID = ID.NEW
            *            IF CC.REMV.FLAG EQ 1 OR TRANSACTION.TYPE[1,2] EQ 'OT' THEN
            IF TRANSACTION.TYPE[1,2] EQ 'OT' THEN
                FT.ID = ID.NEW:'-1'
            END
            GOSUB DEBIT.LINE.PROCESS
        CASE CR.FLAG EQ '1' AND DR.FLAG EQ '1' AND CC.FLAG NE '1' AND DR.INCLUDE.ACCT NE '1' AND CR.INCLUDE.ACCT EQ '1' AND CC.INCLUDE.ACCT NE '1'
            FT.ID = ID.NEW
            GOSUB CREDIT.LINE.PROCESS
        CASE 1
            RETURN
    END CASE

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= MAIN.PROCESS>
*** <desc>Main process</desc>
*------------------------------------------------------------------------------------------------------------------------------------
MAIN.PROCESS:
*************
    LOCATE 'FT.UNAUTH' IN UNAUTH.FLD.NAMES<1,1> SETTING UNAUTH.POS THEN
    FTUNAUTH.TXN.VALS = R.TXN.TYPE.CHECK.UNAUTH<JBWW.GEN.PAR.FIELD.VALUE><1,UNAUTH.POS>
    CHANGE 'SM' TO VM IN FTUNAUTH.TXN.VALS
    CHANGE ',' TO FM IN FTUNAUTH.TXN.VALS

    LOCATE TXN.TYPE IN FTUNAUTH.TXN.VALS SETTING UNAUTH.TRX.POS THEN
    UNAUTH.FLAG = 1
    END

    END

    LOCATE TRANSACTION.TYPE IN FTTXNCODE.PAYOUT.VALS<1,1> SETTING PAYOUT.POS THEN
    PAYOUT.FLAG = 1
    END

    LOCATE TRANSACTION.TYPE IN FTTXNCODE.PAYIN.VALS<1,1> SETTING PAYIN.POS THEN
    PAYIN.FLAG = 1
    END

    BEGIN CASE
        CASE PAYOUT.FLAG EQ '1'
            GOSUB UPDATE.CONCAT.AND.TRADE.TABLES
        CASE PAYIN.FLAG EQ '1'
            GOSUB UPDATE.CONCAT.AND.TRADE.TABLES
        CASE 1
            RETURN
    END CASE

    RETURN
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= UPDATE.CONCAT.AND.TRADE.TABLES>
*** <desc>Update Concat & Trade Table</desc>
*------------------------------------------------------------------------------------------------------------------------------------
UPDATE.CONCAT.AND.TRADE.TABLES:
*******************************

* To exclude closed message during EOD due to NAU.PROCESSING delete function. Which creates confusions at TCA level
    IF R.DATES(EB.DAT.CO.BATCH.STATUS) EQ 'B' THEN
        NAU.PROCESS.OFS.VAL = 'NAU.PROCESS.OFS'
        LOCATE NAU.PROCESS.OFS.VAL IN PARAM.FLD.NAMES<1,1> SETTING OFS.POS THEN
        EXCLUDE.OFS.VALS = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.VALUE><1,OFS.POS>
    END

    OFS.SOURCE.REF.VAL = OFS$SOURCE.ID
    IF FUNCTION.VAL EQ 'D' AND EXCLUDE.OFS.VALS EQ OFS.SOURCE.REF.VAL THEN
        RETURN
    END
    END

    IF (FUNCTION.VAL EQ 'R' AND NO.AUTH.VAL GE 1) OR (FUNCTION.VAL EQ 'D'  AND CURR.NO.VAL GT 1) THEN
        RETURN
    END

    R.TRADE.RECORD.ARRAY = ''

* MATBUILD R.TRADE.RECORD.ARRAY FROM R.NEW
* Form the Record Array from the R.new

    GOSUB CHECK.CLIENT.CUST

    R.FT.TXN.TYPE.CONDITION = '' ; FTC.ERR = ''
    CALL F.READ(FN.FT.TXN.TYPE.CONDITION,TRANSACTION.TYPE,R.FT.TXN.TYPE.CONDITION,F.FT.TXN.TYPE.CONDITION,FTC.ERR)
    TXN.CODE.DR = R.FT.TXN.TYPE.CONDITION<FT6.TXN.CODE.DR>
    
    * P3737-6808 Start
    NARRATIVE = R.FT.TXN.TYPE.CONDITION<FT6.DESCRIPTION>

*    R.TRANSACTION = '' ; TRNS.ERR = ''
*    CALL F.READ(FN.TRANSACTION,TXN.CODE.DR,R.TRANSACTION,F.TRANSACTION,TRNS.ERR)
*    NARRATIVE = R.TRANSACTION<AC.TRA.NARRATIVE>
     
    * P3737-6808 End
    
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.is.Batch>      = 'False'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.src.System>    = 'T24-FT'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.client.Nbr>    = R.CUSTOMER<EB.CUS.MNEMONIC>

    SEC.ACC.MASTER.ERR = '' ; SEC.ACC.MASTER.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,PORTFOLIO.ID, R.SEC.ACC.MASTER, F.SEC.ACC.MASTER,SEC.ACC.MASTER.ERR)
    ACCOUNT.NAME = ''

    IF NOT(SEC.ACC.MASTER.ERR) THEN
        ACCOUNT.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
    END ELSE
       * If Portfolio id is not available in Account>Portfolio.No field then get the portfolio name from alt.acct.id field.  
        ALT.ACT.POS = ''
        Y.ALT.ACCT.ID = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.ACT.POS THEN
        Y.ALT.ACCT.ID = R.ACCOUNT<AC.ALT.ACCT.ID, ALT.ACT.POS>
        PORTFOLIO.NAME = FIELD(Y.ALT.ACCT.ID,'-',1,2)   ;* Portfolio Name
        END

        PORT.ALT.ERR.CODE = ''
        R.ALT.PORTFOLIO = ''
    
        FN.SEC.ACC.MASTER.ACCOUNT.NAME = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
        F.SEC.ACC.MASTER.ACCOUNT.NAME = ''
        CALL OPF(FN.SEC.ACC.MASTER.ACCOUNT.NAME, F.SEC.ACC.MASTER.ACCOUNT.NAME)

        CALL F.READ(FN.SEC.ACC.MASTER.ACCOUNT.NAME,PORTFOLIO.NAME,R.ALT.PORTFOLIO,F.SEC.ACC.MASTER.ACCOUNT.NAME,PORT.ALT.ERR.CODE)
        IF R.ALT.PORTFOLIO NE '' THEN
            PORTFOLIO.NUMBER.VAL = FIELD(R.ALT.PORTFOLIO<1>,'*',2)  ;* T24 Portfolio id
        END
        GOSUB GET.PORTFOLIO.DETAILS
        ACCOUNT.NAME = PORTFOLIO.NAME
    END
    
    
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.portfolio.Nbr> = ACCOUNT.NAME
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Type> = TXN.TYPE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.inst.Identifier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.underlying> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sub.Asset.Type> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Amt> = TXM.AMT
    IF DESC.FLAG EQ '1' THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.txn.Ccy> = R.ACCOUNT<AC.CURRENCY>
    END ELSE
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.txn.Ccy> = TXN.CCY
    END
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.ref.Nbr> = FT.ID
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.value.Date> = FT.VALUE.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.quantity> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.strike.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.spot.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.run.Notional> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.short.Notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Size> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta.Structure> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.number.Of.Settl.Dates> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.multiplier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.nbr.Of.Options> = ''
    IF DESC.FLAG EQ '1' THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.trans.Desc> = 'Commissions and Charges'
    END ELSE
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.trans.Desc> = NARRATIVE
    END
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.tenor> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.option.Desc> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.dlv.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.link.Reference> = ''
* UCCE-2858 S
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.processing.Date> = PROCING.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.buy.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.base.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status>     = ''
* UCCE-2858 E
    R.FUNDS.TRANSFER = ''
    FT.ERR = ''
    CALL F.READ(FN.FUNDS.TRANSFER, ID.NEW, R.FUNDS.TRANSFER, F.FUNDS.TRANSFER, FT.ERR)

    R.JBWW.L.XX.TRH.TRADES = ''
    TRH.TRADES.ERR = ''
    CALL F.READ(FN.JBWW.L.XX.TRH.TRADES, FT.ID, R.JBWW.L.XX.TRH.TRADES, F.JBWW.L.XX.TRH.TRADES, TRH.TRADES.ERR)

    R.JBWW.H.XX.TRH.TRADES = ''
    TRADES.ERR = ''
    CALL F.READ(FN.JBWW.H.XX.TRH.TRADES, FT.ID, R.JBWW.H.XX.TRH.TRADES, F.JBWW.H.XX.TRH.TRADES, TRADES.ERR)

* Incase record not available in staging table and record
    IF (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND CURR.NO.VAL GE 1) OR (FUNCTION.VAL EQ 'A' AND CURR.NO.VAL GT 1) THEN
        AMENDMENT.FLAG = 1
    END

    DUP.INCEP.FLAG = 0
    IF UNAUTH.FLAG = 1 THEN
        BEGIN CASE
            CASE FUNCTION.VAL EQ 'D' AND NOT(R.FUNDS.TRANSFER)
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Closed'
            CASE (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL GE 1)
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Unauth'
            CASE (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND NOT(R.FUNDS.TRANSFER) AND CURR.NO.VAL)
                DUP.INCEP.FLAG = 1
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'
            CASE (FUNCTION.VAL EQ 'A' AND NOT(R.FUNDS.TRANSFER)) OR (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0 AND NOT(R.FUNDS.TRANSFER))
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'
            CASE (R.JBWW.H.XX.TRH.TRADES AND NOT(TRADES.ERR)) OR CC.REMV.FLAG = 1 OR AMENDMENT.FLAG = 1
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Amendment'
        END CASE

        IF DUP.INCEP.FLAG = 1 THEN
            * RETURN
            CALL OCOMO("Write duplicate check":R.TRADE.RECORD.ARRAY:" ":CURR.NO.VAL)
        END

    END ELSE

        BEGIN CASE
            CASE FUNCTION.VAL EQ 'D' AND NOT(R.FUNDS.TRANSFER)
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Closed'
            CASE (R.JBWW.H.XX.TRH.TRADES AND NOT(TRADES.ERR)) OR CC.REMV.FLAG = 1
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Amendment'
            CASE 1
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>              = 'Inception'
                R.TRADE.RECORD.ARRAY<JB.TRHTRD.org.Trx.Datetime>    = TRX.DATE.TIME.VAL   ;* UCCE-3477
        END CASE

    END
    GOSUB UPDATE.AUDIT
    IF STATUS.VAL EQ 'MAT' THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>  = 'Closed'
    END

    IF STATUS.VAL EQ 'REVE' OR STATUS.VAL EQ 'REV' OR STATUS.VAL EQ 'R' OR STATUS.VAL EQ 'RNAU' OR (FUNCTION.VAL EQ 'R' AND NO.AUTH.VAL EQ 0) THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Closed'
    END ELSE
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'False'
    END

    FT.HIS.ERR = '' ; R.FUNDS.TRANSFER.HIS = ''
    TXN.REF = FIELD(FT.ID,'-',1)
    CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS, TXN.REF, R.FUNDS.TRANSFER.HIS, FT.HIS.ERR)
    MAT.STATUS = R.FUNDS.TRANSFER.HIS<FT.RECORD.STATUS>

* UCCE-2858 S
    BEGIN CASE
        CASE MAT.STATUS EQ 'MAT' AND FT.VALUE.DATE GT TODAY AND TXN.TYPE EQ 'PAYOUT'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Amendment'
        CASE MAT.STATUS EQ 'MAT' AND FT.VALUE.DATE LE TODAY   AND TXN.TYPE EQ 'PAYOUT'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Amendment'
            * UCCE-2954 S
        CASE MAT.STATUS EQ 'MAT' AND FT.VALUE.DATE GT TODAY AND TXN.TYPE EQ 'PAYIN'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Closed'
        CASE MAT.STATUS EQ 'MAT' AND FT.VALUE.DATE LE TODAY AND TXN.TYPE EQ 'PAYIN'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Amendment'
            * UCCE-2954 E
    END CASE
* UCCE-2858 E
* UCCE-3023/S
    IF MAT.STATUS NE 'MAT' THEN
        REV.ARRAY = ''
        REV.ARRAY<1> = STATUS.VAL
        REV.ARRAY<2> = FUNCTION.VAL
        REV.ARRAY<3> = NO.AUTH.VAL
        REV.ARRAY<4> = TRX.DATE.TIME.VAL
        SAME.DAY.FLAG = ''
        REV.STATUS = ''

        CALL JBWW.R.XX.TRH.REV.MARKER.CALC(REV.ARRAY,REVERSE.FLAG,REV.STATUS,SAME.DAY.FLAG)
        IF SAME.DAY.FLAG EQ '1' THEN
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'True'
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.status>      = 'Closed'
        END
    END
* UCCE-3023/E
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''
    

    CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,FT.ID,R.TRADE.RECORD.ARRAY)

**** To update H table to maintain history ******
    APP.ID = FT.ID
    R.APP.RECORD.ARRAY = R.TRADE.RECORD.ARRAY
    GOSUB WRITE.DATA.IN.H.TABLE
**** To update H table to maintain history ******

*RET.FLAG = ''
*CALL JBWW.R.XX.TRH.DUPLICATE.CHECK(FT.ID, R.TRADE.RECORD.ARRAY, RET.FLAG)
*IF RET.FLAG EQ 1 THEN
    CALL OCOMO("TRH Record updated":R.TRADE.RECORD.ARRAY:" ":FT.ID)
    Y.ID = FT.ID
    FLOW.CATALOG.ID = 'TRH-JbwwLXxTrhTrades'
    FLOWNAME = 'JBWW.L.XX.TRH.TRADES'
    APPLICATIONNAME = 'JBWW.L.XX.TRH.TRADES'
    CALL JBWW.R.IF.TRHTRADES.CAPTURE(FLOWNAME , FLOW.CATALOG.ID , APPLICATIONNAME ,  Y.ID)
*END

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
UPDATE.AUDIT:
*************
    
    TRX.DATE.TIME.VAL = ''
    CALL JBWW.R.XX.TRH.TRXDATETIME.UPD(TRX.DATE.TIME.VAL)
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Datetime> = TRX.DATE.TIME.VAL
    IF FUNCTION.VAL EQ 'A' OR (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0) THEN
        R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status>  = ''
    END ELSE
        IF NOT(R.FUNDS.TRANSFER) THEN    ;* UCCE-3759
            IF NOT(STATUS.VAL) OR STATUS.VAL EQ 'IHLD' THEN
                STATUS.VAL = 'INAU'
            END
            R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status>  = STATUS.VAL
        END
    END

    R.TRADE.RECORD.ARRAY<JB.TRHTRD.curr.Number> = CURR.NO.VAL

    RETURN
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= DR.CHECK.CUSTOMER>
*** <desc>Debit customer check process</desc>
*------------------------------------------------------------------------------------------------------------------------------------
DR.CHECK.CUSTOMER:
******************
    GOSUB CHECK.CLIENT.CUST

    DR.FLAG = ''
    LOCATE Y.SECTOR IN INCLUDE.SECTOR.VALS<1,1> SETTING SECT.POS THEN
    DR.FLAG = '1'
    END
    DR.INCLUDE.ACCT = ''
    LOCATE CATEGORY.VAL IN INCLUDE.CATEGORY.VALS<1,1> SETTING CATEGORY.POS THEN
    DR.INCLUDE.ACCT = '1'
    END

    RETURN
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= CR.CHECK.CUSTOMER>
*** <desc>Check credit customer process</desc>
*------------------------------------------------------------------------------------------------------------------------------------
CR.CHECK.CUSTOMER:
******************
    GOSUB CHECK.CLIENT.CUST

    CR.FLAG = ''
    LOCATE Y.SECTOR IN INCLUDE.SECTOR.VALS<1,1> SETTING SECT.POS THEN
    CR.FLAG = '1'
    END
    CR.INCLUDE.ACCT = ''
    LOCATE CATEGORY.VAL IN INCLUDE.CATEGORY.VALS<1,1> SETTING CATEGORY.POS THEN
    CR.INCLUDE.ACCT = '1'
    END

    RETURN
CC.CHECK.CUSTOMER:
******************
    GOSUB CHECK.CLIENT.CUST
    CC.FLAG = ''
    LOCATE Y.SECTOR IN INCLUDE.SECTOR.VALS<1,1> SETTING SECT.POS THEN
    CC.FLAG = '1'
    END
    CC.INCLUDE.ACCT = ''
    LOCATE CATEGORY.VAL IN INCLUDE.CATEGORY.VALS<1,1> SETTING CATEGORY.POS THEN
    CC.INCLUDE.ACCT = '1'
    END

    RETURN
COMMISSION.CHARGE.PROCESS:
**************************
    IF R.NEW(FT.DEBIT.ACCT.NO) THEN
        FT.ID = ID.NEW:'-1'
        GOSUB DEBIT.LINE.PROCESS
    END
    IF R.NEW(FT.COMMISSION.AMT)[4,99] GT 0 OR R.NEW(FT.CHARGE.AMT)[4,99] GT 0 THEN
        ACCT.NO = R.NEW(FT.CHARGES.ACCT.NO)
        FT.ID = ID.NEW:'-2'
        TXM.AMT = (R.NEW(FT.COMMISSION.AMT)[4,99] + R.NEW(FT.CHARGE.AMT)[4,99]) * -1
        TXN.TYPE = 'PAYOUT'
        FT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
        DESC.FLAG = '1'
        GOSUB MAIN.PROCESS
    END

    RETURN
DEBIT.LINE.PROCESS:
*******************
    ACCT.NO = R.NEW(FT.DEBIT.ACCT.NO)
    TXM.AMT = R.NEW(FT.AMOUNT.DEBITED)[4,99] * -1
    TXN.CCY = R.NEW(FT.DEBIT.CURRENCY)
    TXN.TYPE = 'PAYOUT'
    FT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
    GOSUB MAIN.PROCESS

    RETURN
CREDIT.LINE.PROCESS:
********************
    ACCT.NO = R.NEW(FT.CREDIT.ACCT.NO)
    TXM.AMT = R.NEW(FT.AMOUNT.CREDITED)[4,99]
    TXN.CCY = R.NEW(FT.CREDIT.CURRENCY)
    TXN.TYPE = 'PAYIN'
    FT.VALUE.DATE = R.NEW(FT.CREDIT.VALUE.DATE)
    GOSUB MAIN.PROCESS

    RETURN
CHECK.CLIENT.CUST:
******************
    R.ACCOUNT = '' ; ACCT.ERR = ''
    CALL F.READ(FN.ACCOUNT,ACCT.NO,R.ACCOUNT,F.ACCOUNT,ACCT.ERR)
    CUSTOMER.ID = R.ACCOUNT<AC.CUSTOMER>
    PORTFOLIO.ID = R.ACCOUNT<AC.PORTFOLIO.NO>
    CATEGORY.VAL = R.ACCOUNT<AC.CATEGORY>
    R.CUSTOMER = '' ; CUSTOMER.ERR = ''
    CALL F.READ(FN.CUSTOMER,CUSTOMER.ID,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
    Y.SECTOR = R.CUSTOMER<EB.CUS.SECTOR>

    RETURN
CHECK.PREVIOUS.RECORDS:
***********************

    R.JBWW.L.XX.TRH.TRADES.CC = ''
    CC.TRADES.ERR = ''

    IF CC.FLAG EQ '' THEN
        * If the record is in NAU and the commission flag is not set now then check whether the previous record
        * for commission leg is created with '2' then close the old record and create a new with -1
        TXN.ID = ID.NEW:"-2"
        CC.REMV.FLAG = 1
    END ELSE
        * If the record is in NAU and the commission flag is set now then check whether the previous record
        * for DR leg is created without '-1' then close the old record and create a new with -1 and -2
        * TXN.ID = ID.NEW
        CC.REMV.FLAG = 1
    END

    CALL F.READ(FN.JBWW.L.XX.TRH.TRADES,TXN.ID,R.JBWW.L.XX.TRH.TRADES.CC, F.JBWW.L.XX.TRH.TRADES, CC.TRADES.ERR)
    IF NOT(CC.TRADES.ERR) AND R.JBWW.L.XX.TRH.TRADES.CC THEN
        TRX.DATE.TIME.VAL = ''
        CALL JBWW.R.XX.TRH.TRXDATETIME.UPD(TRX.DATE.TIME.VAL)
        R.JBWW.L.XX.TRH.TRADES.CC<JB.TRHTRD.trx.Datetime> = TRX.DATE.TIME.VAL
        R.JBWW.L.XX.TRH.TRADES.CC<JB.TRHTRD.status>       = 'Closed'
        CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,TXN.ID,R.JBWW.L.XX.TRH.TRADES.CC)

**** To update H table to maintain history ******
        APP.ID = TXN.ID
        R.APP.RECORD.ARRAY = R.JBWW.L.XX.TRH.TRADES.CC
        GOSUB WRITE.DATA.IN.H.TABLE
**** To update H table to maintain history ******

        CALL OCOMO("TRH Record updated":R.TRADE.RECORD.ARRAY:" ":TXN.ID)
        Y.ID             = TXN.ID
        FLOW.CATALOG.ID  = 'TRH-JbwwLXxTrhTrades'
        FLOWNAME         = 'JBWW.L.XX.TRH.TRADES'
        APPLICATIONNAME  = 'JBWW.L.XX.TRH.TRADES'
        CALL JBWW.R.IF.TRHTRADES.CAPTURE(FLOWNAME , FLOW.CATALOG.ID , APPLICATIONNAME ,  Y.ID)
    END
    RETURN


*-----------------------------------------------------------------------------
WRITE.DATA.IN.H.TABLE:
**********************

    R.JBWW.H.XX.TRH.TRADES.OLD = '' ; TRADES.ERR = ''
    CALL F.READ(FN.JBWW.H.XX.TRH.TRADES, APP.ID, R.JBWW.H.XX.TRH.TRADES.OLD, F.JBWW.H.XX.TRH.TRADES, TRADES.ERR)

    IF R.JBWW.H.XX.TRH.TRADES.OLD THEN

        FN.JBWW.H.XX.TRH.TRADES.HIS = 'F.JBWW.H.XX.TRH.TRADES$HIS'
        F.JBWW.H.XX.TRH.TRADES.HIS = ''
        CALL OPF(FN.JBWW.H.XX.TRH.TRADES.HIS,F.JBWW.H.XX.TRH.TRADES.HIS)

        APP.HIS.ID = APP.ID:';':CURR.NO.VAL

        R.JBWW.H.XX.TRH.TRADES.HIS = '' ; TRADES.HIS.ERR = ''
        CALL F.READ(FN.JBWW.H.XX.TRH.TRADES.HIS, APP.HIS.ID, R.JBWW.H.XX.TRH.TRADES.HIS, F.JBWW.H.XX.TRH.TRADES.HIS, TRADES.HIS.ERR)

        R.JBWW.H.XX.TRH.TRADES.HIS = R.JBWW.H.XX.TRH.TRADES.OLD

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES.HIS,APP.HIS.ID,R.JBWW.H.XX.TRH.TRADES.HIS)

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,APP.ID,R.APP.RECORD.ARRAY)

    END ELSE

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,APP.ID,R.APP.RECORD.ARRAY)
    END

    RETURN

*-----------------------------------------------------------------------------
GET.PORTFOLIO.DETAILS:
    R.SEC.ACC.MASTER = '' ; SEC.ACC.MASTER.ERR = '' ; PORTFOLIO.NAME = ''
    CALL F.READ(FN.SEC.ACC.MASTER, PORTFOLIO.NUMBER.VAL, R.SEC.ACC.MASTER, F.SEC.ACC.MASTER, SEC.ACC.MASTER.ERR)
    IF NOT(SEC.ACC.MASTER.ERR) THEN
        PORTFOLIO.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
        INC.ACCOUNT.NO.VAL = R.SEC.ACC.MASTER<SC.SAM.INC.ACCOUNT.NO>
    END

    RETURN

    END