*-----------------------------------------------------------------------------
* <Rating>447</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBSO.B.OLY.FT.COMM.TYPE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------

    GOSUB INITIALIZE
    GOSUB OPENFILES
    GOSUB OPENSEQFILE
    GOSUB PROCESS
    GOSUB CLOSESEQFILE

    RETURN

*-----------------------------------------------------------------------------
INITIALIZE:
*-----------------------------------------------------------------------------
    Y.COMP = ID.COMPANY[1,2]

    Y.OLY.FILE = Y.COMP:'OLYPRICE.csv'
    Y.T24OUT.FILE = Y.COMP:'-FTCOMMT24.csv'

    RETURN

*-----------------------------------------------------------------------------
OPENFILES:
*-----------------------------------------------------------------------------
    FN.VOC = 'VOC'
    F.VOC =''
    CALL OPF(FN.VOC,F.VOC)

    CALL F.READ(FN.VOC,'JBSHMIG', R.VOC, F.VOC, Y.ERR)

    Y.BASE.PATH = R.VOC<2>

    FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHIN.OLY/PRICING'
    OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
        ERRFLAG = 1
    END

    RETURN

*-----------------------------------------------------------------------------
OPENSEQFILE:
*-----------------------------------------------------------------------------
    IF Y.COMP EQ 'SG' THEN
        Y.T24DIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/SGPRICING'
    END
    IF Y.COMP EQ 'HK' THEN
        Y.T24DIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/HKPRICING'
    END

    DELETESEQ Y.T24DIR.NAME,Y.T24OUT.FILE THEN
    END

    OPENSEQ Y.T24DIR.NAME,Y.T24OUT.FILE TO Y.T24OUT.POINTER ELSE
        CREATE Y.T24OUT.POINTER ELSE
        RETURN
    END
    END
    RETURN

*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
    READ R.REC FROM F.FILE.DIR,Y.OLY.FILE THEN
        LOOP
            REMOVE SEQ.REC FROM R.REC SETTING Y.POS

            GOSUB ASSIGN.NULL.VALUES

        WHILE SEQ.REC:Y.POS

            CONVERT ',' TO FM IN SEQ.REC
            GOSUB ASSIGN.VALUES
            GOSUB ASSIGN.FT.VALUES
            Y.HEADER = 'Id':',':'Description':',':'Short Descr':',':'Category account':',':'Txn code cr':',':'Txn code dr':',':'Calculation basis':',':'Currency':',':'Flat amt':',':'Calc type':',':'Percentage':',':'Unit charage':',':'Upto amt':',':'Overall min amt':',':'Overall max amt':',':'Mthly amortisation':',':'Default ccy'                  ;*06/03/17
            IF Y.FT.CODE NE '' THEN
                Y.FT.ARRAY<-1> = Y.FT.CODE:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CAT.CDE:',':Y.TXN.CR:',':Y.TXN.DR:',':Y.FT.CALBASIS:',':Y.FT.CCY
                Y.FT.ARRAY:=',':Y.FT.FLAT.AMT:',':Y.FT.CALCTYPE:',':Y.FT.PERCENTAGE:',':Y.FT.UNIT.CHRG:',':Y.FT.UPTO.AMT:',':Y.FT.OVR.MIN.AMT:',':Y.FT.OVR.MAX.AMT:',':Y.MNTHLY.AMORT:',':Y.DEFLT.CCY:',':Y.TBCODE


                Y.FT.CODE = ''
                Y.DESC = ''
                Y.SHRT.DESC = ''
                Y.CAT.CDE = ''
                Y.TXN.CR = ''
                Y.TXN.DR = ''
                Y.FT.CALBASIS = ''
                Y.FT.CCY = ''
                Y.FT.CALCTYPE = ''
                Y.FT.PERCENTAGE = ''
                Y.FT.UNIT.CHRG = ''
                Y.FT.UPTO.AMT = ''
                Y.FT.OVR.MIN.AMT = ''
                Y.FT.OVR.MAX.AMT = ''
                Y.MNTHLY.AMORT = ''
                Y.DEFLT.CCY = ''
                Y.FT.FLAT.AMT = ''

            END
        REPEAT

        Y.FINAL.ARRAY = Y.HEADER:FM:Y.FT.ARRAY
        GOSUB WRITE.T24FTCOM.FILE

        Y.FT.ARRAY = ''
        Y.FINAL.ARRAY = ''
    END
    RETURN

*-----------------------------------------------------------------------------
ASSIGN.NULL.VALUES:
*-----------------------------------------------------------------------------
    Y.FLAG = '' ;  Y.TEMP.1 = '' ; Y.TEMP.2 = '' ; Y.TEMP.3 = '' ; Y.TEMP.4 = '' ; Y.TEMP.5 = ''
    Y.CALMETHOD = '' ; Y.TB.CODE = '' ; Y.DESC = '' ; Y.PERUNIT = '' ; Y.BANDCCY = '' ; Y.MIN = '' ; Y.MAX = ''
    Y.BYBANDIN = ''; Y.BAND.1 = '' ; Y.BAND.2 = '' ; Y.BAND.3 = '' ; Y.BAND.4 = '' ; Y.BAND.5 = ''; Y.BAND.6 = ''
    Y.BAND.7 = '' ; Y.RATE.1 = '' ; Y.RATE.2 = '' ; Y.RATE.3 = '' ; Y.RATE.4 = '' ; Y.RATE.5 = '' ; Y.RATE.6 = ''
    Y.RATE.7 = '' ; Y.UPTO.AMT = '' ; Y.PERCENT = '';  Y.BAND = '' ; Y.RATES = ''; Y.CAL.BASIS = ''
    Y.CCY = '' ; Y.CALC.TYPE = '' ; Y.PERCENTAGE = '' ; Y.UNIT.CHRG = '';  Y.FLAT.AMT = ''; Y.OVR.MIN.AMT = ''
    Y.OVR.MAX.AMT = ''; Y.TB.POS = ''; Y.CONCAT.VALUE1 = ''; Y.CONCAT.VALUE2 = ''; Y.TB.POS3 = '' ; Y.DECI.VAL = '' ; Y.UNIT.CHG.A = '' ; Y.UNIT.CHG.B = ''
    Y.FT.CDE = '' ; Y.TBCODE = '';

    RETURN
*-----------------------------------------------------------------------------
ASSIGN.VALUES:
*-----------------------------------------------------------------------------

    Y.TBCODE = SEQ.REC<1>
    Y.PERUNIT = SEQ.REC<9>
    Y.CALMETHOD = SEQ.REC<4>
    Y.PERCENT = SEQ.REC<25>
    Y.MIN = SEQ.REC<26>
    Y.MAX = SEQ.REC<27>
    Y.BYBANDIN = SEQ.REC<7>
    Y.BANDCCY = SEQ.REC<10>
    Y.BAND.1 = SEQ.REC<11>
    Y.RATE.1 = SEQ.REC<12>
    Y.BAND.2 = SEQ.REC<13>
    Y.RATE.2 = SEQ.REC<14>
    Y.BAND.3 = SEQ.REC<15>
    Y.RATE.3 = SEQ.REC<16>
    Y.BAND.4 = SEQ.REC<17>
    Y.RATE.4 = SEQ.REC<18>
    Y.BAND.5 = SEQ.REC<19>
    Y.RATE.5 = SEQ.REC<20>
    Y.BAND.6 = SEQ.REC<21>
    Y.RATE.6 = SEQ.REC<22>
    Y.BAND.7 = SEQ.REC<23>
    Y.RATE.7 = SEQ.REC<24>
    Y.BAND = Y.BAND.1:FM:Y.BAND.2:FM:Y.BAND.3:FM:Y.BAND.4:FM:Y.BAND.5:FM:Y.BAND.6:FM:Y.BAND.7
    Y.RATES = Y.RATE.1:FM:Y.RATE.2:FM:Y.RATE.3:FM:Y.RATE.4:FM:Y.RATE.5:FM:Y.RATE.6:FM:Y.RATE.7
    IF Y.PERCENT EQ '' THEN
        Y.PERCENT = '100'
    END

    IF Y.PERCENT EQ '000' THEN
        Y.PERCENT = '100'
    END

    Y.PERCENT = Y.PERCENT/100
    Y.MIN = Y.MIN + 0
    Y.MAX = Y.MAX + 0
    GOSUB FORM.FT.CODE
    GOSUB UPDT.CAL.BASIS
    GOSUB UPDT.CCY
    GOSUB UPDT.CALC.TYPE
    GOSUB UPDT.FLT.AMT
    IF Y.CALC.TYPE NE 'LOT' AND Y.CALC.TYPE NE 'FLAT' THEN
        GOSUB UPDT.PERCENT
    END
    GOSUB UPDT.UNIT.CHRG
    GOSUB UPDT.MIN.MAX.AMT

    RETURN

*-----------------------------------------------------------------------------
ASSIGN.FT.VALUES:
*-----------------------------------------------------------------------------
    Y.FT.CODE = Y.FT.CDE
    Y.DESC = Y.FT.CDE
    Y.SHRT.DESC = Y.FT.CDE
    Y.CAT.CDE = '52001'
    Y.TXN.CR = '614'
    Y.TXN.DR = '613'
    Y.FT.CALBASIS = Y.CAL.BASIS
    Y.FT.CCY = Y.CCY
    Y.FT.CALCTYPE = Y.CALC.TYPE
    Y.FT.PERCENTAGE = Y.PERCENTAGE
    Y.FT.UNIT.CHRG = Y.UNIT.CHRG
    Y.FT.UPTO.AMT = Y.UPTO.AMT
    Y.FT.FLAT.AMT = Y.FLAT.AMT
    Y.FT.OVR.MIN.AMT = Y.OVR.MIN.AMT
    Y.FT.OVR.MAX.AMT = Y.OVR.MAX.AMT
    Y.MNTHLY.AMORT = 'NO'
    Y.DEFLT.CCY = Y.CCY

    Y.FT.PER.CNT = DCOUNT(Y.PERCENTAGE,'!!')
    IF Y.FT.PER.CNT GT '1' THEN
        Y.FT = 2
        LOOP
        WHILE Y.FT LE Y.FT.PER.CNT
            Y.FT.CALCTYPE:='!!': Y.CALC.TYPE
            Y.FT.UNIT.CHRG:='!!':Y.UNIT.CHRG               ;*25/05/17 added for recon report comparision
            Y.FT = Y.FT + 1
        REPEAT

    END

    RETURN
*-----------------------------------------------------------------------------
FORM.FT.CODE:
*-----------------------------------------------------------------------------
    Y.TB.POS = Y.TBCODE[3,3]
    Y.CONCAT.VALUE1 = Y.TBCODE[5,10]
    Y.CONCAT.VALUE2 = Y.TBCODE[6,10]
    Y.TB.POS3 = Y.TBCODE[3,1]

    IF Y.TB.POS3 EQ '0' THEN
        GOSUB TBCDE.WITH.0
    END ELSE
        GOSUB TBCDE.WITOUT.0
    END

    RETURN

*-----------------------------------------------------------------------------
TBCDE.WITH.0:
*-----------------------------------------------------------------------------
    BEGIN CASE
        CASE Y.TB.POS EQ '003'
            Y.FT.CDE = 'O':Y.CONCAT.VALUE1
        CASE Y.TB.POS EQ '004'
            Y.FT.CDE = 'F':Y.CONCAT.VALUE1
        CASE 1
            Y.FT.CDE = 'B':Y.CONCAT.VALUE1
    END CASE
    RETURN

*-----------------------------------------------------------------------------
TBCDE.WITOUT.0:
*-----------------------------------------------------------------------------
    BEGIN CASE
        CASE Y.TB.POS EQ 'ACT'
            Y.FT.CDE = 'BA':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'VCT'
            Y.FT.CDE = 'BV':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'VFI'
            Y.FT.CDE = 'BF':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'SRP'
            Y.FT.CDE = 'BR':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'LFR'
            Y.FT.CDE = 'BL':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'SFI'
            Y.FT.CDE = 'BS':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'TMS'
            Y.FT.CDE = 'BM':Y.CONCAT.VALUE2
        CASE Y.TB.POS EQ 'TRS'
            Y.FT.CDE = 'BT':Y.CONCAT.VALUE2
    END CASE
    RETURN
*-----------------------------------------------------------------------------
UPDT.CAL.BASIS:
*-----------------------------------------------------------------------------

    IF Y.PERUNIT EQ 'N' OR Y.PERUNIT EQ '' THEN

        IF Y.CALMETHOD EQ '0' OR Y.CALMETHOD EQ '1' THEN
            Y.CAL.BASIS = 'PERCENTAGE'
        END
    END
    IF Y.PERUNIT EQ 'Y' THEN
        Y.CAL.BASIS = 'RATEPERLOT'
        Y.CALC.TYPE = 'LOT'
    END

    RETURN
*-----------------------------------------------------------------------------
UPDT.CALC.TYPE:
*-----------------------------------------------------------------------------
    Y.CHK.RATE = ''
    Y.RTE.FLAG = ''
    Y.RATE.CNT = DCOUNT(Y.RATES,FM)

    I = 1
    LOOP
    WHILE I LE Y.RATE.CNT
        Y.CHK.RATE = Y.RATES<I>

        IF Y.CHK.RATE NE '' THEN
            IF Y.CHK.RATE NE '00.0000' OR Y.CHK.RATE NE '0' THEN
                Y.RTE.FLAG = '1'
            END
        END
        I = I + 1
    REPEAT

    IF Y.MIN NE '' AND Y.MIN NE '0' THEN
        IF Y.RTE.FLAG EQ '' THEN
            Y.CALC.TYPE = 'FLAT'
            Y.CAL.BASIS = 'NULL'
        END
    END
    IF Y.CALC.TYPE EQ '' THEN
        IF Y.CALMETHOD EQ '0' THEN
            Y.CALC.TYPE = 'BAND'
        END

        IF Y.CALMETHOD EQ '1' THEN
            Y.CALC.TYPE = 'LEVEL'
        END
    END
    RETURN

*-----------------------------------------------------------------------------
UPDT.CCY:
*-----------------------------------------------------------------------------

    IF Y.BANDCCY EQ '001' OR Y.BANDCCY EQ '' THEN
        Y.CCY = 'CHF'
    END
    IF Y.BANDCCY EQ 0 THEN
        Y.CCY = 'CHF'
    END
    IF Y.BANDCCY EQ '978' THEN
        Y.CCY = 'EUR'
    END

    IF Y.BANDCCY EQ '840' THEN
        Y.CCY = 'USD'
    END

    RETURN

*-----------------------------------------------------------------------------
UPDT.FLT.AMT:
*-----------------------------------------------------------------------------
    IF Y.CALC.TYPE EQ 'FLAT' THEN
        Y.FLAT.AMT = Y.MIN
        Y.UPTO.AMT = 'NULL'                  ;*11/05/17 to display NULL instead of blank
        Y.PERCENTAGE = 'NULL'                ;*11/05/17 to display NULL instead of blank
    END ELSE                                        ;*11/05/17 to display NULL instead of blank
        Y.FLAT.AMT = 'NULL'
    END
    RETURN

*-----------------------------------------------------------------------------
UPDT.PERCENT:
*-----------------------------------------------------------------------------
    Y.RTE.CNT = DCOUNT(Y.RATES,FM)
    Y.RATE.A = ''
    Y.BAND.A = ''
    Y.R1 = ''
    Y.B1 = ''
    Y.B3 = ''
    Y.B2 = ''
    Y.B2.TEMP = ''

    Y.I = 1
    Y.L = 0
    LOOP
    WHILE Y.I LE Y.RTE.CNT
        Y.RATE.A = Y.RATES<Y.I>
        Y.BAND.A = Y.BAND<Y.I>
        Y.RATE.A = Y.RATE.A + 0
        IF Y.RATE.A NE 0 AND Y.RATE.A NE '' THEN
            Y.L = Y.L + 1
            IF Y.BAND.A EQ '999999' THEN
                Y.BAND.A = ''
            END
            Y.RATE.POS = ''
            LOCATE Y.RATE.A IN Y.R1 SETTING Y.RATE.POS THEN
            Y.B2 = Y.B1<Y.RATE.POS>
            IF Y.CALC.TYPE EQ 'BAND' THEN
                Y.B2.TEMP = Y.BAND.A + Y.B2
                Y.B1<Y.RATE.POS> = Y.B2.TEMP
                Y.R1<Y.RATE.POS> = Y.RATE.A
            END

            IF Y.CALC.TYPE EQ 'LEVEL' THEN
                IF Y.BAND.A GT Y.B2 THEN
                    Y.B1<Y.RATE.POS> = Y.BAND.A
                    Y.R1<Y.RATE.POS> = Y.RATE.A
                END ELSE
                    Y.B1<Y.RATE.POS> = Y.B2
                    Y.R1<Y.RATE.POS> = Y.RATE.A
                END
            END

            IF Y.BAND.A EQ '' THEN
                Y.B1<Y.RATE.POS> = ''
            END
        END ELSE
            Y.R1<-1> = Y.RATE.A
            Y.B1<-1> = Y.BAND.A
        END
    END
    Y.I = Y.I + 1
    REPEAT

    Y.R1.CNT = DCOUNT(Y.R1,FM)

    Y.J =1

    BEGIN CASE

        CASE Y.R1.CNT EQ 1
            Y.PERCENTAGE = Y.R1*Y.PERCENT
            Y.UPTO.AMT = 'NULL'

        CASE Y.R1.CNT EQ Y.L
            GOSUB UPDT.UPTO.AMT
        CASE OTHERWISE
            LOOP
            WHILE Y.J LE Y.R1.CNT

                Y.R2 = Y.R1<Y.J>
                Y.R3 = Y.R2*Y.PERCENT
                Y.PERCENTAGE<-1> = Y.R3

                Y.B2 = Y.B1<Y.J>
                IF Y.CALC.TYPE EQ 'LEVEL' THEN
                    Y.B3 = Y.B2*Y.BYBANDIN
                    IF Y.B3 EQ 0 THEN
                        Y.B3 = 'NULL'
                        Y.UPTO.AMT<-1> = Y.B3
                    END ELSE
                        Y.UPTO.AMT<-1> = Y.B3
                        Y.B3 = ''
                    END
                END
                IF Y.CALC.TYPE EQ 'BAND' THEN
                    Y.B3.1 = Y.B2*Y.BYBANDIN
                    IF Y.B3.1 EQ 0 THEN
                        Y.B3.2 = 'NULL'
                    END ELSE
                        Y.B3.2 = Y.B3.1 + Y.B3.2
                    END
                    Y.UPTO.AMT<-1> = Y.B3.2
                    Y.B3.1 = ''

                END
                Y.J = Y.J + 1
            REPEAT
            LOCATE '999999' IN Y.BAND SETTING Y.BAND.POS ELSE
            Y.PERCENTAGE := FM:'0'
            Y.UPTO.AMT := FM:'NULL'
        END

        CHANGE FM TO '!!' IN Y.PERCENTAGE
        CHANGE FM TO '!!' IN Y.UPTO.AMT
    END CASE

    RETURN
*-----------------------------------------------------------------------------
UPDT.UNIT.CHRG:
*-----------------------------------------------------------------------------
    IF Y.CAL.BASIS EQ 'RATEPERLOT' THEN

        Y.UNIT.CHG.A = Y.RATE.1*100000
        Y.UNIT.CHG.B = Y.UNIT.CHG.A*Y.PERCENT
        Y.UNIT.CHRG = Y.UNIT.CHG.B
        Y.UPTO.AMT = 'NULL'                  ;*11/05/17 to display NULL instead of blank
        Y.PERCENTAGE = 'NULL'                ;*11/05/17 to display NULL instead of blank
    END ELSE
        Y.UNIT.CHRG = 'NULL'                 ;*11/05/17 to display NULL instead of blank

    END
    RETURN
*-----------------------------------------------------------------------------
UPDT.UPTO.AMT:
*-----------------------------------------------------------------------------
    Y.PER.TEMP = ''
    Y.BAND.TEMP = ''
    Y.BAND.CNT = DCOUNT(Y.R1,FM)
    IF Y.BAND.CNT EQ 0 THEN
        Y.PERCENTAGE = 0
        Y.UPTO.AMT = 'NULL'
    END
    Y.K = 1

    LOOP
    WHILE Y.K LE Y.BAND.CNT
        Y.BAND.1 = Y.B1<Y.K>
        Y.RATE.1 = Y.R1<Y.K>
        BEGIN CASE
            CASE Y.CAL.BASIS EQ 'PERCENTAGE' AND Y.CALC.TYPE EQ 'BAND'
                Y.BAND.TEMP = Y.BAND.1 * Y.BYBANDIN
                IF Y.BAND.TEMP EQ 0 THEN
                    Y.AMT.TEMP = 'NULL'
                END ELSE
                    Y.AMT.TEMP = Y.BAND.TEMP + Y.AMT.TEMP
                END
                Y.UPTO.AMT<-1> = Y.AMT.TEMP
                Y.BAND.TEMP = ''
                Y.PER.TEMP = Y.RATE.1 * Y.PERCENT
                Y.PERCENTAGE<-1> = Y.PER.TEMP

            CASE Y.CAL.BASIS EQ 'PERCENTAGE' AND Y.CALC.TYPE EQ 'LEVEL'
                Y.BAND.TEMP = Y.BAND.1 * Y.BYBANDIN
                IF Y.BAND.TEMP EQ 0 THEN
                    Y.BAND.TEMP = 'NULL'
                END
                Y.UPTO.AMT<-1> = Y.BAND.TEMP
                Y.PER.TEMP = Y.RATE.1 * Y.PERCENT
                Y.PERCENTAGE<-1> = Y.PER.TEMP
        END CASE

        Y.K = Y.K + 1
    REPEAT

    LOCATE '999999' IN Y.BAND SETTING Y.BAND.POS ELSE
    Y.PERCENTAGE := FM:'0'
    Y.UPTO.AMT := FM:'NULL'
    END

    CHANGE FM TO '!!' IN Y.UPTO.AMT
    CHANGE FM TO '!!' IN Y.PERCENTAGE

    RETURN
*-----------------------------------------------------------------------------
UPDT.MIN.MAX.AMT:
*-----------------------------------------------------------------------------

    IF Y.MIN EQ '' OR Y.MIN EQ 0 THEN
        Y.OVR.MIN.AMT = 'NULL'
    END ELSE
        Y.OVR.MIN.AMT = Y.MIN
    END
    IF Y.MAX EQ '' OR Y.MAX EQ 0 THEN
        Y.OVR.MAX.AMT = 'NULL'
    END ELSE
        Y.OVR.MAX.AMT = Y.MAX
    END
    RETURN

*-----------------------------------------------------------------------------
WRITE.T24FTCOM.FILE:
*-----------------------------------------------------------------------------
    CHANGE FM TO CHARX(10) IN Y.FINAL.ARRAY
    WRITESEQ Y.FINAL.ARRAY APPEND TO Y.T24OUT.POINTER THEN
    END
    RETURN
*-----------------------------------------------------------------------------
CLOSESEQFILE:
*-----------------------------------------------------------------------------

    CLOSESEQ Y.T24OUT.POINTER

    RETURN

    END

