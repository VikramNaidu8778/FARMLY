SUBROUTINE JB.R.PP.RETURNCMPLTDCT.NOF(OUT.ARR)
* This a NoFile enquiry to list transactions based on User's Company.
*Attached to No File Enquiries of Payment Hub Queues.
*-------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------
** Date         Developer           Reference        Description
* 22-OCT-2024   Vikram Pavuluru     CBPAY-1259       This routine is used to fetch the records based on user's Company
*
* 17-JAN-2025   Lakshmi Priya       CBPAY-1674       Included the condition for enquiry JB.E.PP.SWIFTEXCEPBUSAUTH.LIST
*                                                    to call E.NOFILE.PP.RTGS.AUTH.EXCEP

*20-JAN-2025    Vikram Pavuluru     CBPAY-1620       Included the condition for enquiry JB.E.PP.SWIFTEXCEPTECHLIST.DETAIL
*                                                    to call NOFILE.PP.SWIFTOUT.TECH.EXCEP.LIST
*20-MAR-2025    Prabhu D S          CBPAY-2228       Implementing filtering logic for user roles
*
*28-APR-2025    Lakshmi Priya       CBPAY-2463       Including User Roles Filtering logic to Enquiry JB.E.PP.SWIFTEXCEPBUSAUTH.LIST,
*                                                     JB.E.PP.SWMXISOBUSINESSEXCEP.LIST and JB.E.PP.SWIFTEXCEPTECHLIST.DETAIL.
*22-MAY-2025    Prabhu D S          CBPAY-2340       WHILE loop replaced with FOR loop as it is truncating value by READNEXT statement
*
*16-Jun-2025   Lakshmi Priya        CBPAY-3142      Included the condition for enquiry JB.E.PP.SWMXOUT.NOTICEMSG 
*                                                   to call E.NOFILE.PP.SWIFTMX.OUT.NOTICE.MSG
*-------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.COMPANY
    $USING EB.Reports
    $INSERT I_F.POR.SUPPLEMENTARY.INFO

    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS

RETURN

INIT:
*****

    Y.MNEMONIC = ''
    Y.POS = ''
    Y.ENQ.NAME = ENQ.SELECTION<1>
    Y.POS = DCOUNT(ENQ.SELECTION<2>,@VM)
    Y.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
 
   
    IF Y.POS THEN
        Y.POS += 1
    END ELSE
        Y.POS = 1
    END

    ENQ.SELECTION<2,Y.POS> = "CompanyID"
    ENQ.SELECTION<3,Y.POS> = "EQ"
    ENQ.SELECTION<4,Y.POS> = Y.MNEMONIC


    D.LOGICAL.OPERANDS<Y.POS> = "1"

    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    FV.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)


RETURN

GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)

    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END

RETURN

PROCESS:
********

    BEGIN CASE
        CASE Y.ENQ.NAME EQ "JB.E.PP.RETURNCOMPLETED.CT"
            CALL E.NOFILE.PP.RETURN.COMPLETED.CT(ENQ.ARR)

        CASE Y.ENQ.NAME EQ "JB.E.PP.SWIFTCMPTD.CRTXN"
            CALL E.NOFILE.PP.RETURN.COMPLETED.SWIFT.CT(ENQ.ARR)
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.RVRSLINWRDSWIFTMTRTN.AUTH"
            CALL E.NOFILE.PP.SELECT.SWIFT.RETURNS.AUTHORISE(ENQ.ARR)
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.WAREHOUSE.PAYMENTS"
            ENQ.SELECTION<1> = "PP.WAREHOUSE.PAYMENTS"
            CALL PP.NOFILE.WAREHOUSE.PAYMENTS(ENQ.ARR)
            ENQ.SELECTION<1> = "JB.E.PP.WAREHOUSE.PAYMENTS"
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.WAREHOUSEPAYMENTS.NAU"
            ENQ.SELECTION<1> = "PP.WAREHOUSE.PAYMENTS"
            CALL PP.NOFILE.WAREHOUSE.PAYMENTS(ENQ.ARR)
            ENQ.SELECTION<1> = "JB.E.PP.WAREHOUSEPAYMENTS.NAU"
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWMXISOBUSINESSEXCEP.LIST"
            CALL E.NOFILE.PP.SWIFTOUT.BUSINESS.EXCEP.LIST(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWIFTEXCEPTECHLIST.DETAIL"
            CALL E.NOFILE.PP.SWIFTOUT.TECH.EXCEP.LIST(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWIFTEXCEPBUSAUTH.LIST"
            CALL E.NOFILE.PP.RTGS.AUTH.EXCEP(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWIFTMXOUTCANCEL.CUST"
            CALL E.NOFILE.PP.SWCR.RECALL.INITIATED(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWIFTMXOUTCANCEL.BANK"
            CALL E.NOFILE.PP.SWCR.RECALL.INITIATED(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.QUERY.SEND"
            CALL E.NOFILE.PP.QUERY.SEND(ENQ.ARR)
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.SENDFREEFORMAT.MSG"
            CALL E.NOFILE.PP.SEND.FREE.FORMAT.MSG(ENQ.ARR)
            
        CASE Y.ENQ.NAME EQ "JB.E.PP.REVERSEPAYMENT.INP"
            CALL E.NOFILE.PP.REVERSE.PAYMENT(ENQ.ARR)
      
        CASE Y.ENQ.NAME EQ "JB.E.PP.SWMXOUT.NOTICEMSG"
            CALL E.NOFILE.PP.SWIFTMX.OUT.NOTICE.MSG(ENQ.ARR)
            GOSUB FILTER.USER.GROUP
              
    END CASE

    OUT.ARR = ENQ.ARR

   
RETURN

FILTER.USER.GROUP:
******************

   OUT.ARRAY = ENQ.ARR
   ENQ.ARR = ''

    IF OUT.ARRAY THEN
       ARR.CNT = DCOUNT(OUT.ARRAY,FM)
        FOR I = 1 TO ARR.CNT
           Y.ENQ.DATA = OUT.ARRAY<I>
            Y.FT.NO = FIELD(Y.ENQ.DATA,"*",2)
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            IF R.POR.SUPPL.INFO.REC THEN
                LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                    Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                    IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                        ENQ.ARR<-1> = Y.ENQ.DATA
                    END
                END
            END
        NEXT I
    END

RETURN

END

