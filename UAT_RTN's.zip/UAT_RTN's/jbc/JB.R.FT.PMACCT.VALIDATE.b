SUBROUTINE JB.R.FT.PMACCT.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer           Reference           Description
* 05/04/2025        Ayush Kumar         CBPAY-2269          This is a new validation routine attached with version
*                                                           FUNDS.TRANSFER,JBWW.V.FT.OT60.INP to allow only Precious
*                                                           Metal's debit account
* 10/05/2025        Lakshmi Priya       CBPAY -2745         Included logic to call JB.R.PP.ACCTCURRDEFAULT.INP routine .
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.CURRENCY
    $INSERT I_F.FUNDS.TRANSFER

    CALL JB.R.PP.ACCTCURRDEFAULT.INP
    GOSUB INITILISATION
    GOSUB PROCESS

RETURN

*-------------
INITILISATION:
*-------------
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
    
    FN.CURRENCY = 'F.CURRENCY'
    F.CURRENCY = ''
    CALL OPF(FN.CURRENCY,F.CURRENCY)
    
    Y.AC.ID = COMI
    R.AC.REC = ''
    Y.AC.ERR = ''
    R.ALTACC.REC = ''
    Y.ALTACC.ERR = ''
    
    Y.CCY = ''
    R.CCY.REC = ''
    Y.CCY.ERR = ''
    Y.PMCCY.FLAG = ''
    
RETURN

*-------
PROCESS:
*-------
    
    IF NOT(NUM(Y.AC.ID)) THEN
        CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.AC.ID,R.ALTACC.REC,F.ALTERNATE.ACCOUNT,Y.ALTACC.ERR)
        IF R.ALTACC.REC THEN
            Y.AC.ID = R.ALTACC.REC<AAC.GLOBUS.ACCT.NUMBER>
        END
    END
        
    CALL F.READ(FN.ACCOUNT,Y.AC.ID,R.AC.REC,F.ACCOUNT,Y.AC.ERR)
    IF R.AC.REC THEN
        Y.CCY = R.AC.REC<AC.CURRENCY>
    END
    
    IF Y.CCY THEN
        CALL F.READ(FN.CURRENCY,Y.CCY,R.CCY.REC,F.CURRENCY,Y.CCY.ERR)
        IF R.CCY.REC THEN
            Y.PMCCY.FLAG = R.CCY.REC<EB.CUR.PRECIOUS.METAL>
        END
    END

    IF Y.PMCCY.FLAG NE 'YES' THEN
        AF = FT.DEBIT.ACCT.NO
        ETEXT = 'FT-JB.D.FT.INVALID.PMCCYACCT'
        CALL STORE.END.ERROR
    END
    
RETURN
END

