*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.REFUNDFEE.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*This routine added in the enquiry JBWW.E.SAFE.FEE.NAU & JBWW.E.ADV.FEE.NAU.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*
* Date              Developer                        Reference                     Description
*----------------------------------------------------------------------------------------------
* 20-Jun-2018       PuthumaiSamy                   JB2A Day15-597                 Change to be made in CSN enquiries, Input screens to have Business Keys used as Searchable criteria
* 
***********************************************************************************
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
	$INSERT I_F.FUNDS.TRANSFER
	
*-----------------------------------------------------------------------------
    
	GOSUB INIT
    GOSUB PROCESS

    RETURN
*-------------------------------------------------------------------	
INIT:
*****
	
	FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)

	Y.SEL.FIELD = ENQ.DATA<2>
	Y.SEL.OPRND = ENQ.DATA<3>
	Y.SEL.VALUE = ENQ.DATA<4>
	
	
  RETURN
*-------------------------------------------------------------------------------  
PROCESS:
********    
	
	LOCATE 'SAMCR.ID' IN Y.SEL.FIELD<1,1> SETTING SELSAM.POS THEN
	    
	    Y.SAM.ID = 	Y.SEL.VALUE<1,SELSAM.POS>
		CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
		IF R.SAM.ALT.REC THEN
			Y.SAMALT.DATA = R.SAM.ALT.REC
			Y.SAM.ID = FIELD(Y.SAMALT.DATA,'*',2)
		END
        ENQ.DATA<4,SELSAM.POS> = Y.SAM.ID	
		
	END
	
RETURN
*----------------------------------------------------------------------------
END