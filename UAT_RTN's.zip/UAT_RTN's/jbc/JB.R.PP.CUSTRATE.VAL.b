SUBROUTINE JB.R.PP.CUSTRATE.VAL
*-------------------------------------------------------------------------
* Attached: As validation routine for ORDERING.PAYMENT.TREASURY.RATE field
*-------------------------------------------------------------------------
* Input/Output: NA
*--------------
*
* Revision History:
*---------------------------------------------------------------------------------------------------------------------------------------------------
* Date           who                    Reference            Description
*05-06-2024     Hariharan T              CBPAY-81            This routine is to Null INDICATIVE.RATE field in PAYMENT.ORDER when ORDERING.PAYMENT.TREASURY.RATE is Null.
*
*****************************************************************************************************************************************************


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER

    GOSUB PROCESS
RETURN

*********
PROCESS:
********

    IF R.NEW(PO.INDICATIVE.RATE) EQ "" THEN
        COMI = ""
    END
RETURN

END
