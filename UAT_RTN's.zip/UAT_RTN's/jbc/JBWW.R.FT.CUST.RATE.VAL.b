SUBROUTINE JBWW.R.FT.CUST.RATE.VAL
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This routine is to Null CUSTOMER.RATE field in FUNDS.TRANSFER when TREASURY.RATE is Null.
*-------------------------------------------------------------------------
* Attached: As validation routine for CUSTOMER.RATE field
*-------------------------------------------------------------------------
* Input/Output: NA
*--------------
*
* Revision History:
*------------------
* Date               who                    Reference                 Description
* 10-05-2017       Balaji                   Payments                 Initial Version
***********************************************************************************


    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	
	GOSUB PROCESS
    RETURN

*********
PROCESS:
********
      
	    IF R.NEW(FT.TREASURY.RATE) EQ "" THEN
		  COMI = ""
		END
        RETURN

    END