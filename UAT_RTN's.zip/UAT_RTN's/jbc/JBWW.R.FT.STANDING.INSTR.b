*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.STANDING.INSTR(FINAL.ARRAY) 
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                        Reference               Description
*-----------------------------------------------------------------------------
* 25/07/2016    cognizant.com     PAYMENT interface           Initial Version

* 10/08/2017    Sushmitha.B       JB2A-38411                 For auto-populated the values in Beneficiary template
* 27/09/2017    PuthumaiSamy      JB2A-38411                 For auto-populated the values in Beneficiary template
* 30/11/2017    Parameshwari      JB2A_45605				 Displaying Ben Customer based on Description.
*-----------------------------------------------------------------------------
   
	$INSERT I_COMMON
   	$INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
	$INSERT I_F.JBWW.H.FT.STANDINGINSTR
*---------------------------------------------------

    	GOSUB INIT
	GOSUB PROCESS
	RETURN
	
******
INIT:
******
    
	FN.JBWW.H.FT.STANDINGINSTR = 'F.JBWW.H.FT.STANDINGINSTR'
        F.JBWW.H.FT.STANDINGINSTR= ""
        CALL OPF(FN.JBWW.H.FT.STANDINGINSTR,F.JBWW.H.FT.STANDINGINSTR)
*JB2A-38411  START
	Y.ID = ID.COMPANY
	FINAL.ARRAY=''
	Y.BEN.POS = ''
	LOCATE 'BEN.CUST.NO' IN D.FIELDS<1> SETTING Y.BEN.POS THEN
		Y.BEN.CUSTNO = D.RANGE.AND.VALUE<Y.BEN.POS>
		Y.SM.FLAG = DCOUNT(Y.BEN.CUSTNO,SM)
     		  IF Y.SM.FLAG THEN
		   CONVERT SM TO " " IN Y.BEN.CUSTNO
      		  END
***JB2A-38411 END
        END		
	RETURN  

*******
PROCESS:
*******  
   
	CALL F.READ(FN.JBWW.H.FT.STANDINGINSTR,Y.ID,R.STR,F.JBWW.H.FT.STANDINGINSTR,STR.ERR)
	Y.DESC = R.STR<JB.FT.STNG.DESCRIPTION>
	
	STRINT.POS = ''
	LOCATE Y.BEN.CUSTNO IN Y.DESC<1,1> SETTING STRINT.POS THEN
		Y.CREDIT.ACCNO = R.STR<JB.FT.STNG.CREDIT.ACCT.NO,STRINT.POS>
		Y.BEN.ACCT.NO = R.STR<JB.FT.STNG.BEN.ACCT.NO,STRINT.POS>
		Y.ACCT.WITH.BANK= R.STR<JB.FT.STNG.ACCT.WITH.BANK,STRINT.POS>
		Y.ACCT.WITH.BANK.ACC = R.STR<JB.FT.STNG.ACCT.WITH.BANK.ACC,STRINT.POS>
		BEN.LIST = R.STR<JB.FT.STNG.BEN.CUSTOMER,STRINT.POS>		;*Fix for JB2A_45605
		CHANGE SM TO VM IN BEN.LIST
		CHANGE SM TO VM IN Y.ACCT.WITH.BANK
		FINAL.ARRAY<-1> = Y.CREDIT.ACCNO:'*':Y.BEN.ACCT.NO:'*':Y.ACCT.WITH.BANK:'*':Y.ACCT.WITH.BANK.ACC:'*':BEN.LIST
	END
    RETURN
*-----------------------------------------------------------------------------

    END