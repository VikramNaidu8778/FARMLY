SUBROUTINE JB.R.PP.PONOSTROCASHFLOW.PSAHOOK(iStatusAction)
*--------------------------------------------------------------------------------------------------
* when the payment is authorized and Payment status reached to 677 or 999 or 19
* This routine is attached as hook routine in PP.PROGRAM.CHARACTERISTIC > JB.D.PP.NSTRCSHFLW to delete the cancat table.
* PP.STATUS.ACTION > '677.*' or '999.*' or 19.* or 993.* or 996.* or 997.* or 998.*
*--------------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------------
* Date          Developer          Reference           Description
*-----------------------------------------------------------------------------
*21-11-2024     P Amala            CBPAY-1262           Routine will delete the concat table JB.L.PP.CASHFLOWDATA.
*19/03/2025     P Amala            CBPAY-65             Fix to delete both Credit and Debit Account entry from the table JB.L.PP.CASHFLOWDATA.
*16/04/2025     P Amala            CBPAY-2507           Code has been modified to pick PO id from the field FileReferenceIncoming of PORT table.
*14/05/2025     P Amala            CBPAY-2687           Attached the hook routine in the following PPStatusAction 993.* or 996.* or 997.* or 998.*
*20/05/2025     P Amala            CBPAY-65             To remove the entry for camt.056 from the table JB.L.PP.CASHFLOWDATA.
*---------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.JB.L.PP.CASHFLOWDATA
    $INSERT I_F.CURRENCY
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.POSTING.AND.CONFIRMATION
    $USING PP.TRIPService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentSTPFlowService
    $USING PP.PaymentWorkflowGUI

*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB GET.REC.DETAILS

RETURN
*-----------------------------------------------------------------------------
INIT:
*----

    F.PAYMENT.ORDER = ''
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
	
    F.PP.ORDER.ENTRY = ''
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)

    F.POR.TRANSACTION = ''
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
    
    R.POR.TRANSACTION = '' ; rPorSuppInfo = '' ; FTNo = ''

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    FV.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, FV.POR.SUPPLEMENTARY.INFO)
   
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA, F.JB.L.PP.CASHFLOWDATA)
                
    Y.DB.AC.NO = '' ; Y.CR.AC.NO = '' ; Y.PP.ID = ''
    R.PAYMENT.ORDER = '' ; Y.CHANNEL = '' ; FTNo = ''
    R.POR.GET.SUPPLEMENTARY.INFO = '' ; Y.ORIG.TRANSREF = '' ; Y.CANC.MSGREF = ''

RETURN
*-----------------------------------------------------------------------------
GET.REC.DETAILS:
*---------------

    StatusCode = iStatusAction<PP.TRIPService.StatusAction.statusCode>
    PaymentRecord = iStatusAction<PP.TRIPService.StatusAction.paymentRecord> ;*To get the PAYMENT.ORDER record data
    iPaymentRecord = RAISE(PaymentRecord)

    FTNo = iPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ftNumber>

    CALL F.READ(FN.POR.TRANSACTION,FTNo,R.POR.TRANSACTION,F.POR.TRANSACTION,'')

    Y.DB.AC.NO = R.POR.TRANSACTION<PPPTX.DebitMainAccount>
    Y.CR.AC.NO = R.POR.TRANSACTION<PPPTX.CreditMainAccount>
    Y.PP.ID = R.POR.TRANSACTION<PPPTX.FileReferenceIncoming>
    Y.CHANNEL = R.POR.TRANSACTION<PPPTX.OutputChannel>
	
* Included the logic to delete the entry of Outward camt.056 from cashflow table.

	IF Y.PP.ID[1,2] NE 'PI' THEN
        Y.ORIG.TRANSREF = R.POR.TRANSACTION<PPPTX.MessageUserReference>
        CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.ORIG.TRANSREF,R.POR.SUPPL.INFO.REC,FV.POR.SUPPLEMENTARY.INFO,PORS.ERR)
        IF R.POR.SUPPL.INFO.REC THEN
            Y.CANC.MSGREF = R.POR.SUPPL.INFO.REC<PORID.CANCEL.MSG.REFERENCE>
            IF Y.CANC.MSGREF NE '' THEN
                Y.PP.ID = Y.CANC.MSGREF
            END
        END
    END

* Attached the hook routine in the following PPStatusAction 993.* or 996.* or 997.* or 998.*.Hence commented statuscode check logic.
*    BEGIN CASE
*        CASE Y.CHANNEL EQ 'NOSTRO' AND StatusCode EQ '677'
*            GOSUB CHECK.NOSTROCASHFLW
*        CASE StatusCode EQ '19'
*            GOSUB CHECK.NOSTROCASHFLW
*		CASE Y.CHANNEL NE 'NOSTRO' AND StatusCode EQ '999'
*            GOSUB CHECK.NOSTROCASHFLW
*    END CASE
    GOSUB CHECK.NOSTROCASHFLW

RETURN
*-----------------------------------------------------------------------------
CHECK.NOSTROCASHFLW:
*-------------------

    R.PP.NSTRCSHFLW = '' ; Y.NST.CSHFLW.ACCT = '' ; ERR.PP.NOSTROCASHFLOW = ''
    CALL F.READ(FN.JB.L.PP.CASHFLOWDATA,Y.DB.AC.NO,R.PP.NSTRCSHFLW,F.JB.L.PP.CASHFLOWDATA,ERR.PP.NOSTROCASHFLOW)
    IF R.PP.NSTRCSHFLW NE '' THEN
        Y.NST.CSHFLW.ACCT = Y.DB.AC.NO
        CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
    END

	R.PP.NSTRCSHFLW = '' ; Y.NST.CSHFLW.ACCT = '' ; ERR.PP.NOSTROCASHFLOW = ''
    CALL F.READ(FN.JB.L.PP.CASHFLOWDATA,Y.CR.AC.NO,R.PP.NSTRCSHFLW,F.JB.L.PP.CASHFLOWDATA,ERR.PP.NOSTROCASHFLOW)
    IF R.PP.NSTRCSHFLW NE '' THEN
        Y.NST.CSHFLW.ACCT = Y.CR.AC.NO
        CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
    END
  
RETURN
*-----------------------------------------------------------------------------

END
