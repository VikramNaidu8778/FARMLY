SUBROUTINE JB.R.AC.ALTACCT.CONV
*-----------------------------------------------------------------------------------------------------
* This is a conversion routine to retrieve BJB.ACCT for actual T24 account for display.
* Attached in ENQUIRY>JB.E.PP.ALTACCT.CONV
*
*-----------------------------------------------------------------------------------------------------
* Modification History:
*----------------------
*  Date        Resource                  JIRA Ref                     Remarks
* 03-05-2025   Prabhu D S                CBPAY-2641                   Initial version
*-----------------------------------------------------------------------------------------------------
  $INSERT I_COMMON
  $INSERT I_EQUATE
  $INSERT I_ENQUIRY.COMMON
  $INSERT I_F.ACCOUNT

  FN.ACCOUNT = "F.ACCOUNT"
  F.ACCOUNT = ""
  CALL OPF(FN.ACCOUNT,F.ACCOUNT)

  AC.ID = O.DATA
  CALL F.READ(FN.ACCOUNT, AC.ID, R.ACCT, F.ACCOUNT, AC.ERR)
  IF R.ACCT THEN
   ALT.ACCT.TYPES = R.ACCT<AC.ALT.ACCT.TYPE>
   LOCATE "BJB.ACCT" IN ALT.ACCT.TYPES<1,1> SETTING ALT.POS THEN
      O.DATA = R.ACCT<AC.ALT.ACCT.ID,ALT.POS>
   END ELSE
      O.DATA = ""
   END
  END ELSE
   O.DATA = ""
  END

RETURN
END
  
