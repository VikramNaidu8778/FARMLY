*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.ALTACCT.CONV
*-----------------------------------------------------------------------------
* This is a copy of existing routuine JBWW.R.AC.ALTACCT.CONV. Modified to send
* Alternate Account only if found.
*-----------------------------------------------------------------------------
* Modification History :
*------------------------
** Date          Developer              Reference       Description
* 17-Mar-2025    Prabhu D S             CBPAY-2210      Initial draft
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
	$INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

      GOSUB INIT
	  GOSUB PROCESS
	  
RETURN
*
*-----------------------------------------------------------------
INIT:
*****

	Y.ACCT.ID = ''
	Y.STO.ACCT = ''
	Y.FT.ACCT = ''
   
	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
	F.ACCOUNT.HIS = ''
	CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)
	
RETURN
*
*--------------------------------------------------------------------------
PROCESS:
********

	Y.FT.ACCT = O.DATA
	Y.STO.ACCT = FIELD(Y.FT.ACCT,'.',1)
   
	IF Y.STO.ACCT THEN
		Y.ACCT.ID = Y.STO.ACCT
	END ELSE
		Y.ACCT.ID = Y.FT.ACCT
	END
	
	R.ACCT.REC = ''
	ACCT.ERR = ''
	CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCT.REC,F.ACCOUNT,ACCT.ERR)
	
	IF NOT(R.ACCT.REC) THEN ;* If Account Closed	
		CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACCT.ID,R.ACCT.HIST,ACCT.HERR)
		ALT.ACCT.TYPE = R.ACCT.HIST<AC.ALT.ACCT.TYPE>
		ALT.ACCT.IDS = R.ACCT.HIST<AC.ALT.ACCT.ID>
	END ELSE	
		ALT.ACCT.TYPE = R.ACCT.REC<AC.ALT.ACCT.TYPE>
		ALT.ACCT.IDS = R.ACCT.REC<AC.ALT.ACCT.ID>
	END
	
	LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
		    Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
                    IF Y.AC.ALT.ID THEN O.DATA = Y.AC.ALT.ID
	END
	 	 	
RETURN
*--------------------------------------------------------------------------
END
