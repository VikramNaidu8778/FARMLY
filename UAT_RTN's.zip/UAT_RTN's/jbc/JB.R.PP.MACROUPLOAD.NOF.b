* @ValidationCode : MjotMTA1NDEzMDI3MTpDcDEyNTI6MTc1MDA2ODI3Njk1MDp1MXA5NDI6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjRfQU1SLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 16 Jun 2025 18:04:36
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : u1p942
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R24_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2025. All rights reserved.
*------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.MACROUPLOAD.NOF(OUT.ARRAY)
*------------------------------------------------------------------------------------
* Description:
*------------------------------------------------------------------------------------
* This is a no-file enquiry routine which will fetch the Live & Inau records
* from the application PAYMENT.ORDER & PP.ORDER.ENTRY
* This routine is attached enquiry JB.E.PP.MACRO200.STATUS & JB.E.PP.MACRO202.STATUS
*------------------------------------------------------------------------------------
* Attached: NA
*------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY(Result Array)
* Dependencies:
*---------------
* NA
* Revision History:
*------------------
* 04/06/2025            Raghunandan              CBPAY-3087              Initial Version
*
* 14/06/2025            Vikram Pavuluru          CBPAY-3006              Mapped File upload status against PO/OE record status
*                                                                        If the REC.STATUS is IHLD then FAILURE, If REC.STATUS is INAU then SUCCESS
*-----------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JB.XX.FILEUPLD.DASHBOARD

    GOSUB INIT
    GOSUB PROCESS

RETURN
*****
INIT:
*****
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)
    
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)
    
    FN.PP.ORDER.ENTRY.NAU = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY.NAU = ''
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,F.PP.ORDER.ENTRY.NAU)
    
    FN.JB.XX.FILEUPLD.DASHBOARD = 'F.JB.XX.FILEUPLD.DASHBOARD'
    F.JB.XX.FILEUPLD.DASHBOARD = ''
    CALL OPF(FN.JB.XX.FILEUPLD.DASHBOARD,F.JB.XX.FILEUPLD.DASHBOARD)
    
    APPL = 'PP.ORDER.ENTRY':FM:'PAYMENT.ORDER'
    LREF.FLD = 'L.FT.FILEUPD.ID':FM:'L.FT.FILEUPD.ID'
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
    Y.L.PPOE.FILEUPD.ID.POS = Y.POS<1,1>
    Y.L.PO.FILEUPD.ID.POS = Y.POS<2,1>

    Y.ENQ.NAME = ENQ.SELECTION<1>
    LOCATE "Upload Id" IN D.FIELDS<1> SETTING ID.POS THEN
        Y.UPLOAD.ID = D.RANGE.AND.VALUE<ID.POS>
    END

RETURN

*********
PROCESS:
*********
    BEGIN CASE
        CASE Y.ENQ.NAME EQ 'JB.E.PP.MACRO200.STATUS'
            GOSUB SELECT.PP.ORDER.ENTRY
        CASE Y.ENQ.NAME EQ 'JB.E.PP.MACRO202.STATUS'
            GOSUB SELECT.PAYMENT.ORDER
    END CASE

RETURN
**********************
SELECT.PP.ORDER.ENTRY:
**********************
    Y.SELECT.PP.OE.CMD.LIVE = "SELECT ":FN.PP.ORDER.ENTRY:" WITH L.FT.FILEUPD.ID NE ''"
    IF Y.UPLOAD.ID NE '' THEN
        Y.SELECT.PP.OE.CMD.LIVE = ''
        Y.SELECT.PP.OE.CMD.LIVE = "SELECT ":FN.PP.ORDER.ENTRY:" WITH L.FT.FILEUPD.ID LIKE ":Y.UPLOAD.ID:"..."
    END
    CALL EB.READLIST(Y.SELECT.PP.OE.CMD.LIVE,Y.SEL.LIST1,'',Y.SEL.CNT1,'')
    
    
    Y.SELECT.PP.OE.CMD.NAU = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH L.FT.FILEUPD.ID NE ''"
    IF Y.UPLOAD.ID NE '' THEN
        Y.SELECT.PP.OE.CMD.NAU = ''
        Y.SELECT.PP.OE.CMD.NAU = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH L.FT.FILEUPD.ID LIKE ":Y.UPLOAD.ID:"..."
    END
    CALL EB.READLIST(Y.SELECT.PP.OE.CMD.NAU,Y.SEL.LIST2,'',Y.SEL.CNT2,'')
    
    Y.PP.OE.LIST = ''
    Y.FILE.UPLOAD.STATUS = ''
    BEGIN CASE
        CASE Y.SEL.LIST1 NE '' AND Y.SEL.LIST2 NE ''
            Y.PP.OE.LIST = Y.SEL.LIST1:FM:Y.SEL.LIST2
        CASE Y.SEL.LIST1 EQ ''
            Y.PP.OE.LIST = Y.SEL.LIST2
        CASE Y.SEL.LIST2 EQ ''
            Y.PP.OE.LIST = Y.SEL.LIST1
    END CASE
    
    LOOP
        REMOVE Y.PP.OE.ID FROM Y.PP.OE.LIST SETTING Y.PP.OE.POS
    WHILE Y.PP.OE.ID:Y.PP.OE.POS
        Y.TXN.ID = Y.PP.OE.ID
        Y.FILEUPD.ID = ''
        CALL F.READ(FN.PP.ORDER.ENTRY,Y.PP.OE.ID,R.PP.OE.REC,F.PP.ORDER.ENTRY,PP.OE.ERR)
        IF R.PP.OE.REC NE '' THEN
            Y.FILEUPD.ID = R.PP.OE.REC<PP.OEYG.LOCAL.REF,Y.L.PPOE.FILEUPD.ID.POS>
            GOSUB READ.FILEUPLD.DASHBOARD
        END ELSE
            CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.PP.OE.ID,R.PP.OE.REC.NAU,F.PP.ORDER.ENTRY.NAU,PP.OE.ERR.NAU)
            Y.FILEUPD.ID = R.PP.OE.REC.NAU<PP.OEYG.LOCAL.REF,Y.L.PPOE.FILEUPD.ID.POS>
*If the Y.REC.STATUS is 'IHLD' then FAILURE, If Y.REC.STATUS is 'INAU' then SUCCESS
            Y.REC.STATUS = R.PP.OE.REC.NAU<PP.OEYG.RECORD.STATUS>
            IF Y.REC.STATUS EQ 'INAU' THEN
                Y.FILE.UPLOAD.STATUS = 'SUCCESS'
            END ELSE
                IF Y.REC.STATUS EQ 'IHLD' THEN
                    Y.FILE.UPLOAD.STATUS = 'FAILURE'
                END
            END
            GOSUB READ.FILEUPLD.DASHBOARD
        END
        
        GOSUB FORM.ARRAY
    REPEAT
    
RETURN
*********************
SELECT.PAYMENT.ORDER:
*********************
    Y.SELECT.PO.LIVE = "SELECT ":FN.PAYMENT.ORDER:" WITH L.FT.FILEUPD.ID NE ''"
    IF Y.UPLOAD.ID NE '' THEN
        Y.SELECT.PO.LIVE = ''
        Y.SELECT.PO.LIVE = "SELECT ":FN.PAYMENT.ORDER:" WITH L.FT.FILEUPD.ID LIKE ":Y.UPLOAD.ID:"..."
    END
    CALL EB.READLIST(Y.SELECT.PO.LIVE,Y.SEL.LIST3,'',Y.SEL.CNT3,'')
    
    Y.SELECT.PO.NAU = "SELECT ":FN.PAYMENT.ORDER.NAU:" WITH L.FT.FILEUPD.ID NE ''"
    IF Y.UPLOAD.ID NE '' THEN
        Y.SELECT.PO.NAU = ''
        Y.SELECT.PO.NAU = "SELECT ":FN.PAYMENT.ORDER.NAU:" WITH L.FT.FILEUPD.ID LIKE ":Y.UPLOAD.ID:"..."
    END
    CALL EB.READLIST(Y.SELECT.PO.NAU,Y.SEL.LIST4,'',Y.SEL.CNT4,'')
    
    Y.PO.LIST = ''
    Y.FILE.UPLOAD.STATUS = ''
    BEGIN CASE
        CASE Y.SEL.LIST3 NE '' AND Y.SEL.LIST4 NE ''
            Y.PO.LIST = Y.SEL.LIST3:FM:Y.SEL.LIST4
        CASE Y.SEL.LIST3 EQ ''
            Y.PO.LIST = Y.SEL.LIST4
        CASE Y.SEL.LIST4 EQ ''
            Y.PO.LIST = Y.SEL.LIST3
    END CASE
    
    LOOP
        REMOVE Y.PO.ID FROM Y.PO.LIST SETTING Y.PO.POS
    WHILE Y.PO.ID:Y.PO.POS
        Y.TXN.ID = Y.PO.ID
        Y.FILEUPD.ID = ''
        CALL F.READ(FN.PAYMENT.ORDER,Y.PO.ID,R.PO.REC,F.PAYMENT.ORDER,PO.ERR)
        IF R.PO.REC NE '' THEN
            Y.FILEUPD.ID = R.PO.REC<PO.LOCAL.REF,Y.L.PO.FILEUPD.ID.POS>
            GOSUB READ.FILEUPLD.DASHBOARD
        END ELSE
            CALL F.READ(FN.PAYMENT.ORDER.NAU,Y.PO.ID,R.PO.REC.NAU,F.PAYMENT.ORDER.NAU,PO.ERR.NAU)
            Y.FILEUPD.ID = R.PO.REC.NAU<PO.LOCAL.REF,Y.L.PO.FILEUPD.ID.POS>
*If the Y.REC.STATUS is 'IHLD' then FAILURE, If Y.REC.STATUS is 'INAU' then SUCCESS
            Y.REC.STATUS = R.PO.REC.NAU<PO.RECORD.STATUS>
            IF Y.REC.STATUS EQ 'INAU' THEN
                Y.FILE.UPLOAD.STATUS = 'SUCCESS'
            END ELSE
                IF Y.REC.STATUS EQ 'IHLD' THEN
                    Y.FILE.UPLOAD.STATUS = 'FAILURE'
                END
            END
            GOSUB READ.FILEUPLD.DASHBOARD
        END
        
        GOSUB FORM.ARRAY
    REPEAT
    
RETURN

************************
READ.FILEUPLD.DASHBOARD:
************************
    Y.FILEUPLD.DASHBOARD.ID = ''
*Y.FILE.UPLOAD.STATUS = ''
    Y.FAILED.TXN = ''
    Y.ERROR.MSG = ''
    
    Y.FILEUPLD.DASHBOARD.ID = FIELD(Y.FILEUPD.ID,'-',1)
    CALL F.READ(FN.JB.XX.FILEUPLD.DASHBOARD,Y.FILEUPLD.DASHBOARD.ID,R.FILEUPLD.DASHBOARD,F.JB.XX.FILEUPLD.DASHBOARD,DASH.ERR)
    
    IF R.FILEUPLD.DASHBOARD THEN
*Y.FILE.UPLOAD.STATUS = R.FILEUPLD.DASHBOARD<JB.XX.FILE.UPLD.STATUS>
        Y.FAILED.TXN = R.FILEUPLD.DASHBOARD<JB.XX.FAILED.TXN>
        LOCATE Y.TXN.ID IN Y.FAILED.TXN<1,1> SETTING TXN.POS THEN
            IF Y.REC.STATUS EQ 'IHLD' THEN
                Y.ERROR.MSG = R.FILEUPLD.DASHBOARD<JB.XX.ERROR.MSG,TXN.POS>
            END
        END
    END

RETURN

***********
FORM.ARRAY:
***********

    OUT.ARRAY<-1> = Y.FILEUPLD.DASHBOARD.ID:'*':Y.FILEUPD.ID:'*':Y.TXN.ID:'*':Y.FILE.UPLOAD.STATUS:'*':Y.ERROR.MSG
    
RETURN
*******************************************************************************************************
END
