* @ValidationCode : MTotMTE0NzQ5MjI5NzpVVEYtODoxNTI4ODEyNTg3OTU2OjIzMzE2MzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 18 April 2024 19:39:47
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PORLCTCA.INPUT
*------------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing FT Version control Routine JBWW.R.FT.RLCTCA.INPUT and incorporated with TPH Payment order application Logic.
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*------------------------------------------------------------------------------------------------------------------------------------------------------
* 18/04/2024      Amala P                      CBPAY-302                       Capture of TCA and EB.GC.CONSTRAINTS soft Blocks and updating application local fields
*                                                                              and updating TCA hard BlocKs to JBWW.H.XX.SOFTBLOCK table
*
* 27/02/2025      Amala P                      CBPAY-1841                      Facing overrride with IHLD status When transaction amount is null/zero.
* 17/03/2025      Prabhu D S                   CBPAY-1790                      Only Debit Amount should be sent to TCA and not with Charges. So removed
*                                                                              case where considering PO.TOTAL.DEBIT.AMOUNT
* 15/04/2025      Amala P                      CBPAY-1402                      Facing overrride with IHLD status When Debit amount is null/zero.
*------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.OVERRIDE
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.JBWW.H.XX.MABPCOND
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.GC.CONSTRAINTS
    $INSERT I_GTS.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_System
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.JBWW.L.XX.RLCSOFTBLOCK.LOG
    $INSERT I_F.JBWW.L.XX.SOFTBLOCK.DETS
    $INSERT I_GTS.COMMON
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.COMPANY
    $INSERT I_F.PAYMENT.ORDER
* ACSL type is not in scope for TPH
*	IF R.NEW(FT.TRANSACTION.TYPE) EQ 'ACSL' AND PGM.VERSION EQ ',JBWW.V.FT.UPD' THEN RETURN ;* SLBA-6485 - No RLC block validation if FT posting by SLB version with txn type is ACSL
	

    IF V$FUNCTION EQ 'D' OR V$FUNCTION EQ 'R' THEN
*T24-14666-start
        GOSUB INITIALISE
        Y.BLOCK.ID = ID.NEW
        GOSUB READ.SOFT.BLOCK
        IF R.BLOCKS AND Y.OVERALL.STATUS EQ '' THEN
            GOSUB DEL.PREVIOUS.VALUES
            CALL F.DELETE(FN.JBWW.H.XX.SOFTBLOCK,Y.BLOCK.ID)
        END
        RETURN
    END
    IF V$FUNCTION EQ 'I' OR V$FUNCTION EQ 'C' AND ID.OLD EQ '' THEN
        GOSUB INITIALISE
        GOSUB CHECK.HARD.BLOCK.EXISTS
        IF Y.FT.MAKER.CHECK EQ 'MAKER' THEN RETURN
        IF Y.FT.MAKER.CHECK EQ 'CHECKER' THEN RETURN
        IF  Y.TC.DONE[1,1] EQ 'Y' THEN
            GOSUB PROCESS.DATA.NON.JAVA.CALL
        END ELSE
            GOSUB CUSTOMER.CLIENT.CONDITION
            IF NOT(Y.SEC.FLAG) THEN
                Y.PARAM.ID = 'BUYING.POWER'
                GOSUB BUYING.POWER.MARKET.CONDITION
                Y.PARAM.ID = 'MARKET.AUTHORITY'
                GOSUB BUYING.POWER.MARKET.CONDITION
                IF NOT(Y.BUYING.POWER.FAILED)  OR  NOT(Y.MARKET.CHECK.FAILED) THEN
                    GOSUB PROCESS
                    IF R.HARD.BLOCKS NE '' THEN
                        GOSUB UPDATE.HARD.BLOCKS.TABLE
                    END
                    IF R.SOFT.BLOCKS NE '' AND R.HARD.BLOCKS EQ '' THEN
                        GOSUB RAISE.NO.OF.AUTH
                    END
                END
            END
        END
        GOSUB FETCH.PORTFOLIO.DETAILS
        GOSUB PROCESS.GENERIC.OVERRIDES
        GOSUB PROCESS.EB.GC.CONSTRAINT
    END


RETURN
*-----------------------------------------------------------------------------

DELETE.BLOCKS.EXIST:
*******************
    R.SOFT.BLOCKS = ''
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW,R.SOFT.BLOCKS,F.JBWW.H.XX.SOFTBLOCK,'')
    Y.REJ.STATUS = R.SOFT.BLOCKS<JHXS.OVERALL.STATUS>
    IF R.SOFT.BLOCKS NE '' AND Y.REJ.STATUS NE 'REJECT' THEN
        CALL F.DELETE(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW)
    END
RETURN
INITIALISE:
*****************
    F.SC.INC.ACCOUNT = ''
    FN.SC.INC.ACCOUNT = 'F.SC.INC.ACCOUNT'
    CALL OPF(FN.SC.INC.ACCOUNT,F.SC.INC.ACCOUNT)

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.JBWW.L.XX.SOFTBLOCK.DETS = ''
    FN.JBWW.L.XX.SOFTBLOCK.DETS = 'F.JBWW.L.XX.SOFTBLOCK.DETS'
    CALL OPF(FN.JBWW.L.XX.SOFTBLOCK.DETS,F.JBWW.L.XX.SOFTBLOCK.DETS)

    F.JBWW.L.XX.RLCSOFTBLOCK.LOG = ''
    FN.JBWW.L.XX.RLCSOFTBLOCK.LOG = 'F.JBWW.L.XX.RLCSOFTBLOCK.LOG'
    CALL OPF(FN.JBWW.L.XX.RLCSOFTBLOCK.LOG,F.JBWW.L.XX.RLCSOFTBLOCK.LOG)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.EB.GC.CONSTRAINTS = ''
    FN.EB.GC.CONSTRAINTS = 'F.EB.GC.CONSTRAINTS'
    CALL OPF(FN.EB.GC.CONSTRAINTS,F.EB.GC.CONSTRAINTS)

    F.PAYMENT.ORDER = ''
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    F.JBWW.H.XX.SOFTBLOCK = ''
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    F.JBWW.H.EB.GENERICPARAMETER = ''
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    F.SECURITY.MASTER = ''
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)

    F.CUSTOMER = ''
    FN.CUSTOMER = 'F.CUSTOMER'
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    F.OVERRIDE = ''
    FN.OVERRIDE = 'F.OVERRIDE'
    CALL OPF(FN.OVERRIDE,F.OVERRIDE)
	
    APPL = 'PAYMENT.ORDER':FM:'OVERRIDE':FM:'SEC.ACC.MASTER'

    LREF.FLD = 'L.XX.BLK.MSG':VM:'L.XX.BLK.CODE':VM:'L.XX.BLK.CATEG':VM:'L.XX.BLK.TYPE':VM:'L.XX.DONE.DEAL':VM:'L.XX.TC.DONE':VM:'L.FT.VALDT.CHKD':VM:'L.XX.RLCBLK.REQ':FM:'L.ST.BLK.APRVR':FM:'L.XX.TAG.BLK.ID'
    Y.POS = ''
    Y.TC.DONE.POS = ''
    Y.BLK.CATEG.POS = ''
    Y.BLK.TYPE.POS = ''
    Y.BLK.CODE.POS = ''
    Y.BLK.MSG.POS = ''
    Y.BLK.APR.POS = ''
    Y.DONE.DEAL.POS = ''
    Y.L.FT.VALDT.CHKD.POS = ''
    Y.TAG.BLK.POS = ''
    Y.RLC.BLK.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)

    Y.BLK.MSG.POS = Y.POS<1,1>
    Y.BLK.CODE.POS = Y.POS<1,2>
    Y.BLK.CATEG.POS = Y.POS<1,3>
    Y.BLK.TYPE.POS  = Y.POS<1,4>
    Y.DONE.DEAL.POS = Y.POS<1,5>
    Y.TC.DONE.POS = Y.POS<1,6>
    Y.L.FT.VALDT.CHKD.POS = Y.POS<1,7>
    Y.RLC.BLK.POS = Y.POS<1,8>
    Y.BLK.APR.POS = Y.POS<2,1>
    Y.TAG.BLK.POS = Y.POS<3,1>

    Y.CU.CLINET.ID = 'CUSTOMER.CLIENT'
    Y.BUY.POWER.ID = 'BUYING.POWER'
    Y.MARKET.ID = 'MARKET.AUTHORITY'

    Y.SEC.FLAG = ''
    Y.DONE.DEAL = R.NEW(PO.LOCAL.REF)<1,Y.DONE.DEAL.POS>
    X = OCONV(DATE(),'D4-')
    TIME.STAMP = TIMEDATE()
    DATE.TIME = X[9,2]:X[1,2]:X[4,2]:TIME.STAMP[1,2]:TIME.STAMP[4,2]

    Y.TC.DONE = R.NEW(PO.LOCAL.REF)<1,Y.TC.DONE.POS>
    Y.NO.OF.AUTH = R.VERSION(EB.VER.NO.OF.AUTH)

    Y.PARAM.ID = 'RL160.TCA.ERROR.HANDLING'
    GOSUB READ.GEN.TABLE
    R.TCA.PARAM = R.GEN.PARAM

    Y.PGM.VER = PGM.VERSION

    Y.FT.MAKER.CHECK = R.NEW(PP.LOCAL.REF)<1,Y.L.FT.VALDT.CHKD.POS>
    Y.SRC = '' ; Y.INWARD.PAY.TYPE = ''
		
    Y.INWARD.PAY.TYPE = R.NEW(PO.ORDER.INITIATION.TYPE)
	IF Y.INWARD.PAY.TYPE EQ 'Po From Sto' THEN
        Y.INWARD.PAY.TYPE = 'STO'
	END
    IF OFS$SOURCE.ID EQ 'PMT.ORDER.HLD' THEN
        Y.SRC = 'OFS'
    END
    Y.FIN.ID = '' ; Y.DEBIT.VALDATE = ''
	
	BEGIN CASE
        CASE R.NEW(PO.DEBIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.DEBIT.VALUE.DATE)
	    CASE R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE)
		CASE R.NEW(PO.CREDIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.CREDIT.VALUE.DATE)
	END CASE
	
RETURN


CUSTOMER.CLIENT.CONDITION:
********************
    Y.SOO.CUSTOMER = ''
    Y.SOO.CUSTOMER =  R.NEW(PO.ORDERING.CUSTOMER)
    Y.PARAM.ID = Y.CU.CLINET.ID
    GOSUB READ.GEN.TABLE

    IF R.GEN.PARAM NE '' THEN

        Y.CLIENT.ID = R.NEW(PO.ORDERING.CUSTOMER)
        Y.CUSTOMER.ID = Y.CLIENT.ID
        GOSUB READ.CUSTOMER
        Y.SECTOR = R.CUS<EB.CUS.SECTOR>
        Y.SEC.VALUES = ''
        Y.SEC.VALUES = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE>

        CONVERT SM TO VM IN Y.SEC.VALUES
        CONVERT VM TO FM IN Y.SEC.VALUES
        Y.SEC.POS = ''

        LOCATE Y.SECTOR IN Y.SEC.VALUES SETTING Y.SEC.POS ELSE Y.SEC.POS = ''
        IF Y.SEC.POS EQ '' THEN
            Y.SEC.FLAG = '1'
        END

    END
    IF Y.SEC.POS EQ '' THEN
        Y.SEC.FLAG = '1'
    END
RETURN

BUYING.POWER.MARKET.CONDITION:
****************************

    CRDT.CUSTOMER = '' ; DBT.CUSTOMER = ''
    Y.CR.ACCT.NO = R.NEW(PO.CREDIT.ACCOUNT)  ; * Credit account is not available for Outward payment and applicable only fo book payment.
    Y.ACCT.NO = Y.CR.ACCT.NO
    GOSUB READ.AC
	CRDT.CUSTOMER = R.AC<AC.CUSTOMER>
    DBT.CUSTOMER =  R.NEW(PO.ORDERING.CUSTOMER)
	
    IF DBT.CUSTOMER EQ CRDT.CUSTOMER THEN
        Y.BUYING.POWER.FAILED = '1'
        RETURN
    END

    Y.PARAM.FLD.NAME = ''

    Y.TR.CODE = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    GOSUB READ.GEN.TABLE

    IF R.GEN.PARAM NE '' THEN
        Y.PARAM.FLD.NAME = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        CONVERT VM TO FM IN Y.PARAM.FLD.NAME
        Y.TRX.CODE.POS = ''
        FIND 'trxCode' IN Y.PARAM.FLD.NAME SETTING Y.TRX.CODE.POS ELSE Y.TRX.CODE.POS = ''

        IF Y.TR.CODE NE '' THEN
            Y.TRN.CODES = ''
            Y.TRN.CODES =  R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.TRX.CODE.POS>
            CONVERT SM TO VM IN Y.TRN.CODES
            CONVERT VM TO FM IN Y.TRN.CODES


            LOCATE Y.TR.CODE IN Y.TRN.CODES SETTING Y.TRN.CODE.POS ELSE Y.TRN.CODE.POS = ''

        END

    END

    IF Y.PARAM.ID EQ 'BUYING.POWER' THEN
        IF Y.TRN.CODE.POS EQ ''  THEN
            Y.BUYING.POWER.FAILED = '1'
        END ELSE
            Y.BUYING.POWER.PASS = '1'
        END
    END

    IF Y.PARAM.ID EQ Y.MARKET.ID THEN
        IF Y.TRN.CODE.POS EQ ''  THEN
            Y.MARKET.CHECK.FAILED = '1'
        END ELSE
            Y.MARKET.CHECK.PASS = '1'
        END
    END
CHECK.HARD.BLOCK.EXISTS:
***********************
    IF R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS,1> EQ 'HB' THEN

        R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS,1> = ''
        R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS,1> = ''
        R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,1> = ''
        R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS,1> = ''
    END

RETURN

READ.GEN.TABLE:
********************
    R.GEN.PARAM = ''
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.PARAM.ID,R.GEN.PARAM,F.JBWW.H.EB.GENERICPARAMETER,'')

RETURN

READ.SECURITY.MASTER:
*************************
    CALL F.READ(FN.SECURITY.MASTER,Y.SECURITY.NO,R.SECURITY.MASTER,F.SECURITY.MASTER,'')

RETURN


PROCESS:
*****************
    Y.TC.DONE = R.NEW(PO.LOCAL.REF)<1,Y.TC.DONE.POS>
    IF  Y.TC.DONE[1,1] NE 'Y' THEN
        GOSUB FORM.DATA.TO.CALL.JAVA
    END

RETURN
FORM.DATA.TO.CALL.JAVA:
*********************
 
    GOSUB FETCH.PORTFOLIO.DETAILS
    GOSUB FETCH.CUSTOMER.DETAILS
    Y.PAY.AMT = ''
	GOSUB GET.PAYMENT.AMOUNT
    Y.SET.CCY = R.NEW(PO.DEBIT.CCY)
    CONVERT VM TO '|' IN Y.SET.CCY
    Y.REF.NUM = ID.NEW
    Y.NOMINAL = ''
    Y.TODAY = TODAY
    Y.TIME = OCONV(TIME(),"MTS")
    Y.TIME.STAMP = Y.TODAY[1,4]:'-':Y.TODAY[5,2]:'-':Y.TODAY[7,2]:'T':Y.TIME
    Y.CATEGORY = '9990'
    Y.CO.CODE = ID.COMPANY
    Y.CO.CODE = Y.CO.CODE[1,2]

    GOSUB GET.PARAM.DATA
    GOSUB CALL.JAVA.WEB.SERVICE
    GOSUB EXTRACT.CALJ.DETAILS
    GOSUB DISPLAY.ERROR.OVERRIDE.ON.SCREEN
    GOSUB MA.CC.CALL.FAIL

RETURN

MA.CC.CALL.FAIL:
***************
    Y.FLD.NAME = R.TCA.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    CHANGE VM TO FM IN Y.FLD.NAME

    IF OUT.REPONSE[1,9] MATCHES 'ErrorCode' THEN
        Y.ERROR = OUT.REPONSE[1,13]
        Y.ERROR.CODE = FIELD(Y.ERROR,'=',2)

        Y.ERR.CODE.POS = ''
        Y.TCA.DOWN = 'TCA.DOWN.ERROR':'-':Y.ERROR.CODE
        FIND Y.TCA.DOWN IN Y.FLD.NAME SETTING Y.ERR.CODE.POS ELSE Y.ERR.CODE.POS = ''

        BEGIN CASE
            CASE Y.ERR.CODE.POS NE ''
                Y.TCA.VALUE = R.TCA.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.ERR.CODE.POS,1>
                IF Y.TCA.VALUE EQ 'OVERRIDE' THEN
                    Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                    Y.OVE.CNT += 1
                    TEXT = 'EB-JBWW.D.XX.RLCTCA.TCADOWN'
                    CALL STORE.OVERRIDE(Y.OVE.CNT)
                END
                IF Y.TCA.VALUE EQ 'ERROR' THEN
                    AF = '0'
                    ETEXT = 'EB-JBWW.D.XX.RLCTCA.TCADOWN'
                    CALL STORE.END.ERROR
                END


            CASE Y.ERR.CODE.POS EQ ''
                Y.TECH.ERR.POS = ''
                FIND 'TECHNICAL.ERROR' IN Y.FLD.NAME SETTING Y.TECH.ERR.POS ELSE Y.TECH.ERR.POS = ''
                Y.TCA.VALUE = R.TCA.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.TECH.ERR.POS,1>
                IF Y.TCA.VALUE EQ 'OVERRIDE' THEN
                    Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                    Y.OVE.CNT += 1
                    TEXT = 'EB-JBWW.D.XX.RLCTCA.TECHERROR'
                    CALL STORE.OVERRIDE(Y.OVE.CNT)
                END
                IF Y.TCA.VALUE EQ 'ERROR' THEN
                    AF = '0'
                    ETEXT = 'EB-JBWW.D.XX.RLCTCA.TECHERROR'
                    CALL STORE.END.ERROR
                END

        END CASE
    END

RETURN

RAISE.CALJ.ERROR.IF.EXISTS:
*************************************
    Y.FLD.NAME = R.TCA.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    CHANGE VM TO FM IN Y.FLD.NAME
    Y.CHECK.POS = ''
    FIND Y.CHECK.TYPE IN Y.FLD.NAME SETTING Y.CHECK.POS ELSE Y.CHECK.POS = ''
    Y.TCA.VALUE = R.TCA.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.CHECK.POS,1>

    BEGIN CASE

        CASE Y.CHECK.TYPE MATCHES 'MA'
            IF Y.TCA.VALUE EQ 'OVERRIDE' THEN
                Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                Y.OVE.CNT += 1
                TEXT = 'EB-JBWW.D.XX.RLCTCA.MAERROR'
                CALL STORE.OVERRIDE(Y.OVE.CNT)
            END
            IF Y.TCA.VALUE EQ 'ERROR' THEN
                AF = '0'
                ETEXT = 'EB-JBWW.D.XX.RLCTCA.MAERROR'
                CALL STORE.END.ERROR
            END


        CASE Y.CHECK.TYPE MATCHES 'CC'
            IF Y.TCA.VALUE EQ 'OVERRIDE' THEN
                Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                Y.OVE.CNT += 1
                TEXT = 'EB-JBWW.D.XX.RLCTCA.CCERROR'
                CALL STORE.OVERRIDE(Y.OVE.CNT)
            END
            IF Y.TCA.VALUE EQ 'ERROR' THEN
                AF = '0'
                ETEXT = 'EB-JBWW.D.XX.RLCTCA.CCERROR'
                CALL STORE.END.ERROR
            END
    END CASE
RETURN


GET.PARAM.DATA:
******************

    param = ''
    param = "clientNbr=":Y.CLIENT:'^':"portfolioNbr=":R.SAM:'^':"trxAmount=":Y.PAY.AMT:'^':"id=":Y.FIN.ID:'^':"type=JB_INST_ID":'^':"trxTimestamp=":Y.TIME.STAMP:'^':"reversal=false":'^':
    param := "referenceNbr=":Y.REF.NUM:'^':"quantity=":Y.NOMINAL:'^':"category=":Y.CATEGORY:'^':"trxType=":Y.TR.CODE:'^':"targetEntityId=":Y.CO.CODE:'^':

RETURN

PROCESS.DATA.NON.JAVA.CALL:
***************************

    Y.CHECK.TYPES = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS>
    Y.RESPONSE.CATEGORY = R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS>
    Y.MSG.IDS = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS>
    Y.MSG.VALUES = R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS>

    CHANGE SM TO FM IN Y.CHECK.TYPES
    CHANGE SM TO FM IN Y.RESPONSE.CATEGORY
    CHANGE SM TO FM IN Y.MSG.IDS
    CHANGE SM TO FM IN Y.MSG.VALUES

    IF Y.RESPONSE.CATEGORY EQ '' THEN RETURN
    Y.RESPONSE.CATEGORY.CNT = DCOUNT(Y.RESPONSE.CATEGORY,FM)

    I = 0

    LOOP

        I = I + 1

    WHILE I LE Y.RESPONSE.CATEGORY.CNT
        Y.CHECK.TYPE = Y.CHECK.TYPES<I>
        Y.RESPONSE.CATEG = Y.RESPONSE.CATEGORY<I>
        Y.RESPONSE.CATEG = UPCASE(Y.RESPONSE.CATEG)
        Y.MSG.ID = Y.MSG.IDS<I>
        Y.MSG.ID = UPCASE(Y.MSG.ID)
        Y.MSG.VAL = Y.MSG.VALUES<I>
        Y.CC.TYPE = Y.CHECK.TYPES<I>

        CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW,R.SOFT.BLK,F.JBWW.H.XX.SOFTBLOCK,'')
        IF R.SOFT.BLK NE '' THEN
            Y.BLOCK.MSG.IDS = R.SOFT.BLK<JHXS.BLOCK.ID>
            CHANGE VM TO FM IN Y.BLOCK.MSG.IDS
            Y.BLOCK.POS = ''
            FIND Y.MSG.ID IN Y.BLOCK.MSG.IDS SETTING Y.BLOCK.POS ELSE Y.BLOCK.POS = ''
        END

        IF Y.BLOCK.POS EQ '' THEN
            IF Y.RESPONSE.CATEG[1,4] EQ 'SOFT' THEN
                IF Y.INWARD.PAY.TYPE[1,3] NE 'STO' AND Y.SRC NE 'OFS' THEN
                    IF Y.NO.OF.AUTH GE '1' THEN
                        R.VERSION(46) = '2'
                    END ELSE
                        R.VERSION(46) = '1'
                    END
                END
                GOSUB UPDATE.MESSAGE.BLOCKS
                GOSUB UPDATE.BLOCK.DETAILS
            END
        END

    REPEAT

    IF R.SOFT.BLOCKS NE '' THEN
        GOSUB UPDATE.AUDIT.FIELDS.SOFT.BLOCKS
    END
RETURN

UPDATE.BLOCK.DETAILS:
**********************

    Y.SBD.CNT += 1
    R.SBD.DETAILS<SBD.BLOCK.ID,Y.SBD.CNT> = Y.MSG.ID
    R.SBD.DETAILS<SBD.BLOCK.MESSAGE,Y.SBD.CNT> = Y.MSG.VAL
    R.SBD.DETAILS<SBD.BLOCK.TYPE,Y.SBD.CNT> = Y.CC.TYPE
    R.SBD.DETAILS<SBD.BLOCK.CATEGORY,Y.SBD.CNT> = Y.RESPONSE.CATEG

RETURN

CALL.JAVA.WEB.SERVICE:
************************
 
    GEN.PARAM.ID = ''
    RESERVER1 = ''
    RESERVE2 = ''
    RESERVE3 = ''

    IF Y.BUYING.POWER.PASS NE '' THEN
        param := "trxSettlementCcy=":Y.SET.CCY
        GEN.PARAM.ID = 'CREDIT.SERVICE'
    END

    IF Y.MARKET.CHECK.PASS NE '' THEN
        GOSUB GET.PARAM.DATA
        param := "trxCcy=":Y.SET.CCY
        GEN.PARAM.ID = 'MARKET.SERVICE'
    END

    IF Y.BUYING.POWER.PASS NE '' AND Y.MARKET.CHECK.PASS NE '' THEN
        GOSUB GET.PARAM.DATA
        param := "trxSettlementCcy=":Y.SET.CCY:'^':"trxCcy=":Y.SET.CCY
        GEN.PARAM.ID = 'CREDIT.MARKET.SERVICE'
    END

    IN.DATA = param

    CALL JBWW.R.XX.WEBSERVICE.CALL(GEN.PARAM.ID,IN.DATA,RESERVER1,RESERVE2,RESERVE3,OUT.REPONSE,OVE.ERR.IND,ERR.OVE.ID,RESERVE4)
    GOSUB UPDATE.CALLJ.LOG
RETURN

UPDATE.CALLJ.LOG:
****************


    LOG.DATA = IN.DATA
    LOG.RESPONSE = OUT.REPONSE
    CONVERT '^' TO FM IN LOG.DATA
    CHANGE FM TO '&&' IN LOG.DATA
    CONVERT '^' TO FM IN LOG.RESPONSE
    CHANGE FM TO '&&' IN LOG.RESPONSE

    R.CALLJ.LOG = ''
    R.CALLJ.LOG<RLG.CALLJ.REQUEST> = LOG.DATA
    R.CALLJ.LOG<RLG.CALLJ.RESPONSE> = LOG.RESPONSE
    R.CALLJ.LOG<RLG.CALLJ.ERROR> = OVE.ERR.IND
    R.CALLJ.LOG<RLG.DATE.TIME> = DATE.TIME
    Y.TRANSACTION.ID = ID.NEW
    CALL F.WRITE(FN.JBWW.L.XX.RLCSOFTBLOCK.LOG,Y.TRANSACTION.ID,R.CALLJ.LOG)
RETURN

FETCH.CUSTOMER.DETAILS:
***********************

    Y.CUSTOMER.ID = R.NEW(PO.ORDERING.CUSTOMER)
    GOSUB READ.CUSTOMER
    Y.CLIENT = R.CUS<EB.CUS.MNEMONIC>

RETURN

FETCH.PORTFOLIO.DETAILS:
************************
    Y.DR.AC.NO = R.NEW(PO.DEBIT.ACCOUNT)
    Y.ACCT.NO = Y.DR.AC.NO
    GOSUB READ.AC
    IF R.AC NE '' THEN
        Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO,1>
        Y.SAM.ID = Y.PORTFOLIO
        GOSUB READ.SAM
        IF R.SAM.REC THEN
            R.SAM = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
        END
    END
RETURN

READ.SAM:
************
    R.SAM.REC = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
RETURN
READ.AC:
*************
    R.AC = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.NO,R.AC,F.ACCOUNT,'')
RETURN
RAISE.NO.OF.AUTH:
********************

    IF Y.INWARD.PAY.TYPE[1,3] EQ 'STO' AND Y.SRC EQ 'OFS' THEN RETURN
    IF Y.SOFT.BLOCK.FLAG NE '' AND R.HARD.BLOCKS EQ '' THEN
        IF Y.NO.OF.AUTH GE '1' THEN
            R.VERSION(EB.VER.NO.OF.AUTH) = '2'
        END ELSE
            R.VERSION(EB.VER.NO.OF.AUTH) = '1'
        END
    END
RETURN

EXTRACT.CALJ.DETAILS:
******************************
    Y.CALJ.CC.TYPE = 'checkType'
    Y.CALJ.MSG.ID = 'msgId'
    Y.CALJ.MSG.TEXT = 'msgTxt'
    Y.CALJ.RESPONSE.CATEG = 'responseCategory'
    Y.CALL.J.RESPONSE = OUT.REPONSE
    Y.CAL.J.RESP.CNT = DCOUNT(Y.CALL.J.RESPONSE,'|')

    IF Y.CAL.J.RESP.CNT GT '0' THEN
        Y.CJ = 0
        LOOP

            Y.CJ = Y.CJ + 1

        WHILE Y.CJ LE Y.CAL.J.RESP.CNT
            Y.CALJ.REC = FIELD(Y.CALL.J.RESPONSE,'|',Y.CJ)
            GOSUB FETCH.HARD.SOFT.BLOCK.DETAILS
        REPEAT

    END ELSE

        Y.CALJ.REC = Y.CALL.J.RESPONSE
        GOSUB FETCH.HARD.SOFT.BLOCK.DETAILS
    END

RETURN

FETCH.HARD.SOFT.BLOCK.DETAILS:
******************************
    Y.CALJ.FIELD = Y.CALJ.REC
    CHANGE '^' TO FM IN Y.CALJ.FIELD
    Y.COUNT = DCOUNT(Y.CALJ.FIELD,@FM)
    I = 0
    LOOP
        I = I + 1
    WHILE I LE Y.COUNT

        Y.CHECK.TYPE = Y.CALJ.FIELD<I>
        Y.CALJ.TAG.NAME = FIELD(Y.CHECK.TYPE,'=',1)
        Y.CALJ.VALUE = FIELD(Y.CHECK.TYPE,'=',2)

        IF Y.CALJ.CC.TYPE  EQ Y.CALJ.TAG.NAME THEN
            Y.CHECK.TYPES<-1> = UPCASE(Y.CALJ.VALUE)
        END

        IF Y.CALJ.MSG.ID EQ Y.CALJ.TAG.NAME THEN
            Y.MSG.IDS<-1> = UPCASE(Y.CALJ.VALUE)
        END

        IF Y.CALJ.MSG.TEXT EQ Y.CALJ.TAG.NAME THEN
            Y.MSG.VALUES<-1> = Y.CALJ.VALUE
        END

        IF Y.CALJ.RESPONSE.CATEG EQ Y.CALJ.TAG.NAME THEN
            Y.RESPONSE.CATEGORY<-1> = UPCASE(Y.CALJ.VALUE)
        END

    REPEAT

PREV.SOFT.OR.HARD.BLOCK.EXIST:
**********************************
*****Deleting Soft Block Record and Application fields for Previous soft Blocks holding data

    Y.BLOCK.ID = ID.NEW
    GOSUB READ.SOFT.BLOCK
    IF R.BLOCKS AND Y.OVERALL.STATUS EQ '' THEN
        GOSUB DEL.PREVIOUS.VALUES
        CALL F.DELETE(FN.JBWW.H.XX.SOFTBLOCK,Y.BLOCK.ID)
    END
    Y.HARD.BLOCK.ID = 'HB':ID.NEW
    Y.BLOCK.ID = Y.HARD.BLOCK.ID
    GOSUB READ.SOFT.BLOCK
    IF R.BLOCKS THEN
        GOSUB DEL.PREVIOUS.VALUES
        CALL F.DELETE(FN.JBWW.H.XX.SOFTBLOCK,Y.BLOCK.ID)
    END

RETURN


DEL.PREVIOUS.VALUES:
*********************

    Y.BLK.CATEG = R.NEW.LAST(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS>

    IF Y.BLK.CATEG EQ '' THEN RETURN

    Y.BLK.CATEG.CNT = DCOUNT(Y.BLK.CATEG,SM)

    IF Y.BLK.CATEG.CNT LT '1' THEN
        IF Y.TC.DONE[1,1] NE 'Y' THEN
            R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS> = ''
            R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS> = ''
            R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS> = ''
            R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS> = ''
        END

        IF Y.TC.DONE[1,1] EQ 'Y' THEN
            Y.OVE.ID = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,1>
            GOSUB READ.OVERRIDE

            IF R.OVERRIDE NE '' THEN
                R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS> = ''
                R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS> = ''
                R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS> = ''
                R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS> = ''

            END
        END
    END ELSE

        KK = 0

        LOOP
            KK = KK + 1

        WHILE KK LE Y.BLK.CATEG.CNT
            Y.OVE.ID = ''
            IF Y.TC.DONE[1,1] NE 'Y' THEN

                IF KK NE Y.BLK.CATEG.CNT THEN
                    DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS,KK>
                    DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS,KK>
                    DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,KK>
                    DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS,KK>
                END ELSE

                    R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS> = ''
                    R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS> = ''
                    R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS> = ''
                    R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS> = ''
                END
            END

            IF Y.TC.DONE[1,1] EQ 'Y' THEN
                Y.OVE.ID =  R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,KK>
                GOSUB READ.OVERRIDE
                IF R.OVERRIDE NE '' THEN
                    IF KK NE Y.BLK.CATEG.CNT THEN
                        DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS,KK>
                        DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS,KK>
                        DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,KK>
                        DEL R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS,KK>
                    END ELSE
                        R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS> = ''
                        R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS> = ''
                        R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS> = ''
                        R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS> = ''

                    END
                END
            END

        REPEAT

    END

RETURN

READ.SOFT.BLOCK:
***************
    R.BLOCKS = ''
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,Y.BLOCK.ID,R.BLOCKS,F.JBWW.H.XX.SOFTBLOCK,'')
    Y.OVERALL.STATUS = R.BLOCKS<JHXS.OVERALL.STATUS>
    IF Y.OVERALL.STATUS NE '' THEN
        Y.SB.FLAG = '1'
    END

RETURN


DISPLAY.ERROR.OVERRIDE.ON.SCREEN:
************************************
    IF  Y.OVERALL.STATUS NE '' THEN RETURN
    IF Y.RESPONSE.CATEGORY EQ '' THEN RETURN

    IF R.NEW.LAST(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS> NE '' THEN
        GOSUB PREV.SOFT.OR.HARD.BLOCK.EXIST
    END

    Y.CATEGORY.CNT = DCOUNT(Y.RESPONSE.CATEGORY,FM)
    NN = 0

    LOOP

        NN = NN + 1

    WHILE NN LE Y.CATEGORY.CNT

        Y.RESPONSE.CATEG = Y.RESPONSE.CATEGORY<NN>
        Y.RESPONSE.CATEG = UPCASE(Y.RESPONSE.CATEG)
        BEGIN CASE

            CASE  Y.RESPONSE.CATEG EQ 'SOFT_BLOCK'

                Y.MSG.ID =  Y.MSG.IDS<NN>
                Y.MSG.VAL = Y.MSG.VALUES<NN>
                Y.CHECK.TYPE = Y.CHECK.TYPES<NN>
                Y.CC.TYPE = Y.CHECK.TYPE
                TEXT = 'EB-JBWW.D.XX.RLCTCA.MABP':FM:Y.MSG.VAL
                Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                Y.OVE.CNT += 1
                CALL STORE.OVERRIDE(Y.OVE.CNT)

                IF Y.INWARD.PAY.TYPE[1,3] NE 'STO' AND Y.SRC NE 'OFS' THEN
                    IF Y.NO.OF.AUTH GE '1' THEN
                        R.VERSION(46) = '2'
                    END ELSE
                        R.VERSION(46) = '1'
                    END
                END

                Y.BLK.CODE = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS>
                CONVERT SM TO VM IN Y.BLK.CODE
                CONVERT VM TO FM IN Y.BLK.CODE

                Y.CODE.POS = ''
                LOCATE Y.MSG.ID IN Y.BLK.CODE SETTING Y.CODE.POS ELSE Y.CODE.POS = ''

                IF Y.CODE.POS EQ '' THEN
                    GOSUB UPDATE.LOCAL.FIELDS
                    GOSUB UPDATE.BLOCK.DETAILS
                END


            CASE  Y.RESPONSE.CATEG EQ 'HARD_BLOCK'

                Y.MSG.VAL = Y.MSG.VALUES<NN>
                IF Y.MSG.VAL NE '' THEN
                    AF = '0'
                    ETEXT = 'EB-JBWW.D.XX.RLCTCA.MABP':FM:Y.MSG.VAL
                    CALL STORE.END.ERROR
                    IF Y.DONE.DEAL EQ 'Y' THEN
                        R.VERSION(66) = '1'
                        Y.MSG.ID =  Y.MSG.IDS<NN>
                        Y.MSG.VAL = Y.MSG.VALUES<NN>
                        Y.CHECK.TYPE = Y.CHECK.TYPES<NN>
                        GOSUB UPDATE.TCA.HARD.BLOCKS
                        GOSUB UPDATE.BLOCK.DETAILS
                    END
                END
            CASE  Y.RESPONSE.CATEG EQ 'WARNING'
                Y.MSG.VAL = Y.MSG.VALUES<NN>
                IF Y.MSG.VAL NE '' THEN
                    TEXT = 'EB-JBWW.D.XX.RLCTCA.MABP':FM:Y.MSG.VAL
                    Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
                    Y.OVE.CNT += 1
                    CALL STORE.OVERRIDE(Y.OVE.CNT)
                END

            CASE  Y.RESPONSE.CATEG EQ 'ERROR'
                Y.CHECK.TYPE = Y.CHECK.TYPES<NN>
                GOSUB RAISE.CALJ.ERROR.IF.EXISTS
        END CASE
    REPEAT

RETURN


UPDATE.AUDIT.FIELDS.SOFT.BLOCKS:
***********************
    Y.TRANSACTION.ID = ID.NEW

    IF R.SOFT.BLOCKS NE '' THEN
        IF  Y.TC.DONE[1,1] EQ 'Y' THEN
            CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK,Y.TRANSACTION.ID,R.SOFT.BLOCKS)
        END
        CALL F.WRITE(FN.JBWW.L.XX.SOFTBLOCK.DETS,Y.TRANSACTION.ID,R.SBD.DETAILS)
    END
RETURN
UPDATE.MESSAGE.BLOCKS:
*******************

    IF R.SOFT.BLOCKS<JHXS.BLOCK.ID> EQ '' THEN
        R.SOFT.BLOCKS<JHXS.BLOCK.ID,1> = Y.MSG.ID
        R.SOFT.BLOCKS<JHXS.BLOCK.MSG,1> = Y.MSG.VAL
        R.SOFT.BLOCKS<JHXS.BLOCK.DEPT,1> = Y.CHECK.TYPE
        R.SOFT.BLOCKS<JHXS.BLOCK.USER.ID> = OPERATOR
    END ELSE
        R.SOFT.BLOCKS<JHXS.BLOCK.ID,-1> = Y.MSG.ID
        R.SOFT.BLOCKS<JHXS.BLOCK.MSG,-1> = Y.MSG.VAL
        R.SOFT.BLOCKS<JHXS.BLOCK.DEPT,-1> = Y.CHECK.TYPE
    END

RETURN


UPDATE.TCA.HARD.BLOCKS:
*************************

    IF R.HARD.BLOCKS<JHXS.BLOCK.ID> EQ '' THEN

        R.HARD.BLOCKS<JHXS.BLOCK.ID,1> = Y.MSG.ID
        R.HARD.BLOCKS<JHXS.BLOCK.MSG,1> = Y.MSG.VAL
        R.HARD.BLOCKS<JHXS.BLOCK.DEPT,1> = Y.CHECK.TYPE
        R.HARD.BLOCKS<JHXS.BLOCK.USER.ID> = OPERATOR
    END ELSE
        R.HARD.BLOCKS<JHXS.BLOCK.ID,-1> = Y.MSG.ID
        R.HARD.BLOCKS<JHXS.BLOCK.MSG,-1> = Y.MSG.VAL
        R.HARD.BLOCKS<JHXS.BLOCK.DEPT,-1> = Y.CHECK.TYPE

    END

    IF Y.TC.DONE[1,1] NE 'Y' THEN
        IF Y.DONE.DEAL EQ 'Y' THEN
            GOSUB UPDATE.LOCAL.FIELDS
        END
    END

RETURN

UPDATE.HARD.BLOCKS.TABLE:
**************************
    IF R.HARD.BLOCKS NE '' THEN
        GOSUB GET.CUSTOMER.PORTFOLIO.HARD.BLOCK.DETAILS
        Y.TRANSACTION.ID = 'HB':ID.NEW
        R.HARD.BLOCKS<JHXS.APPLICATION> = APPLICATION
        R.HARD.BLOCKS<JHXS.ISIN.IDENTIFIER> = ''
        R.HARD.BLOCKS<JHXS.TRADE.DATE> = R.NEW(PO.PAYMENT.EXECUTION.DATE)
        R.HARD.BLOCKS<JHXS.VALUE.DATE> = Y.DEBIT.VALDATE
        R.HARD.BLOCKS<JHXS.DONE.DEAL> = R.NEW(PO.LOCAL.REF)<1,Y.DONE.DEAL.POS>
        R.HARD.BLOCKS<JHXS.CREDIT.READY> = 'NO'
        GOSUB UPDATE.AUDIT.FIELDS

    END

RETURN

GET.CUSTOMER.PORTFOLIO.HARD.BLOCK.DETAILS:
******************************************
    Y.PAY.AMT = ''
    Y.SOO.CUSTOMER = R.NEW(PO.ORDERING.CUSTOMER)
    Y.CUSTOMER.ID = Y.SOO.CUSTOMER
	GOSUB GET.PAYMENT.AMOUNT
    IF R.HARD.BLOCKS<JHXS.CLIENT.ID> EQ '' THEN
        R.HARD.BLOCKS<JHXS.CLIENT.ID,1> =  Y.SOO.CUSTOMER
        Y.PORTFOLIO = ''
        R.HARD.BLOCKS<JHXS.PORTFOLIO.ID,1> = Y.PORTFOLIO
        GOSUB READ.CUSTOMER
        R.HARD.BLOCKS<JHXS.REL.MANAGER,1> = Y.DAO
        R.HARD.BLOCKS<JHXS.ACCT.OFFICER,1> = Y.OTHER.OFFICER
        R.HARD.BLOCKS<JHXS.TRANSACTION.TYPE,1> = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
        R.HARD.BLOCKS<JHXS.CURRENCY,1> = R.NEW(PO.DEBIT.CCY)
        R.HARD.BLOCKS<JHXS.QUANTITY,1> = ''
        R.HARD.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
    END ELSE
		IF NOT(R.HARD.BLOCKS<JHXS.AMOUNT,1>) THEN
			R.HARD.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
		END
	END

RETURN


UPDATE.AUDIT.FIELDS:
***********************
    Y.TRANSACTION.ID = 'HB':ID.NEW
    IF R.HARD.BLOCKS NE '' THEN

        X = OCONV(DATE(),'D4-')
        TIME.STAMP = TIMEDATE()
        DATE.TIME = X[9,2]:X[1,2]:X[4,2]:TIME.STAMP[1,2]:TIME.STAMP[4,2]
        R.HARD.BLOCKS<JHXS.INPUTTER> = TNO:'_':OPERATOR

        R.HARD.BLOCKS<JHXS.CURR.NO> = '1'

        R.HARD.BLOCKS<JHXS.AUTHORISER> = TNO:'_':OPERATOR

        R.HARD.BLOCKS<JHXS.AUDIT.DATE.TIME> = DATE.TIME

        R.HARD.BLOCKS<JHXS.CO.CODE> = ID.COMPANY

        WRITE R.HARD.BLOCKS ON F.JBWW.H.XX.SOFTBLOCK,Y.TRANSACTION.ID ON ERROR
            PRINT "CANT WRITE HARD BLOCKS":Y.TRANSACTION.ID
        END
    END

    IF R.SBD.DETAILS NE '' THEN
        R.SBD.DETAILS<SBD.DATE.TIME> = DATE.TIME
        Y.TRANSACTION.ID = ID.NEW
        WRITE R.SBD.DETAILS ON F.JBWW.L.XX.SOFTBLOCK.DETS,Y.TRANSACTION.ID ON ERROR
            PRINT "CANT WRITE BLOCKS":Y.TRANSACTION.ID
        END
    END

    IF R.CALLJ.LOG NE '' THEN
        Y.TRANSACTION.ID = ID.NEW
        WRITE R.CALLJ.LOG ON F.JBWW.L.XX.RLCSOFTBLOCK.LOG,Y.TRANSACTION.ID ON ERROR
        END
    END


RETURN
UPDATE.LOCAL.FIELDS:
**********************
    IF R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS> NE '' THEN
        IF Y.SOFT.BLOCK.FLAG EQ '' THEN
            Y.SOFT.BLOCK.FLAG = '1'
        END
    END
    Y.NEW.CATEGORY = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS>
    Y.NEW.CATEG.CNT = DCOUNT(Y.NEW.CATEGORY,SM)
    Y.POS.CNT = Y.NEW.CATEG.CNT + 1

    R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS,Y.POS.CNT> = Y.CHECK.TYPE
    R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS,Y.POS.CNT>  =  Y.RESPONSE.CATEG
    R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS,Y.POS.CNT> =  Y.MSG.ID
    R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS,Y.POS.CNT> = Y.MSG.VAL[1,65]


RETURN




READ.OVERRIDE:
****************
    R.OVERRIDE = ''

    CALL F.READ(FN.OVERRIDE,Y.OVE.ID,R.OVERRIDE,F.OVERRIDE,'')

    IF R.OVERRIDE THEN
        Y.BLK.APR = R.OVERRIDE<EB.OR.LOCAL.REF,Y.BLK.APR.POS>
    END

RETURN



READ.CUSTOMER:
*******************
    R.CUS = ''
    CALL F.READ(FN.CUSTOMER,Y.CUSTOMER.ID,R.CUS,F.CUSTOMER,'')
    IF R.CUS THEN
        Y.DAO = R.CUS<EB.CUS.ACCOUNT.OFFICER>
        Y.OTHER.OFFICER = R.CUS<EB.CUS.OTHER.OFFICER>
    END
RETURN

PROCESS.CREDIT.CONSTRAINTS:
*****************************
    Y.CR.ACCT.NO = R.NEW(PO.CREDIT.ACCOUNT)  ; * Credit account is not available for Outward payment and applicable only fo book payment.
    Y.ACCT.NO = Y.CR.ACCT.NO
    GOSUB READ.AC
    Y.CR.PORTFOLIO = ''
    Y.SAM.ID = ''
    Y.CR.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID =  Y.CR.PORTFOLIO<1,1>
    GOSUB READ.SAM
    IF Y.CR.PORTFOLIO NE '' THEN
        Y.CR.TAG.BLOCKS = R.EB.GC.REC<EB.GCC.EVAL.VALUE>
        CHANGE VM TO FM IN Y.CR.TAG.BLOCKS
        IF R.SAM.REC NE '' THEN
            Y.BULK.TAG.IDS = R.SAM.REC<SC.SAM.LOCAL.REF>
            Y.TAG.BLK.IDS = Y.BULK.TAG.IDS<1,Y.TAG.BLK.POS>
            CHANGE SM TO FM IN Y.TAG.BLK.IDS
            Y.TAG.BLK.CNT = DCOUNT(Y.TAG.BLK.IDS,FM)
            JJ = 0
            LOOP
                JJ = JJ + 1
            WHILE JJ LE Y.TAG.BLK.CNT
                Y.TAG.BLK.ID = Y.TAG.BLK.IDS<JJ>
                Y.CR.BLK.POS = ''
                FIND Y.TAG.BLK.ID IN Y.CR.TAG.BLOCKS SETTING Y.CR.BLK.POS ELSE Y.CR.BLK.POS = ''

                IF Y.CR.BLK.POS THEN
                    IF Y.TAG.BLK.ID[1,2] EQ 'SB' THEN
                        R.VERSION(EB.VER.NO.OF.AUTH) = '1'
                        Y.NAU.FLAG = '1'
                    END
                END
            REPEAT
        END
    END

RETURN

READ.GEN.PARAM:
***************
    Y.PARAM.ID = ''
    Y.MNEMONIC = ''
    Y.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    Y.PARAM.ID = 'EGCFT.SBTXNTYPE':'.':Y.MNEMONIC
    GOSUB READ.GEN.TABLE
    Y.FIELD.NAME = ''
    Y.FIELD.NAME = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    CONVERT VM TO FM IN Y.FIELD.NAME
    Y.FLD.POS = ''
    FIND 'TRANSACTION.TYPE' IN Y.FIELD.NAME SETTING Y.FLD.POS ELSE Y.FLD.POS = ''
    IF Y.FLD.POS THEN
        Y.FILTER.TXN.TYPES = ''
        Y.FILTER.TXN.TYPES =  R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.FLD.POS>
        CONVERT SM TO VM IN Y.FILTER.TXN.TYPES
        CONVERT VM TO FM IN Y.FILTER.TXN.TYPES
        Y.TXN.POS = ''
        Y.TXN.TYPE =''
        Y.TXN.TYPE = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
        FIND Y.TXN.TYPE IN Y.FILTER.TXN.TYPES SETTING Y.TXN.POS ELSE Y.TXN.POS = ''

    END
RETURN

READ.SC.INC.ACCOUNT:
******************
    R.INC = ''
    CALL F.READ(FN.SC.INC.ACCOUNT,Y.ACT.NO,R.INC,F.SC.INC.ACCOUNT,'')
    Y.SAM.ID = R.INC<1>

RETURN
SB.DR.CR.BLOCK.CHK:
****************
    Y.DR.CR.FLAG = ''
    Y.SAM.DR.POS = ''
    FIND 'SAM.ID.DR' IN Y.FIELD.NAME SETTING Y.SAM.DR.POS ELSE Y.SAM.DR.POS = ''
    IF Y.SAM.DR.POS THEN
        Y.SAM.DR.CR.ARR = ''
        Y.SAM.DR.CR.ARR = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.SAM.DR.POS>
        CHANGE SM TO VM IN  Y.SAM.DR.CR.ARR
        CHANGE VM TO FM IN  Y.SAM.DR.CR.ARR
        Y.ACCT.NO = R.NEW(PO.DEBIT.ACCOUNT)
        GOSUB READ.AC
        Y.CR.PORTFOLIO = ''
        Y.SAM.ID = ''
        Y.PORTFOLIO.NUM = ''
        Y.PORTFOLIO.NUM = R.AC<AC.PORTFOLIO.NO>
        Y.SAM.ID =  Y.PORTFOLIO.NUM<1,1>
        IF  Y.SAM.ID EQ '' THEN
            GOSUB READ.SC.INC.ACCOUNT
        END
        GOSUB READ.SAM
        GOSUB CHK.DR.CR.BLK.CONSTRAINTS
    END


    IF Y.DR.CR.FLAG NE '' THEN RETURN
    Y.SAM.CR.POS = ''
    FIND 'SAM.ID.CR' IN Y.FIELD.NAME SETTING Y.SAM.CR.POS ELSE Y.SAM.CR.POS = ''
    IF Y.SAM.CR.POS THEN
        Y.SAM.DR.CR.ARR = ''
        Y.SAM.DR.CR.ARR = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.SAM.CR.POS>
        CHANGE SM TO VM IN  Y.SAM.DR.CR.ARR
        CHANGE VM TO FM IN  Y.SAM.DR.CR.ARR
        Y.ACCT.NO = R.NEW(PO.CREDIT.ACCOUNT)   ; * Credit account is not available for Outward payment and applicable only fo book payment.
        GOSUB READ.AC
        Y.CR.PORTFOLIO = ''
        Y.SAM.ID = ''
        Y.PORTFOLIO.NUM = ''
        Y.PORTFOLIO.NUM = R.AC<AC.PORTFOLIO.NO>
        Y.SAM.ID =  Y.PORTFOLIO.NUM<1,1>
        GOSUB READ.SAM
        GOSUB CHK.DR.CR.BLK.CONSTRAINTS
    END
RETURN

CHK.DR.CR.BLK.CONSTRAINTS:
**************************

    IF Y.SAM.ID  NE '' THEN
        Y.DR.CR.BLOCKS = ''
        CHANGE VM TO FM IN Y.CR.TAG.BLOCKS
        IF R.SAM.REC NE '' THEN
            Y.DR.CR.BLOCKS = R.SAM.REC<SC.SAM.LOCAL.REF>
            Y.SB.TAG.BLK.IDS =  Y.DR.CR.BLOCKS<1,Y.TAG.BLK.POS>
            CHANGE SM TO FM IN  Y.SB.TAG.BLK.IDS
            Y.SB.TAG.BLK.CNT = ''
            Y.SB.TAG.BLK.CNT = DCOUNT(Y.SB.TAG.BLK.IDS,FM)
            JJ = 0
            LOOP
                JJ = JJ + 1
            WHILE JJ LE Y.SB.TAG.BLK.CNT
                Y.SB.TAG.BLK.ID = Y.SB.TAG.BLK.IDS<JJ>
                Y.DR.CR.BLK.POS = ''
                FIND Y.SB.TAG.BLK.ID IN Y.SAM.DR.CR.ARR  SETTING Y.DR.CR.BLK.POS ELSE Y.DR.CR.BLK.POS = ''
                IF Y.DR.CR.BLK.POS NE '' THEN
                    Y.DR.CR.FLAG = '1'
                END
            REPEAT
        END
    END


RETURN

PROCESS.EB.GC.CONSTRAINT:
*************************

    CRDT.CUSTOMER = '' ; DBT.CUSTOMER = ''
    Y.CR.ACCT.NO = R.NEW(PO.CREDIT.ACCOUNT)  ; * Credit account is not available for Outward payment and applicable only fo book payment.
    Y.ACCT.NO = Y.CR.ACCT.NO
    GOSUB READ.AC
	CRDT.CUSTOMER = R.AC<AC.CUSTOMER>
    DBT.CUSTOMER =  R.NEW(PO.ORDERING.CUSTOMER)
	
	IF DBT.CUSTOMER EQ CRDT.CUSTOMER THEN
        R.NEW(PO.LOCAL.REF)<1,Y.RLC.BLK.POS> = 'NO'
    END ELSE
        IF R.NEW(PO.LOCAL.REF)<1,Y.RLC.BLK.POS> NE '' THEN
            Y.LAST.VALUE = R.NEW.LAST(PO.LOCAL.REF)<1,Y.RLC.BLK.POS>
            R.NEW(PO.LOCAL.REF)<1,Y.RLC.BLK.POS> = Y.LAST.VALUE
        END
    END
    IF R.NEW(PO.LOCAL.REF)<1,Y.RLC.BLK.POS> EQ 'NO' THEN RETURN

    IF Y.INWARD.PAY.TYPE[1,3] EQ 'STO' AND Y.SRC EQ 'OFS' THEN RETURN

    GOSUB READ.GEN.PARAM
    IF Y.TXN.POS NE '' THEN RETURN

* IT is applicable only for PP.ORDER.ENTRY

    IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'IT' THEN
        GOSUB SB.DR.CR.BLOCK.CHK
    END
    IF Y.DR.CR.FLAG NE '' THEN RETURN

    Y.APPLICATION = APPLICATION
    R.EB.GC.REC = ''
    CALL F.READ(FN.EB.GC.CONSTRAINTS,Y.APPLICATION,R.EB.GC.REC,F.EB.GC.CONSTRAINTS,'')
    IF R.EB.GC.REC NE '' THEN
        GOSUB PROCESS.CREDIT.CONSTRAINTS
        IF Y.NAU.FLAG NE '' THEN RETURN
        Y.TEST.FILE =  R.EB.GC.REC<EB.GCC.TEST.FILE>
        Y.FILE.CNT = DCOUNT(Y.TEST.FILE,VM)

        I = 0

        LOOP

            I = I + 1

        WHILE I LE Y.FILE.CNT
            Y.TARGET.APP = ''
            Y.TARGET.FLD.NAME = ''
            Y.TARGET.FLD.NAME = R.EB.GC.REC<EB.GCC.TEST.KEY,I>
            Y.TARGET.APP.NAME = Y.APPLICATION
            GOSUB GET.SS.NAME.TO.FIELD.DETAILS
            Y.TEST.KEY = R.NEW(FIELD.NO)
            GOSUB READ.TEST.FILE
        REPEAT
    END
RETURN

GET.SS.NAME.TO.FIELD.DETAILS:
******************************
    R.SS = ''
    FIELD.NO = ''
    FLDNAME = ''
    Y.FINAL.VALUE = ''
    Y.TARGET.APP = ''
    CALL GET.STANDARD.SELECTION.DETS(Y.TARGET.APP.NAME,R.SS)
    FLDNAME = Y.TARGET.FLD.NAME
    CALL FIELD.NAMES.TO.NUMBERS(FLDNAME,R.SS,FIELD.NO,YAF,YAV,YAS,DATA.TYPE,ERR.MSG)

RETURN

READ.TEST.FILE:
*****************
    Y.TEST.FILE.APP = R.EB.GC.REC<EB.GCC.TEST.FILE,I>
    IF Y.TEST.FILE.APP NE '' THEN
        Y.TEST.APP = 'F.':Y.TEST.FILE.APP
        FN.APPLICATION = Y.TEST.APP
        CALL OPF(FN.APPLICATION,Y.TEST.APP)
        IF Y.TEST.FILE.APP EQ 'SEC.ACC.MASTER' THEN
            Y.TEST.KEY = Y.PORTFOLIO
        END
        R.TEST.REC = ''
        CALL F.READ(FN.APPLICATION,Y.TEST.KEY,R.TEST.REC,Y.TEST.APP,'')
        IF R.TEST.REC NE '' THEN
            Y.TEST.FIELD = R.EB.GC.REC<EB.GCC.TEST.FIELD,I>
            Y.TARGET.APP.NAME =  Y.TEST.FILE.APP
            Y.TARGET.FLD.NAME = Y.TEST.FIELD
            GOSUB GET.SS.NAME.TO.FIELD.DETAILS
            Y.TEST.FIELD.NO = R.TEST.REC<FIELD.NO>
            IF Y.TEST.FIELD.NO EQ '' THEN
                Y.TARGET.FLD.NAME = 'LOCAL.REF'
                GOSUB GET.SS.NAME.TO.FIELD.DETAILS
                GOSUB GET.LOCAL.FIELD.POSITION
                Y.TEST.FIELD.NO = R.TEST.REC<FIELD.NO,Y.LOC.POS>
            END
            CONVERT SM TO VM IN Y.TEST.FIELD.NO
            CONVERT VM TO FM IN Y.TEST.FIELD.NO
            Y.EVAL.VALUE = R.EB.GC.REC<EB.GCC.EVAL.VALUE,I>
            Y.ERR.OVERRIDE = R.EB.GC.REC<EB.GCC.ERROR.OVERRIDE,I>
            Y.EVAL.POS = ''
            FIND Y.EVAL.VALUE IN Y.TEST.FIELD.NO SETTING Y.EVAL.POS ELSE Y.EVAL.POS = ''
            IF Y.ERR.OVERRIDE EQ 'OVERRIDE' THEN
                IF Y.EVAL.POS THEN
                    IF Y.NO.OF.AUTH GE '1' THEN
                        R.VERSION(EB.VER.NO.OF.AUTH) = '2'
                    END ELSE
                        R.VERSION(EB.VER.NO.OF.AUTH) = '1'
                    END
                END
            END
        END
    END ELSE
        Y.FIELD.VALUES = R.EB.GC.REC<EB.GCC.EVAL.VALUE,I>
        IF Y.FIELD.VALUES[1,2] EQ 'SB' THEN
            Y.TXN.VALUE = ''
            Y.LOGIC = ''
            Y.TARGET.APP.NAME = APPLICATION
            Y.TARGET.FLD.NAME = R.EB.GC.REC<EB.GCC.TEST.FIELD,I>
            GOSUB GET.SS.NAME.TO.FIELD.DETAILS
            Y.TXN.VALUE = R.NEW(FIELD.NO)
            IF FIELD.NO  EQ '' THEN
                Y.TARGET.FLD.NAME = 'LOCAL.REF'
                GOSUB GET.SS.NAME.TO.FIELD.DETAILS
                GOSUB GET.LOCAL.FIELD.POSITION
                Y.TXN.VALUE = R.NEW(FIELD.NO)<1,Y.LOC.POS>
            END
            OPERAND.VALUE = R.EB.GC.REC<EB.GCC.OPERAND,I>

            IF OPERAND.VALUE EQ 'EQ' THEN
                Y.LOGIC =  R.EB.GC.REC<EB.GCC.LOGIC,I>
                Y.ERR.OVERRIDE = R.EB.GC.REC<EB.GCC.ERROR.OVERRIDE,I>
                Y.TXN.VALUE.POS = ''
                FIND Y.TXN.VALUE IN Y.FIELD.VALUES SETTING Y.TXN.VALUE.POS ELSE Y.TXN.VALUE.POS = ''
                IF Y.TXN.VALUE.POS AND Y.ERR.OVERRIDE EQ 'OVERRIDE' THEN
                    IF Y.NO.OF.AUTH GE '1' THEN
                        R.VERSION(EB.VER.NO.OF.AUTH) = '2'
                    END ELSE
                        R.VERSION(EB.VER.NO.OF.AUTH) = '1'
                    END
                END
            END
        END
    END
RETURN

GET.LOCAL.FIELD.POSITION:
***************************
    Y.LOC.POS = ''
    CALL GET.LOC.REF(Y.TARGET.APP.NAME,Y.TEST.FIELD,Y.LOC.POS)

RETURN

PROCESS.GENERIC.OVERRIDES:
*************************
    IF Y.INWARD.PAY.TYPE[1,3] EQ 'STO' AND Y.SRC EQ 'OFS' THEN RETURN
    Y.OVERIDES = R.NEW(PO.OVERRIDE)
    Y.OVERRIDES.CNT = DCOUNT(Y.OVERIDES,VM)
    YY = 0

    LOOP

        YY = YY + 1

    WHILE YY LE Y.OVERRIDES.CNT
        Y.OVERRIDE = ''
        Y.BLK.APR = ''
        Y.OVERRIDE = R.NEW(PO.OVERRIDE)<1,YY>
        Y.OVE.ID = Y.OVERRIDE['}',1,1]
        GOSUB READ.OVERRIDE
        IF Y.BLK.APR NE '' THEN
            IF R.VERSION(EB.VER.NO.OF.AUTH) GE '1' THEN
                R.VERSION(EB.VER.NO.OF.AUTH) = '2'
            END ELSE
                R.VERSION(EB.VER.NO.OF.AUTH) = '1'
            END
        END
    REPEAT

RETURN


* CBPAY-1841 To Avoid payment to place in IHLD status
GET.PAYMENT.AMOUNT:

    BEGIN CASE
        CASE (R.NEW(PO.DEBIT.AMOUNT) NE '') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0.00') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0')
            Y.PAY.AMT = R.NEW(PO.DEBIT.AMOUNT)
	    CASE R.NEW(PO.PAYMENT.AMOUNT) NE ''
            Y.PAY.AMT = R.NEW(PO.PAYMENT.AMOUNT)
    END CASE
RETURN
* CBPAY-1841
