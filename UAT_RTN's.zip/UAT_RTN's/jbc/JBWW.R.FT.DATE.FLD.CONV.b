 SUBROUTINE JBWW.R.FT.DATE.FLD.CONV
*Description: To Seprate the values from inputter field.
*-------------------------------------------------------------------------
* Modification History : 
*-----------------------------------------------------------------------------
* Date          Developer                      Reference               Description
*-----------------------------------------------------------------------------
* 03/07/2018    Lakshmanan                     CR DAY15-136            Conversion routine for the DATE Field.
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_ENQUIRY.COMMON
*-------------------------------------------------------------------------
    Y.DATA = O.DATA
    Y.DATAS = OCONV(ICONV(Y.DATA[1,6],"D2/"),'D4Y'):Y.DATA[3,4]
    O.DATA = Y.DATAS
    RETURN
    END
*-------------------------------------------------------------------------
	
