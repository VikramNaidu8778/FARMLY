SUBROUTINE JB.R.PP.BENBIC.DEFAULT
*-----------------------------------------------------------------------------
* This subroutine attached as the Auto New Content routine to the versions
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.INP
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.API.1.0.0
* This routine to default the corresponding BIC to the BeneficiaryIdentifierCode (Creditor BIC)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 15-Apr-2025 u40786             CBPAY-2086        Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.COMPANY
    $USING PP.PaymentFrameworkService

    COMP.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    O.COMPANY.PROPERTIES = ''
    O.GET.COMP.ERROR = ''
    PP.PaymentFrameworkService.getCompanyProperties(COMP.MNEMONIC, O.COMPANY.PROPERTIES, O.GET.COMP.ERROR)
    R.NEW(PP.OEYG.BeneficiaryIdentifierCode) = O.COMPANY.PROPERTIES<PP.PaymentFrameworkService.CompanyProperties.companyBIC>
*
RETURN
*
END
*
