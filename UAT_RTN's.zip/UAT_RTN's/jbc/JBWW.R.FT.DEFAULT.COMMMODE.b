SUBROUTINE JBWW.R.FT.DEFAULT.COMMMODE

$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER

*-------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                           Reference               Description
*-----------------------------------------------------------------------------
* 22/10/2018    Balakrishnan K                      DAY15-4984              Routine will default COMMUNICATION MODE as YES when transaction type as ACMI 
*
* 23/05/2019    Lakshmanan                          T24-15028               Included condition to exclude reverse action from error 
*
*-------------------------------------------------------------------------

	appl = 'FUNDS.TRANSFER'

    localRefField = 'L.FT.COMM.MODE'
	localRefFieldPos = ''
	lFtCommModePos=''
   
        CALL MULTI.GET.LOC.REF( appl, localRefField , localRefFieldPos)

	lFtCommModePos  = localRefFieldPos<1,1>

	transTypeVal = R.NEW(FT.TRANSACTION.TYPE)
	cashInpTransType = 'ACDL':VM:'ACWL'
	
	communicationModeVal = R.NEW(FT.LOCAL.REF)<1,lFtCommModePos>
		
	BEGIN CASE
	CASE PGM.VERSION EQ ',JBWW.V.FT.REFUNDS.INP' AND transTypeVal EQ 'ACMI' AND V$FUNCTION NE 'R'
			GOSUB callErrorMessgae
	CASE PGM.VERSION EQ ',JBWW.V.FT.FEECHRG.INP' AND transTypeVal EQ 'ACME' AND V$FUNCTION NE 'R'
			GOSUB callErrorMessgae
	CASE PGM.VERSION EQ ',JBWW.V.FT.CASH.INP' AND transTypeVal  MATCHES cashInpTransType AND V$FUNCTION NE 'R'
			GOSUB callErrorMessgae
	END CASE 


	RETURN
**************************************************************************************************
callErrorMessgae:

	IF NOT(communicationModeVal) THEN
			AF=FT.LOCAL.REF
			AV=lFtCommModePos
			AS=1
			ETEXT='EB-MAND.INP'
			CALL STORE.END.ERROR()
	END 
	
RETURN
***************************************************************************************************	
	END 
*-------------------------------------------------------------------------


