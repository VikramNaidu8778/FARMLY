*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.B.SC.STOVER.CORRECTION(Y.ID)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :

*04/09/2024     CBGBB-10335    This is the ONE-TIME correction routine to be executed to update the FT.VERSION field in existing STO records with the new STP version name replacing current version name
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER
    $INSERT I_JB.B.SC.STOVER.CORRECTION.COMMON
*-----------------------------------------------------------------------------
   
    STO.ID = Y.ID
    R.STANDING.ORDER = ''
    CALL F.READ(FN.STANDING.ORDER,STO.ID,R.STANDING.ORDER,F.STANDING.ORDER,'')
    IF R.STANDING.ORDER THEN
        Y.FT.VERSION = R.STANDING.ORDER<STO.FT.VERSION>
    END

    BEGIN CASE
        CASE Y.FT.VERSION EQ "FUNDS.TRANSFER,JBWW.V.FT.ACAC.INP"
            R.STANDING.ORDER<STO.FT.VERSION> = "FUNDS.TRANSFER,JBWW.V.FT.ACAC.STP"
            GOSUB UPDATE.STO
        CASE Y.FT.VERSION EQ "FUNDS.TRANSFER,JBWW.V.FT.OT103.INP"
            R.STANDING.ORDER<STO.FT.VERSION> = "FUNDS.TRANSFER,JBWW.V.FT.OT103.STP"
            GOSUB UPDATE.STO
        CASE Y.FT.VERSION EQ "FUNDS.TRANSFER,JBWW.V.FT.OT103COVER.INP"
            R.STANDING.ORDER<STO.FT.VERSION> = "FUNDS.TRANSFER,JBWW.V.FT.OT103COVER.STP"
            GOSUB UPDATE.STO
        CASE Y.FT.VERSION EQ "FUNDS.TRANSFER,JBWW.V.FT.OT60.INP"
            R.STANDING.ORDER<STO.FT.VERSION> = "FUNDS.TRANSFER,JBWW.V.FT.OT60.STP"
            GOSUB UPDATE.STO
    END CASE


RETURN

************
UPDATE.STO:
************

    CALL F.WRITE(FN.STANDING.ORDER,STO.ID,R.STANDING.ORDER)
*
RETURN
*
END