* @ValidationCode : MjoxODc5MDI1MzI1OkNwMTI1MjoxNzIwNTE4MDk5MjE2OnU0MDYxNjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDIzMTAuMTotMTotMQ==
* @ValidationInfo : Timestamp         : 09 Jul 2024 17:41:39
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : u40616
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.1
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
SUBROUTINE JBWW.R.XX.GSTRC.ENTRY(Y.ENTRY.LIST)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 07-Oct-2022       Madhu        P-3998          Fetch the RC entry raised and related transaction entires
*                                               to display in enquiry
* 16/11/2022       D Suresh     P.3948          ACU DBU Decommission
* 14-Mar-2023      Madhu        T24-19044      Remove the selection command and form the ID to read the record JBWW.L.FT.GSTENTRY.PROCESSED table
* 15-Mar-2024      Madhu         L1GST          Amended the condition to display both RC and GST entries
* 05-Nov-2024      Amala P      CBPAY-808       GST & RC entries - incorporated with TPH.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.L.FT.GSTENTRY.DETAILS
    $INSERT I_F.JBWW.L.FT.GSTENTRY.PROCESSED
    $INSERT I_F.STMT.ENTRY
    $INSERT I_F.CATEG.ENTRY
    $INSERT I_F.RE.CONSOL.SPEC.ENTRY
    $INSERT I_F.COMPANY
    $INSERT I_F.POR.TRANSACTION
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB GET.SELECTION
    GOSUB PROCESS
    
RETURN
*-----------------------------------------------------------------------------
INIT:
*------

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
    
    FN.FUNDS.TRANSFER$HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER$HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER$HIS, F.FUNDS.TRANSFER$HIS)
    
    FN.JBWW.L.FT.GSTENTRY.DETAILS = 'F.JBWW.L.FT.GSTENTRY.DETAILS'
    F.JBWW.L.FT.GSTENTRY.DETAILS = ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.DETAILS, F.JBWW.L.FT.GSTENTRY.DETAILS)
    
    FN.JBWW.L.FT.GSTENTRY.PROCESSED = 'F.JBWW.L.FT.GSTENTRY.PROCESSED'
    F.JBWW.L.FT.GSTENTRY.PROCESSED = ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.PROCESSED,F.JBWW.L.FT.GSTENTRY.PROCESSED)
    
    FN.STMT.ENTRY = 'F.STMT.ENTRY'
    F.STMT.ENTRY = ''
    CALL OPF(FN.STMT.ENTRY, F.STMT.ENTRY)
    
    FN.CATEG.ENTRY = 'F.CATEG.ENTRY'
    F.CATEG.ENTRY = ''
    CALL OPF(FN.CATEG.ENTRY, F.CATEG.ENTRY)
    
    FN.SPEC.ENTRY = 'F.RE.CONSOL.SPEC.ENTRY'
    F.SPEC.ENTRY = ''
    CALL OPF(FN.SPEC.ENTRY, F.SPEC.ENTRY)
*CBPAY-808 - Start
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
*CBPAY-808 - End
    Y.STMT.ID1 = '' ; Y.STMT.NO = '' ; Y.STMT.CNT = ''; Y.ST.ID = ''
    Y.STMT.LIST = '' ; Y.TRANS.LIST = ''
    
RETURN
*-----------------------------------------------------------------------------
GET.SELECTION:
*-------------
    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1,1> SETTING DATE.POS THEN
        Y.TRANS.REF = D.RANGE.AND.VALUE<1,DATE.POS>
    END
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*---------
*CALL GST.E.TXN.ENTRY(Y.TRANS.LIST)
    CALL E.MB.TXN.GET.ENTRIES(Y.TRANS.LIST)
    BEGIN CASE
        CASE Y.TRANS.REF[1,2] EQ 'FT'
            GOSUB MODIFY.ORG.GST.ENTRY
*T24-19044/S
            R.FT = '' ; YERR.FT = '' ; Y.ID = ''
            CALL F.READ(FN.FUNDS.TRANSFER, Y.TRANS.REF, R.FT,F.FUNDS.TRANSFER, YERR.FT)
            IF R.FT EQ '' THEN
                R.FT = '' ; YERR.FT.HIST = '' ; ; Y.ORG.FT.ID = ''
                CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER$HIS, Y.TRANS.REF, R.FT, YERR.FT.HIST)
            END
            IF R.FT NE '' THEN
                IF R.FT<FT.AUTH.DATE> EQ R.FT<FT.PROCESSING.DATE> THEN
                    Y.DATE = R.FT<FT.AUTH.DATE>
                END ELSE
                    Y.DATE = R.FT<FT.PROCESSING.DATE>
                END
                Y.RECORD.STATUS = R.FT<FT.RECORD.STATUS>
                BEGIN CASE
                    CASE Y.RECORD.STATUS EQ 'REVE'
                        Y.DATE1 = R.FT<FT.PROCESSING.DATE>
                        Y.ID = Y.DATE1:'*':FIELD(Y.TRANS.REF,';',1):'*R'
                        Y.ORG.FT.ID = Y.DATE1:'*':FIELD(Y.TRANS.REF,';',1)
                        GOSUB GET.ORG.FT.STMT.DET
                    CASE Y.RECORD.STATUS EQ 'MAT'
                        Y.ID = Y.DATE:'*':FIELD(Y.TRANS.REF,';',1)
                    CASE OTHERWISE
                        Y.ID = Y.DATE:'*':Y.TRANS.REF
                END CASE
*T24-19044/E
*CBPAY-808 - Start
                GOSUB EXT.ENTRY.DETAILS
            END
        CASE Y.TRANS.REF[1,3] EQ 'SGD'
            GOSUB MODIFY.ORG.GST.ENTRY
            R.POR.TRANSACTION = '' ; YERR.PO = '' ; Y.ID = ''
            CALL F.READ(FN.POR.TRANSACTION, Y.TRANS.REF, R.POR.TRANSACTION,F.POR.TRANSACTION, YERR.PO)
            IF R.POR.TRANSACTION NE '' THEN
                Y.APPRDATE = R.POR.TRANSACTION<PPPTX.ApprovedDateTime>[1,8]
                IF Y.APPRDATE EQ R.POR.TRANSACTION<PPPTX.ProcessingDate> THEN
                    Y.DATE = Y.APPRDATE
                END ELSE
                    Y.DATE = R.POR.TRANSACTION<PPPTX.ProcessingDate>
                END
                Y.STATUS.CODE = R.POR.TRANSACTION<PPPTX.StatusCode>
                BEGIN CASE
                    CASE Y.STATUS.CODE EQ '993'
                        Y.DATE1 = R.POR.TRANSACTION<PPPTX.ProcessingDate>
                        Y.ID = Y.DATE1:'*':Y.TRANS.REF:'*R'
                        Y.ORG.FT.ID = Y.DATE1:'*':Y.TRANS.REF
                        GOSUB GET.ORG.FT.STMT.DET
                    CASE Y.STATUS.CODE EQ '999'
                        Y.ID = Y.DATE:'*':Y.TRANS.REF
                END CASE
                GOSUB EXT.ENTRY.DETAILS
            END
*CBPAY-808 - End
        CASE Y.TRANS.REF[1,2] EQ 'DC'
            Y.ENTRY.LIST = Y.TRANS.LIST
            
        CASE OTHERWISE
            Y.ENTRY.LIST = Y.TRANS.LIST
    END CASE
    
RETURN
*CBPAY-808 - Start
*-----------------------------------------------------------------------------
EXT.ENTRY.DETAILS:
*-----------------
    R.JBWW.L.FT.GTSENTRY.PROC = '' ; YERR.PROC= ''
    CALL F.READ(FN.JBWW.L.FT.GSTENTRY.PROCESSED, Y.ID, R.JBWW.L.FT.GSTENTRY.PROC, F.JBWW.L.FT.GSTENTRY.PROCESSED, YERR.PROC)
    IF R.JBWW.L.FT.GSTENTRY.PROC NE '' THEN
        Y.GST.FLAG = R.JBWW.L.FT.GSTENTRY.PROC<JBWW.FT.DESCRIPTION>
        IF Y.ORG.FT.ID NE "" THEN
            Y.STMT.ID2 = R.JBWW.L.FT.GSTENTRY.PROC<JBWW.FT.STMT.ENTRY.IDS>:FM:Y.ORG.STMT.ID1
        END ELSE
            Y.STMT.ID2 = R.JBWW.L.FT.GSTENTRY.PROC<JBWW.FT.STMT.ENTRY.IDS>
        END
        Y.STMT.CNT1 = DCOUNT(Y.STMT.ID2, FM)
        Y.J = 0
        LOOP
            Y.J+=1
        WHILE Y.J LE Y.STMT.CNT1
            Y.STMT.ID1 = Y.STMT.ID2<Y.J>
            CHANGE VM TO '*' IN Y.STMT.ID1
            Y.STMT.NO = FIELD(Y.STMT.ID1,'*',1)
            Y.STMT.CNT = FIELD(Y.STMT.ID1,'-',2)
            Y.ST.ID = ''
            Y.I=0
            LOOP
                Y.I+=1
            WHILE Y.I LE Y.STMT.CNT
                Y.STMT.ID = Y.STMT.NO:FMT(Y.I,'4"0"R')
                Y.STMT.FLAG = 'S'
                GOSUB READ.ENTRY
                Y.ST.ID = 'S':Y.STMT.ID : "*" : CO.MNEMONIC
                IF Y.STMT.LIST THEN
                    Y.STMT.LIST := FM:Y.ST.ID
                END ELSE
                    Y.STMT.LIST = Y.ST.ID
                END
            REPEAT
        REPEAT
    END
    IF Y.STMT.LIST NE '' THEN
        Y.ENTRY.LIST = Y.TRANS.LIST:FM:Y.STMT.LIST
    END
    IF Y.ENTRY.LIST EQ '' THEN
        Y.ENTRY.LIST = Y.TRANS.LIST
    END

RETURN
*CBPAY-808 - End
*-----------------------------------------------------------------------------
GET.ORG.FT.STMT.DET:
*-------------------
    R.ORG.FT.REC = '' ; Y.ERR.ORG.FT = '' ; Y.ORG.STMT.ID1 = ''
    CALL F.READ(FN.JBWW.L.FT.GSTENTRY.PROCESSED, Y.ORG.FT.ID, R.ORG.FT.REC, F.JBWW.L.FT.GSTENTRY.PROCESSED, Y.ERR.ORG.FT)
    IF R.ORG.FT.REC NE '' THEN
        Y.ORG.STMT.ID1 = R.ORG.FT.REC<JBWW.FT.STMT.ENTRY.IDS>
    END

RETURN
*-----------------------------------------------------------------------------
MODIFY.ORG.GST.ENTRY:
*--------------------
    ORG.GST.ENTRY = ''
    Y.ORG.ST.ID = ''
    Y.ORG.GST.ENT = ''
    
    Y.ORG.GST.ENT = DCOUNT(Y.TRANS.LIST,FM)
    Y.J=0
    LOOP
        Y.J+=1
    WHILE Y.J LE Y.ORG.GST.ENT
        Y.STMT.FLAG = ''
        Y.STMT.ID = FIELD(Y.TRANS.LIST<Y.J>,'*',1)
        Y.STMT.FLAG = Y.STMT.ID[1,1]
        Y.STMT.ID = Y.STMT.ID[2,99]
        GOSUB READ.ENTRY
        Y.ORG.ST.ID =  Y.STMT.FLAG:Y.STMT.ID : "*" : CO.MNEMONIC
        IF ORG.GST.ENTRY THEN
            ORG.GST.ENTRY := FM:Y.ORG.ST.ID
        END ELSE
            ORG.GST.ENTRY = Y.ORG.ST.ID
        END
    REPEAT
    Y.TRANS.LIST = ORG.GST.ENTRY
RETURN
*-----------------------------------------------------------------------------
READ.ENTRY:
*----------
    R.STMT.ENTRY = '' ; YERR.ENTRY = ''
    BEGIN CASE
        CASE Y.STMT.FLAG = 'S'
            CALL F.READ(FN.STMT.ENTRY, Y.STMT.ID, R.STMT.ENTRY, F.STMT.ENTRY, YERR.ENTRY)
            IF R.STMT.ENTRY NE '' THEN
                Y.COMP.CODE = R.STMT.ENTRY<AC.STE.COMPANY.CODE>
                GOSUB DETERMINE.COMP.MNE
            END
        
        CASE Y.STMT.FLAG = 'C'
            CALL F.READ(FN.CATEG.ENTRY, Y.STMT.ID, R.CATEG.ENTRY, F.CATEG.ENTRY, YERR.ENTRY)
            IF R.CATEG.ENTRY NE '' THEN
                Y.COMP.CODE = R.CATEG.ENTRY<AC.CAT.COMPANY.CODE>
                GOSUB DETERMINE.COMP.MNE
            END
    
        CASE Y.STMT.FLAG = 'R'
            CALL F.READ(FN.SPEC.ENTRY, Y.STMT.ID, R.SPEC.ENTRY, F.SPEC.ENTRY, YERR.ENTRY)
            IF R.SPEC.ENTRY NE '' THEN
                Y.COMP.CODE = R.SPEC.ENTRY<AC.STE.COMPANY.CODE>
                GOSUB DETERMINE.COMP.MNE
            END
    END CASE
    
RETURN
*-----------------------------------------------------------------------------
DETERMINE.COMP.MNE:
*------------------
    BEGIN CASE
        CASE Y.COMP.CODE = 'SG0020001'
            CO.MNEMONIC = 'SGD'
        CASE Y.COMP.CODE = 'SG0020002'
            CO.MNEMONIC = 'SGA'
        CASE Y.COMP.CODE = 'SG0020003'
            CO.MNEMONIC = 'SGB'
        CASE Y.COMP.CODE = 'HK0030001'
            CO.MNEMONIC = 'HKD'
    END CASE
    
* ACUDCU Decommission change/S
    IF Y.COMP.CODE EQ 'SG0020001' THEN
        ACUDCU.MIG.DAT = ''
        CALL JBWW.R.XX.ACUDCU.MIGDATECHK(ACUDCU.MIG.DAT)
        IF TODAY GT ACUDCU.MIG.DAT THEN
            CO.MNEMONIC = 'SGD'
        END
    END
    
* ACUDCU Decommission change/E
    
RETURN
*-----------------------------------------------------------------------------
END