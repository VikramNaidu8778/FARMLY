SUBROUTINE JB.R.PP.CHKPAYCHNL.INPUT
*----------------------------------------------------------------------------------------------------------------------------------
*This is the Input routine attached to Versions OT12,0T03,OT22 to default Order Initiation Type based on Payment ccy 
*and Payment Channel.
*Attached: to version PAYMENT.ORDER,JBHK.V.PP.NOSTRO103.INP,PAYMENT.ORDER,JBHK.V.PP.NOSTRO202.INP,PAYMENT.ORDER,JBHK.V.PP.NOST103COV.INP
*-----------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-----------------------------------------------------------------------------------------------------------------------------------
*06/08/2024   LAKSHMI PRIYA KS               CBPAY-439           Based on the PAYMENT.CURRENCY and PAYMENT.CHANNEL ,
*                                                                         ORDER.INITIATION.TYPE is defaulted .
*17/02/2025    PRABHU                        CBPAY-1705          Excluded the condition for assigning the ORDER.INITIATION.TYPE field value
*------------------------------------------------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE 
    $INSERT I_F.PAYMENT.ORDER
    
    Y.PAY.CCY = R.NEW(PO.PAYMENT.CURRENCY)
 
    CALL GET.LOC.REF('PAYMENT.ORDER','L.PO.HKPAY.CHNL',Y.POS)

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","ORD.INIT.TYPE.CURRENCY",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE
    Y.LOC.REF = R.NEW(PO.LOCAL.REF)<1,Y.POS>
    IF NOT(Y.PAY.CCY MATCHES Y.GPM.VALUE) AND NOT(R.NEW(PO.LOCAL.REF)<1,Y.POS> EQ 'SWIFTMX') THEN
        AF = PO.ORDER.INITIATION.TYPE
        ETEXT = 'EB-JB.D.PP.CHKORDINIT.TYPE':@FM:Y.PAY.CCY
        CALL STORE.END.ERROR
    END
 
RETURN

END
