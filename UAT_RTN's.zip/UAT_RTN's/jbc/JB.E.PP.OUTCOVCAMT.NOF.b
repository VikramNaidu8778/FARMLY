SUBROUTINE JB.E.PP.OUTCOVCAMT.NOF(Y.ARR)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is NoFile Routine to display Customer initiated Swift Out Cov Payments and attached to the enquiry JB.E.PP.SWMXOUTCNCLCUST.VIEW.
*-------------------------------------------------------------------------
* Attached: As NoFile routine to JB.E.PP.SWMXOUTCNCLCUST.VIEW.
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*---------------------------------------------------------------------------------------------------------------------
* Date             Developer        Reference       Description
*03-06-2024        Hariharan T      CBPAY-93        This is NoFile Routine to display Customer initiated Swift Out Cov Payments and attached to the *                                                   enquiry JB.E.PP.SWMXOUTCNCLCUST.VIEW.
*---------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDARD.SELECTION
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_ENQUIRY.COMMON
    
*------------------------------------------
   
    GOSUB INITIALIZATION
    GOSUB PROCESS

RETURN

*------------------------------------------
INITIALIZATION:
*------------------------------------------
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,FV.PAYMENT.ORDER)
    

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
    
    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO,FV.POR.SUPPLEMENTARY.INFO)
RETURN
*---------------------------------------
PROCESS:
*---------------------------------------   
R.PAYMENT.ORDER = ''
Y.PO.FT.NO = ''
    
Y.SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH StatusCode EQ '999' AND PaymentDirection EQ 'O' AND CTRBTRIndicator EQ 'C' AND OutgoingMessageType EQ 'pacs.008' AND CoverFlag EQ 'Y'"
CALL EB.READLIST(Y.SEL.CMD,Y.FT.ID.LIST,'',NO.OF.POR.TRANSACTION.RECS,POR.TRANS.ERR)
    
LOOP
    REMOVE Y.FT.ID FROM Y.FT.ID.LIST SETTING FT.POS
    WHILE Y.FT.ID:FT.POS
               
        CALL F.READ(FN.POR.SUPPLEMENTARY.INFO, Y.FT.ID, R.POR.SUPP.INFO, F.POR.SUPPLEMENTARY.INFO, POR.SUPP.INFO.ERR)
        Y.RECALL.STATUS = R.POR.SUPP.INFO<PORID.RECALL.STATUS>
				          
        IF Y.RECALL.STATUS EQ "" THEN
                
            ENQ.SELECTION<1,1> = "SWIFTMX.OUT.CANCEL.CUST"
            ENQ.SELECTION<2,1> = "FTNumber"
            ENQ.SELECTION<3,1> = "EQ"
            ENQ.SELECTION<4,1> = Y.FT.ID

            CALL E.NOFILE.PP.SWCR.RECALL.INITIATED(OUT.ARRAY)
            IF ENQ.ERROR EQ "" THEN
                Y.ARR<-1> = OUT.ARRAY
            END ELSE
            END
        END
        
    
REPEAT
   
    
    
    
    



RETURN
END
