* @ValidationCode : MTotMTI4NzM4NDAwMDpJU08tODg1OS0xOjE1MTE3ODA4MTYwMDU6MzExODQ5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 27 Nov 2017 16:36:56
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
    SUBROUTINE JBWW.R.FT.ALTID.CONV
*-----------------------------------------------------------------------------------------
*REFERENCE     DEVELOPER			DESCRIPTION
*JB2A-46012    Lakshmanan           To display first value of the BEN.CUSTOMER
*-----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON


    IF R.RECORD<500> EQ '' THEN
        GOSUB PROCESS
        R.RECORD<500>=Y.DATA.1
        O.DATA=''
    END
    RETURN

PROCESS:
    Y.REC=R.RECORD
    Y.FLD1="BEN.CUSTOMER"
    Y.APP="JBWW.H.FT.STANDINGINSTR"
    CALL GET.STANDARD.SELECTION.DETS(Y.APP,R.SS)

    CALL FIELD.NAMES.TO.NUMBERS(Y.FLD1,R.SS,Y.FIELD.NO1,YAF.1,YAV.1,YAS.1,DATA.TYPE,ERR.MSG)

    Y.CNT=DCOUNT(Y.REC<Y.FIELD.NO1>,@VM)
    I=1
    LOOP
    WHILE I LE Y.CNT
        Y.DATA.1<-1>=Y.REC<YAF.1,I,1>
        I++
    REPEAT


    CHANGE @FM TO @VM IN Y.DATA.1

    RETURN
