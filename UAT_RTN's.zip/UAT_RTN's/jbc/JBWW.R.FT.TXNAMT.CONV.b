SUBROUTINE JBWW.R.FT.TXNAMT.CONV
*Description: To Seprate the values from inputter field.
*-------------------------------------------------------------------------
* Modification History : 
*-----------------------------------------------------------------------------
* Date          Developer                      Reference               Description
*-----------------------------------------------------------------------------
* 03/07/2018    Lakshmanan                     CR DAY15-136            Conversion routine for the TXN AMOUNT Field.
*
* 04/07/2019    Lakshmanan                     T24-15229               Restricted category codes to get credit account number
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_ENQUIRY.COMMON
    $INSERT  I_F.ACCOUNT
*-------------------------------------------------------------------------

    Y.ACC.ID = O.DATA
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT  = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
    F.ACCOUNT.HIS = ''
    CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)
   
    R.ACC.REC = ''
    O.DATA = '0'
    CALL F.READ(FN.ACCOUNT,Y.ACC.ID,R.ACC.REC,F.ACCOUNT,ACC.ERR)
    IF R.ACC.REC<AC.CUSTOMER> THEN
       Y.CATEGORY = R.ACC.REC<AC.CATEGORY>
*       IF ((Y.CATEGORY LE 2999) AND (Y.CATEGORY GE 1000)) THEN
       IF ((Y.CATEGORY LE 9999) AND (Y.CATEGORY GE 1000) AND (Y.CATEGORY[1,1] NE '5') AND (Y.CATEGORY NE '2001') ) THEN
          O.DATA = '1'
       END
    END ELSE
      CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACC.ID,R.ACC.HIS.REC,Y.ACC.ERR)
      IF R.ACC.HIS.REC<AC.CUSTOMER> THEN
      Y.CATEGORY = R.ACC.HIS.REC<AC.CATEGORY>
*      IF ((Y.CATEGORY LE 2999) AND (Y.CATEGORY GE 1000)) THEN
      IF ((Y.CATEGORY LE 9999) AND (Y.CATEGORY GE 1000) AND (Y.CATEGORY[1,1] NE '5') AND (Y.CATEGORY NE '2001') ) THEN
         O.DATA = '1'
      END
      END
    END

    RETURN
    END
*-------------------------------------------------------------------------
