SUBROUTINE JB.R.PP.SELPOPRD.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*Attached in : ENQUIRY>JB.E.PP.PAYPENPROCESS.LIST
*Attached as : Build Routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer       Reference        Description
*------------------------------------------------------------------------------
*13-FEB-2025       Lakshmi Priya    CBPAY-1892     Build routine to display the payments based on the payment order product configured in JBWW.H.EB.GENERICPARAMETER>JB.D.PP.TPH.CONFIG
*-----------------------------------------------------------------------------

   
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ENQUIRY
    $INSERT I_F.PAYMENT.ORDER
    
    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS

RETURN
*****
INIT:
*****
    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)
  
RETURN


*****************
GET.PARAM.VALUES:
*****************

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","PO.PRD",Y.GPM.FLD.VALUES)
    CONVERT "," TO @VM IN Y.GPM.FLD.VALUES
       
RETURN

PROCESS:
********
   Y.SEL.CMD = "SELECT ":FN.PAYMENT.ORDER.NAU:" WITH PAYMENT.ORDER.PRODUCT MATCHES ":Y.GPM.FLD.VALUES
  
   GOSUB FORM.SEL.CMD
   Y.SEL.CMD := Y.SEL.OPER
  

  CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',Y.SEL.CNT,'')
 
  CHANGE FM TO ' ' IN Y.SEL.LIST

  ENQ.DATA<2> = '@ID'
  ENQ.DATA<3> = 'EQ'
  ENQ.DATA<4> = Y.SEL.LIST

 
  ENQ$SKIP.FLAG = 1

      
RETURN

FORM.SEL.CMD:
************
   Y.CNT = DCOUNT(ENQ.DATA<2>,VM)
   FOR I = 1 TO Y.CNT
   
    Y.SEL.OPERAND = ENQ.DATA<3,I>
    BEGIN CASE
         CASE Y.SEL.OPERAND EQ "BW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LK ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "EW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LK ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "CT"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LK ...":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNBW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UL ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNEW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UL ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND MATCHES "EQ":VM:"NE":VM:"GT":VM:"GE":VM:"LT":VM:"LE"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" ":Y.SEL.OPERAND:" ":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND MATCHES "LK":VM:"UL"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" ":Y.SEL.OPERAND:" ":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "RG"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" GE ":Y.TEMP.DATA<1,1>:" AND ":ENQ.DATA<2,I>:" LE ":Y.TEMP.DATA<1,2>:")"
         CASE Y.SEL.OPERAND EQ "NR"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" LT ":Y.TEMP.DATA<1,1>:" OR ":ENQ.DATA<2,I>:" GT ":Y.TEMP.DATA<1,2>:")"
    END CASE

   NEXT I
    

RETURN
       
END  
