* @ValidationCode : MTotMTk2ODkzNDMzNDpJU08tODg1OS0xOjE2MDE4MTI1Mjk5MTI6YTM4OTYwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4xMQ==
* @ValidationInfo : Timestamp         : 04 Oct 2020 19:55:29
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
*-----------------------------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------------------------
SUBROUTINE JB.B.SC.STOVER.CORRECTION.LOAD
*-----------------------------------------------------------------------------------------------
* Description:
*-----------------------------------------------------------------------------------------------
*-----------------------------------------------------------------------------------------------
* Revision History:
*-----------------------------------------------------------------------------------------------

*04/09/2024     CBGBB-10335    This is the ONE-TIME correction routine to be executed to update the FT.VERSION field in existing STO records with the new STP version name replacing current version name
*-----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_JB.B.SC.STOVER.CORRECTION.COMMON
    
    FN.STANDING.ORDER = 'F.STANDING.ORDER'
    F.STANDING.ORDER = ''
    CALL OPF(FN.STANDING.ORDER,F.STANDING.ORDER) 
    
RETURN
END