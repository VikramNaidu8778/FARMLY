*----------------------------------------------------------------------------------
    SUBROUTINE JBWW.E.FT.STO.CONV
*----------------------------------------------------------------------------------
* Description: Conversion routine to display STO reference in the below enquiries,
*ENQUIRY>JBWW.E.FT.VALUE.DT.AMEND
*ENQUIRY>JBWW.E.FT.AUTH.NAU
*ENQUIRY>JBWW.E.FT.REVERSE
*ENQUIRY>JBWW.E.FT.UNAUTH.TXN 
*----------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: - NA- 
* OUT: O.DATA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------
* Date               who               Reference          Description
* 03-03-2016        Balaji             JB2A-23356         Initial Version
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
                			
   Y.INWARD.PAY.TYPE = O.DATA
   Y.STO.IDN = FIELD(Y.INWARD.PAY.TYPE,"-",1)
   Y.STO.ACC = FIELD(Y.INWARD.PAY.TYPE,"-",3)
   Y.STO.SEQ = FIELD(Y.INWARD.PAY.TYPE,"-",4)
    IF (Y.STO.IDN EQ "STO") OR (Y.STO.IDN EQ "BULK.STO") THEN
	   Y.STO.ID = Y.STO.ACC:".":Y.STO.SEQ
	   O.DATA = Y.STO.ID
	 END
	   RETURN
END


