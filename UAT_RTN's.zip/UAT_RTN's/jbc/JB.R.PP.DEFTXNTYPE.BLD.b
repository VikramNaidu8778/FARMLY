SUBROUTINE JB.R.PP.DEFTXNTYPE.BLD(ENQ.DATA)
*--------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 06-Jun-2025   P Amala                                CBPAY-3002             Initial Draft
*
* Description : Routine to List the payments based on Txn Types.
* Attached to : ENQUIRY>JBSG.E.PP.PAYPENPROCESS.LIST / JBHK.E.PP.PAYPENPROCESS.LIST
* Attached as : BUILD.ROUTINE
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
   
    GOSUB INIT

    LOCATE 'IncomingMessageType' IN ENQ.DATA<2,1> SETTING YTXN.POS THEN
       Y.TXN.ID = ENQ.DATA<4,YTXN.POS>
    CHANGE ' ' TO VM IN Y.TXN.ID
    CHANGE SM TO VM IN Y.TXN.ID
    END ELSE
        RETURN
    END
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS

RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
   
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)
    YTXN.POS = '' ; Y.FNL.SEL.LIST = '' ; Y.TISTXNCD.VAL = ''
    Y.TISMSGTYP.VAL = '' ; R.POR.TRANSACTION.REC = '' ; PORT.ERR = ''
    
RETURN
*****************
GET.PARAM.VALUES:
*****************
* In this para of the program, the GPM details are fetched
** 
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","TIS.TXNCODE",Y.TISTXNCD.VAL)
    CHANGE ',' TO VM IN Y.TISTXNCD.VAL
    CHANGE FM TO VM IN Y.TISTXNCD.VAL

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","TIS.MSGTYPE",Y.TISMSGTYP.VAL)
    CHANGE ',' TO VM IN Y.TISMSGTYP.VAL
    CHANGE FM TO VM IN Y.TISMSGTYP.VAL
       
RETURN

********
PROCESS:
********

   BEGIN CASE

     CASE Y.TXN.ID EQ 'IRRT'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'I' AND ClearingTransactionType EQ 'RT' AND IncomingMessageType EQ 'pacs.004' "
     CASE Y.TXN.ID EQ 'IRRJ'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'B' AND ClearingTransactionType EQ 'RJ' AND IncomingMessageType EQ 'pacs.002' "
     CASE Y.TXN.ID EQ 'ORRT'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'O' AND ClearingTransactionType EQ 'RT' AND IncomingMessageType EQ 'pacs.008' "
     CASE Y.TXN.ID EQ 'ORRJ'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'B' AND IncomingMessageType EQ 'pacs.002' "
     CASE Y.TXN.ID[1,4] EQ 'ITCV' OR Y.TXN.ID[1,4] EQ 'ITSL'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'I' AND IncomingMessageType EQ 'pacs.009' "
     CASE Y.TXN.ID EQ 'IT'
          SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'I' AND (IncomingMessageType EQ 'pacs.008' OR IncomingMessageType EQ '103') "
     CASE Y.TXN.ID EQ 'OT20'
         SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND PaymentDirection EQ 'O' AND IncomingMessageType EQ 'pacs.009' "
     CASE OTHERWISE
         SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID:" AND IncomingMessageType EQ ":Y.TXN.ID      
    END CASE

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST EQ '' THEN
        ENQ.ERROR = "No records found to display"
    END ELSE
        LOOP
            REMOVE SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.ID : SEL.POS
            Y.FT.NO = SEL.ID

            CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FV.POR.TRANSACTION,PORT.ERR)

            IF R.POR.TRANSACTION.REC THEN
               Y.FNL.SEL.LIST<-1> = Y.FT.NO
            END
        REPEAT
  
      CHANGE FM TO ' ' IN Y.FNL.SEL.LIST

        ENQ.DATA<2,YTXN.POS> = '@ID'
        ENQ.DATA<3,YTXN.POS> = 'EQ'
        ENQ.DATA<4,YTXN.POS> =  Y.FNL.SEL.LIST
    END
RETURN
**********************************************************************************************
END