*----------------------------------------------------------------------------------------------------------------
SUBROUTINE JB.B.XX.MOVERLCOE.SELECT
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the select routine of the multi thread job that moves the few application
* records placed for authorization
*----------------------------------------------------------------------------------------------------------------
* Attached: to 
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date           Developer           Reference             Description
* 04-Jun-2025    Prabhu D S          CBPAY-2933            Initial Draft
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_F.COMPANY
    $INSERT I_JB.B.XX.MOVEOE.COMMON

    COMP.MNE = R.COMPANY(EB.COM.MNEMONIC)

    SEL.CMD = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH ProcessCompany EQ '":COMP.MNE:"' AND Status EQ '315'"
    CALL EB.READLIST(SEL.CMD,SEL.LIST,NO.OF.REC,"",SEL.ERR)
    CALL BATCH.BUILD.LIST("",SEL.LIST)

    RETURN
END

