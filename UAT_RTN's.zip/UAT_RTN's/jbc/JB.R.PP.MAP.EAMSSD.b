* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 914815
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
* Description : To fetch local reference field position in EAM SSD fileupload in
*Routine attached to the version PAYMENT.ORDER,PI.API.EAMSSD.1.0.0
*--------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*02/04/2024	Murali krishnan H			CBPAY-9		To fetch local reference field position in EAM SSD fileupload in
*									Payment order
*--------------------------------------------------------------------------------------------------------------------------------------------------------


SUBROUTINE JB.R.PP.MAP.EAMSSD

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.PAYMENT.ORDER
	$INSERT I_F.ALTERNATE.ACCOUNT
	$INSERT I_F.ACCOUNT
	$INSERT I_F.MNEMONIC.CUSTOMER
	$INSERT I_F.CUSTOMER

	IF MESSAGE NE 'VAL' THEN
		IF V$FUNCTION EQ 'I' OR V$FUNCTION EQ 'C' THEN
			GOSUB INIT
			GOSUB PROCESS
		END
	END
*
RETURN
*
*****
INIT:
*****

	GOSUB OPEN.FILES
	GOSUB GET.LRF.POS
*
RETURN
*
********
PROCESS:
********

	IF COMI THEN
		BEGIN CASE
            CASE AF EQ PO.DEBIT.ACCOUNT
                GOSUB GET.ACCT.NO
                COMI = Y.DEBIT.ACCT
            CASE AF EQ PO.BENEFICIARY.ACCOUNT.NO
                GOSUB GET.BEN.ACCT.NO
                COMI = Y.BEN.ACCT
		END CASE
	END
*
RETURN
*
***********
OPEN.FILES:
***********

	FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
	F.ALTERNATE.ACCOUNT = ''
	CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
	
	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	FN.MNEMONIC.CUSTOMER = 'F.MNEMONIC.CUSTOMER'
	F.MNEMONIC.CUSTOMER = ''
	CALL OPF(FN.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER)
	
	FN.CUSTOMER = 'F.CUSTOMER'
	F.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
*
RETURN
*
************
GET.LRF.POS:
************

	LR.APPL = 'CUSTOMER'
	LR.FIELDS = 'L.ST.EAM.ZHACCT'
	LR.POS = ''
	CALL MULTI.GET.LOC.REF(LR.APPL,LR.FIELDS,LR.POS)
	Y.EAM.ZHAC.POS = LR.POS<1,1>
*
RETURN
*
************
GET.ACCT.NO:
************

	Y.EAM.ACCT = COMI
	R.ALTERNATE.ACCOUNT = ''
	E.ALTERNATE.ACCOUNT = ''
	CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.EAM.ACCT,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,E.ALTERNATE.ACCOUNT)
	
	IF R.ALTERNATE.ACCOUNT THEN
		Y.DEBIT.ACCT = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
	END ELSE
		Y.DEBIT.ACCT = Y.EAM.ACCT
	END
*
RETURN
*
***********
GET.DB.CCY:
***********

	YR.ACCOUNT = ''
	YE.ACCOUNT = ''
	CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT,YR.ACCOUNT,F.ACCOUNT,YE.ACCOUNT)
	Y.DEBIT.CCY = YR.ACCOUNT<AC.CURRENCY>
*
RETURN
*
****************
GET.BEN.ACCT.NO:
****************

	Y.AGENT.CODE = COMI
	R.MNEMONIC.CUSTOMER = ''
	E.MNEMONIC.CUSTOMER = ''
	CALL F.READ(FN.MNEMONIC.CUSTOMER,Y.AGENT.CODE,R.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER,E.MNEMONIC.CUSTOMER)
	Y.CUS.ID = R.MNEMONIC.CUSTOMER<EB.MCU.CUSTOMER>
	R.CUSTOMER = ''
	E.CUSTOMER = ''
	CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,E.CUSTOMER)
	Y.BEN.ACCT = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.EAM.ZHAC.POS>
*
RETURN
*
END
*
