* @ValidationCode : MjotMzQ3NDI5NzQ0OkNwMTI1MjoxNzE1MTQ4NTA1Mjc0OjkxNDgxNTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDIzMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 19 Dec 2024 11:38:25
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202408.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

$PACKAGE PP.RoutingAndSettlementService
SUBROUTINE JB.R.PP.RSTRCTINCACC.CPDHOOK(iTransactionDetails,iCreditPartyDetails,HookResponse)
*------------------------------------------------------------------------------
* Description :
* Routine attached in PP.COMPONENT.HOOK.API>CreditPartyDetermination
* API routine to block Payment Order with DR/CR acct being an Income account
* with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date              Developer        Reference          Description
*
* 17/04/2024        Murali Krishnan H    CBPAY-39       API routine to block Payment Order with DR/CR acct being an Income account
*                                                       with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*                                                       with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*
*08/07/2024         Lakshmi Priya K S    CBPAY-548     Raise a Warning if Account is not found for Payment Currency received in incoming pacs.008.
*
*19/12/2024         Vikram Pavuluru      CBPAY-1282     Added logic to supress Send Swift,MT210/camt.059,MT202/pacs.009 Messages for Money Market,Supress Send Payment for Fiduciary.
*
*12/02/2025         Resmi R              CBPAY-1882     Included logic to get Alternate ID from the Credit Account number
*
*21/02/2025         Prabhu D S           CBPAY-1927     Logic included to default Txn Type for Outward Return Payments
*
*27/03/2025         Vikram Pavuluru      CBPAY-2276     Modified the logic to fetch Payment currency from POR.TRANSACTION.
*31/03/2025         Resmi R              CBPAY-2090     Updated the logic for fetching parameter values from JBWW.H.EB.GENERICPARAMETER>JB.D.PP.TPH.CONFIG to F.READ instead of call Api
*
*30/04/2025       Lakshmi Priya K S      CBPAY-2217     Modified the logic to fetch POR.SUPPLEMENTARY.INFO details using FRead instead of GetSupplementaryInfo call API.
*
*07/05/2025       Lakshmi Priya K S      CBPAY-2246     Updated logic to Fetch Supplementary Info Details using Call API from Internal Table POR.INFORMATION .
*
*09/05/2025         P Amala              CBPAY-2217     Reversing above changes of reading PorSupplementaryInfo logic.
*
*15/05/2025         Prabhu D S           CBPAY-2916     L.PO.DEF.INW.IT should not be defaulted for TRSY payments.
*
*05/06/2025         Resmi R              CBPAY-2923     Fixed the logic such that transaction type wont be defaulted for outgoing payments triggered from Payment Order
*
*18/06/2025         P Amala              CBPAY-2936     Fixed the logic  to check creditcurrency against with paymentcurrency and raise warning message if not equal for the incoming message.
*------------------------------------------------------------------------------------------------------------------------------------------------------

*-------------------------------------------------------------------------------------------------------------------------------------------------------
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.CreditPartyDeterminationService
    $USING SC.ScoPortfolioMaintenance
    $USING AC.AccountOpening
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $USING PP.StaticDataGUI
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentLifecycleHook
    $USING FX.Contract
    $USING MM.Contract
    $USING FD.Contract
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    iPaymentID=iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
        
    PP.PaymentWorkflowDASService.getPaymentRecord(iPaymentID, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)
    GOSUB INIT
    GOSUB UPDATE.TXNCODES
    IF ((oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ctrBtrIndicator>="C") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.paymentDirection>="I") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.repairFlag>='')) THEN
        GOSUB GET.ACCT.DETAILS
        GOSUB PROCESS
        RETURN
    END
RETURN

*****
INIT:
*****

    FN.ACC = 'F.ACCOUNT' ; F.ACC = '' ; R.ACC = ''
    EB.DataAccess.Opf(FN.ACC, F.ACC)

    FN.ALT.ACC = 'F.ALTERNATE.ACCOUNT' ; F.ALT.ACC = '' ; R.ALT.ACC = '' ; ALT.ERR = ''
    EB.DataAccess.Opf(FN.ALT.ACC, F.ALT.ACC)

    FN.SAMN = 'F.SEC.ACC.MASTER.ACCOUNT.NAME' ; F.SAMN = '' ; R.SAMN = ''
    EB.DataAccess.Opf(FN.SAMN, F.SAMN)

    FN.SAM = 'F.SEC.ACC.MASTER'  ;  F.SAM = '' ; R.SAM = ''
    EB.DataAccess.Opf(FN.SAM, F.SAM)

    FN.ERRCODE='F.PP.ERRORCODE' ; F.ERRCODE='' ; R.ERRCODE=''
    EB.DataAccess.Opf(FN.ERRCODE, F.ERRCODE)

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    EB.DataAccess.Opf(FN.POR.TRANSACTION, F.POR.TRANSACTION)

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    EB.DataAccess.Opf(FN.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO)

    FN.PP.POR.EXTENSION = 'F.PP.POR.EXTENSION'
    F.PP.POR.EXTENSION = ''
    EB.DataAccess.Opf(FN.PP.POR.EXTENSION,F.PP.POR.EXTENSION)
    
    FN.FOREX = 'F.FOREX'
    F.FOREX = ''
    EB.DataAccess.Opf(FN.FOREX,F.FOREX)
    
    FN.MONEYMARKET = 'F.MM.MONEY.MARKET'
    F.MONEYMARKET = ''
    EB.DataAccess.Opf(FN.MONEYMARKET,F.MONEYMARKET)

    FN.FD.FIDUCIARY = 'F.FD.FIDUCIARY'
    F.FD.FIDUCIARY = ''
    EB.DataAccess.Opf(FN.FD.FIDUCIARY,F.FD.FIDUCIARY)
    
    FN.GENERICPARAM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.GENERICPARAM = ''
    EB.DataAccess.Opf(FN.GENERICPARAM,F.GENERICPARAM)
    
    yCrAccount = ''
    yAltAccPos=''
    yAltAccVal=''
    yAltAccValue=''
    yCurrencyCode = ''
    SAM.ERR = ''
    INC.POS=''
    Y.POS=''
    yPos = ''
    iPaymentID = ''
    yCcyFlag = 0
    ySenderCorrBic = ''
	yCrAccCcy = ''
    iPaymentID=iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
    yCompanyID = iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.companyID>

RETURN
   
UPDATE.TXNCODES:
****************

    EB.DataAccess.FRead(FN.POR.TRANSACTION,iPaymentID,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)
    yPaymentDirection = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxPaymentdirection>
    yTransactionType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxClearingtransactiontype>
    yPaymentCcy = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxTransactioncurrencycode>
        
    IF (yPaymentDirection EQ 'I') OR (yPaymentDirection EQ 'B') THEN
        yMessageType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxIncomingmessagetype>

    END ELSE
        BEGIN CASE

            CASE yTransactionType EQ 'RT'
                yMessageType = 'pacs.004'
       
            CASE yTransactionType EQ 'RJ'
                yMessageType = 'pacs.002'

        END CASE
    END
    
       
    yValdationFlag = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxValidationflag>

    PP.PaymentWorkflowGUI.getSupplementaryInfo('POR.PAYMENTFLOWDETAILS', iPaymentID,'LOCK',R.POR.GET.SUPPLEMENTARY.INFO, Error)
    Y.PI.INF.CODE = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INFORMATIONCODE>

    LOCATE 'INSSDR' IN Y.PI.INF.CODE<1,1> SETTING Y.PI.INF.POS THEN
        Y.PI.INF.LINE = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INFORMATION.LINE,Y.PI.INF.POS>
        Y.PI.INF.LINE  = FIELD(Y.PI.INF.LINE,"/",3)
        Y.PI.INF.LINE  = Y.PI.INF.LINE [1,3]
    END
    
    CALL F.READ(FN.GENERICPARAM,'JB.D.PP.TPH.CONFIG',R.GP,F.GENERICPARAM,'')
    Y.GPM.FIELDNAMES = R.GP<JBWW.GEN.PAR.FIELD.NAME>
    
    CHANGE @SM TO @VM IN Y.GPM.FIELDNAMES
    
    LOCATE 'TIS.MSGTYPE' IN Y.GPM.FIELDNAMES<1,1> SETTING MSGTYP.POS THEN
        TIS.MSGTYPE = R.GP<JBWW.GEN.PAR.FIELD.VALUE,MSGTYP.POS>
    END

    LOCATE 'TIS.TXNCODE' IN Y.GPM.FIELDNAMES<1,1> SETTING CODE.POS THEN
        TIS.TXNCODE = R.GP<JBWW.GEN.PAR.FIELD.VALUE,CODE.POS>
    END
    
    CHANGE @SM TO @VM IN TIS.MSGTYPE
    CHANGE @SM TO @VM IN TIS.TXNCODE
    CHANGE @FM TO @VM IN TIS.MSGTYPE
    CHANGE @FM TO @VM IN TIS.TXNCODE
    CHANGE ',' TO @VM IN TIS.MSGTYPE
    CHANGE ',' TO @VM IN TIS.TXNCODE

    Y.PP.MSG.DIR = yMessageType:"_":yPaymentDirection
    
    LOCATE Y.PP.MSG.DIR IN TIS.MSGTYPE<1,1> SETTING Y.POS THEN
        Y.TXN.TYPE =  TIS.TXNCODE<1,Y.POS>
    END

    IF yMessageType EQ 'pacs.009' THEN
        BEGIN CASE
            CASE  yValdationFlag EQ 'COV'
                Y.TXN.TYPE = FIELD(Y.TXN.TYPE,"_",1)

            CASE Y.PI.INF.LINE EQ 'SLB'
                Y.TXN.TYPE = FIELD(Y.TXN.TYPE,"_",2)

        END CASE
    END

    IF Y.TXN.TYPE THEN
        Y.DEF.INW = R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldname>
        
        LOCATE 'L.PP.DEF.INW.IT' IN Y.DEF.INW<1,1> SETTING Inwpos THEN
            R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldvalue,Inwpos> = Y.TXN.TYPE
        END ELSE
            R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldname,-1> = 'L.PP.DEF.INW.IT'
            R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldvalue,-1> = Y.TXN.TYPE
        END
        PP.PaymentWorkflowGUI.updateSupplementaryInfo('POR.PAYMENTFLOWDETAILS', iPaymentID, R.POR.GET.SUPPLEMENTARY.INFO, '', Error)
    END

    GOSUB SWIFT.SUPRESS

RETURN

*-------------
SWIFT.SUPRESS:
*-------------

    PP.PaymentWorkflowGUI.getSupplementaryInfo('POR.PAYMENTFLOWDETAILS', iPaymentID,'LOCK',R.POR.GET.SUPPLEMENTARY.INFO, Error)
            
    Y.PP.LOC.FLD.NAME = '' ; Y.L.PP.SEND.PYMT = '' ; Y.SND.FLD.POS = '' ; R.PP.POR.EXTENSION = '' ;
    Y.PP.LOC.FLD.NAME = R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldname>
   
    LOCATE 'L.PP.SEND.PYMT' IN Y.PP.LOC.FLD.NAME<1,1> SETTING Y.SND.FLD.POS THEN
        Y.L.PP.SEND.PYMT = R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldvalue,Y.SND.FLD.POS>
    END
    
    IF Y.L.PP.SEND.PYMT EQ 'NO' THEN
        GOSUB UPDATE.POR.EXTENSION
    END
    
    YmessageUserReference = '' ; R.FOREX = '' ; FOREX.ERR = '' ; Y.TXN.TRADE.TYPE = '' ;
    YmessageUserReference = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxMessageuserreference>
 
** Incoming pacs.008 HKICL: Tracker should not be sent for payments to Clearing - Start
    YorgSource = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxOriginatingsource>
    IF YorgSource EQ 'CHATSMX' AND yMessageType EQ 'pacs.008' AND yPaymentDirection EQ 'I' THEN
        GOSUB UPDATE.POR.EXTENSION
    END
** Incoming pacs.008 HKICL: Tracker should not be sent for payments to Clearing - End
        
    BEGIN CASE
    
        CASE YmessageUserReference[1,2] EQ 'FX'
            Y.APP     = 'FOREX'
            Y.FIELD   = 'L.FX.TRADE.TYPE'
            Y.POS     = ''; Y.FX.LOCAL.REF.POS = ''
            CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.POS)
            Y.FX.LOCAL.REF.POS = Y.POS<1,1>
            EB.DataAccess.FRead(FN.FOREX,YmessageUserReference,R.FOREX,F.FOREX,FOREX.ERR)
            Y.TXN.TRADE.TYPE = R.FOREX<FX.Contract.Forex.LocalRef,Y.FX.LOCAL.REF.POS>
            GOSUB READ.GEN.PARAM
            IF Y.FX.TRADE.TYPE EQ Y.TXN.TRADE.TYPE THEN
                GOSUB UPDATE.POR.EXTENSION
            END
        
        CASE YmessageUserReference[1,2] EQ 'FD'
            
            EB.DataAccess.FRead(FN.FD.FIDUCIARY,YmessageUserReference,R.FD.FIDUCIARY,F.FD.FIDUCIARY,FD.FIDUCIARY.ERR)
            Y.FD.FIDUCIARY.TYPE = R.FD.FIDUCIARY<FD.Contract.Fiduciary.SendPayment>
            IF Y.FD.FIDUCIARY.TYPE EQ "NO" THEN
                GOSUB UPDATE.POR.EXTENSION
            END

        CASE YmessageUserReference[1,2] EQ 'MM'
    
            EB.DataAccess.FRead(FN.MONEYMARKET,YmessageUserReference,R.MONEYMARKET,F.MONEYMARKET,MONEYMARKET.ERR)
            Y.MM.SEND.PYMT = R.MONEYMARKET<MM.Contract.MoneyMarket.SendPayment>
            Y.APP = "MM.MONEY.MARKET"
            Y.FIELD = 'L.MM.MT202.SUPP'
            Y.POS     = ''; Y.MM.LOCAL.REF.POS = ''
            CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.POS)
                
            Y.MT202.SUPP = R.MONEYMARKET<MM.Contract.MoneyMarket.LocalRef,Y.POS>
                        
            IF Y.MT202.SUPP EQ "NO" OR Y.MM.SEND.PYMT EQ "NO" THEN
                GOSUB UPDATE.POR.EXTENSION
            END
    END CASE
    
    
RETURN
*--------------
READ.GEN.PARAM:
*--------------
    Y.FX.GPM.FLD.NAME = 'FX.TRADE.TYPE'
    Y.FX.TRADE.TYPE = '' ;
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.D.FX.SPENDHPEND.PARAM",Y.FX.GPM.FLD.NAME,Y.FX.GPM.FLD.VALUES)
    Y.FX.TRADE.TYPE = Y.FX.GPM.FLD.VALUES<1>
RETURN

*--------------------
UPDATE.POR.EXTENSION:
*--------------------

    R.PP.POR.EXTENSION<PP.PaymentLifecycleHook.PorExtension.ExtHoldMessage> = 'Y'
    CALL F.WRITE(FN.PP.POR.EXTENSION,iPaymentID,R.PP.POR.EXTENSION)
    
RETURN

*****************
GET.ACCT.DETAILS:
*****************

    yCrAccountNo = iCreditPartyDetails<PP.CreditPartyDeterminationService.DetermineCreditPartyInput.crMainAccNumber>
		
    IF NUM(yCrAccountNo) THEN
        EB.DataAccess.FRead(FN.ACC, yCrAccountNo, R.ACC, F.ACC, Err)
        LOCATE "BJB.ACCT" IN R.ACC<AC.AccountOpening.Account.AltAcctType,1> SETTING yAltAccPos THEN
            yCrAccount= R.ACC<AC.AccountOpening.Account.AltAcctId,yAltAccPos>
			yCrAccCcy = R.ACC<AC.AccountOpening.Account.Currency>
        END
    END
  
RETURN
********
PROCESS:
********

    LOCATE "BJB.ACCT" IN R.ACC<AC.AccountOpening.Account.AltAcctType,1> SETTING yAltAccPos THEN
        yAltAccVal= R.ACC<AC.AccountOpening.Account.AltAcctId,yAltAccPos>
        yAltAccValue=FIELD(yAltAccVal,'-',1):'-':FIELD(yAltAccVal,'-',2)
    END
    	
    EB.DataAccess.FRead(FN.SAMN, yAltAccValue, R.SAMN, F.SAMN, Err)
    IF R.SAMN  THEN
        SamId = FIELD(R.SAMN,'*',2)
    END

    EB.DataAccess.FRead(FN.SAM, SamId, R.SAM, F.SAM, Err)
    Err=''
    IF R.SAM THEN
	
* Fixed the logic  to check creditcurrency against with paymentcurrency and raise warning message if not equal for the incoming message.	
*        LOCATE yPaymentCcy IN R.SAM<SC.ScoPortfolioMaintenance.SecAccMaster.ScSamAccountCcy,1> SETTING Y.POS ELSE 
         IF yPaymentCcy NE yCrAccCcy THEN
            iErrorTableKey<PP.PaymentFrameworkService.ErrorTableKey.errorCode> = 'CPD90002'
            PP.PaymentFrameworkService.getErrorDetails(iErrorTableKey, oErrorDetails, oGetErrTypeError)
            yErrorDetails = oErrorDetails<PP.PaymentFrameworkService.ErrorDetails.errorText>
            yErrorDetails = EREPLACE(yErrorDetails,"&",yPaymentCcy)
            IF oErrorDetails THEN
                IF HookResponse THEN
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode , -1> = "CPD90002"
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "WAR"
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = yErrorDetails
                END ELSE
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode> = "CPD90002"
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType> = "WAR"
                    HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText> = yErrorDetails
                END
            END
        END
    END
      
RETURN
*--------------------------------------------------------------------------------------------------------
END
