* @ValidationCode : MjoxMjA4NDgyMzMwOkNwMTI1MjoxNzEyODk3NzkxNDk4OjIxMTcwNzg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAyMzEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 12 Apr 2024 10:26:31
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

*--------------------------------------------------------------------------------------------------

SUBROUTINE JB.R.PP.BENEFICIARY.DEFAULT
*--------------------------------------------------------------------------------------------------
* Description: This Auto New Content routine is used to default Beneficiary Customer
*---------------------------------------------------------------------------------------------------
* Modification History :
*
*---------------------------------------------------------------------------------------------------
* Date              Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
 
*03-APR-2024       Vikram Pavuluru       JBWW.R.FT.BENEFICIARY.DEFAULT  Defaulting Beneficiary Customer field
*--------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
 
   
    GOSUB PROCESS
        
RETURN
 
PROCESS:
********

   
    R.NEW(PO.BENEFICIARY.NAME) = "BANK JULIUS BAER AND CO LTD ZURICH EAM TAX SSD"
      
RETURN
END

