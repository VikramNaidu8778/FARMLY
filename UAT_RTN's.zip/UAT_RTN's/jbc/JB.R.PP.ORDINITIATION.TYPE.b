* @ValidationCode : MjoxMzI4ODU4ODM2OkNwMTI1MjoxNzEyNTc0MTczNjI5OjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 09 May 2024 16:32:53
* @ValidationInfo : Encoding          : Cp12521
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.R.PP.ORDINITIATION.TYPE(PO.ID,R.PAYMENT.ORDER,COMP.ID,RESERVED.IN,SUXS.FAIL,ERR.DETS,OVERRIDE.DETS)
*-----------------------------------------------------------------------------------------------------
*This is the validation routine attached to the field ORDER.INITIATION.TYPE in OTO3 & OT22 versions
*Attached: to version PAYMENT.ORDER,JB.V.PP.NOSTRO103.INP & PAYMENT.ORDER,JB.V.PP.NOSTRO202.INP
*-----------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*22/05/2024     Resmi R                    CBPAY-329 & CBPAY-330     Based on the PAYMENT.CURRENCY, ORDER.INITIATION.TYPE & ORDER.TYPE values field PAYMENT.CATEGORYPURP.PRTY is defaulted
*
*17/02/2025     Resmi R                    CBPAY-1705	             Amended the logic for fetching the Category Purpose Proprietary field value
*
*25/03/2025  Lakshmi Priya                CBPAY - 2037              Order Initiation type default is only limited to PO and not applicable for STO Payments.
*                                                                    And Category purpose code is applicable for both PO and STO Payments . 	
*04/04/2025  Lakshmi Priya 		  CBPAY - 1971              For Swiftmx Payment ,Category Purpose code and order Initiation type is 
*                                                                       defaulted only for PO . 
*28/06/25    Prabhu D S                   CBPAY-2677                Included logic to handle HKCHATS scenario		
*--------------------------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

 
    GOSUB INIT
    GOSUB READ.GPM
    GOSUB PROCESS

RETURN

INIT:
*****

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    Y.ORD.INIT.TYPE = '' ; Y.PAYMENT.CURRENCY = '' ; Y.ORDER.TYPE = ''
    R.GENERICPARAMETER = '' ; Y.GPM.FIELD.NAMES = '' ; Y.GPM.FIELD.VALUES = ''

   CALL GET.LOC.REF('PAYMENT.ORDER','L.PO.HKPAY.CHNL',Y.POS)
	
    Y.PAY.CCY = R.PAYMENT.ORDER<PO.PAYMENT.CURRENCY>
    Y.ORDER.TYPE = R.PAYMENT.ORDER<PO.ORDER.TYPE>
   Y.ORDERING.REF = R.PAYMENT.ORDER<PO.ORDERING.REFERENCE>


RETURN

READ.GPM:
*********

   Y.GPM.FIELD.NAMES = "HKCHATS_CCY_":UPCASE(Y.ORDER.TYPE):"_MXCHATS"
   CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.FIELD.NAMES,Y.GPM.FIELD.VALUES)
	   
   Y.GPM.CCY = FIELD(Y.GPM.FIELD.VALUES,"_",2)
   CHANGE ',' TO @VM IN Y.GPM.CCY

  
RETURN

PROCESS:
********
  
    IF Y.PAY.CCY MATCHES Y.GPM.CCY THEN
	    BEGIN CASE
		CASE R.PAYMENT.ORDER<PO.LOCAL.REF,Y.POS> EQ 'HKCHATS' AND Y.ORDERING.REF EQ ''
                    R.PAYMENT.ORDER<PO.ORDER.INITIATION.TYPE> = 'MXCHATS'
	            Y.ORD.INIT.TYPE = 'MXCHATS'
	            GOSUB DEFAULT.CATEG.PURP.CODE
                CASE R.PAYMENT.ORDER<PO.LOCAL.REF,Y.POS> EQ 'SWIFTMX' AND Y.ORDERING.REF EQ ''
                     R.PAYMENT.ORDER<PO.ORDER.INITIATION.TYPE> = 'POA'
                     R.PAYMENT.ORDER<PO.PAYMENT.CATEGORYPURP.PRTY> = ''
		CASE R.PAYMENT.ORDER<PO.LOCAL.REF,Y.POS> EQ 'HKCHATS' AND Y.ORDERING.REF NE ''
	            GOSUB DEFAULT.CATEG.PURP.CODE
                
            END CASE
   
    END ELSE

         R.PAYMENT.ORDER<PO.PAYMENT.CATEGORYPURP.PRTY> = ''

   END



RETURN
DEFAULT.CATEG.PURP.CODE:
************************

      Y.HKCHATS.PRTY = FIELD(Y.GPM.FIELD.VALUES,"_",1)

      Y.HKCHATS.CCY = FIELD(Y.GPM.FIELD.VALUES,"_",2)

      CHANGE "," TO @VM IN Y.HKCHATS.CCY

    IF Y.PAY.CCY MATCHES Y.HKCHATS.CCY THEN
       R.PAYMENT.ORDER<PO.PAYMENT.CATEGORYPURP.PRTY> = Y.HKCHATS.PRTY
    END

RETURN

*---------------------------------------------------------------------------------------------------------
END
