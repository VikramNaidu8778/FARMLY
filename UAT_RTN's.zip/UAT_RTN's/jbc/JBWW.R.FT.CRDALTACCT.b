*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.CRDALTACCT
*-----------------------------------------------------------------------------
* Description: This routine used to fetch DEBIT Alternate Account
*-----------------------------------------------------------------------------
* * Attached: This is the validate routine attached to Enquires JBWW.E.FT.DATECHECK.LIST and JBWW.E.FT.DATEAPPROVE.LIST
*
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_ENQUIRY.COMMON
$INSERT I_F.ACCOUNT
$INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
   
	Y.ACCT.ID = ''
	Y.STO.ACCT = ''
	Y.FT.ACCT = ''
	Y.ALT.ID = ''
	Y.FT.ID = ''
   
	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER$NAU'
	F.FUNDS.TRANSFER = ''
	CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
	 
	Y.FT.ID = O.DATA
	CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FT,F.FUNDS.TRANSFER,FT.ERR)
	
	Y.CR.ACC = R.FT<FT.CREDIT.ACCT.NO>
	Y.ALT.ID = Y.CR.ACC
	GOSUB ACC.ID
	RETURN 
*****************************************************	
 ACC.ID:
*********************************************************
	
	Y.FT.ACCT = Y.ALT.ID
	Y.STO.ACCT = FIELD(Y.FT.ACCT,'.',1)
   
	IF Y.STO.ACCT THEN
		Y.ACCT.ID = Y.STO.ACCT
	END ELSE
		Y.ACCT.ID = Y.FT.ACCT
	END

	
	R.ACC.REC = ''
	ACCT.ERR = ''
	CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACC.REC,F.ACCOUNT,ACCT.ERR)
	
	ALT.ACCT.TYPE = R.ACC.REC<AC.ALT.ACCT.TYPE>
	ALT.ACCT.IDS = R.ACC.REC<AC.ALT.ACCT.ID>

	LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
		    Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
	END ELSE
	
     Y.AC.ALT.ID = ''
	 END
	 
	 O.DATA = Y.AC.ALT.ID
	 
	 	 	
RETURN

END
