* @ValidationCode : MTotMTkxMDQ1MjcyNjpJU08tODg1OS0xOjE1OTY2MDg4MDUyNzk6YTM4OTYwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4xMQ==
* @ValidationInfo : Timestamp         : 05 Aug 2020 14:26:45
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.R.FT.SAPOTSADEF.CHECK
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 05-Aug-2020 - T24-16532
*               Check record rtn for Version FUNDS.TRANSFER,JBWW.V.FT.OT103SAPPAY.INP
*               This routine is to default BEN.OUR.CHARGES in OTSA payment as 'OUR'.
*               This check is in addition to AUTO.NEW.CONTENT to default as OUR as some cases
*               reported by Payment OPS that BEN.OUR.CHARGES is updated as SHA
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
* <region name= Main para>

    BEN.CHARGES = ''
    BEN.CHARGES = R.NEW(FT.BEN.OUR.CHARGES)
    
    IF BEN.CHARGES NE 'OUR' THEN
        R.NEW(FT.BEN.OUR.CHARGES) = 'OUR'
    END

    RETURN
    
* </region>
*-----------------------------------------------------------------------------    
END
