* @ValidationCode : MTotMTczNjIxNzY2NjpJU08tODg1OS0xOjE1MzYwNDA1MTE1MDQ6MzExODQ5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 04 Sep 2018 11:25:11
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.CIDDATAPAGE.NOF(OUT.ARRAY)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
*
* This Nofile routine attached to the enquiry JBWW.E.FT.CIDDATA.EXTRACT
* and it is triggered from EC to extract ID DATA from T24 / CID
*
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY
*
* Dependencies:
*---------------
*
* Revision History:
*-------------------------------------------------------------------------
* Date        Developer         Reference             Description
*-------------------------------------------------------------------------
*
* 03/09/2018  CTS               CID Data Extract- FT  Initial Version
*
* 14/01/2019  CTS               T24-14581             Invalid portfolio selection handled
*
* 20/02/2019  CTS               T24-14581             Closed portfolio selection handled
*-------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COMPANY
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.MNEMONIC.CUSTOMER
    $INSERT I_F.JBWW.L.XX.CLOSEDACCT


    GOSUB INIT
    GOSUB PROCESS

*
    RETURN
*
*-------------------------------------------------------------------------
INIT:
*-------------------------------------------------------------------------

    OUT.ARRAY = ''
    Y.FILTER = ''

    SQL.AC.DELIM = "','"
    Y.FM.CHAR = CHAR(251)
    ACCOUNT.SQL = ''
    CO.ID = R.COMPANY(EB.COM.MNEMONIC)

    Y.ERR = ''
    Y.T24.FILE =  'FUNDS.TRANSFER'
    CALL JBWW.R.XX.GETORACLE.FILENAME(Y.T24.FILE,Y.ORACLE.FILE,Y.ERR)
    Y.ORACLE.LIVE = Y.ORACLE.FILE
    Y.T24.FILE = 'FUNDS.TRANSFER$HIS'
    CALL JBWW.R.XX.GETORACLE.FILENAME(Y.T24.FILE,Y.ORACLE.FILE,Y.ERR)
    Y.ORACLE.HIS = Y.ORACLE.FILE

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)


    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    FN.CUSTOMER.ACCOUNT = 'F.CUSTOMER.ACCOUNT'
    F.CUSTOMER.ACCOUNT = ''
    CALL OPF(FN.CUSTOMER.ACCOUNT,F.CUSTOMER.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)

    FN.MNEMONIC.CUSTOMER = 'F.MNEMONIC.CUSTOMER'
    F.MNEMONIC.CUSTOMER = ''
    CALL OPF(FN.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER)

    FN.JBWW.L.XX.CLOSEDACCT = 'F.JBWW.L.XX.CLOSEDACCT'
    F.JBWW.L.XX.CLOSEDACCT = ''
    CALL OPF(FN.JBWW.L.XX.CLOSEDACCT,F.JBWW.L.XX.CLOSEDACCT)

    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING REF.POS THEN
    Y.TXN.REF = D.RANGE.AND.VALUE<REF.POS>
    Y.TXN.REF = TRIM(Y.TXN.REF)
    GOSUB GET.FT.TXN.REF
    END

    LOCATE 'PORTFOLIO.NO' IN D.FIELDS<1> SETTING PORT.POS THEN
    Y.PORTFOLIO = D.RANGE.AND.VALUE<PORT.POS>
    Y.PORTFOLIO = TRIM(Y.PORTFOLIO)
    END

    LOCATE 'CUSTOMER.NO' IN D.FIELDS<1> SETTING CUST.POS THEN
    Y.CUSTOMER = D.RANGE.AND.VALUE<CUST.POS>
    Y.CUSTOMER = TRIM(Y.CUSTOMER)
    END

    LOCATE 'PROCESSING.DATE' IN D.FIELDS<1> SETTING PDATE.POS THEN
    Y.PR.DATE = D.RANGE.AND.VALUE<PDATE.POS>
    Y.PR.DATE = TRIM(Y.PR.DATE)
    GOSUB GET.PROCESSING.DATE
    END

    LOCATE 'DEBIT.VALUE.DATE' IN D.FIELDS<1> SETTING DV.POS THEN
    Y.DV.DATE = D.RANGE.AND.VALUE<DV.POS>
    Y.DV.DATE = TRIM(Y.DV.DATE)
    GOSUB GET.DEBIT.VALUE.DATE
    END

    LOCATE 'CREDIT.VALUE.DATE' IN D.FIELDS<1> SETTING CV.POS THEN
    Y.CV.DATE = D.RANGE.AND.VALUE<CV.POS>
    Y.CV.DATE = TRIM(Y.CV.DATE)
    GOSUB GET.CREDIT.VALUE.DATE
    END

    LOCATE 'TRANSACTION.TYPE' IN D.FIELDS<1> SETTING TXN.POS THEN
    Y.TXN.TYPE = D.RANGE.AND.VALUE<TXN.POS>
    Y.TXN.TYPE = TRIM(Y.TXN.TYPE)
    GOSUB GET.TXN.TYPE
    END

    LOCATE 'RECORD.STATUS' IN D.FIELDS<1> SETTING STATUS.POS THEN
    Y.REC.STATUS = D.RANGE.AND.VALUE<STATUS.POS>
    Y.REC.STATUS = TRIM(Y.REC.STATUS)
    END

    LOCATE 'PAGE.FROM' IN D.FIELDS<1> SETTING PAGE.FROM.POS THEN
    Y.PAGE.FROM = D.RANGE.AND.VALUE<PAGE.FROM.POS>
    END

    LOCATE 'PAGE.TO' IN D.FIELDS<1> SETTING PAGE.TO.POS THEN
    Y.PAGE.TO = D.RANGE.AND.VALUE<PAGE.TO.POS>
    END

    APPLN.NAME = 'SEC.ACC.MASTER'
    FLD.NAME = 'L.SC.STATUS':VM:'L.SC.CLOSE.DATE'
    CALL MULTI.GET.LOC.REF(APPLN.NAME,FLD.NAME,FLD.POS)
    Y.STATUS.POS = FLD.POS<1,1>
    Y.DATE.POS = FLD.POS<1,2>
    

*
    RETURN
*
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------

    IF (Y.PORTFOLIO NE '') OR (Y.CUSTOMER NE '') THEN
        GOSUB GET.CUSTOMER.ACCOUNT
    END
    BEGIN CASE
        CASE Y.REC.STATUS EQ ''
            *            GOSUB EXTRACT.ALL.FT
            GOSUB EXTRACT.LIVE.FT
        CASE Y.REC.STATUS EQ 'MAT'
            GOSUB EXTRACT.MATURE.FT
        CASE Y.REC.STATUS EQ 'REVE'
            GOSUB EXTRACT.REVERSED.FT
        CASE Y.REC.STATUS EQ 'LIVE'
            Y.REC.STATUS = ''
            GOSUB EXTRACT.LIVE.FT
    END CASE

*
    RETURN
*-------------------------------------------------------------------------
GET.TXN.TYPE:
*-------------------------------------------------------------------------

    IF Y.TXN.TYPE THEN
        IF NOT(Y.FILTER) THEN
            Y.FILTER = " TRANSACTION_TYPE = '":Y.TXN.TYPE:"'"
        END ELSE
            Y.FILTER := " AND TRANSACTION_TYPE = '":Y.TXN.TYPE:"'"
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.DEBIT.VALUE.DATE:
*-------------------------------------------------------------------------

    IF Y.DV.DATE THEN
        TO.DV.DATE = ''
        CONVERT SM TO VM IN Y.DV.DATE
        TOTL.DV.DATE = DCOUNT(Y.DV.DATE,VM)

        I = 1
        LOOP
        WHILE I LE TOTL.DV.DATE
            Y.DATE = Y.DV.DATE<1,I>
            Y.DATE = TRIM(Y.DATE)
            IF Y.DATE THEN
                Y.DV.DATES<1,-1> = Y.DATE
            END
            I += 1
        REPEAT

        TOTL.DV.DATES = DCOUNT(Y.DV.DATES,VM)
        IF TOTL.DV.DATES EQ '1' THEN
            FROM.DV.DATE = Y.DV.DATES<1,1>
            GOSUB DV.DATE.FILTER.FORM
        END ELSE
            FROM.DV.DATE = Y.DV.DATES<1,1>
            TO.DV.DATE = Y.DV.DATES<1,2>
            GOSUB DV.DATE.FILTER.FORM
        END

    END
*
    RETURN
*
*-------------------------------------------------------------------------
DV.DATE.FILTER.FORM:
*-------------------------------------------------------------------------

    IF Y.FILTER THEN
        IF TO.DV.DATE THEN
            Y.FILTER := " AND DEBIT_VALUE_DATE >= ":SQUOTE(FROM.DV.DATE):" AND DEBIT_VALUE_DATE <= ":SQUOTE(TO.DV.DATE):" "
        END ELSE
            Y.FILTER := " AND DEBIT_VALUE_DATE = ":SQUOTE(FROM.DV.DATE)
        END
    END ELSE
        IF TO.DV.DATE THEN
            Y.FILTER = " DEBIT_VALUE_DATE >= ":SQUOTE(FROM.DV.DATE):" AND DEBIT_VALUE_DATE <= ":SQUOTE(TO.DV.DATE):" "
        END ELSE
            Y.FILTER = " DEBIT_VALUE_DATE = ":SQUOTE(FROM.DV.DATE)
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.CREDIT.VALUE.DATE:
*-------------------------------------------------------------------------

    IF Y.CV.DATE THEN
        TO.CV.DATE = ''
        CONVERT SM TO VM IN Y.CV.DATE
        TOTL.CV.DATE = DCOUNT(Y.CV.DATE,VM)

        I = 1
        LOOP
        WHILE I LE TOTL.CV.DATE
            Y.DATE = Y.CV.DATE<1,I>
            Y.DATE = TRIM(Y.DATE)
            IF Y.DATE THEN
                Y.CV.DATES<1,-1> = Y.DATE
            END
            I += 1
        REPEAT

        TOTL.CV.DATES = DCOUNT(Y.CV.DATES,VM)
        IF TOTL.CV.DATES EQ '1' THEN
            FROM.CV.DATE = Y.CV.DATES<1,1>
            GOSUB CV.DATE.FILTER.FORM
        END ELSE
            FROM.CV.DATE = Y.CV.DATES<1,1>
            TO.CV.DATE = Y.CV.DATES<1,2>
            GOSUB CV.DATE.FILTER.FORM
        END

    END
*
    RETURN
*
*-------------------------------------------------------------------------
CV.DATE.FILTER.FORM:
*-------------------------------------------------------------------------
    IF Y.FILTER THEN
        IF TO.CV.DATE THEN
            Y.FILTER := " AND CREDIT_VALUE_DATE >= ":SQUOTE(FROM.CV.DATE):" AND CREDIT_VALUE_DATE <= ":SQUOTE(TO.CV.DATE):" "
        END ELSE
            Y.FILTER := " AND CREDIT_VALUE_DATE = ":SQUOTE(FROM.CV.DATE)
        END
    END ELSE
        IF TO.CV.DATE THEN
            Y.FILTER = " CREDIT_VALUE_DATE >= ":SQUOTE(FROM.CV.DATE):" AND CREDIT_VALUE_DATE <= ":SQUOTE(TO.CV.DATE):" "
        END ELSE
            Y.FILTER = " CREDIT_VALUE_DATE = ":SQUOTE(FROM.CV.DATE)
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.PROCESSING.DATE:
*-------------------------------------------------------------------------

    IF Y.PR.DATE THEN
        TO.PR.DATE = ''
        CONVERT SM TO VM IN Y.PR.DATE
        TOTL.PR.DATE = DCOUNT(Y.PR.DATE,VM)

        I = 1
        LOOP
        WHILE I LE TOTL.PR.DATE

            Y.DATE = Y.PR.DATE<1,I>
            Y.DATE = TRIM(Y.DATE)
            IF Y.DATE THEN
                Y.PR.DATES<1,-1> = Y.DATE
            END

            I += 1
        REPEAT

        TOTL.PR.DATES = DCOUNT(Y.PR.DATES,VM)
        IF TOTL.PR.DATES EQ '1' THEN
            FROM.PR.DATE = Y.PR.DATES<1,1>
            GOSUB PV.DATE.FILTER.FORM
        END ELSE
            FROM.PR.DATE = Y.PR.DATES<1,1>
            TO.PR.DATE = Y.PR.DATES<1,2>
            GOSUB PV.DATE.FILTER.FORM
        END

    END
*
    RETURN
*
*-------------------------------------------------------------------------
PV.DATE.FILTER.FORM:
*-------------------------------------------------------------------------

    IF Y.FILTER THEN
        IF TO.PR.DATE THEN
            Y.FILTER := " AND PROCESSING_DATE >= ":SQUOTE(FROM.PR.DATE):" AND PROCESSING_DATE <= ":SQUOTE(TO.PR.DATE):" "
        END ELSE
            Y.FILTER := " AND PROCESSING_DATE = ":SQUOTE(FROM.PR.DATE)
        END
    END ELSE
        IF TO.PR.DATE THEN
            Y.FILTER := " PROCESSING_DATE >= ":SQUOTE(FROM.PR.DATE):" AND PROCESSING_DATE <= ":SQUOTE(TO.PR.DATE):" "
        END ELSE
            Y.FILTER := " PROCESSING_DATE = ":SQUOTE(FROM.PR.DATE)
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.CUSTOMER.ACCOUNT:
*-------------------------------------------------------------------------

    IF Y.CUSTOMER NE '' AND Y.PORTFOLIO EQ '' THEN
        Y.CUSTACCT.LIST = ''
        Y.CUSTOMER = TRIM(Y.CUSTOMER)
        CONVERT SM TO VM IN Y.CUSTOMER
        TOTL.CUSTOMER = DCOUNT(Y.CUSTOMER,VM)
        J = 1
        LOOP
        WHILE J LE TOTL.CUSTOMER
            Y.CUSTOMER.ID = Y.CUSTOMER<1,J>
            R.CUSTOMER.ACCOUNT = ''
            CUSTACC.ERR= ''
            R.MNEMONIC.CUSTOMER = ''
            CALL F.READ(FN.MNEMONIC.CUSTOMER,Y.CUSTOMER.ID,R.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER,MNE.ERR)
            IF R.MNEMONIC.CUSTOMER THEN
                Y.CUSTOMER.ID = R.MNEMONIC.CUSTOMER<EB.MCU.CUSTOMER>
            END
            CALL F.READ(FN.CUSTOMER.ACCOUNT,Y.CUSTOMER.ID,R.CUSTOMER.ACCOUNT,F.CUSTOMER.ACCOUNT,CUSTACC.ERR)
            Y.CUST.ACCTS = R.CUSTOMER.ACCOUNT
            IF Y.CUST.ACCTS THEN
                Y.CUSTACCT.CNT = DCOUNT(Y.CUST.ACCTS,FM)
                AC.CNT = 1
                LOOP
                WHILE AC.CNT LE Y.CUSTACCT.CNT
                    Y.ACCT = Y.CUST.ACCTS<AC.CNT>
                    IF Y.ACCT THEN
                        IF Y.CUSTACCT.LIST THEN
                            Y.CUSTACCT.LIST := SQL.AC.DELIM : Y.ACCT
                        END ELSE
                            Y.CUSTACCT.LIST = "('":Y.ACCT
                        END
                    END
                    AC.CNT += 1
                REPEAT
            END
            J += 1
        REPEAT
        IF Y.CUSTACCT.LIST THEN
            ACCOUNT.SQL = Y.CUSTACCT.LIST:"')"     ;* This AC List value passed to SQL query
        END
    END



    IF (Y.PORTFOLIO NE '' AND Y.CUSTOMER NE '') OR (Y.PORTFOLIO NE '' AND Y.CUSTOMER EQ '')  THEN
        Y.PORT.FLAG = 'Y'
        Y.PORTFOLIO = TRIM(Y.PORTFOLIO)
        CONVERT SM TO VM IN Y.PORTFOLIO
        TOT.PORTFOLIO = DCOUNT(Y.PORTFOLIO,VM)
        LOOP
            REMOVE Y.PORT.ID FROM Y.PORTFOLIO SETTING PORT.POS
        WHILE Y.PORT.ID:PORT.POS

            CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.PORT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
            IF R.SAM.ALT.REC THEN
                Y.SAMALT.DATA = R.SAM.ALT.REC
                Y.SAM.ID = FIELD(Y.SAMALT.DATA,'*',2)
            END
            CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,ERR.SAM)
            Y.SAMACC.NOS = R.SAM<SC.SAM.ACCOUNT.NOS>
            Y.SAM.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.STATUS.POS>
            Y.CL.DATE    = R.SAM<SC.SAM.LOCAL.REF,Y.DATE.POS>
            IF Y.SAM.STATUS EQ 'CLOSED' THEN
            Y.SAM.CLS.ID = Y.SAM.ID:'*':Y.CL.DATE
            CALL F.READ(FN.JBWW.L.XX.CLOSEDACCT,Y.SAM.CLS.ID,R.JBWW.L.XX.CLOSEDACCT,F.JBWW.L.XX.CLOSEDACCT,CLS.ERR)
            IF R.JBWW.L.XX.CLOSEDACCT THEN
               Y.SAMACC.NOS = R.JBWW.L.XX.CLOSEDACCT<POR.CLS.ACCOUNT.ID>
            END

            END

            IF Y.SAMACC.NOS THEN
                Y.SAMACCT.CNT = DCOUNT(Y.SAMACC.NOS,VM)
                AC.CNT = 1
                LOOP
                WHILE AC.CNT LE Y.SAMACCT.CNT
                    Y.ACCT = Y.SAMACC.NOS<1,AC.CNT>
                    IF Y.ACCT THEN
                        IF Y.SAMACCT.LIST THEN
                            Y.SAMACCT.LIST := SQL.AC.DELIM : Y.ACCT
                        END ELSE
                            Y.SAMACCT.LIST = "('":Y.ACCT
                        END
                    END
                    AC.CNT += 1
                REPEAT
            END
        REPEAT
        IF Y.SAMACCT.LIST THEN
            ACCOUNT.SQL = Y.SAMACCT.LIST:"')"     ;* This AC List value passed to SQL query
        END
    END
    IF ACCOUNT.SQL THEN

        IF Y.FILTER THEN
            Y.FILTER := " AND ((DEBIT_ACCT_NO IN ":ACCOUNT.SQL:") OR (CREDIT_ACCT_NO IN ":ACCOUNT.SQL:" ))"
        END ELSE
            Y.FILTER = " ((DEBIT_ACCT_NO IN ":ACCOUNT.SQL:") OR (CREDIT_ACCT_NO IN ":ACCOUNT.SQL:" ))"
        END
    END ELSE
        IF Y.FILTER NE '' AND Y.PORT.FLAG EQ 'Y' THEN
           Y.FILTER := " AND ((DEBIT_ACCT_NO IS NULL) AND (CREDIT_ACCT_NO IS NULL ))"
        END ELSE
           IF Y.PORT.FLAG EQ 'Y' THEN
           Y.FILTER = " ((DEBIT_ACCT_NO IS NULL) AND (CREDIT_ACCT_NO IS NULL ))"
           END
        END
    END

*
    RETURN
*
*-------------------------------------------------------------------------
GET.FT.TXN.REF:
*-------------------------------------------------------------------------

    Y.TXN.REF = TRIM(Y.TXN.REF)
    CONVERT SM TO VM IN Y.TXN.REF
    TOT.TXN.REF = DCOUNT(Y.TXN.REF,VM)
    Y.FT.LIST = ''
    FT.SQL = ''
    I = 1
    LOOP
    WHILE I LE TOT.TXN.REF
        FT.ID = Y.TXN.REF<1,I>
        IF TRIM(FT.ID) THEN
            FT.ID = TRIM(FT.ID)
            IF Y.FT.LIST THEN
                Y.FT.LIST := SQL.AC.DELIM : FT.ID
            END ELSE
                Y.FT.LIST = "('":FT.ID
            END
        END
        I += 1
    REPEAT
    IF Y.FT.LIST THEN
        FT.SQL = Y.FT.LIST:"')"

        IF Y.FILTER THEN
            Y.FILTER := " AND RECID IN ":FT.SQL
        END ELSE
            Y.FILTER = "RECID IN ":FT.SQL
        END

    END

*
    RETURN
*
*-------------------------------------------------------------------------
EXTRACT.ALL.FT:
*-------------------------------------------------------------------------

    IF NOT(Y.FILTER) THEN
        SQL.L.FILTER = ''
        SQL.H.FILTER = " WHERE RECORD_STATUS IN ('REVE', 'MAT')"
    END ELSE
        SQL.L.FILTER = " WHERE ":Y.FILTER
        SQL.H.FILTER = " WHERE RECORD_STATUS IN ('REVE', 'MAT')":" AND ":Y.FILTER
    END


    SQL.FT.LIVE = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY FROM V_":Y.ORACLE.LIVE:"":SQL.L.FILTER

    SQL.FT.LIVE = EXECSQLQUERY(1,SQL.FT.LIVE)
    CONVERT FM TO '*' IN SQL.FT.LIVE
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.LIVE

    SQL.FT.HIS = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY FROM V_":Y.ORACLE.HIS:"":SQL.H.FILTER

    SQL.FT.HIS = EXECSQLQUERY(1,SQL.FT.HIS)
    CONVERT FM TO '*' IN SQL.FT.HIS
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.HIS

    IF SQL.FT.HIS THEN
        SQL.FT.LIVE<-1> = SQL.FT.HIS
    END

    IF SQL.FT.LIVE THEN
        OUT.ARRAY = SQL.FT.LIVE
    END

*
    RETURN
*
*-------------------------------------------------------------------------
EXTRACT.MATURE.FT:
*-------------------------------------------------------------------------
    SQL.M.FILTER = " WHERE RECORD_STATUS IN ('MAT') "
    IF NOT(Y.FILTER) THEN
    END ELSE
        SQL.M.FILTER = " WHERE RECORD_STATUS IN ('MAT') AND ":Y.FILTER
    END

    SQL.FT.MAT = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY FROM V_":Y.ORACLE.HIS:"":SQL.M.FILTER

    IF ((Y.PAGE.FROM EQ '' AND Y.PAGE.TO EQ '') OR (Y.PAGE.FROM EQ '0' AND Y.PAGE.TO EQ '0')) THEN
        SQL.FT.MAT = EXECSQLQUERY(1,SQL.FT.MAT)
    END ELSE
        SQL.FT.MAT.PAGE = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY  FROM (SELECT A.*,rownum rn FROM  (":SQL.FT.MAT:" ) A WHERE rownum <= ":Y.PAGE.TO:" )  WHERE rn >= ":Y.PAGE.FROM
        SQL.FT.MAT = EXECSQLQUERY(1,SQL.FT.MAT.PAGE)
    END
    CONVERT FM TO '*' IN SQL.FT.MAT
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.MAT

    IF SQL.FT.MAT THEN
        OUT.ARRAY = SQL.FT.MAT
    END

*
    RETURN
*
*-------------------------------------------------------------------------
EXTRACT.REVERSED.FT:
*-------------------------------------------------------------------------
    SQL.R.FILTER = " WHERE RECORD_STATUS IN ('REVE') "
    IF NOT(Y.FILTER) THEN

    END ELSE
        SQL.R.FILTER = " WHERE RECORD_STATUS IN ('REVE') AND ":Y.FILTER
    END

    SQL.FT.REV = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY FROM V_":Y.ORACLE.HIS:"":SQL.R.FILTER

    SQL.FT.REV = EXECSQLQUERY(1,SQL.FT.REV)
    CONVERT FM TO '*' IN SQL.FT.REV
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.REV

    IF SQL.FT.REV THEN
        OUT.ARRAY = SQL.FT.REV
    END

*
    RETURN
*
*-------------------------------------------------------------------------
EXTRACT.LIVE.FT:
*-------------------------------------------------------------------------
    SQL.L.FILTER = " WHERE RECORD_STATUS IS NULL "
    IF NOT(Y.FILTER) THEN

    END ELSE
        SQL.L.FILTER = " WHERE RECORD_STATUS IS NULL AND ":Y.FILTER
    END
    SQL.FT.LIVE = "SELECT RECID,TRANSACTION_TYPE,DATE_TIME,PROCESSING_DATE,DEBIT_VALUE_DATE,DEBIT_CUSTOMER,DEBIT_ACCT_NO,DEBIT_AMOUNT,DEBIT_CURRENCY,LOC_AMT_DEBITED,DEBIT_THEIR_REF,ACCT_WITH_BANK,CHEQUE_NUMBER,PAYMENT_DETAILS,CREDIT_VALUE_DATE,CREDIT_CUSTOMER,CREDIT_ACCT_NO,CREDIT_AMOUNT,CREDIT_CURRENCY FROM V_":Y.ORACLE.LIVE:"":SQL.L.FILTER

    SQL.FT.LIVE = EXECSQLQUERY(1,SQL.FT.LIVE)
    CONVERT FM TO '*' IN SQL.FT.LIVE
    CONVERT Y.FM.CHAR TO FM IN SQL.FT.LIVE

    IF SQL.FT.LIVE THEN
        OUT.ARRAY = SQL.FT.LIVE
    END
*
    RETURN
*
*-------------------------------------------------------------------------
    END
