SUBROUTINE JB.R.PP.PAYENQREPAIR.NOF(OUT.ARRAY)
*---------------------------------------------------------------------------------------------------
* This is a Nofile enquiry to display received responses (reject/return) for pacs.009 sent.
* Transactions should be filtered for user who initiated original pacs.009
*---------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------
* Date            Developer                    Reference               Description
* 16/05/2024      Prabhu D S                   CBPAY-49                Initial Draft
* 22/01/2025      Vikram Pavuluru              CBPAY-294               Added Enquiry "JB.E.PP.PACS002PACS004-PACS009.VIEW" in GOSUB FORM.SEL.CMD
*                                                                      and GOSUB FORM.OUT.QUEUE
* 23/01/2025      P Amala                      CBPAY-1682              Incorporating RLC logic to trigger the RLC version for authorisation.
*
*07/03/2025       Vikram Pavuluru              CBPAY-2088 &            Changed the condition for CASE Y.OUT.MSG.TYPE MATCHES "pacs.009" :@VM: "202"
*                                              CBPAY-2064              in GOSUB FORM.OUT.QUEUE
*28/03/2025       Lakshmi Priya                CBPAY - 2314            User Group Check is only limited for outgoing Payments, and not applicable for
*                                                                      incoming Payments.And removed Logic to Form Out Queue only when inputter does not
*                                                                      match the authoriser.
*05/04/2025       Resmi R                      CBPAY-2020              Introduced the logic to handle the selection fields and send the details in the out array
*
*21/04/2025       Raghunandan PD               CBPAY-2347			   Introduced selection fields (Ccy,Captureid,amount,datetime)
*05/05/2025       P Amala                      CBPAY-2665              Fix to not trigger RLC version if RLC block approval is rejected.
*09/05/2025       P Amala                      CBPAY-2392              Fix to null the RLC block check variable only for the RLC rejected payment.
*05/06/2025       P Amala                      CBPAY-3396              Fix to skip INA2 status of OrderEntry record.
*---------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.USER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $USING EB.DataAccess
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
       

    GOSUB INIT
    GOSUB OPEN.FILES
    GOSUB GET.PARAM.VALUES
    GOSUB GET.USER.ROLE.GROUP
    GOSUB CHECK.ENQ.NAME
    GOSUB FORM.SEL.CMD
    GOSUB PROCESS


RETURN

INIT:
    
    Y.LOC.REF.FLDS.POS = '' ; R.JB.GPM.REC = ''
    Y.GPM.FIELD.VALUES = '' ; Y.GPM.FIELD.NAMES = ''
    Y.USER.ROLES.LIST = ''  ; Y.USER.ROLES = ''
    Y.ROLE.POS = ''         ; Y.USR.GRP = ''
    Y.SEL.LIST = ''         ; Y.SEL.CNT = ''
    Y.FM.POS = ''           ; Y.SEL.FT.NO = ''
    Y.VM.POS = ''
    Y.SM.POS = ''
    Y.BLK.CATEG.POS = ''    ; Y.RLC.BLKCATEG = ''
    Y.ORG.TXN.REF = ''      ; Y.ORG.CNCL.REQ = ''
    Y.TXN.AMT = ''          ; Y.INC.MSG.TYP = ''
	Y.CCY = ''              ; Y.CAPTURE.ID = ''
	Y.DATE.TIME = ''

    
    FN.JB.GPM = "F.JBWW.H.EB.GENERICPARAMETER"     ; F.JB.GPM = ''
    FN.PAYMENT.ORDER = "F.PAYMENT.ORDER"           ; FV.PAYMENT.ORDER = ''
    FN.PP.ORDER.ENTRY.NAU = "F.PP.ORDER.ENTRY$NAU" ; FV.PP.ORDER.ENTRY.NAU = ''
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"       ; FV.POR.TRANSACTION = ''
    FN.POR.SUPPLEMENTARY.INFO = "F.POR.SUPPLEMENTARY.INFO" ; FV.POR.SUPPLEMENTARY.INFO = ''
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK' ; F.JBWW.H.XX.SOFTBLOCK = ''

    Y.ENQ.NAME = ENQ.SELECTION<1>

    LOCATE "FTNumber" IN D.FIELDS<1> SETTING FT.POS THEN
        Y.SEL.FT.NO = D.RANGE.AND.VALUE<FT.POS>
    END
        
    LOCATE "OriginalTransactionReference" IN D.FIELDS<1> SETTING REF.POS THEN
        Y.ORG.TXN.REF = D.RANGE.AND.VALUE<REF.POS>
    END
            
    LOCATE "TransactionAmount" IN D.FIELDS<1> SETTING TXNAMT.POS THEN
        Y.TXN.AMT = D.RANGE.AND.VALUE<TXNAMT.POS>
    END
    
    LOCATE "IncomingMessageType" IN D.FIELDS<1> SETTING MSGTYP.POS THEN
        Y.INC.MSG.TYP = D.RANGE.AND.VALUE<MSGTYP.POS>
    END
    
	LOCATE "Ccy" IN D.FIELDS<1> SETTING CCY.POS THEN
        Y.CCY = D.RANGE.AND.VALUE<CCY.POS>
    END
	
	LOCATE "CaptureID" IN D.FIELDS<1> SETTING CAPTURE.POS THEN
        Y.CAPTURE.ID = D.RANGE.AND.VALUE<CAPTURE.POS>
    END
	
	LOCATE "EntryDateAndTime" IN D.FIELDS<1> SETTING DATE.TIME.POS THEN
        Y.DATE.TIME = D.RANGE.AND.VALUE<DATE.TIME.POS>
    END
	
    
RETURN

OPEN.FILES:
    
    CALL OPF(FN.JB.GPM,F.JB.GPM)
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,FV.PP.ORDER.ENTRY.NAU)
    CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO,FV.POR.SUPPLEMENTARY.INFO)
    CALL GET.LOC.REF("PAYMENT.ORDER","L.PO.USR.GRP",Y.LOC.REF.FLDS.POS)
    CALL GET.LOC.REF("PP.ORDER.ENTRY","L.XX.BLK.CATEG",Y.BLK.CATEG.POS)
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK, F.JBWW.H.XX.SOFTBLOCK)
    
RETURN



GET.PARAM.VALUES:
    
    CALL F.READ(FN.JB.GPM,"JBWW.E.XX.CASHSEC.USERROLES",R.JB.GPM.REC,F.JB.GPM,GPM.ERR)
    Y.GPM.FIELD.NAMES = R.JB.GPM.REC<JBWW.GEN.PAR.FIELD.NAME>
    Y.GPM.FIELD.VALUES = R.JB.GPM.REC<JBWW.GEN.PAR.FIELD.VALUE>
        
RETURN

GET.USER.ROLE.GROUP:

    IF USER.ROLE THEN
        FIND USER.ROLE IN Y.GPM.FIELD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
            Y.USR.GRP = Y.GPM.FIELD.NAMES<Y.FM.POS,Y.VM.POS>
        END
    END
    
RETURN

CHECK.ENQ.NAME:

    BEGIN CASE
        CASE Y.ENQ.NAME MATCHES "JB.E.PP.PAYENQREPPACS008.INP":@VM:"JB.E.PP.PAYENQREPPACS009.INP":@VM:"JB.E.PP.PACS002PACS004-PACS009.VIEW"
            Y.OE.STATUS = "235"
        CASE Y.ENQ.NAME MATCHES "JB.E.PP.PAYENQREPPACS008.AUTH":@VM:"JB.E.PP.PAYENQREPPACS009.AUTH"
            Y.OE.STATUS = "315"
    END CASE

RETURN

FORM.SEL.CMD:
 
    BEGIN CASE
        
        CASE Y.ORG.TXN.REF NE ''
            GOSUB SELECT.PORS
    
        CASE OTHERWISE
            GOSUB SELECT.OE
        
    END CASE
 
RETURN

SELECT.PORS:

 	
    IF Y.ORG.TXN.REF THEN
	
        Y.SEL.CMD.1 = "SELECT ":FN.POR.SUPPLEMENTARY.INFO:" WITH ORIGINAL.OR.RETURN.ID EQ ":Y.ORG.TXN.REF

    END

    EB.DataAccess.Readlist(Y.SEL.CMD.1,Y.SEL.PORS,'',Y.SEL.CNT,'')

    LOOP
        REMOVE PORS.ID FROM Y.SEL.PORS SETTING Y.PORS.POS
    WHILE PORS.ID : Y.PORS.POS
        CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,PORS.ID,R.POR.SUPPL.INFO,FN.POR.SUPPLEMENTARY.INFO,POR.ERR)
        Y.PP.ORD.ENT.ID = R.POR.SUPPL.INFO<PORID.ORDER.ENTRY.ID>
        Y.SEL.LIST<-1> = Y.PP.ORD.ENT.ID
  
    REPEAT

RETURN
 
SELECT.OE:
   
    Y.SEL.CMD = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH Status EQ ":Y.OE.STATUS:" AND (OriginalTransactionRef NE '' OR InstructionIdentification NE '') AND CO.CODE EQ " : ID.COMPANY
    IF Y.SEL.FT.NO THEN
        Y.SEL.CMD := " AND WITH TransactionReferenceNumber EQ '":Y.SEL.FT.NO:"'"
    END
    
    IF Y.TXN.AMT THEN
        Y.SEL.CMD := " AND WITH TransactionAmount  EQ '":Y.TXN.AMT:"'"
    END
    
    IF Y.INC.MSG.TYP THEN
        Y.SEL.CMD := " AND WITH IncomingMessageType  EQ '":Y.INC.MSG.TYP:"'"
    END
	
	IF Y.CCY THEN
        Y.SEL.CMD := " AND WITH TransactionCurrency  EQ '":Y.CCY:"'"
    END
    
	IF Y.CAPTURE.ID THEN
        Y.SEL.CMD := " AND WITH @ID  EQ '":Y.CAPTURE.ID:"'"
    END
	
	IF Y.DATE.TIME THEN
        Y.SEL.CMD := " AND WITH DATE.TIME  EQ '":Y.DATE.TIME:"'"
    END
	
    EB.DataAccess.Readlist(Y.SEL.CMD,Y.SEL.LIST,'',Y.SEL.CNT,'')


RETURN

PROCESS:
        
    LOOP
        REMOVE Y.OE.ID FROM Y.SEL.LIST SETTING Y.OE.POS
    WHILE Y.OE.ID : Y.OE.POS
        CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.OE.ID,R.OE.REC.NAU,FV.PP.ORDER.ENTRY.NAU,OE.ERR)
        IF R.OE.REC.NAU THEN
            IF R.OE.REC.NAU<PP.OEYG.OriginalTransactionRef> THEN
                Y.OE.ORIG.FT.REF = R.OE.REC.NAU<PP.OEYG.OriginalTransactionRef>
            END ELSE
                Y.OE.ORIG.FT.REF = R.OE.REC.NAU<PP.OEYG.InstructionIdentification>
            END
            Y.OE.DIRECTION = R.OE.REC.NAU<PP.OEYG.Direction>
            Y.PP.TXN.AMT = R.OE.REC.NAU<PP.OEYG.TransactionAmount>
            Y.PP.MSG.TYPE = R.OE.REC.NAU<PP.OEYG.IncomingMessageType>
	        Y.PP.RECSTAT = R.OE.REC.NAU<PP.OEYG.RECORD.STATUS>
            GOSUB GET.PO.REC
           
            IF (Y.TXN.AMT AND (Y.TXN.AMT NE Y.PP.TXN.AMT)) OR (Y.INC.MSG.TYP AND (Y.INC.MSG.TYP NE Y.PP.MSG.TYPE)) THEN CONTINUE

            IF ((Y.USR.GRP EQ Y.PO.USR.GRP) OR Y.OE.DIRECTION EQ 'I') AND NOT(Y.PP.RECSTAT EQ 'INA2') THEN
                GOSUB FORM.OUT.QUEUE
            END
        END
    REPEAT
    
RETURN

FORM.OUT.QUEUE:
 
    BEGIN CASE
        
        CASE Y.OUT.MSG.TYPE MATCHES "pacs.008" :@VM: "103"
            
            IF Y.ENQ.NAME MATCHES "JB.E.PP.PAYENQREPPACS008.INP" :@VM: "JB.E.PP.PAYENQREPPACS008.AUTH" THEN
                
                GOSUB FORM.ARRAY
            
            END
        
        CASE Y.OUT.MSG.TYPE MATCHES "pacs.009" :@VM: "202"
        
            IF Y.ENQ.NAME MATCHES "JB.E.PP.PAYENQREPPACS009.INP":@VM:"JB.E.PP.PACS002PACS004-PACS009.VIEW":@VM:"JB.E.PP.PAYENQREPPACS009.AUTH" THEN
                
                GOSUB FORM.ARRAY
            
            END
    
    END CASE

RETURN

GET.PO.REC:
    
    Y.OUT.MSG.TYPE = ''
    Y.COVER.FLAG = ''
    R.POR.TRANSACTION = ''
    Y.POR.LOC.FLD.NAMES = ''
    Y.POR.LOC.FLD.VALUES = ''
    Y.PO.USR.GRP = ''
    R.POR.SUPPL.INFO = ''
    
    CALL F.READ(FN.POR.TRANSACTION,Y.OE.ORIG.FT.REF,R.POR.TRANSACTION,FV.POR.TRANSACTION,POR.ERR)
    Y.OUT.MSG.TYPE = R.POR.TRANSACTION<PPPTX.OutgoingMessageType>
        
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.OE.ORIG.FT.REF,R.POR.SUPPL.INFO,FN.POR.SUPPLEMENTARY.INFO,POR.ERR)
    Y.POR.LOC.FLD.NAMES = R.POR.SUPPL.INFO<PORID.LOC.FIELD.NAME>
    Y.POR.LOC.FLD.VALUES = R.POR.SUPPL.INFO<PORID.LOC.FIELD.VALUE>
    LOCATE "L.PO.USR.GRP" IN Y.POR.LOC.FLD.NAMES<1,1> SETTING LOC.POS THEN
        Y.PO.USR.GRP = Y.POR.LOC.FLD.VALUES<1,LOC.POS>
    END
    
RETURN

FORM.ARRAY:

    Y.OE.COMPANY = R.OE.REC.NAU<PP.OEYG.ProcessCompany>
    Y.OE.FT.NO = R.OE.REC.NAU<PP.OEYG.TransactionReferenceNumber>
    Y.OE.TXN.CCY = R.OE.REC.NAU<PP.OEYG.TransactionCurrency>
    Y.OE.TXN.AMT = R.OE.REC.NAU<PP.OEYG.TransactionAmount>
    Y.OE.DR.AC.NO = R.OE.REC.NAU<PP.OEYG.DebitAccountNumber>
    Y.OE.CR.AC.NO = R.OE.REC.NAU<PP.OEYG.CreditAccountNumber>
    Y.OE.CR.AC.COMP = R.OE.REC.NAU<PP.OEYG.CreditAccountCompany>
    Y.OE.DR.AC.COMP = R.OE.REC.NAU<PP.OEYG.DebitAccountCompany>
    Y.OE.SRC = R.OE.REC.NAU<PP.OEYG.Source>
    Y.OE.DATE.TIME = R.OE.REC.NAU<PP.OEYG.DATE.TIME>
    Y.OE.FUNC.ERR = R.OE.REC.NAU<PP.OEYG.FunctionalError>
    GOSUB RLC.CHECK
	
    CHANGE '*' TO '-' IN Y.OE.FUNC.ERR
    
    OUT.ARRAY<-1> = Y.OE.COMPANY:"*":Y.OE.FT.NO:"*":Y.OE.TXN.CCY:"*":Y.OE.TXN.AMT:"*":Y.OE.DR.AC.NO:"*":Y.OE.CR.AC.NO:"*":Y.OE.CR.AC.COMP:"*":Y.OE.DR.AC.COMP:"*":Y.OE.SRC:"*":Y.OE.ID:"*":Y.OE.DATE.TIME:"*":Y.OE.FUNC.ERR:"*":Y.RLC.BLKCATEG

RETURN
   
RLC.CHECK:

    Y.BLK.CATEG = '' ; R.SOFT.REC = '' ; R.SOFT.ERR = ''
	Y.OVERALL.STATUS = ''
	
    Y.BLK.CATEG = R.OE.REC.NAU<PP.OEYG.LOCAL.REF,Y.BLK.CATEG.POS>
    IF Y.BLK.CATEG NE '' THEN
        CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK, Y.OE.ID, R.SOFT.REC, F.JBWW.H.XX.SOFTBLOCK, R.SOFT.ERR)
        Y.OVERALL.STATUS = R.SOFT.REC<JHXS.OVERALL.STATUS>
    END
    IF Y.OVERALL.STATUS EQ 'REJECT' THEN
        Y.RLC.BLKCATEG = ''
    END ELSE
        Y.RLC.BLKCATEG = Y.BLK.CATEG
    END


RETURN

*******************************************
END


    
