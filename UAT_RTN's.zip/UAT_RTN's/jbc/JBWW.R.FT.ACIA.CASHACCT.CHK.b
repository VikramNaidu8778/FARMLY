* @ValidationCode : MToxMjUyNDAwODk4OlVURi04OjE1NDQ0MzkwNzAxNzE6NTgyMTU0Oi0xOi0xOjA6MDpmYWxzZTpOL0E=
* @ValidationInfo : Timestamp         : 10 Dec 2018 16:21:10
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 582154
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.ACIA.CASHACCT.CHK
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is input routine to throw error if transaction type is equal to ACIA
* and account both are cash account.
*-------------------------------------------------------------------------
* Attached: As input routine to FUNDS.TRANSFER,JBWW.V.FT.ACAC.INP
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               Developer                 Reference                 Description
*10-12-2018			Subbu 					   T24-14275				Initial version
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER

    GOSUB OPEN.FILES

    IF R.NEW(FT.TRANSACTION.TYPE) = 'ACIA' THEN
        GOSUB PROCESS
    END

    RETURN

*============
OPEN.FILES:
*============
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)

    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
    RETURN

*==============
PROCESS:
*==============

    Y.CASH.FLAG = ''

    Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
    GOSUB CHECK.ACCOUNT.SAM
    Y.DBCASH.FLAG = Y.CASH.FLAG

    Y.CASH.FLAG = ''

    Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
    GOSUB CHECK.ACCOUNT.SAM

    IF Y.DBCASH.FLAG EQ 1 AND  Y.CASH.FLAG EQ '1' THEN
        ETEXT = "FT-JBWW.D.FT.ACIA.TRANS.PORTFOLIO"
        CALL STORE.END.ERROR
    END


    RETURN

*=================
CHECK.ACCOUNT.SAM:
*================
    R.ACCOUNT = '' ; ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE "" THEN
        Y.ALT.ACCT.TYPE = R.ACCOUNT<AC.ALT.ACCT.TYPE>
        Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN Y.ALT.ACCT.TYPE<1,1> SETTING ALT.POS THEN
                Y.SAM.ALT.ID = Y.ALT.ACCT.IDS<1,ALT.POS>
                Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
                R.SAM.ALT.REC = '' ; SAM.ALT.ERR = ''
                CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
                IF R.SAM.ALT.REC NE '' THEN
                    Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
                    R.SAM = '' ; SAM.ERR = ''
                    CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
                    IF R.SAM NE '' THEN
                        Y.CASH.ACCT.LIST = R.SAM<SC.SAM.ACCOUNT.NOS>
                        INC.POS = ''
                        LOCATE Y.ACCOUNT IN Y.CASH.ACCT.LIST<1,1> SETTING INC.POS THEN
                           Y.CASH.FLAG = '1'
                    END
                END
            END
        END
    END

RETURN

END
