*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PO.DEFSAPFIVALUES.INP
*-----------------------------------------------------------------------------
* This subroutine is to default the required values for ACSA & OTSA payments
*
* Attached as the Input Routine to the below list of versions
* PAYMENT.ORDER,JB.V.PP.PAIN001.SAPFI
* PAYMENT.ORDER,JBHK.V.PP.OTSA.INP
* PAYMENT.ORDER,JBHK.V.PP.ACSA.INP
* PAYMENT.ORDER,JB.V.PP.OTSA.API.1.0.0
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer          Reference         Description
*
* 04-JUL-2024   Prabhu D S         CBPAY-850         Initial Draft
*
* 04-Jun-2025   Kandan                               Added Additional conditionf for processing ACSA payment.
*
* 05-Jul-2025   u40786             CBPAY-850         PAYMENT.EXECUTION.DATE defaulted to TODAY at version level
*                                                    REQUIRED.CREDIT.VALUE.DATE will be mapped at Interface/TIS level
*
* 05-Jul-2025   u40786             CBPAY-2920        Defaulting the PAYMENT.ORDER.PRODUCT can be removed.
*                                                    Handled at Version Input level itself
*                                                    PAYMENT.ORDER,JB.V.PP.ACSA.INP
*                                                    PAYMENT.ORDER,JBSG.V.PP.OTSA.INP
*                                                    PAYMENT.ORDER,JBHK.V.PP.OTSA.INP	
*                                                    
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.CURRENCY.GROUP
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $USING PP.PaymentFrameworkService

    GOSUB INIT
    GOSUB UPD.LOCREF.FLD.VALUE
    GOSUB PROCESS
*    
RETURN
*
*****
INIT:
*****

    FN.ACCOUNT = "F.ACCOUNT"
    F.ACCOUNT = ""
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.CURRENCY.GROUP = "F.CURRENCY.GROUP"
    F.CURRENCY.GROUP = ""
    CALL OPF(FN.CURRENCY.GROUP,F.CURRENCY.GROUP)
        
    RE.ACCOUNT = ""
    ACC.ERR = ""
    RE.CURRENCY.GROUP = ""
   
    LREF.FLD = 'L.PO.SAP.MSGID'
    CALL GET.LOC.REF(APPLICATION,LREF.FLD,Y.POS)
    Y.MSGID.POS = Y.POS<1,1>
*
RETURN
*
********************
UPD.LOCREF.FLD.VALUE:
*********************

    R.NEW(PO.LOCAL.REF)<1,Y.MSGID.POS> = R.NEW(PO.BULK.REFERENCE)
    R.NEW(PO.BULK.REFERENCE) = ''
*
RETURN
*
********
PROCESS:
********

    Y.GPM.FLD.NAMES = "SAPFI.PMT.OTPROD":@FM:"SAPFI.PMT.ACPROD":@FM:"SAPFI.SENDTOREC.UPDATE"
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
    SAPFI.PMT.OTPROD = Y.GPM.FLD.VALUES<1>
    SAPFI.PMT.ACPROD = Y.GPM.FLD.VALUES<2>
    SAPFI.SENDTOREC.UPDATE = Y.GPM.FLD.VALUES<3>
    
    Y.ACCOUNT = R.NEW(PO.BENEFICIARY.ACCOUNT.NO)

    IF LEN(Y.ACCOUNT) EQ 19 THEN
        CALL F.READ(FN.ALTERNATE.ACCOUNNT,Y.ACCOUNT,RE.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ALT.ACC.ERR)
        Y.ACCOUNT = RE.ALTERNATE.ACCOUNT
    END
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,RE.ACCOUNT,F.ACCOUNT,ACC.ERR)

    IF RE.ACCOUNT THEN
		GOSUB DEFAULT.ACSA
    END ELSE
		GOSUB DEFAULT.OTSA
    END
*
RETURN
*
*************
DEFAULT.ACSA:
*************

*	R.NEW(PO.PAYMENT.ORDER.PRODUCT) = SAPFI.PMT.ACPROD
	R.NEW(PO.CREDIT.ACCOUNT) = Y.ACCOUNT
	R.NEW(PO.BENEFICIARY.ACCOUNT.NO) = ''
	R.NEW(PO.ACCT.WITH.BANK.BIC) = ''
	R.NEW(PO.BENEFICIARY.NAME) = ''
	R.NEW(PO.BEN.POST.ADDR.LINE) = ''
	R.NEW(PO.BENEFICIARY.COUNTRY.CODE) = ''
	R.NEW(PO.ACCT.WITH.BANK.CUSTOMER) = ''
	R.NEW(PO.ACCT.WITH.BANK.CLEARING.CODE) = ''
	R.NEW(PO.ACCT.WITH.BANK.IDENTIFIER) = ''
	R.NEW(PO.ACCT.WITH.BANK.COUNTRY) = ''
	R.NEW(PO.BENEFICIARY.TOWN.NAME) = ''
	R.NEW(PO.BENEFICIARY.STREET.NAME) = ''
	R.NEW(PO.BENEFICIARY.POST.CODE) =  ''
	R.NEW(PO.ACCT.WITH.BANK.NAME)  = ''
	R.NEW(PO.ORDERING.CUSTOMER.BIC)  = ''
	R.NEW(PO.CHARGE.ACCOUNT) = ''
	R.NEW(PO.CHARGE.ACCOUNT.CCY) = ''
	R.NEW(PO.MESSAGE.CONTENT.NAME) = ''
	R.NEW(PO.MESSAGE.DATA) = ''
	R.NEW(PO.ACCT.WITH.TOWN.NAME) = ''
	R.NEW(PO.ORIGINAL.MSG.CONTENT) = ''
*
RETURN
*
*************
DEFAULT.OTSA:
*************

*	R.NEW(PO.PAYMENT.ORDER.PRODUCT) = SAPFI.PMT.OTPROD
*	R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE) = R.NEW(PO.PAYMENT.EXECUTION.DATE)
*	R.NEW(PO.PAYMENT.EXECUTION.DATE) = TODAY
	Y.SAPFI.SENDTOREC.CCY = FIELD(SAPFI.SENDTOREC.UPDATE,"_",1)
	Y.BK.TO.BK.INFO = FIELD(SAPFI.SENDTOREC.UPDATE,"_",2)
	IF R.NEW(PO.PAYMENT.CURRENCY) EQ Y.SAPFI.SENDTOREC.CCY THEN
		R.NEW(PO.BANK.TO.BANK.INFO) = Y.BK.TO.BK.INFO
	END
	GOSUB NONASNCCY.CHECK
*
RETURN
*
****************
NONASNCCY.CHECK:
****************
  
    Y.PMT.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    CALL F.READ(FN.CURRENCY.GROUP,"NONASNCCY",RE.CURRENCY.GROUP,F.CURRENCY.GROUP,CCY.GRP.ERR)
    LOCATE Y.PMT.CCY IN RE.CURRENCY.GROUP<ST.CURGP.CURRENCY,1> SETTING CCY.POS THEN
        R.NEW(PO.MESSAGE.PRIORITY) = 2
    END
*
RETURN
*
END
*