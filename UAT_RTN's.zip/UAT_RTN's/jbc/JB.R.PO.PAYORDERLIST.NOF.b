SUBROUTINE JB.R.PO.PAYORDERLIST.NOF(FINAL.ARRAY)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer           Reference           Description
* 21/04/2025        Ayush Kumar         CBPAY-2553          This new nofile enquiry routine is attached JB.E.PO.PAYORDER.LIST
*                                                           to show all unauthorised, authorised and history records from
*                                                           PAYMENT.ORDER application based on the user selection
*
* 09/05/2025        Resmi R             CBPAY-2360          Included logic to segregate payments based on the user group
*
* 23/06/2025        Vikram Pavuluru     CBPAY-3249          Hard coded the PAYMENT.ORDER.PRODUCT for restricting TRSY payment.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    FN.PAYMENT.ORDER.NAU = "F.PAYMENT.ORDER$NAU"
    F.PAYMENT.ORDER.NAU = ""
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)

    FN.PAYMENT.ORDER = "F.PAYMENT.ORDER"
    F.PAYMENT.ORDER = ""
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.PAYMENT.ORDER.HIS = "F.PAYMENT.ORDER$HIS"
    F.PAYMENT.ORDER.HIS = ""
    CALL OPF(FN.PAYMENT.ORDER.HIS,F.PAYMENT.ORDER.HIS)

    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
    F.ACCOUNT.HIS = ''
    CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)

      
    CALL GET.LOC.REF("PAYMENT.ORDER","L.PO.USR.GRP",Y.LOC.REF.FLDS.POS)
    
    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.VALUES)
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","OPS.PO.TXNTYPES",Y.GPM.OPSVAL)
    CHANGE ',' TO VM IN Y.GPM.OPSVAL
    CHANGE FM TO VM IN Y.GPM.OPSVAL
    Y.OPS.TXNTYPES = Y.GPM.OPSVAL<1>

    IF USER.ROLE THEN
        FIND USER.ROLE IN Y.GPM.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
            Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
        END
    END
    
    FINAL.ARRAY = ""
    Y.OPERAND = ""


    SEL.NAU.CMD = "SELECT " : FN.PAYMENT.ORDER.NAU
    SEL.LIVE.CMD = "SELECT " : FN.PAYMENT.ORDER
    SEL.HIS.CMD = "SELECT " : FN.PAYMENT.ORDER.HIS
    SEL.CMD.COND = ""

    Y.FLD.CNT = DCOUNT(D.FIELDS,@FM)
    FOR J = 1 TO Y.FLD.CNT - 1
        Y.FLD.NAME = D.FIELDS<J>
        Y.FLD.VALUE = D.RANGE.AND.VALUE<J>
        Y.OPERAND = D.LOGICAL.OPERANDS<J>
        GOSUB DECIDE.OPERAND
        Y.SEL.OPERAND = Y.OPERAND
        GOSUB FIELD.SELECTION
    NEXT J

    SEL.NAU.CMD = SEL.NAU.CMD : SEL.CMD.COND
    SEL.NAU.LIST = ""
    SEL.NAU.CNT = ""
    SEL.NAU.ERR = ""
    CALL EB.READLIST(SEL.NAU.CMD,SEL.NAU.LIST,"",SEL.NAU.CNT,SEL.NAU.ERR)

    GOSUB READ.NAU

    SEL.LIVE.CMD = SEL.LIVE.CMD : SEL.CMD.COND
    SEL.LIVE.LIST = ""
    SEL.LIVE.CNT = ""
    SEL.LIVE.ERR = ""
    CALL EB.READLIST(SEL.LIVE.CMD,SEL.LIVE.LIST,"",SEL.LIVE.CNT,SEL.LIVE.ERR)


    GOSUB READ.LIVE

    SEL.HIS.CMD = SEL.HIS.CMD : SEL.CMD.COND
    SEL.HIS.LIST = ""
    SEL.HIS.CNT = ""
    SEL.HIS.ERR = ""
    CALL EB.READLIST(SEL.HIS.CMD,SEL.HIS.LIST,"",SEL.HIS.CNT,SEL.HIS.ERR)

    GOSUB READ.HIS

RETURN

FIELD.SELECTION:

    Y.CNT = ""
    Y.CNT = DCOUNT(Y.FLD.VALUE,@VM)
    FOR I = 1 TO Y.CNT

        BEGIN CASE
            CASE Y.SEL.OPERAND MATCHES "EQ":VM:"NE"
                CONVERT @SM TO " " IN Y.FLD.VALUE
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH " : Y.FLD.NAME : " " : Y.SEL.OPERAND : " " : Y.FLD.VALUE
                END ELSE
                    SEL.CMD.COND := " AND " : Y.FLD.NAME : " " : Y.SEL.OPERAND : " " : Y.FLD.VALUE
                END
            CASE Y.SEL.OPERAND MATCHES "GT":VM:"GE":VM:"LT":VM:"LE"
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH " : Y.FLD.NAME : " " : Y.SEL.OPERAND : " " : Y.FLD.VALUE
                END ELSE
                    SEL.CMD.COND := " AND " : Y.FLD.NAME : " " : Y.SEL.OPERAND : " " : Y.FLD.VALUE
                END
            CASE Y.SEL.OPERAND MATCHES "LK"
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH " : Y.FLD.NAME : " LIKE " : Y.FLD.VALUE
                END ELSE
                    SEL.CMD.COND := " AND " : Y.FLD.NAME : " LIKE " : Y.FLD.VALUE
                END
            CASE Y.SEL.OPERAND MATCHES "UL"
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH " : Y.FLD.NAME : " UNLIKE " : Y.FLD.VALUE
                END ELSE
                    SEL.CMD.COND := " AND " : Y.FLD.NAME : " UNLIKE " : Y.FLD.VALUE
                END
            CASE Y.SEL.OPERAND EQ "RG"
                Y.TEMP.DATA = Y.FLD.VALUE
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH (" : Y.FLD.NAME : " GE " : Y.TEMP.DATA<1,1,1> : " AND " : Y.FLD.NAME : " LE " : Y.TEMP.DATA<1,1,2> : ")"
                END ELSE
                    SEL.CMD.COND := " AND (" : Y.FLD.NAME : " GE " : Y.TEMP.DATA<1,1,1> : " AND " : Y.FLD.NAME : " LE " : Y.TEMP.DATA<1,1,2> : ")"
                END
            CASE Y.SEL.OPERAND EQ "NR"
                Y.TEMP.DATA = Y.FLD.VALUE
                IF NOT(SEL.CMD.COND) THEN
                    SEL.CMD.COND := " WITH (" : Y.FLD.NAME : " LT " : Y.TEMP.DATA<1,1,1> : " OR " : Y.FLD.NAME : " GT " : Y.TEMP.DATA<1,1,2> : ")"
                END ELSE
                    SEL.CMD.COND := " AND (" : Y.FLD.NAME : " LT " : Y.TEMP.DATA<1,1,1> : " OR " : Y.FLD.NAME : " GT " : Y.TEMP.DATA<1,1,2> : ")"
                END
        END CASE

    NEXT I
 

RETURN

DECIDE.OPERAND:

    Y.SEL.OPERAND = ""
    BEGIN CASE
        CASE Y.OPERAND EQ "1"
            Y.OPERAND = "EQ"
            
        CASE Y.OPERAND EQ "2"
            Y.OPERAND = "RG"
        
        CASE Y.OPERAND EQ "3"
            Y.OPERAND = "LT"
           
        CASE Y.OPERAND EQ "4"
            Y.OPERAND = "GT"
           
        CASE Y.OPERAND EQ "5"
            Y.OPERAND = "NE"
        
        CASE Y.OPERAND EQ "6"
            Y.OPERAND = "LK"
            
        CASE Y.OPERAND EQ "7"
            Y.OPERAND = "UL"
            
        CASE Y.OPERAND EQ "8"
            Y.OPERAND = "LE"
            
        CASE Y.OPERAND EQ "9"
            Y.OPERAND = "GE"
        
        CASE Y.OPERAND EQ "10"
            Y.OPERAND = "NR"
         
    END CASE

RETURN

READ.NAU:

    Y.NAU.ID = ""
    Y.NAU.ID.POS = ""
    R.PO.NAU.REC = ""
    Y.PO.NAU.ERR = ""
    R.PAYMENT.ORDER = ""
    R.POR.TRANSACTION.REC = ""
    Y.POR.TRANSACTION.ERR = ""
    
    LOOP
        REMOVE Y.NAU.ID FROM SEL.NAU.LIST SETTING Y.NAU.ID.POS
    WHILE Y.NAU.ID:Y.NAU.ID.POS
        CALL F.READ(FN.PAYMENT.ORDER.NAU,Y.NAU.ID,R.PO.NAU.REC,F.PAYMENT.ORDER.NAU,Y.PO.NAU.ERR)
        IF R.PO.NAU.REC THEN
            Y.REC.ID = Y.NAU.ID
            R.PAYMENT.ORDER = R.PO.NAU.REC
            GOSUB READ.PAYMENT.ORDER
            Y.REC.ID = ""
            R.PAYMENT.ORDER = ""
        END
    REPEAT

RETURN

READ.LIVE:


    Y.LIVE.ID = ""
    Y.LIVE.ID.POS = ""
    R.PO.LIVE.REC = ""
    Y.PO.LIVE.ERR = ""
    R.PAYMENT.ORDER = ""
    R.POR.TRANSACTION.REC = ""
    Y.POR.TRANSACTION.ERR = ""
    
    LOOP
        REMOVE Y.LIVE.ID FROM SEL.LIVE.LIST SETTING Y.LIVE.ID.POS
    WHILE Y.LIVE.ID:Y.LIVE.ID.POS
        CALL F.READ(FN.PAYMENT.ORDER,Y.LIVE.ID,R.PO.LIVE.REC,F.PAYMENT.ORDER,Y.PO.LIVE.ERR)
        IF R.PO.LIVE.REC THEN
            Y.REC.ID = Y.LIVE.ID
            R.PAYMENT.ORDER = R.PO.LIVE.REC
            GOSUB READ.PAYMENT.ORDER
            Y.REC.ID = ""
            R.PAYMENT.ORDER = ""
        END
    REPEAT

RETURN

READ.HIS:

    Y.HIS.ID = ""
    Y.HIS.ID.POS = ""
    R.PO.HIS.REC = ""
    Y.PO.HIS.ERR = ""
    R.PAYMENT.ORDER = ""
    R.POR.TRANSACTION.REC = ""
    Y.POR.TRANSACTION.ERR = ""
    
    LOOP
        REMOVE Y.HIS.ID FROM SEL.HIS.LIST SETTING Y.HIS.ID.POS
    WHILE Y.HIS.ID:Y.HIS.ID.POS
        CALL F.READ(FN.PAYMENT.ORDER.HIS,Y.HIS.ID,R.PO.HIS.REC,F.PAYMENT.ORDER.HIS,Y.PO.HIS.ERR)
        IF R.PO.HIS.REC THEN
            Y.REC.ID = Y.HIS.ID
            R.PAYMENT.ORDER = R.PO.HIS.REC
            GOSUB READ.PAYMENT.ORDER
            Y.REC.ID = ""
            R.PAYMENT.ORDER = ""
        END
    REPEAT

RETURN

READ.PAYMENT.ORDER:
    
    Y.ARRAY = ""
    Y.UETR = ""
    Y.PO.USR.GRP.VAL = R.PAYMENT.ORDER<PO.LOCAL.REF,Y.LOC.REF.FLDS.POS>
    
    IF Y.PO.USR.GRP.VAL EQ Y.USR.GRP THEN

        Y.PAYMENT.ORDER.PRODUCT  = R.PAYMENT.ORDER<PO.PAYMENT.ORDER.PRODUCT>
        Y.DEBIT.ACCOUNT.IBAN = R.PAYMENT.ORDER<PO.DEBIT.ACCOUNT.IBAN>
        Y.DEBIT.PL = R.PAYMENT.ORDER<PO.DEBIT.PL>
        Y.DEBIT.ACCOUNT = R.PAYMENT.ORDER<PO.DEBIT.ACCOUNT>
    
        IF Y.PAYMENT.ORDER.PRODUCT MATCHES Y.OPS.TXNTYPES THEN
        
   
            GOSUB READ.ACCOUNT
            IF NOT(Y.DEBIT.ACCOUNT.IBAN) THEN
                Y.DEBIT.ACCOUNT.IBAN = Y.DEBIT.PL
            END
            IF NOT(Y.DEBIT.ACCOUNT) THEN
                Y.DEBIT.ACCOUNT = Y.DEBIT.ACCOUNT.IBAN
            END
            Y.PAYMENT.AMOUNT = R.PAYMENT.ORDER<PO.PAYMENT.AMOUNT>
            Y.PAYMENT.CURRENCY = R.PAYMENT.ORDER<PO.PAYMENT.CURRENCY>
            Y.CREDIT.VALUE.DATE = R.PAYMENT.ORDER<PO.CREDIT.VALUE.DATE>
            Y.REQUIRED.CREDIT.VALUE.DATE = R.PAYMENT.ORDER<PO.REQUIRED.CREDIT.VALUE.DATE>
            IF NOT(Y.CREDIT.VALUE.DATE) THEN
                Y.CREDIT.VALUE.DATE = Y.REQUIRED.CREDIT.VALUE.DATE
            END
            Y.CURRENT.STATE = R.PAYMENT.ORDER<PO.CURRENT.STATE>
            Y.PAYMENT.SYSTEM.ID = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM.ID>
            Y.RECORD.STATUS = R.PAYMENT.ORDER<PO.RECORD.STATUS>
            Y.PAYMENT.SYSTEM = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM>
            CALL F.READ(FN.POR.TRANSACTION,Y.PAYMENT.SYSTEM.ID,R.POR.TRANSACTION.REC,F.POR.TRANSACTION,Y.POR.TRANSACTION.ERR)
            IF R.POR.TRANSACTION.REC THEN
                Y.UETR = R.POR.TRANSACTION.REC<PPPTX.EndToEndReference>
            END
    
            Y.ARRAY = Y.REC.ID : "*" : Y.PAYMENT.ORDER.PRODUCT : "*" : Y.DEBIT.ACCOUNT : "*" : Y.PAYMENT.AMOUNT : "*" : Y.PAYMENT.CURRENCY
            Y.ARRAY := "*" : Y.CREDIT.VALUE.DATE : "*" : Y.CURRENT.STATE : "*" : Y.PAYMENT.SYSTEM.ID : "*" : Y.RECORD.STATUS
            Y.ARRAY := "*" : Y.UETR
            FINAL.ARRAY<-1> = Y.ARRAY
    
        END
    END


RETURN

READ.ACCOUNT:
    
    Y.FT.ACCT = Y.DEBIT.ACCOUNT
    Y.STO.ACCT = FIELD(Y.FT.ACCT,'.',1)
   
    IF Y.STO.ACCT THEN
        Y.ACCT.ID = Y.STO.ACCT
    END ELSE
        Y.ACCT.ID = Y.FT.ACCT
    END
    
    R.ACCT.REC = ''
    ACCT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCT.REC,F.ACCOUNT,ACCT.ERR)
    
    IF NOT(R.ACCT.REC) THEN ;* If Account Closed
        CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACCT.ID,R.ACCT.HIST,ACCT.HERR)
        IF R.ACCT.HIST THEN
            ALT.ACCT.TYPE = R.ACCT.HIST<AC.ALT.ACCT.TYPE>
            ALT.ACCT.IDS = R.ACCT.HIST<AC.ALT.ACCT.ID>
        END
    END ELSE
        ALT.ACCT.TYPE = R.ACCT.REC<AC.ALT.ACCT.TYPE>
        ALT.ACCT.IDS = R.ACCT.REC<AC.ALT.ACCT.ID>
    END
    
    LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
        Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
        IF Y.AC.ALT.ID THEN
            Y.DEBIT.ACCOUNT = Y.AC.ALT.ID
        END
    END
    
    
RETURN

END