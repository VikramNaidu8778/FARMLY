SUBROUTINE JB.R.PP.IDENTIFYPS.POPHOOK(applName,contractId,contractArr,connectionType,connectionError)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  10-May-2025   Kandan             CBPAY-2329        Initial Draft
*  To Resolve the GST Sweeping - Incorrect booking date issue posted for Sweeping Entries
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $USING PI.PaymentOrderLifecycleHook
 
*Routines attached in Payment Order parameter
*ACSW payment generated in COB-EOD will be Processed as FT instead of TPH.
*Based on the connectionType System will create FT
*In FT, PO Reference will be updated in INWARD.PAY.TYPE  (INWARD.PAY.TYPE:1:1="PO-PI2508414YQG6P76")
*In PO, FT Reference will be updated in Payment System Id (FT25084GY8T3 ) and status in Payment System Status

*Arguments,
*applName  - Application Name
*contractId - id of the contract being processed
*contractArr - contract being processed
*connectionType - TPS OR FT OR EXTERNAL
*connectionError - Error.

   
    paymentOrderProduct = contractArr<1>
    IF paymentOrderProduct EQ 'ACSW' THEN
        connectionType = 'FT'
    END ELSE
        connectionType = 'TPS'
    END
 
RETURN
*-----------------------------------------------------------------------------
END

