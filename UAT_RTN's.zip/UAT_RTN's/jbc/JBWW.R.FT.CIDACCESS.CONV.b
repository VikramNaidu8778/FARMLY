    SUBROUTINE JBWW.R.FT.CIDACCESS.CONV
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is the conversion routine attached with enquiries which will give input link
* to edge screens and Payment portal screens for dynamic EDGE url creation.
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
*    Date           Developer                        Reference
**********************************************************************************************************************
* 09-Aug-2018        Vidya A            CID Data Access for Edge and Payments URLs
* 14-Aug-2018        Vidya A            For softblock history enquiry, ';' to be removed before reading FT record.
* 23-Aug-2018        Vidya A            logic of assigning DEBIT.THEIR.REF value is changed. (DAY15-3970) 
**********************************************************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_System

    GOSUB INIT
    GOSUB FT.PROC
    GOSUB FINAL.URL
    RETURN
*-------------------------------------------------------------------------
INIT:
*---
    Y.PARAM.ID = ''
    Y.FT.ID = ''
    Y.INPUTTER = ''
    Y.URL = ''
    EGDE.FLAG = ''
    PAYMENTS.FLAG = ''
    Y.INPUTTER = ''

    Y.FT.ID = System.getVariable('CURRENT.ID')

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)

    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    RETURN
*-------------------------------------------------------------------------
FT.PROC:
*------
**For Softblock history record equiry,
    FINDSTR ';' IN Y.FT.ID SETTING POS THEN
        Y.FT.ID = FIELD(Y.FT.ID,';',1)
    END
**
    CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FT,F.FUNDS.TRANSFER,FT.ERROR)
    Y.INPUTTER = R.FT<FT.INPUTTER>
    Y.SENDER.REF = R.FT<FT.DEBIT.THEIR.REF>

    IF Y.INPUTTER EQ '' THEN
        CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.FT.ID,R.FT.NAU,F.FUNDS.TRANSFER.NAU,FT.ERROR.NAU)
        Y.INPUTTER = R.FT.NAU<FT.INPUTTER>
        Y.SENDER.REF = R.FT.NAU<FT.DEBIT.THEIR.REF>

        IF Y.INPUTTER EQ '' THEN
            *            CALL F.READ(FN.FUNDS.TRANSFER.HIS,Y.FT.ID,R.FT.HIS,F.FUNDS.TRANSFER.HIS,FT.ERROR.HIS)
            CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS,Y.FT.ID,R.FT.HIS,FT.ERROR.HIS)
            Y.INPUTTER = R.FT.HIS<FT.INPUTTER>
            Y.SENDER.REF = R.FT.HIS<FT.DEBIT.THEIR.REF>
        END
    END

    CHANGE '_' TO FM IN Y.INPUTTER
    LOCATE 'IRISPA' IN Y.INPUTTER SETTING POS THEN
    EDGE.FLAG = 'Y'
    END
    LOCATE 'SWIFTIN' IN Y.INPUTTER SETTING POS THEN
    PAYMENTS.FLAG = 'Y'
    END

    IF (EDGE.FLAG EQ 'Y') OR (PAYMENTS.FLAG EQ 'Y') THEN
        Y.COMP = ID.COMPANY
        *        Y.URL = 'EDGE'
        Y.PARAM.ID = 'PAYMENT.EDGE.URL'

        Y.FLAG = 'Flag=7'
        Y.MENU = '&MnuTyp=':Y.FT.ID
        Y.CO.CODE = '&CoCode=':Y.COMP

        GOSUB URL.PROCESS
        Y.EGDE.URL = Y.IP:Y.SERVICE:Y.FLAG:Y.MENU:Y.CO.CODE
        *    END

        *    IF PAYMENTS.FLAG EQ 'Y' THEN
        *       Y.SENDER.REF = R.FT<FT.DEBIT.THEIR.REF>
        *        Y.URL = 'PAY.PORTAL'
        Y.PARAM.ID = 'PAY.PORTAL.URL'

        Y.PAYMENT.REF = 'sendersReferenceNumber=':Y.SENDER.REF
        Y.TEXT = "If 'Debit Their Ref' field is NOT blank, click the Payments Portal link, otherwise click link to Edge Connect"

        GOSUB URL.PROCESS
        Y.PAYMENT.URL = Y.IP:Y.SERVICE:Y.PAYMENT.REF
    END

    RETURN
*-------------------------------------------------------------------------
URL.PROCESS:
*----------
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.PARAM.ID,R.GEN.PAR,F.JBWW.H.EB.GENERICPARAMETER,PAR.ERR)
    Y.GENPAR.NAME = R.GEN.PAR<JBWW.GEN.PAR.FIELD.NAME>
    Y.GENPAR.VALUE = R.GEN.PAR<JBWW.GEN.PAR.FIELD.VALUE>

    IP.POS = ''
    LOCATE "IP.PORT" IN Y.GENPAR.NAME<1,1> SETTING IP.POS THEN
    Y.IP = Y.GENPAR.VALUE<1,IP.POS>
    END

    SERVICE.POS = ''
    LOCATE "SERVICE.LINK" IN Y.GENPAR.NAME<1,1> SETTING SERVICE.POS THEN
    Y.SERVICE = Y.GENPAR.VALUE<1,SERVICE.POS>
    END

    RETURN
*-------------------------------------------------------------------------
FINAL.URL:
*--------
    O.DATA = Y.EGDE.URL:'*':Y.PAYMENT.URL:'*':Y.TEXT
    RETURN
*-------------------------------------------------------------------------
    END


