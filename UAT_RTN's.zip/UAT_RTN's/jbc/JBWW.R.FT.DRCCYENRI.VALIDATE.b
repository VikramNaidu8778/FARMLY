    SUBROUTINE JBWW.R.FT.DRCCYENRI.VALIDATE
*-------------------------------------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------
* This is the validation routine attached to the field DEBIT.CURRENCY in FT Draft versions.
* It is used to default the DEBIT.CURRENCY field with DEBIT.ACCOUNT>CURRENCY value.
*------------------------------------------------------------------------------------------------------
* Attached: to versions FUNDS.TRANSFER,JBWW.V.FT.ODFCY.INP and FUNDS.TRANSFER,JBWW.V.FT.OD110.INP
*           and FUNDS.TRANSFER,JBWW.V.FT.OD103.INP
*-------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*-------------------------------------------------------------------------
* Date               who               Reference          Description
* 02-05-2016        Rekha M             PMT-005         Initial Version
* 25-01-2018        PuthumaiSamy        JB2A-48096
*      
*-------------------------------------------------------------------------

     $INSERT I_COMMON
     $INSERT I_EQUATE
     $INSERT I_F.FUNDS.TRANSFER
     $INSERT I_F.ACCOUNT

     GOSUB INITIALISE
     GOSUB PROCESS
     RETURN
******************************************************************
 INITIALISE:
 ***********

     Y.DR.ID = ''
     Y.DR.CCY  = ''

     FN.ACCOUNT = 'F.ACCOUNT'
     F.ACCOUNT = ''
     CALL OPF(FN.ACCOUNT,F.ACCOUNT)

     RETURN

******************************************************************
PROCESS:
*********

         Y.DR.ID = COMI
         CALL F.READ(FN.ACCOUNT,Y.DR.ID,R.ACCOUNT,F.ACCOUNT,ACC.ERR)
         Y.DR.CCY = R.ACCOUNT<AC.CURRENCY>
         R.NEW(FT.DEBIT.CURRENCY) = Y.DR.CCY

     RETURN

********************************************************************
 END