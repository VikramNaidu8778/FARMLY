*-----------------------------------------------------------------------------
* <Rating>-21</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.H.FT.NOSTROINTEREST.FIELDS
*-----------------------------------------------------------------------------
*<doc>
* Template for field definitions routine JBWW.H.FT.NOSTROINTEREST.FIELDS
*
* @author tcoleman@temenos.com
* @stereotype fields template
* @uses Table
* @public Table Creation
* @package infra.eb
* </doc>
*-----------------------------------------------------------------------------
* Modification History :
*
* 19/10/07 - EN_10003543
*            New Template changes
*
* 14/11/07 - BG_100015736
*            Exclude routines that are not released
* 23/08/07  - JB2A-40786
*             included "AMT' type to  "L.FT.AMOUNT"
* 29.12.2023    Hazirah                         GBLBB-157           R23.10 upgrade - compilation errors - remove END
*-----------------------------------------------------------------------------
*** <region name= Header>
*** <desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
* ID DEFINITION
    ID.F = "@ID"
    ID.N = "35"
    ID.T = "A"

*-----------------------------------------------------------------------------
*    CALL Table.defineId("TABLE.NAME.ID", T24_String) ;* Define Table id
*-----------------------------------------------------------------------------
*    CALL Table.addField(fieldName, fieldType, args, neighbour) ;* Add a new fields
*    CALL Field.setCheckFile(fileName)        ;* Use DEFAULT.ENRICH from SS or just field 1

    CALL Table.addFieldDefinition('XX<L.FT.PL.ACC', '35.1', 'ANY', '') ;* Add a new field
    CALL Field.setCheckFile("CATEGORY")
    CALL Table.addFieldDefinition('XX-L.FT.NOST.ACC', '35.1', 'ACC', '') ;* Add a new field
    CALL Field.setCheckFile("ACCOUNT")
   	
    fieldName = "XX-L.FT.NOSINT.TYPE"
    fieldLength = "6.1"
    fieldType<1> = ''
    fieldType<2> = "DEBIT_CREDIT"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
	
	fieldName = "XX-L.FT.AMOUNT"
    fieldLength = "35.1"
    fieldType = "AMT"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
	
*CALL Table.addFieldDefinition('XX-L.FT.AMOUNT', '35.1', '', '') ;* Add a new field
     
    fieldName = "XX-L.FT.CURRENCY"
    fieldLength = "35"
    fieldType = "CCY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    CALL Table.addFieldDefinition('XX-L.FT.VALUE.DATE', '35.1', 'D', '') ;* Add a new field
    CALL Table.addFieldDefinition('XX-L.FT.BO.REMARK', '35', 'A', '') ;* Add a new field
    
    fieldName = "XX>L.FT.ID"
    fieldLength = "35"
    fieldType = "A"
	fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '') ;* Add a new field
    
    
    
    fieldName = "RESERVED.10"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.9"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.8"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.7"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.6"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')
    
    fieldName = "RESERVED.5"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.4"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.3"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.2"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.1"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')
    
    
    fieldName = "XX.OVERRIDE"
    fieldLength = "35"
    fieldType = "A"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')
    
    
*    CALL Table.addFieldWithEbLookup(fieldName,virtualTableName,neighbour) ;* Specify Lookup values
*    CALL Field.setDefault(defaultValue) ;* Assign default value
*-----------------------------------------------------------------------------
    CALL Table.setAuditPosition ;* Poputale audit information
*-----------------------------------------------------------------------------
RETURN
*-----------------------------------------------------------------------------
*END            ;*GBLBB-157
*--------------------------------------------------------------     ;*GBLBB-157
END