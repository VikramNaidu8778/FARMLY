*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.H.FT.NOSTROINTEREST.RECORD
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.FT.NOSTROINTEREST
*-----------------------------------------------------------------------------    

    GOSUB INIT
    GOSUB CHECK.RECORD 
    RETURN

INIT:
**-----------------------------------------------------------------------
    F.JBWW.H.FT.NOSTROINTEREST = ''
    FN.JBWW.H.FT.NOSTROINTEREST = 'F.JBWW.H.FT.NOSTROINTEREST'
    CALL OPF(FN.JBWW.H.FT.NOSTROINTEREST,F.JBWW.H.FT.NOSTROINTEREST)

    RETURN
**-----------------------------------------------------------------------
CHECK.RECORD:

    REC.ID = ID.NEW
    CALL F.READ(FN.JBWW.H.FT.NOSTROINTEREST,REC.ID,R.REC,F.JBWW.H.FT.NOSTROINTEREST,'')
    IF V$FUNCTION EQ 'I' OR V$FUNCTION EQ 'R' THEN
        IF R.REC NE '' THEN
            E ='EB-JBWW.D.FT.RECORD.CHK'
            CALL STORE.END.ERROR
            RETURN
        END
    END

    RETURN
*-----------------------------------------------------------------------------
    END
