* @ValidationCode : MjoxMzI4ODU4ODM2OkNwMTI1MjoxNzEyNTc0MTczNjI5OjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 15 Jul 2024 09:50:53
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.R.PP.CHKCLNTCHGLMT.INPUT
*-----------------------------------------------------------------------------------------------------
*This is the Input routine attached to the OTO3 version
*Attached: to version PAYMENT.ORDER,JB.V.PP.NOSTRO103.INP
*-----------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*15/07/2024     Resmi R                    CBPAY-659                 Charge Amount Limit check
*
*--------------------------------------------------------------------------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.FT.COMMISSION.TYPE
    
    GOSUB INIT
    GOSUB PROCESS
    
RETURN
    
INIT:
*****
    FN.PP.CLIENTCHARGES = 'F.PP.CLIENTCHARGES'
    F.PP.CLIENTCHARGES = ''
    CALL OPF(FN.PP.CLIENTCHARGES, F.PP.CLIENTCHARGES)
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    
    FN.FT.COMM.TYPE = 'F.FT.COMMISSION.TYPE'
    F.FT.COMM.TYPE = ''
    CALL OPF(FN.FT.COMM.TYPE, F.FT.COMM.TYPE)

    Y.CHARGE.TYPE = ''  ; Y.CHARGE.AMT = ''    ;  Y.CLNT.CHG.POS = ''
    Y.CHRG.TYP.CNT = '' ; Y.CLNT.COMM.AMT = '' ;  Y.CORR.BNK.POS = ''
    Y.CHRG.FLG = '0'
        
	LREF.FLD = 'L.PO.CLNT.CHG'
    CALL GET.LOC.REF(APPLICATION,LREF.FLD,Y.POS)
    Y.CLNT.CHG.POS = Y.POS<1,1>

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","OUT.CLCHG.TYPE",Y.GPM.CHARGE.TYPE)
         
RETURN

PROCESS:
********

    Y.PMT.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    Y.CURR.NO = R.NEW(PO.CURR.NO)
    Y.CHARGE.TYPE = R.NEW(PO.CHARGE.TYPE)
    Y.CLNT.COMM.AMT = R.NEW(PO.LOCAL.REF)<1,Y.CLNT.CHG.POS>
       
    LOCATE Y.GPM.CHARGE.TYPE IN Y.CHARGE.TYPE<1,1> SETTING CHRG.POS THEN
        Y.CHRG.TYPE =  Y.CHARGE.TYPE<1,CHRG.POS>
        R.FT.COMM.TYPE.REC = '' ; FT.COMM.ERR = ''
        CALL F.READ(FN.FT.COMM.TYPE,Y.CHRG.TYPE,R.FT.COMM.TYPE.REC,F.FT.COMM.TYPE,FT.COMM.ERR)
        Y.CHRG.AMT = R.FT.COMM.TYPE.REC<FT4.FLAT.AMT>
        IF Y.CLNT.COMM.AMT GT Y.CHRG.AMT THEN
            TEXT = 'EB-JB.CHK.CLNTCHG.LIMIT'
            CALL STORE.OVERRIDE(Y.CURR.NO)
        END
    
    END

    LOCATE "OUTBOUNDOURCHARGE" IN Y.CHARGE.TYPE<1,1> SETTING CHRG.POS THEN
        R.NEW(PO.CHARGE.CURRENCY)<1,CHRG.POS> = Y.PMT.CCY
    END         

RETURN

**********************************************************
END
