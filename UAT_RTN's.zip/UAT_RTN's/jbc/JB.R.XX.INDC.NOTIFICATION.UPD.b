SUBROUTINE JB.R.XX.INDC.NOTIFICATION.UPD(TYPE,ENTITY.TYPE,ENTITY.ID,NAME,VALUE,UID,Y.NOTIF.VALUES,Y.UNIQUE.ID,Y.ERROR,RESERVE4)
*-----------------------------------------------------------------------------
* This routine is to update details for notification alert coming from TPH payments
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date       Resource         JIRA Ref          Description
* 20/11/2024  Prabhu D S       CBPAY-1252        Initial draft
* 17/01/2205  Prabhu D S       CBPAY-528         Table restrucuted with field name
*                                                change and new field introduction.
* 01/07/2025  P Amala          CBPAY-410         Changing format of Amount,Date, portfolio ID in NameValue Pair.
* Input/Output:
*--------------
* IN: TYPE,ENTITY.TYPE,ENTITY.ID,NAME,VALUE,UID,Y.NOTIF.VALUES (TYPE,ENTITY.TYPE,ENTITY.ID,UID are mandatory to write data in live table)
* OUT: Y.UNIQUE.ID,Y.ERROR
*------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.JB.XX.NOTIFICATION.REQ
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-------------------------------------------------------------------------------

    IF UID EQ '' THEN
        Y.ERROR = 'Error Code : Pass all the arguments'
    END ELSE
        GOSUB INIT
        GOSUB WRITE.VALUES
    END

RETURN
*-----------------------------------------------------------------------------
INIT:
*****
    
    FN.JB.XX.NOTIFICATION.REQ = 'F.JB.XX.NOTIFICATION.REQ'
    F.JB.XX.NOTIFICATION.REQ = ''
    CALL OPF(FN.JB.XX.NOTIFICATION.REQ,F.JB.XX.NOTIFICATION.REQ)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.SEC.ACC.MASTER.ACCOUNT.NAME = ''
    FN.SEC.ACC.MASTER.ACCOUNT.NAME = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    CALL OPF(FN.SEC.ACC.MASTER.ACCOUNT.NAME,F.SEC.ACC.MASTER.ACCOUNT.NAME)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
        
    CALL JBWW.R.EB.GETGENPARM.VAL('NOTIFICATION.HANDLER',"MSG.PREFIX",Y.PREFIX)
    CALL JBWW.R.EB.GETGENPARM.VAL('NOTIFICATION.HANDLER',"FILE.PGM.TYPE",Y.PGM)
    
    R.JLXINR<JLXINR.EVENT.SHORT.NAME> = TYPE
    R.JLXINR<JLXINR.TITLE> = Y.NOTIF.VALUES<1,1>
    R.JLXINR<JLXINR.DESCRIPTION> = Y.NOTIF.VALUES<1,2>
    R.JLXINR<JLXINR.LANGUAGE> = "EN"
    R.JLXINR<JLXINR.BOOKING.CENTER> = ID.COMPANY[1,2]
    R.JLXINR<JLXINR.SOURCE.APPLN> = Y.NOTIF.VALUES<1,3>
    R.JLXINR<JLXINR.TARGET.APPLN> = Y.NOTIF.VALUES<1,4>
    R.JLXINR<JLXINR.IAUDIENCE.SECTION> = Y.NOTIF.VALUES<1,5>
    R.JLXINR<JLXINR.IAUDIENCE.TYPE> = Y.NOTIF.VALUES<1,6>
    R.JLXINR<JLXINR.IAUDIENCE.VALUE> = Y.NOTIF.VALUES<1,7>
    R.JLXINR<JLXINR.TRIGGER.USER> = UID
    
	UNIQUE.ID = ''
    Y.FLAG = '1'
    
    NAME = TRIM(NAME,'','A')
	
    Y.CCY.POS1 = '' ; R.SAM.ACC.NAME = '' ; Y.PORTFOLIO.ID = ''
	Y.TRADEDATE.POS = '' ; Y.VALUEDATE.POS = '' ; Y.DATETIME.POS = ''
    Y.PORTFOLIOID.POS = '' ; Y.CCY.ID = '' ; Y.SAMACC.NO = ''
	Y.SAM.CCY = '' ; Y.ACCID = '' ; Y.ALTACCT.ID = ''
    R.ACCT = '' ; R.SAM.REC = '' ; R.SAM.ACC.NAME = ''
    ALT.ACCT.TYPES = '' ; Y.AMOUNT.POS = '' ; Y.AMOUNT = ''
    Y.DATETIME = '' ; Y.VALUEDATE = '' ; Y.TRADEDATE = ''
*
RETURN
*
*-----------------------------------------------------------------------------
WRITE.VALUES:
************

	R.JLXINR<JLXINR.PORTFOLIO.NUMBER> = ENTITY.ID
    R.JLXINR<JLXINR.NAME> = NAME
    GOSUB FETCH.DETAILS
    R.JLXINR<JLXINR.VALUE> = VALUE
    GOSUB GENERATE.ID
    CALL F.WRITE(FN.JB.XX.NOTIFICATION.REQ,Y.UNIQUE.ID,R.JLXINR)
RETURN

*-----------------------------------------------------------------------------
FETCH.DETAILS:
*************

    IF ENTITY.ID THEN
        LOCATE "currency" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.CCY.POS1 THEN
            Y.CCY.ID = VALUE<1,Y.CCY.POS1>
        END
		GOSUB FETCH.PORTFOLIO.DETAILS
        CALL F.READ(FN.SEC.ACC.MASTER,Y.PORTFOLIO.ID,R.SAM.REC,F.SEC.ACC.MASTER,Y.SAM.ERR)
        IF R.SAM.REC THEN
            Y.SAMACC.NO = R.SAM.REC<SC.SAM.ACCOUNT.NOS>
            Y.SAM.CCY = R.SAM.REC<SC.SAM.ACCOUNT.CCY>

            LOCATE Y.CCY.ID IN Y.SAM.CCY<1,1> SETTING Y.SAM.CCY.POS THEN
                Y.ACCID = R.SAM.REC<SC.SAM.ACCOUNT.NOS,Y.SAM.CCY.POS>
            END
            CALL F.READ(FN.ACCOUNT, Y.ACCID, R.ACCT, F.ACCOUNT, AC.ERR)
            IF R.ACCT THEN
                ALT.ACCT.TYPES = R.ACCT<AC.ALT.ACCT.TYPE>
                LOCATE "BJB.ACCT" IN ALT.ACCT.TYPES<1,1> SETTING ALT.POS THEN
                    Y.ALTACCT.ID = R.ACCT<AC.ALT.ACCT.ID,ALT.POS>
                END
            END
            LOCATE "portfolioNumber" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.PORTFOLIOID.POS THEN
			    IF Y.ALTACCT.ID THEN
                    VALUE<1,Y.PORTFOLIOID.POS,1> = Y.ALTACCT.ID
                END
            END
        END
    END
	LOCATE "tradeDate" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.TRADEDATE.POS THEN
        Y.TRADEDATE = VALUE<1,Y.TRADEDATE.POS,1>
        Y.TRADEDATE = OCONV(ICONV(Y.TRADEDATE, 'D'), 'D4-E')
        VALUE<1,Y.TRADEDATE.POS,1> = Y.TRADEDATE
    END
	LOCATE "valueDate" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.VALUEDATE.POS THEN
        Y.VALUEDATE = VALUE<1,Y.VALUEDATE.POS,1>
        Y.VALUEDATE = OCONV(ICONV(Y.VALUEDATE, 'D'), 'D4-E')
        VALUE<1,Y.VALUEDATE.POS,1> = Y.VALUEDATE
    END
	LOCATE "dateTime" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.DATETIME.POS THEN
        Y.DATETIME = VALUE<1,Y.DATETIME.POS,1>
        Y.DATETIME = OCONV(ICONV(Y.DATETIME, 'D'), 'D4-E')
        VALUE<1,Y.DATETIME.POS,1> = Y.DATETIME
    END
	LOCATE "amount" IN R.JLXINR<JLXINR.NAME,1> SETTING Y.AMOUNT.POS THEN
        Y.AMOUNT = VALUE<1,Y.AMOUNT.POS,1>
        Y.AMOUNT = TRIM(FMT(Y.AMOUNT,"R2,#19"))
        VALUE<1,Y.AMOUNT.POS,1> = Y.AMOUNT
    END

RETURN

FETCH.PORTFOLIO.DETAILS:
**************************

    CALL F.READ(FN.SEC.ACC.MASTER.ACCOUNT.NAME,ENTITY.ID,R.SAM.ACC.NAME,F.SEC.ACC.MASTER.ACCOUNT.NAME,'')
    IF R.SAM.ACC.NAME THEN
        Y.SAM.ID = R.SAM.ACC.NAME<1>
        Y.PORTFOLIO.ID = FIELD(Y.SAM.ID,'*',2)
    END

RETURN

*-----------------------------------------------------------------------------
GENERATE.ID:
************
    SAVE.APPLICATION = APPLICATION
    APPLICATION = 'JB.XX.NOTIFICATION.REQ'
    YBASE.ID = ''
    YTYPE = 'F'
    FULL.FNAME = FN.JB.XX.NOTIFICATION.REQ
    PGM.TYPE = Y.PGM
    ID.T = ''
    COMI = ''
    V$FUNCTION = 'I'
    APP.PREFIX = Y.PREFIX
    ID.N = '25'
    CALL UNIQUE.ID(RETURN.REFERENCE,APP.PREFIX)
    Y.UNIQUE.ID = RETURN.REFERENCE
    APPLICATION = SAVE.APPLICATION
    

RETURN
*-----------------------------------------------------------------------------
END
*
