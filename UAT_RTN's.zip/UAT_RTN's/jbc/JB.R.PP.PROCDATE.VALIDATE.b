* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 14 May 2025 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PROCDATE.VALIDATE
*----------------------------------------------------------------------------------------------------------------------------------------------------
*
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
*
*14-05-2025        Resmi R                     CBPAY-2392               Logic to maipulate Processing date when user is trying to amend back dated payments
*26-05-2025        Madhu                      CBPAY-2876                Logic to check the DebitValueDate and CreditValueDate is difference , Then throw error. 
*--------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.PP.ORDER.ENTRY
*-------------------------------------------------------------------------

    IF V$FUNCTION EQ 'I' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
 

RETURN

INIT:
*****
    
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)
 
RETURN
 
PROCESS:
********
    
    IF COMI LT TODAY THEN
        COMI = TODAY
        R.NEW(PP.OEYG.ProcessingDateImposedFlag) = 'YES'
    END

    IF R.NEW(PP.OEYG.DebitValueDate) NE '' AND R.NEW(PP.OEYG.CreditValueDate) NE '' THEN
        IF R.NEW(PP.OEYG.DebitValueDate) NE R.NEW(PP.OEYG.CreditValueDate) THEN
            AF= "DebitValueDate"
            ETEXT = 'EB-JB.D.PP.DBCR.VALUEDATE'
            CALL STORE.END.ERROR
        END
    END
    
RETURN

*******************************************
END
