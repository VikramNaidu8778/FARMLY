* @ValidationCode : MTotMjYxODY0MDE1OklTTy04ODU5LTE6MTUyNzE3MTExMTc0NDphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjEx
* @ValidationInfo : Timestamp         : 24 May 2018 22:11:51
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.H.FT.RETROPAY.VALIDATE
*-----------------------------------------------------------------------------
* Validation routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date          who             Reference        Descrition of Change
* 
* 05-08-2016    Tony Charles    CALCULO          Validation routine for JBWW.H.DC.RETROPAY
*
* 21-09-2017    JB2A-39111
*               ALTERNATE.ACCOUNT is read only when hypen(-) is passed in the BEN.ACCOUNT. There are cases
*               when Olympic Account numbers are passed which does not have hypen. In such cases, Alternate
*               Account is not read resulting in Internal payment error.
*
* 24-05-2018    JB2A-51978
*               If calculo system passes zero amount, then do not raise error. Instead Tech.status and Processing.status
*               is set as CANCEL
*
* ----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.JBWW.H.FT.RETROPAY
$INSERT I_F.ALTERNATE.ACCOUNT 
*-----------------------------------------------------------------------------
* <region>

    IF NOT(R.NEW(RTR.PAY.DATE.RECEIVED)) THEN 
        R.NEW(RTR.PAY.DATE.RECEIVED) = TODAY
    END
    IF NOT(R.NEW(RTR.PAY.TIME.RECEIVED)) THEN
        R.NEW(RTR.PAY.TIME.RECEIVED) = TIME()
    END 
    
    IF R.NEW(RTR.PAY.RECORD.TYPE) NE 102 THEN
        AF = RTR.PAY.RECORD.TYPE
        ETEXT = 'FT-JBWW.D.FT.INVALIDRECORDTYPEPAYMENT.INP'
        CALL STORE.END.ERROR
    END
    
* JB2A-51978 
*    IF R.NEW(RTR.PAY.AMOUNT) EQ '' OR R.NEW(RTR.PAY.AMOUNT) = 0 THEN
*        AF = RTR.PAY.AMOUNT
*        ETEXT = 'FT-JBWW.D.FT.AMOUNTNOTNULLPAYMENT.INP'
*        CALL STORE.END.ERROR
*    END
* JB2A-51978

    IF R.NEW(RTR.PAY.CCY) EQ '' THEN 
        AF = RTR.PAY.CCY
        ETEXT = 'FT-JBWW.D.FT.CURRENCYNULLPAYMENT.INP'
        CALL STORE.END.ERROR
    END
    
    IF R.NEW(RTR.PAY.PAYMENT.TYPE) = '01' THEN
        GOSUB VALIDATE.EXTERNAL.PAYMENT
    END ELSE
        GOSUB VALIDATE.INTERNAL.PAYMENT
    END
    
    IF R.NEW(RTR.PAY.BEN.ACCOUNT) EQ '' THEN
        AF = RTR.PAY.BEN.ACCOUNT
        ETEXT = 'FT-JBWW.D.FT.BENACCOUNTMANDPAYMENT.INP'  ;* Beneficiary Account mandatory for Payment
        CALL STORE.END.ERROR
    END
    
    IF R.NEW(RTR.PAY.PARTNER.ACCOUNT) EQ '' THEN
        AF = RTR.PAY.PARTNER.ACCOUNT
        ETEXT = 'FT-JBWW.D.FT.PARTNERACCTMANDPAYMENT.INP'  ;* Partner Account Mandaory for Payment
        CALL STORE.END.ERROR
    END
    
    IF NOT(ETEXT) THEN  ;* If there is no error, update the Technical status as VALIDATED
        IF R.NEW(RTR.PAY.TECH.STATUS) = '' THEN
            R.NEW(RTR.PAY.TECH.STATUS) = 'VALIDATED'
        END
        ;* JB2A-51978
        IF R.NEW(RTR.PAY.AMOUNT) EQ '' OR R.NEW(RTR.PAY.AMOUNT) = 0 THEN
            R.NEW(RTR.PAY.TECH.STATUS) = 'CANCEL'
            R.NEW(RTR.PAY.PROCESSING.STATUS) = 'CANCEL'
        END
        ;* JB2A-51978
    END
    
    RETURN
           
* </region>
*-----------------------------------------------------------------------------
* <region>
VALIDATE.EXTERNAL.PAYMENT:
* In case of Outward remittance, BEN.NAME and SWIFT.CODE are mandatory

    BEN.NAME = R.NEW(RTR.PAY.BEN.NAME)
    IF BEN.NAME EQ '' THEN
        AF = RTR.PAY.BEN.NAME
        ETEXT = 'FT-JBWW.D.FT.BENNAME.MANDATORY'  ;* BEN.NAME is mandatory for external payments
        CALL STORE.END.ERROR
    END
    
    IF R.NEW(RTR.PAY.SWIFT.CODE) EQ '' THEN  ;* Mapped to ACCT.WITH.BANK in Funds Transfer
        AF = RTR.PAY.SWIFT.CODE
        ETEXT = 'FT-JBWW.D.FT.SWIFTCODE.MANDATORY'
        CALL STORE.END.ERROR
    END
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region>
VALIDATE.INTERNAL.PAYMENT:
* 
* In the template, BEN.ACCOUNT is defined as Alpha numeric because for External payment, it may have Other bank account in case of External Payment. 
* In case of Internal payment, BEN.ACCOUNT should hold valid T24 account. Hence check for valid T24 Account in BEN.ACCOUNT  
        CREDIT.ACCOUNT.ID = R.NEW(RTR.PAY.BEN.ACCOUNT)
        F.ACCOUNT = ''
        ACCT.ERR = ''
        R.ACCOUNT = ''
        
        F.ALTERNATE.ACCOUNT = ''
        R.ALT.ACCT = ''
        CALL F.READ('F.ALTERNATE.ACCOUNT', CREDIT.ACCOUNT.ID, R.ALT.ACCT, F.ALTERNATE.ACCOUNT, ALT.ERR)
        IF R.ALT.ACCT<AAC.GLOBUS.ACCT.NUMBER> THEN 
            CREDIT.ACCOUNT.ID = R.ALT.ACCT<AAC.GLOBUS.ACCT.NUMBER>
        END
        
        CALL F.READ('F.ACCOUNT', CREDIT.ACCOUNT.ID, R.ACCOUNT, F.ACCOUNT, ACCT.ERR)
        IF ACCT.ERR THEN
            AF = RTR.PAY.BEN.ACCOUNT
            ETEXT = 'FT-JBWW.D.FT.INVALID.ACCOUNT'
            CALL STORE.END.ERROR 
        END
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
END

