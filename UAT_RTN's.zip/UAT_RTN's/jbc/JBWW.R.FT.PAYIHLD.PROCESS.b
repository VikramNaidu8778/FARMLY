* @ValidationCode : MToxMjk3NzIzNTUyOklTTy04ODU5LTE6MTUyODMzODU4MTQ2NDp1NDA3NzA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 0Thu Jun  7 07:40:14 CEST 2018
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
*----------------------------------------------------------------------------------------------------------------------------------
*Program Description:
*-------------------*
* This is a input routine attached in VERSION>FUNDS.TRANSFER,INWARD to Hold the Duplicate FT transaction coming from payment portal
*----------------------------------------------------------------------------------------------------------------------------------
* Modification History :
* Ramesh Kummar               JB2A-52431                 Initial Version
*----------------------------------------------------------------------------------------------------------------------------------

SUBROUTINE JBWW.R.FT.PAYIHLD.PROCESS

$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER
$INSERT I_GTS.COMMON


Y.FT.OVERRIDES = R.NEW(FT.OVERRIDE)
FINDSTR 'DUP.CONTRACT' IN Y.FT.OVERRIDES SETTING FM.POS,VM.POS,SM.POS THEN
ETEXT = 'POSSIBLE DUPLICATE CONTRACT':ID.NEW
AF = 'FT.OVERRIDE'
CALL STORE.END.ERROR

END
RETURN
END


