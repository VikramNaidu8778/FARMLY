SUBROUTINE JB.R.PP.INCOMINGSBREJ.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
* Description : Routine to List all the incoming payments which are failed due to Softblock rejection.
* Attached to : ENQUIRY>JB.E.PP.RLCREJECT.ENQ
* Attached as : BUILD.ROUTINE
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer              Reference             Description
*--------------------------------------------------------------------------------------------
* 15-JUL-2024   P Amala                CBPAY-660            Routine to extract the incoming payment failed due to Softblock rejection.
*
* 30-Dec-2024   P Amala                CBPAY-1376           CBPR - RLC Reject queue is displaying the dx.order/trade for payment ops user
*
* 13-Mar-2025   P Amala                CBPAY-2120           Transaction id is not displaying in RLC Reject Queue if it has more than one Softblock.
* 03-May-2025   Ayush Kumar            CBPAY-2269           Use Transaction id to pull the data even if user provide FT number in this selection field
* 06-May-2025   P Amala                CBPAY-2701           Included status code 997 to display manual pacs.004 transaction in queue.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.EB.QUERIES.ANSWERS
    $INSERT I_F.COMPANY     ; * CBPAY-2269 - S/E
                                                
    GOSUB INITIALISE
    GOSUB PROCESS
    
RETURN
*----------
INITIALISE:
*----------

    FN.JBWW.H.XX.SOFTBLOCK='F.JBWW.H.XX.SOFTBLOCK'
    F.JBWW.H.XX.SOFTBLOCK=''
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    F.PP.ORDER.ENTRY$NAU = ''
    FN.PP.ORDER.ENTRY$NAU = 'F.PP.ORDER.ENTRY$NAU'
    CALL OPF(FN.PP.ORDER.ENTRY$NAU,F.PP.ORDER.ENTRY$NAU)
    
    F.EB.QUERIES.ANSWERS$NAU = ''
    FN.EB.QUERIES.ANSWERS$NAU = 'F.EB.QUERIES.ANSWERS$NAU'
    CALL OPF (FN.EB.QUERIES.ANSWERS$NAU,F.EB.QUERIES.ANSWERS$NAU)

    LREF.FLD = 'L.XX.BLK.TYPE':FM:'L.XX.BLK.TYPE'
    Y.BLK.MSG.POS = '' ; FINAL.ARRAY = ''
    APPL = 'EB.QUERIES.ANSWERS':FM:'PP.ORDER.ENTRY'
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
    Y.EQABLK.TYPE.POS  = Y.POS<1,1>
    Y.OEBLK.TYPE.POS  = Y.POS<2,1>

    Y.SEL.CRIT = ENQ.DATA<4,1>
    Y.ID.COMPANY = R.COMPANY(EB.COM.MNEMONIC)     ; * CBPAY-2269 - S
    Y.ID.LIST = Y.SEL.CRIT
    CONVERT " " TO @FM IN Y.ID.LIST
    Y.ID.CNT = DCOUNT(Y.ID.LIST,@FM)
    Y.NEW.ID = ""
    FOR I = 1 TO Y.ID.CNT
        Y.ID = Y.ID.LIST<I>
        IF Y.ID.COMPANY EQ Y.ID[1,3] THEN
            GOSUB GET.IDS
        END ELSE
            Y.NEW.ID<-1> = Y.ID
        END
    NEXT I
    CONVERT @FM TO " "  IN Y.NEW.ID
    Y.SEL.CRIT = Y.NEW.ID     ; * CBPAY-2269 - E

RETURN
*-------
PROCESS:
*-------
 
    SEL.CMD = "SELECT ":FN.JBWW.H.XX.SOFTBLOCK:" WITH APPLICATION EQ 'PP.ORDER.ENTRY' OR APPLICATION EQ 'EB.QUERIES.ANSWERS' AND OVERALL.STATUS EQ 'REJECT' "
    SB.SEL = "SELECT ":FN.JBWW.H.XX.SOFTBLOCK
    IF ENQ.DATA<4,1> NE "" THEN
        SB.SEL := " WITH @ID EQ ":Y.SEL.CRIT
        SB.SEL := " AND APPLICATION EQ 'PP.ORDER.ENTRY' OR APPLICATION EQ 'EB.QUERIES.ANSWERS'"
        SB.SEL := " AND OVERALL.STATUS EQ 'REJECT' "
    END ELSE
        SB.SEL := " WITH APPLICATION EQ 'PP.ORDER.ENTRY' OR APPLICATION EQ 'EB.QUERIES.ANSWERS'"
        SB.SEL := " AND OVERALL.STATUS EQ 'REJECT' "
    END

    CALL EB.READLIST(SB.SEL,SEL.LIST,'',NO.OF.REC,RET.CODE)

    IF SEL.LIST THEN
        LOOP
            REMOVE Y.PP.ID FROM SEL.LIST SETTING Y.ROLE.POS
        WHILE Y.PP.ID:Y.ROLE.POS
            BEGIN CASE
                CASE Y.PP.ID[1,2] EQ 'OE'
                    R.PP.NAU = '' ; Y.PP.BLKTYPE = ''
                    CALL F.READ(FN.PP.ORDER.ENTRY$NAU,Y.PP.ID,R.PP.NAU,F.PP.ORDER.ENTRY$NAU,'')
                    IF R.PP.NAU THEN
                        Y.PP.STATUS = '' ; Y.PP.REJDES = '' ; Y.PP.BLKTYPE = ''
                        BLK.POS = ''
                        Y.PP.BLKTYPE =  R.PP.NAU<PP.OEYG.LOCAL.REF,Y.OEBLK.TYPE.POS>
                        CONVERT SM TO VM IN Y.PP.BLKTYPE
                        CONVERT VM TO FM IN Y.PP.BLKTYPE
                        Y.PP.STATUS =  R.PP.NAU<PP.OEYG.Status>
                        Y.PP.REJDES =  R.PP.NAU<PP.OEYG.RejectDescription>
                        IF (Y.PP.STATUS EQ '235' OR Y.PP.STATUS EQ '135' OR Y.PP.STATUS EQ '997') AND Y.PP.REJDES NE '' THEN
                            FINDSTR 'SB' IN Y.PP.BLKTYPE SETTING BLK.POS THEN
                                FINAL.ARRAY<-1> = Y.PP.ID
                            END
                        END
                    END
                CASE Y.PP.ID[1,4] EQ 'FMQA'
                    R.PP.NAU = '' ; Y.PP.BLKTYPE = '' ; Y.ACPT.REJ = ''
                    BLK.POS = ''
                    CALL F.READ(FN.EB.QUERIES.ANSWERS$NAU,Y.PP.ID,R.PP.NAU,F.EB.QUERIES.ANSWERS$NAU,'')
                    IF R.PP.NAU THEN
                        Y.PP.BLKTYPE =  R.PP.NAU<EB.QA.LOCAL.REF,Y.EQABLK.TYPE.POS>
                        CONVERT SM TO VM IN Y.PP.BLKTYPE
                        CONVERT VM TO FM IN Y.PP.BLKTYPE
                        Y.ACPT.REJ = R.PP.NAU<EB.QA.ACCEPT.REJECT>
                        Y.PP.REC.STATUS =  R.PP.NAU<EB.QA.RECORD.STATUS>
                        IF Y.PP.REC.STATUS EQ 'IHLD' AND Y.ACPT.REJ EQ 'REJECT' THEN
                            FINDSTR 'SB' IN Y.PP.BLKTYPE SETTING BLK.POS THEN
                                FINAL.ARRAY<-1> = Y.PP.ID
                            END
                        END
                    END
            END CASE
        REPEAT
    END
    CONVERT FM TO ' ' IN FINAL.ARRAY
    ENQ.DATA<2,1> = '@ID'
    ENQ.DATA<3,1> = 'EQ'
    ENQ.DATA<4,1> = FINAL.ARRAY

RETURN

*CBPAY-2269 - S
*----------
GET.IDS:
*----------
    
    Y.SEL.CMD = "SELECT " : FN.PP.ORDER.ENTRY$NAU : " WITH TransactionReferenceNumber EQ " :  Y.ID
    Y.SEL.LIST = ""
    Y.SEL.CNT = ""
    Y.SEL.ERR = ""
    CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',Y.SEL.CNT,Y.SEL.ERR)
    IF Y.SEL.LIST THEN
        CONVERT @FM TO " " IN Y.SEL.LIST
        Y.NEW.ID<-1> = Y.SEL.LIST
    END
    
RETURN
* CBPAY-2269 - E
*-----------------------------------------------------------------------------
END
