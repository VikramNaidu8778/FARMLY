* @ValidationCode : MToxMDIxMjUxNDgzOklTTy04ODU5LTE6MTQ3NTY1MTg0OTY0MjphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 05 Oct 2016 15:17:29
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.FT.RETROUPDSTSFT.AUT
*-----------------------------------------------------------------------------
* Attached as auth routine in version FUNDS.TRANSFER,JBWW.V.FT.RETROPAYOTRT.INP. 
* This version is used in Payment enquiry (drilldown) to authorise the FT
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.JBWW.H.FT.RETROPAY
$INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    
    LREF.APPL = 'FUNDS.TRANSFER'
    LREF.FLDS = 'L.XX.RETRO.REF'
    LREF.POS = ''
    CALL MULTI.GET.LOC.REF(LREF.APPL,LREF.FLDS,LREF.POS)
    
    LOCAL.REF.VALUE = R.NEW(FT.LOCAL.REF)<1, LREF.POS>
    RETROPAYMENT.ID = FIELD(LOCAL.REF.VALUE,'-',1)
        
    RETRO.PAY.ER = ''
    CALL F.READ ('F.JBWW.H.FT.RETROPAY',RETROPAYMENT.ID,RETROPAYMENT.REC,F.JBWW.H.FT.RETROPAYMENT, RETRO.PAY.ER)
    
    IF RETRO.PAY.ER NE '' THEN
        RETURN
    END
    
    RETROPAYMENT.REC<RTR.PAY.TECH.STATUS> = 'PROCESSED' 
    RETROPAYMENT.REC<RTR.PAY.DATE.AUTH> = TODAY
    RETROPAYMENT.REC<RTR.PAY.TIME.AUTH> = TIME() 
    
    CALL F.WRITE ('F.JBWW.H.FT.RETROPAY',RETROPAYMENT.ID,RETROPAYMENT.REC)
    
END
