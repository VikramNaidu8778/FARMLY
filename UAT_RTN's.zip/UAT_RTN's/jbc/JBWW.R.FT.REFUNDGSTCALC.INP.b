SUBROUTINE JBWW.R.FT.REFUNDGSTCALC.INP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*24-Sep-22       P-3998         This routine is attached as input routine for version
*                               FUNDS.TRANSFER,JBWW.V.FT.GSTREFUNDS.INP to calcuate GST 8%
*29-Nov-22     T24-18774        Credit account can accept the Internal account or Nostro or PL
*07-Aug-23     FSQD-3481         Amended the routine to cater the HK GST
*14-Mar-24      L1TAXGST         Modified the routine to align with L1TAXGST  
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.GST.TYPE.MB
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER 
*-----------------------------------------------------------------------------
    Y.FUN = V$FUNCTION
    IF Y.FUN EQ 'I' AND ISDIGIT(R.NEW(FT.CREDIT.ACCT.NO)) THEN
        GOSUB INIT
        GOSUB GET.LOCAL.FIELD
        GOSUB PROCESS
    END
RETURN
*-----------------------------------------------------------------------------
INIT:
*-----
 
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER, F.JBWW.H.EB.GENERICPARAMETER)
    
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER, F.FUNDS.TRANSFER)
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)
    
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)
    
    Y.COMM.AMT = '' ; Y.GST.AMT = '' ; Y.SELL.AMT = '' ; Y.SELL.CCY = ''
    Y.GST.TYPE = '' ; Y.GST.RATE = '' ; Y.BELONG.STATUS = '' ; Y.GST.TYPE.OUT = ''
        
RETURN
*-----------------------------------------------------------------------------
GET.LOCAL.FIELD:
*---------------
    Y.APPL = '' ; Y.FLD.NAME = '' ; Y.POS = '' ; Y.COMP.ID = ''
    Y.APPL = 'CUSTOMER'
    Y.FLD.NAME = 'BELONG.STATUS'
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.FLD.NAME,Y.POS)
    Y.BELONG.POS = ''
    Y.BELONG.POS = Y.POS<1,1>
	
	* Get the generic parameter details
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'JB.R.XX.FT.GST',R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,ERR.GPM)

    Y.FIELD.NAME = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
   
    LOCATE "BACKDATED" IN Y.FIELD.NAME<1,1> SETTING Y.BK.DT.POS THEN
        Y.BK.DATE = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.BK.DT.POS>
    END
	
	LOCATE "GST.CATEGORY" IN Y.FIELD.NAME<1,1> SETTING Y.GC.POS THEN
        GST.CATEG = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.GC.POS>
    END
	
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    Y.COMP.ID = ID.COMPANY
    
    Y.CREDIT.ACC = R.NEW(FT.CREDIT.ACCT.NO)
    Y.PROCESSING.DATE = R.NEW(FT.PROCESSING.DATE)
    Y.DEBIT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
    R.ACC = '' ; Y.ERR.AC = ''
    CALL F.READ(FN.ACCOUNT, Y.CREDIT.ACC, R.ACC, F.ACCOUNT, YERR.AC)
    IF R.ACC NE '' THEN
        Y.CUSTOMER = R.ACC<AC.CUSTOMER>
        Y.CATEG = R.ACC<AC.CATEGORY>
        IF Y.CATEG GE '5000' AND Y.CATEG LE '5999' ELSE
            R.CUS = '' ; YERR.CUS = ''
            CALL F.READ(FN.CUSTOMER, Y.CUSTOMER, R.CUS, F.CUSTOMER, YERR.CUS)
            IF R.CUS NE '' THEN
                Y.BELONG.STATUS = R.CUS<EB.CUS.LOCAL.REF,Y.BELONG.POS>
            END
        END
    END
    
    IF Y.BELONG.STATUS EQ 'Y' THEN
        Y.BELONG = 'BELONG'
        GOSUB CALC.GST.AMT
    END
        
RETURN
**-----------------------------------------------------------------------------
CALC.GST.AMT:
*------------
    Y.COMM.AMT = R.NEW(FT.AMOUNT.CREDITED)
    Y.PROCESSING.DATE = R.NEW(FT.PROCESSING.DATE)
    Y.AC.CUSTOMER = Y.CUSTOMER
    GST.RATE = 0; Y.GST.TYPE = ''
    CALL JBWW.R.FT.GET.GST.RATE(Y.AC.CUSTOMER,AC.CAT,R.JBWW.H.EB.GENERICPARAMETER,Y.PROCESSING.DATE,GST.RATE,Y.GST.TYPE)
    Y.GST.RATE = GST.RATE
    Y.COMM.AMT = Y.COMM.AMT[4,-1]
    Y.GST.AMT = (Y.COMM.AMT * Y.GST.RATE)/100
    Y.SELL.CCY = R.NEW(FT.CREDIT.CURRENCY)
    Y.SELL.AMT = Y.GST.AMT
    CALL EB.ROUND.AMOUNT(Y.SELL.CCY,Y.SELL.AMT,'','')
    Y.GST.AMT = Y.SELL.AMT
    
    R.NEW(FT.TAX.AMT)<1,1> = R.NEW(FT.CREDIT.CURRENCY):Y.GST.AMT
    R.NEW(FT.TAX.TYPE)<1,1> = Y.GST.TYPE
RETURN
*-----------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------
