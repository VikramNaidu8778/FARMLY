SUBROUTINE JB.R.PP.BENCATEGORYDEF.INP
*-----------------------------------------------------------------------------
*Attached as : Validation Routine for the field CATEGORY in BENEFICIARY,JB.V.PP.BENEFICIARY.INP
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date         Developer         Reference           Description
*------------------------------------------------------------------------------
*10/06/2025   Lakshmi Priya      CBPAY-3106    Defaulting the CATEGORY with company ID 
*                                                 (SGD :SG0020001 & HKD: HK0030001)
*-----------------------------------------------------------------------------

$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.COMPANY
$INSERT I_F.BENEFICIARY

   COMI = ID.COMPANY

RETURN


END
