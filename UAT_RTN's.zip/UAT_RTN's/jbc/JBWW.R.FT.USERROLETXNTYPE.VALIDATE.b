* @ValidationCode : MTotMTgxNjYwNzI5MjpJU08tODg1OS0xOjE1NDMyMDkwMzg3MTQ6NTUwMzUwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 26 Nov 2018 10:40:38
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 550350
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.USERROLETXNTYPE.VALIDATE
*-----------------------------------------------------------------------------
** Description:
*-------------------------------------------------------------------------
* This is field validation routine attached to TRANSACTION.TYPE field in FUNDS.TRANSFER,JBWW.V.FT.REFUNDS.INP, FUNDS.TRANSFER,JBWW.V.FT.FEECHRG.INP &
* FUNDS.TRANSFER,JBWW.V.FT.INTERNAL.INP versions to restrict user to manually input different TRANSACTION.TYPES not accessible for his role.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer              Reference             Description
*-----------------------------------------------------------------------------
* 12-Oct-2018       Rajagopalan R    DAY15-4245 & DAY15-4482    Initial Draft
* 31-Oct-2018       Rajagopalan R    DAY15-5110                 Added OPF statements for USER and changed its RECORD variable.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.ERROR
    $INSERT I_F.USER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB GET.GEN.PARAM.DETAILS
    GOSUB GET.USER.ROLES
    GOSUB CASHROLE.CHECK

    RETURN
*-----------------------------------------------------------------------------
INIT:
*****
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER  = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.FT.TXN.TYPE.CONDITION = 'F.FT.TXN.TYPE.CONDITION'
    F.FT.TXN.TYPE.CONDITION  = ''
    CALL OPF(FN.FT.TXN.TYPE.CONDITION,F.FT.TXN.TYPE.CONDITION)

    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)
    
    F.EB.ERROR = ''
    FN.EB.ERROR = 'F.EB.ERROR'
    CALL OPF(FN.EB.ERROR,F.EB.ERROR)


    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER, F.USER)

    Y.TXN.TYPE = COMI

    JBWW.GEN.PAR.FN = ''   ; JBWW.GEN.PAR.FV = ''
    FT.TXN.CNT     = ''    ; FT.TXN.ID       = ''
    FT.TXN.DESC    = ''    ; FV.CNT          = ''
    FT.TXN.CNT     = ''    ; GP.ERR.MSG      = ''
    R.FT.TXN       = ''    ; R.GEN.REC.ROLE  = ''
    FT.ERR         = ''    ; VER.POS         = ''
    VER.NAME       = ''    ; R.GEN.REC.CASH  = ''
    R.GEN.REC.SEC  = ''
    Y.CASH.TXNTYPES.FN = ""
    Y.SEC.TXNTYPES.FN = ""

    RETURN
*-----------------------------------------------------------------------------
GET.GEN.PARAM.DETAILS:
**********************

    VER.NAME = APPLICATION:PGM.VERSION
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.GEN.REC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASHSEC.ROLES.FN = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.NAME>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.AC.CASH.TXNTYPES",R.GEN.CASHROLETXN,F.JBWW.H.EB.GENERICPARAMETER,CASHROLE.ERR)
    Y.CASHROLE.TXN.FN = R.GEN.CASHROLETXN<JBWW.GEN.PAR.FIELD.NAME>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.SC.SEC.TXNTYPES",R.GEN.SECROLETXN,F.JBWW.H.EB.GENERICPARAMETER,SECROLE.ERR)
    Y.SECROLE.TXN.FN = R.GEN.SECROLETXN<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE "CASH.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
         Y.CASH.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
         LOCATE VER.NAME IN Y.CASHROLE.TXN.FN<1,1> SETTING CASHTXN.POS THEN
              Y.CASH.TXNTYPES.FV = R.GEN.CASHROLETXN<JBWW.GEN.PAR.FIELD.VALUE,CASHTXN.POS>
          END
     END

    LOCATE "SEC.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
            Y.SEC.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
            LOCATE VER.NAME IN Y.SECROLE.TXN.FN<1,1> SETTING SECTXN.POS THEN
                 Y.SEC.TXNTYPES.FV = R.GEN.SECROLETXN<JBWW.GEN.PAR.FIELD.VALUE,SECTXN.POS>
            END
    END

    RETURN
    

READ.EB.ERROR:
**************
    R.EB.REC = ''
    Y.MSG.VAL = ''
    CALL F.READ(FN.EB.ERROR,"EB-JBWW.D.FT.TXNTYPE.CHK",R.EB.REC,F.EB.ERROR,'')
    Y.MSG.VAL = R.EB.REC<EB.ERR.ERROR.MSG>
    RETURN

GET.USER.ROLES:
***************
    Y.INPUT.USER = OPERATOR
    CALL F.READ(FN.USER,Y.INPUT.USER,R.INP.USER,F.USER,USR.ERR)
    Y.INPUSER.ROLES.LIST = R.INP.USER<EB.USE.USER.ROLES>
    IF Y.INPUSER.ROLES.LIST EQ '' THEN
        RETURN
    END
   CHANGE SM TO FM IN Y.INPUSER.ROLES.LIST
   Y.INPUSER.ROLES.CASH = Y.INPUSER.ROLES.LIST
    RETURN

CASHROLE.CHECK:
***************


    LOOP

        Y.USER.ROLES1 = ''
        ROLE.POS1 = ''

        REMOVE Y.USER.ROLES1 FROM Y.INPUSER.ROLES.LIST SETTING ROLE.POS1
    WHILE Y.USER.ROLES1:ROLE.POS1
        FV.CASH.ROLE.POS1 = ''
        LOCATE Y.USER.ROLES1 IN Y.CASH.USER.ROLES<1,1,1> SETTING FV.CASH.ROLE.POS1 THEN
            CASHTXNTYPE.POS1 = ''
            LOCATE Y.TXN.TYPE IN Y.CASH.TXNTYPES.FV<1,1,1> SETTING CASHTXNTYPE.POS1 THEN
                   CALL F.READ(FN.FT.TXN.TYPE.CONDITION,Y.TXN.TYPE,R.FT.TXN,F.FT.TXN.TYPE.CONDITION,CASHFT.ERR)
                   CASH.FT.TXN.DESC = R.FT.TXN<FT6.DESCRIPTION>
                   LIST.ARRY<-1> = Y.TXN.TYPE:"*":CASH.FT.TXN.DESC
             END ELSE

                   GOSUB READ.EB.ERROR
                   ETEXT = Y.MSG.VAL
                   CALL STORE.END.ERROR
                   RETURN
             END
         END ELSE
  *           GOSUB GET.USER.ROLES
             GOSUB SECROLE.CHECK
         END
    REPEAT
 RETURN

SECROLE.CHECK:
**************

    LOOP
        Y.USER.ROLES2 = ''
        ROLE.POS2 = ''
        REMOVE Y.USER.ROLES2 FROM Y.INPUSER.ROLES.CASH SETTING ROLE.POS2
    WHILE Y.USER.ROLES2:ROLE.POS2
        FV.SEC.ROLE.POS2 = ''
        LOCATE Y.USER.ROLES2 IN Y.SEC.USER.ROLES<1,1,1> SETTING FV.SEC.ROLE.POS2 THEN
            SECTXNTYPE.POS2 = ''
            LOCATE Y.TXN.TYPE IN Y.SEC.TXNTYPES.FV<1,1,1> SETTING SECTXNTYPE.POS2 THEN
              CALL F.READ(FN.FT.TXN.TYPE.CONDITION,Y.TXN.TYPE,R.FT.TXN,F.FT.TXN.TYPE.CONDITION,SECFT.ERR)
              SEC.FT.TXN.DESC = R.FT.TXN<FT6.DESCRIPTION>
              LIST.ARRY<-1> = Y.TXN.TYPE:"*":SEC.FT.TXN.DESC
            END ELSE

               GOSUB READ.EB.ERROR
               ETEXT = Y.MSG.VAL
               CALL STORE.END.ERROR
               RETURN
            END
         END
    
    REPEAT
  RETURN
END