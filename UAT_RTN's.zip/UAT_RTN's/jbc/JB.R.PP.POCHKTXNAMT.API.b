SUBROUTINE JB.R.PP.POCHKTXNAMT.API(iApplication, iPmtOrdrId, iPmtOrdrRecord, iPorTransaction, iPorSupplementaryInfo, iAgreementAndAdvice, iPostingAndConfirmation, iAuditTrail)
*--------------------------------------------------------------------------------------------------------------------
* This is a Send Payment Txn API attached in Payment Order Product to validate and throw an error if Credit Amount
* is less than Charge Amount.
*--------------------------------------------------------------------------------------------------------------------
* Date          Resource               JIRA                   Remarks
* 09-Jun-2025   Prabhu D S             CBPAY-2759             Initial Draft
*--------------------------------------------------------------------------------------------------------------------
    $USING EB.SystemTables
    $USING PI.Contract
    $USING EB.ErrorProcessing

    PoCreditAmount = iPmtOrdrRecord<PI.Contract.PaymentOrder.PoCreditAmount>
    PoChargeAmount = iPmtOrdrRecord<PI.Contract.PaymentOrder.PoChargeAcCcyAmount>
    PoChargeType = iPmtOrdrRecord<PI.Contract.PaymentOrder.PoChargeBearer>
    PoAmountDIff = PoCreditAmount - PoChargeAmount

    IF (PoChargeType EQ "BEN") AND (PoAmountDIff LE '0.1') THEN
       EB.SystemTables.setAf(PI.Contract.PaymentOrder.PoCreditAmount)
       EB.SystemTables.setEtext("FT-LOCAL.CR.AMT.POSITIVE")
       EB.ErrorProcessing.StoreEndError()
    END

RETURN
END
