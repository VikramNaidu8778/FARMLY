SUBROUTINE JB.R.AC.STODEFFTRTN.INPUT
*------------------------------------------------------------------------------------------------------------
*------------------------------------------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* This Routine is attached in Field Ft Routine , in VERSION "STANDING.ORDER,JB.V.AC.STOOT03OT12" to 
* Default user inputted Charges .
*-------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: N/A
* OUT: N/A
* Revision History:
*--------------------------------------------------------------------------------------------------------------
* Date               who               Reference          Description

*19-JUL-2024         Lakshmi Priya       CBPAY-100          This routine is to set to call '@JB.R.AC.MAPSTOCLCHG.RTN' Routine .

*--------------------------------------------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.STANDING.ORDER

R.NEW(STO.FT.ROUTINE) = '@JB.R.AC.MAPSTOCLCHG.RTN' 

RETURN
END
