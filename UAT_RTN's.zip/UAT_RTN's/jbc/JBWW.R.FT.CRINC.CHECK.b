*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.CRINC.CHECK
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is input routine attached to version FUNDS.TRANSFER,INWARD.This routine
* checks whether the credit account is an Income account, if yes & transaction type is IT
* then stores the error message in the field L.XX.BLK.MSG.
*-------------------------------------------------------------------------
* Attached: As input routine to FUNDS.TRANSFER,INWARD Version.
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN:NA
* OUT:NA
*
* Dependencies:
*---------------
*
* RevisionHistory:
*------------------
* Date          Developer   Reference   Description
*
* 28/09/2018    Anuha P     DAY15-4766  This is input routine to block FT-IT type based on credit account check
*
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.EB.ERROR
    
    IF R.NEW(FT.TRANSACTION.TYPE) EQ 'IT' THEN
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END 

    RETURN

*==========
OPEN.FILES:
*==========

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
 
    FN.EB.ERROR = 'F.EB.ERROR'
    F.EB.ERROR = ''
    CALL OPF(FN.EB.ERROR,F.EB.ERROR)

    RETURN

*=======
PROCESS:
*=======

    Y.CR.INC.FLAG = ''
    Y.MSG.FLAG = ''
    Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)

    APP = 'FUNDS.TRANSFER'
    FLD = 'L.XX.BLK.MSG'
    POS = ''
    CALL MULTI.GET.LOC.REF(APP,FLD,POS)
    Y.BLKMSG.POS = POS<1,1>

    IF R.NEW(FT.TRANSACTION.TYPE) EQ 'IT' THEN
       Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
       GOSUB PROCESS.FETCH.ACCNT
    END

    IF Y.CR.INC.FLAG THEN
        EB.ERR.ID = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        R.ERR = '' ; EB.ERR = '' ; Y.ERR.MSG = '' ; Y.BLK.MSG = ''
        CALL F.READ(FN.EB.ERROR,EB.ERR.ID,R.ERR,F.EB.ERROR,EB.ERR)
        IF R.ERR THEN
           Y.ERR.MSG = R.ERR<EB.ERR.ERROR.MSG>
           Y.BLK.MSG = R.NEW(FT.LOCAL.REF)<1,Y.BLKMSG.POS>
           CHANGE SM TO FM IN Y.BLK.MSG
           MSG.POS = ''
           LOCATE Y.ERR.MSG IN Y.BLK.MSG SETTING MSG.POS THEN
             Y.MSG.FLAG = 1
           END
        END
        IF NOT(Y.MSG.FLAG) THEN 
           Y.BLKMSG.CNT = DCOUNT(Y.BLK.MSG,FM)
           R.NEW(FT.LOCAL.REF)<1,Y.BLKMSG.POS,Y.BLKMSG.CNT+1> = Y.ERR.MSG
           CALL REBUILD.SCREEN()
        END
        ETEXT = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        CALL STORE.END.ERROR
    END

    

    RETURN

*===================
PROCESS.FETCH.ACCNT:
*===================

    R.ACCOUNT = ''; ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE "" THEN
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.POS THEN
            Y.SAM.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,ALT.POS>
            Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
            GOSUB CHECK.ACCOUNT.SAM
        END
    END

    RETURN
    
*=================
CHECK.ACCOUNT.SAM:
*=================

    R.SAM.ALT.REC = ''; SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC NE'' THEN
        Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        R.SAM = ''; SAM.ERR = ''
        CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,SAM.ERR)
        IF R.SAM THEN
*To check CR Account is an income account
           INC.POS = ''
           LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
              Y.CR.INC.FLAG = 1
           END
        END
    END

    RETURN

    END