* @ValidationCode : MjoxNjY1OTc1OTM4OkNwMTI1MjoxNzA0Nzc2OTU0Nzk1OmRldmNsb3VkOjI6MDowOjE6ZmFsc2U6Ti9BOlIyMl9TUDUuMDo0MTo0MQ==
* @ValidationInfo : Timestamp : 09 Jan 2024 05:09:14
* @ValidationInfo : Encoding : Cp1252
* @ValidationInfo : User Name : devcloudi
* @ValidationInfo : Nb tests success : 2
* @ValidationInfo : Nb tests failure : 0
* @ValidationInfo : Rating : N/A
* @ValidationInfo : Coverage : 41/41 (100.0%)
* @ValidationInfo : Strict flag : true
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version : R22_SP5.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.
*
* hookApiInput(IN) :
* channelDetails(IN) :
* debitBankCondiions(IN) :
* creditParty(IN) :
* accountInfo(IN) :
* hookApiOutput(OUT) :
*
SUBROUTINE JB.R.PP.VALUEDATECOV.DDHOOK(hookApiInput, channelDetails, debitBankCondiions, creditParty, accountInfo, hookApiOutput)
*-----------------------------------------------------------------------------
* Attached to : HookApiName field for "PRE" in PP.COMPONENT.API.HOOK table for dateDetermination.
*-----------------------------------------------------------------------------
* Description:
* Subroutine to update the value date of the pacs.009cov message into the value date of the pacs.008 announcement message
* This routine handle both the cases of pacs.008 received first, pacs.009cov received second and viceversa
* In the case of pacs.009cov received first and pacs.008 second. Value date raised for pacs.009cov suspense accounting entries
* is changed to pacs.008 processing date (T+n) day. This is also updated to capture the value date of the pacs.009cov message received (T day)
*-----------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------------------------------------
* Date             Developer        Reference                        Description
*
* 22-Aug-2024      u40786           CBPAY-35/CBPAY-42/PAYCH25-245    Initial Version
*
* 03-Jan-2025      vikram pavuluru  CBPAY-1513                       Added Logic for handling When TPH receives a pacs.008/pacs.009 Payment with Interbank Settlement date as
*                                                                    Back dated payment.In the Order entry record, system needs to equate the Credit value date and Debit value date
*                                                                    with Requested credit value date.
*
* 19-04-2025       u40786           CBPAY-2237 & CBPAY-2105          RCVCBK to be considered first, if not exist then consider SNDCBK - in pacs.008
*                                                                    to search for the corresponding pacs.009cov AC.EXPECTED.RECS record
*
*----------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $USING PP.DateDeterminationService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentWorkflowGUI
    $USING EB.DataAccess
    $USING ER.Contract
    $USING PP.PaymentSTPFlowService
    $USING EB.SystemTables
    $USING ER.Config
    $USING ER.Api
    $USING ST.CompanyCreation
    $USING EB.Foundation
    $USING EB.API

    GOSUB INITIALISE
    GOSUB MAIN.PROCESS
*
RETURN
*
***********
INITIALISE:
***********

    ftNumber = hookApiInput<PP.DateDeterminationService.InDateDetails.ftNumber>
    companyId = hookApiInput<PP.DateDeterminationService.InDateDetails.companyID>
    PaymentDirection = hookApiInput<PP.DateDeterminationService.InDateDetails.paymentDirection>
    IntrBnkStlmntDate = hookApiInput<PP.DateDeterminationService.InDateDetails.reqCreditValueDate>
    
    oPaymentRecord = ""
    oAdditionalPaymentRecord = ""
    oReadErr = ""
    supplementaryRec = ""
    expectedRec = ""
    supplementaryError = ""
    expectedError = ""

    FN.POR.SUPPLEMENTARY.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPLEMENTARY.INFO = ""
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, F.POR.SUPPLEMENTARY.INFO)

    FN.AC.EXPECTED.RECS = "F":companyId:".AC.EXPECTED.RECS"
    F.AC.EXPECTED.RECS = ""
    CALL OPF(FN.AC.EXPECTED.RECS, F.AC.EXPECTED.RECS)
*
RETURN
*
*************
MAIN.PROCESS:
*************

    PP.PaymentWorkflowDASService.getPaymentRecord(ftNumber, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)
    IF oPaymentRecord THEN
        messageType = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.incomingMessageType>
        COV.FLAG = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.validationFlag>
        CALL F.READ("F.POR.SUPPLEMENTARY.INFO", ftNumber, supplementaryRec, F.POR.SUPPLEMENTARY.INFO, supplementaryError)
        IF supplementaryRec THEN

            ANNOUNCEMENT = ''
            IF messageType MATCHES "pacs.008" :@VM: "103" THEN
                LOCATE "SETLMTD" IN supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPiInformationcode,1> SETTING SETLMTD.POS THEN
                    PI.INSTRUCTION.CODE = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPiInstructionCode,SETLMTD.POS>
                    LOCATE "COVE" IN PI.INSTRUCTION.CODE<1,1> SETTING COVE.POS THEN
* Flag to identify the pacs.008 message with setttlement method as COVE
                        ANNOUNCEMENT = 1
                    END
                END
            END
            IF ((messageType EQ "pacs.008" OR messageType EQ "103") AND ANNOUNCEMENT) OR ((messageType EQ "pacs.009" OR messageType EQ "202") AND COV.FLAG EQ "COV") THEN
* To process only for pacs.008 announcement / pacs.009cov messages
                GOSUB PROCESS
            END ELSE
*CBPAY-1513
* To impose credit and debit value date with requested credit value date of pacs.008/pacs.009cov messages when requested credit value date is less than today
                IF PaymentDirection EQ 'I' THEN
                    IF messageType MATCHES 'pacs.008' :@VM: '103' :@VM: 'pacs.009' :@VM: '202' THEN
                        IF IntrBnkStlmntDate LT TODAY THEN
                            GOSUB updateValueDate2
                        END
                    END
                END
            END
        END
*
        RETURN
*
********
PROCESS:
********

        acerMatchId = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdAcerMatchedId>
        matchStatus = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdMatchStatus>
        BEGIN CASE
            CASE messageType EQ "pacs.008" OR messageType EQ "103"
                IF matchStatus EQ "M" THEN
* For Case-01, where pacs.008 received 1st, it is expected to fail - as matchstatus is not M
* For Case-01a, where pacs.008 received 1st, it is expected to pass - AER record will exist, (message move from 20 to 999)
* For Case-02, where pacs.008 received 2nd, it is expected to fail - as matchstatus is not M
                    GOSUB updateValueDate
                END ELSE
* When message move from 4 to 235
* For Case-01, where pacs.008 received 1st, it is expected to pass - but AER record will not exist, so MATCHED flag is not set (message move from 4 to 235)
* For Case-02, where pacs.008 received 2nd, it is expected to pass - as matchstatus is not M, MATCHED flag should be set (message move from 4 to 235)
* For Case-03, manual match where pacs.008 received 2nd, this will fial - Need to write OE Input Routine
                    GOSUB GET.MATCH.AER
                    IF R.MATCHED.MSG.1 THEN
                        GOSUB updateValueDate1
                    END
                END
            CASE (messageType EQ "pacs.009" OR messageType EQ "202") AND acerMatchId
* For Case-01, where pacs.009cov received 2nd, it is expected to fail - this case when message move from 4 to 235
* For Case-02, where pacs.009cov received 1st, it is expected to fail - this case when message move from 4 to 235
* For Case-02, where pacs.009cov received 1st, it is expected to pass - this case when message move from 20 to 999
* Read the corresponding the AC.EXPECTED.RECS to get the value date
                acerMatchId = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdAcerRecordId>
                GOSUB updateValueDate
        END CASE
*
        RETURN
*
**************
GET.MATCH.AER:
**************

        GOSUB READ.ER.PARAM

        IN.MATCH.TYPE = ''
        EXP.FUNDS.TYPE = R.ER.PARAMETER.REC<ER.Config.ErParameter.ErParExpFundsType>
        PAY.FUNDS.TYPE = R.ER.PARAMETER.REC<ER.Config.ErParameter.ErParPayFundsType>
        MSG.FUNDS.TYPE = 'EC' ;* to get the corresponding pacs.009cov message

        GOSUB READ.ER.FUNDS.TYPE.PARAM

        MATCHING.CONDITION = R.ER.FUNDS.TYPE.PARAM<ER.Config.ErfundsTypeParam.ErFPMatchCondition>
        MATCH.CONDITION.CNT = DCOUNT(MATCHING.CONDITION, @VM) ;* Get MatchCondition count

        MATCH.FUNDS.TYPE = R.ER.FUNDS.TYPE.PARAM<ER.Config.ErfundsTypeParam.ErFPMatchFundsType> ;* Get MatchFundsType value

        BEGIN CASE
            CASE MATCH.FUNDS.TYPE AND (MATCH.CONDITION.CNT GT 1)
                MATCH.FUNDS.TYP.VALUES = MATCH.FUNDS.TYPE
                FOR THIS.CONDITION = 1 TO MATCH.CONDITION.CNT
                    MATCHING.COND = MATCHING.CONDITION<1,THIS.CONDITION>
                    MATCH.FUNDS.TYPE = MATCH.FUNDS.TYP.VALUES<1,THIS.CONDITION>
                    GOSUB CALL.MATCHING.CONDITION.PROCESS
                    IF R.MATCHED.MSG.1 THEN
                        RETURN
                    END
                NEXT THIS.CONDITION
                RETURN

            CASE MATCH.CONDITION.CNT EQ 1
                MATCHING.COND = MATCHING.CONDITION
                GOSUB CALL.MATCHING.CONDITION.PROCESS
                RETURN
        END CASE
*
        RETURN
*
****************
updateValueDate:
****************

        CALL F.READ("F.AC.EXPECTED.RECS", acerMatchId, expectedRec, F.AC.EXPECTED.RECS, expectedError)
        IF expectedRec THEN
            hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.creditValueDate> = expectedRec<ER.Contract.ExpectedRecs.ExpValueDate>
            hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.debitValueDate> = expectedRec<ER.Contract.ExpectedRecs.ExpValueDate>
            hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.processingDate> = TODAY
        END
*
        RETURN
*
*****************
updateValueDate1:
*****************

        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.creditValueDate> = R.MATCHED.MSG.1<ER.Contract.ExpectedRecs.ExpValueDate>
        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.debitValueDate> = R.MATCHED.MSG.1<ER.Contract.ExpectedRecs.ExpValueDate>
        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.processingDate> = TODAY
*
        RETURN
*
*****************
updateValueDate2:
*****************

        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.creditValueDate> = IntrBnkStlmntDate
        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.debitValueDate> = IntrBnkStlmntDate
        hookApiOutput<PP.DateDeterminationService.DatesPreApiOutputDetails.processingDate> = TODAY
*
*
        RETURN
*
**************
READ.ER.PARAM:
**************

**READ parameter file

        PARTIAL.MATCH = ''
        ER.PARAMETER.ID = 'SYSTEM'

        R.ER.PARAMETER.REC = ''
        R.ER.PARAMETER.REC = ER.Config.ErParameter.Read(ER.PARAMETER.ID, RETURN.VALUE)

        IF RETURN.VALUE NE '' THEN
            EB.SystemTables.setText('READ FAILED FILE ER.PARAMETER REC SYSTEM')
            RETURN
        END
*
        RETURN
*
*************************
READ.ER.FUNDS.TYPE.PARAM:
*************************

        FUNDS.PARAM.READ.ERR = ""
        R.ER.FUNDS.TYPE.PARAM = ER.Config.ErfundsTypeParam.Read(MSG.FUNDS.TYPE, FUNDS.PARAM.READ.ERR)
*
        RETURN
*
********************************
CALL.MATCHING.CONDITION.PROCESS:
********************************

        IF MATCHING.COND NE "" THEN
            MATCHING.CONDITION.READ.ERR = ""
            R.MATCHING.CONDITION = ""
            R.MATCHING.CONDITION = ER.Config.ErMatchingCondition.Read(MATCHING.COND, MATCHING.CONDITION.READ.ERR)
            IN.MATCH.TYPE<1> = ''
            IN.MATCH.TYPE<2> = EXP.FUNDS.TYPE
            IN.MATCH.TYPE<3> = PAY.FUNDS.TYPE
            IN.MATCH.TYPE<4> = MATCH.FUNDS.TYPE

* Details to be matched based on the ER.MATCHING.CONDITION setup
            R.FIND.M.MSG = ''
            R.FIND.M.MSG<ER.Contract.ExpectedRecs.ExpReference> = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.sendersReferenceIncoming>
            R.FIND.M.MSG<ER.Contract.ExpectedRecs.ExpCcyAmount> = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.transactionCurrencyCode>:oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.transactionAmount>
            R.FIND.M.MSG<ER.Contract.ExpectedRecs.ExpValueDate> = oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.requestedCreditValueDate>
            LOCATE "RCVCBK" IN supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyRole,1> SETTING RCVCBK.POS THEN
				SEARCH.BIC = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyIdentifierCode,RCVCBK.POS>
			END ELSE
				LOCATE "SNDCBK" IN supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyRole,1> SETTING SNDCBK.POS THEN
					SEARCH.BIC = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyIdentifierCode,SNDCBK.POS>
				END
			END
            R.FIND.M.MSG<ER.Contract.ExpectedRecs.ExpCorrespBic> = SEARCH.BIC

            ER.Api.ExpectedRecsMatchingConditionProcess(IN.MATCH.TYPE,R.FIND.M.MSG,R.MATCHING.CONDITION,MATCHED.MSG.ID.1,R.MATCHED.MSG.1,RETURN.VALUE)
        END
*
        RETURN
*
    END
*