SUBROUTINE JB.R.PP.ACCOUNTINFO.BLD(ENQ.DATA)
*--------------------------------------------------------------------------------------------
* Description : Build routine to retrieve Portfolio Number
* Attached to : ENQUIRY>JB.E.PP.ACCT.INFO
* Attached as : BUILD.ROUTINE
*--------------------------------------------------------------------------------------------
*  Modification History :
*--------------------------------------------------------------------------------------------
* Date          Developer            Reference             Description
* 03-01-2025    Prabhu D S           CBPAY-1410            Initial Draft
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    
    GOSUB INIT
    GOSUB EXTRACT.PORT.NO

RETURN

*****
INIT:
*****

    Y.ACCT = ''
    R.ALTERATE.ACCOUNT = ''
    ALT.ACCT.ERR = ''
    R.ACCOUNT = ''
    ACC.ERR = ''


    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ATERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)


RETURN

****************
EXTRACT.PORT.NO:
****************

    Y.ACCT = ENQ.DATA<4,1>

    CALL F.READ(FN.ALTERNATE.ACCOUNT, Y.ACCT, R.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT, ALT.ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACCT = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
    END

    CALL F.READ(FN.ACCOUNT, Y.ACCT, R.ACCOUNT, F.ACCOUNT, ACC.ERR)
    IF R.ACCOUNT THEN
        Y.SAM.ID = R.ACCOUNT<AC.PORTFOLIO.NO,1>
        IF Y.SAM.ID NE '' THEN
            GOSUB READ.SAM
        END
    END

    ENQ.DATA<4,1> = Y.ACCT

RETURN

*********
READ.SAM:
*********

    R.SAM.REC = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
    IF R.SAM.REC THEN
        Y.ACCT = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
    END


RETURN

END
