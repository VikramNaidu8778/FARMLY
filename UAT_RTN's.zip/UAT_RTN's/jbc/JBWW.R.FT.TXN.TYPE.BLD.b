
    SUBROUTINE JBWW.R.FT.TXN.TYPE.BLD(ENQ.DATA)
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
*    Date       Developer             Reference               Description
*-------------------------------------------------------------------------
* 07/08/2018	Balaji				  DAY15-3268             
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON

*-----------------------------------------------------------------------------
    GOSUB PROCESS
	RETURN

*============
PROCESS:
*=========
	ENQ.DATA<2,-1> = 'TRANSACTION.TYPE'
	ENQ.DATA<3,-1> = 'EQ'
	ENQ.DATA<4,-1> = 'ACAC ACPM ODDL ODDF OTDA OT03 OT12 OT60 ICCL ICCF IT ITPM ACIA'
	
	RETURN
	
END