* @ValidationCode : MTotNDIwMDUyNzM5OklTTy04ODU5LTE6MTUzNjkwNTk4NjQwNzphMzg4NDY6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 14 Sep 2018 14:19:46
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38846
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.RSTRCT.NONAC.INCACT
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* Input routine to block FT with DR/CR acct being an Income account
*-------------------------------------------------------------------------
* Attached: As input routine to VERSION.CONTROL>FUNDS.TRANSFER
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN:NA
* OUT:NA
*
* Dependencies:
*---------------
*
* RevisionHistory:
*------------------
* Date              Developer       Reference               Description
*
* 10/09/2018        Prem Chand.E    DAY15-3134/DAY15-3597  Input routine to block FT with DR/CR acct being an Income account
*                                                          And FTTC other than ACIA/ACME/ACMI/ACFX 
*
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER


    IF R.NEW(FT.TRANSACTION.TYPE) MATCHES 'ACIA':VM:'ACME':VM:'ACMI':VM:'ACFX' THEN
        RETURN
    END ELSE
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END


    RETURN

*==========
OPEN.FILES:
*==========
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)

    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
    RETURN

*=======
PROCESS:
*=======
    Y.INC.FLAG = ''
    Y.DR.INC.FLAG = ''
    Y.CR.INC.FLAG = ''
    Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)


    IF Y.DR.ACNO[1,2] NE "PL" THEN
        Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
        GOSUB PROCESS.FETCH.ACCNT
    END

    IF NOT(Y.INC.FLAG) AND Y.CR.ACNO[1,2] NE "PL" THEN
        Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
        GOSUB PROCESS.FETCH.ACCNT
    END


    IF Y.INC.FLAG THEN
        AF = Y.FIELD
        ETEXT = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        CALL STORE.END.ERROR
    END

    RETURN

*=================
CHECK.ACCOUNT.SAM:
*=================

    R.SAM.ALT.REC = '';SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC NE'' THEN
        Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        R.SAM = '';SAM.ERR = ''
        CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
        IF R.SAM THEN
            GOSUB CHECK.SAM.INC.ACCNT
        END
    END

    RETURN

*=========
PROCESS.FETCH.ACCNT:
*=========

    R.ACCOUNT = '';ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE"" THEN
        Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.POS THEN
        Y.SAM.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,ALT.POS>
        Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
        GOSUB CHECK.ACCOUNT.SAM
    END
    END

    RETURN

*==================
CHECK.SAM.INC.ACCNT:
*==================

*To check atleast one of the account(DR/CR acct) is an income account
    INC.POS = ''
    LOCATE Y.DR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
		Y.DR.INC.FLAG = 1
		Y.FIELD = FT.DEBIT.ACCT.NO
    END

    INC.POS = ''
    LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1>SETTING INC.POS THEN
		Y.CR.INC.FLAG = 1
		Y.FIELD = FT.CREDIT.ACCT.NO
    END

    IF Y.DR.INC.FLAG AND Y.CR.INC.FLAG THEN
        Y.PORT.FLAG = 1
    END

    IF Y.DR.INC.FLAG OR Y.CR.INC.FLAG THEN
        Y.INC.FLAG = 1
    END

    RETURN

    END
