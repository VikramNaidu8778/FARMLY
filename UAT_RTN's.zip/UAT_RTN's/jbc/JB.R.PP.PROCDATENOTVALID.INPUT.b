* @ValidationCode : MjoxMDQzMjg3ODc6Q3AxMjUyOjE3MTM3ODQwNzAzNDI6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 12 May 2024 16:37:50
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PROCDATENOTVALID.INPUT
*-------------------------------------------------------------------------
*This routine is the copy of JBWW.R.FT.PROCDATENOTVALID.INPUT in the existing FT version, which changed to PO application now.
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date         Developer           Reference       Description
*-------------------------------------------------------------------------
* 13/08/2018  Hariharan T         CBPAY-51     Changing the no.of.auth to 0, when backdated INAU PO record is inputted and committed.
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.VERSION
*-------------------------------------------------------------------------

    V.FUNC = V$FUNCTION
    IF V.FUNC NE 'D' THEN
        GOSUB PROCESS
    END

RETURN

*--------------------------------------------------------------------------
PROCESS:
********
    Y.PROC.DATE = R.NEW.LAST(PO.PAYMENT.EXECUTION.DATE)

    IF Y.PROC.DATE LT TODAY THEN
        R.VERSION(46) = '0'
    END

RETURN

*--------------------------------------------------------------------------

END
