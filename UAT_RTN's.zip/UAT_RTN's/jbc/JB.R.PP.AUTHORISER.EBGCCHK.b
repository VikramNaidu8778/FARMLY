* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 08 May 2024 08:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 821829
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
* <Rating>-49</Rating>
*------------------------------------------------------------------------------------------------------------------------------------------------------
    SUBROUTINE JB.R.PP.AUTHORISER.EBGCCHK
*------------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing FT Version Routine JBWW.R.FT.AUTHORISER.EBGCCHK and incorporated with TPH Payment order and Order Entry application Logic.
*  Descrption   :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
* 2024-04-16	 Amala P		               CBPAY-274		                         To make the AUTHORISER field as Null in Payment Order.
* 2024-07-02	 Amala P		               CBPAY-534		                         To make the AUTHORISER field as Null in Payment Order.
*--------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
	$INSERT I_F.PP.ORDER.ENTRY
	$INSERT I_F.EB.QUERIES.ANSWERS	
    
	Y.COMI = "" 
	Y.RECORD.STATUS = ""
	Y.COMI = COMI
	BEGIN CASE
	  CASE ID.NEW[1,2] EQ 'PI' 
	       Y.RECORD.STATUS = R.NEW(PO.RECORD.STATUS)
	  CASE ID.NEW[1,2] EQ 'OE'
	       Y.RECORD.STATUS = R.NEW(PP.OEYG.RECORD.STATUS)
	  CASE ID.NEW[1,4] EQ 'FMQA'
	       Y.RECORD.STATUS = R.NEW(EB.QA.RECORD.STATUS)
	  END CASE
	IF Y.RECORD.STATUS EQ "INA2" AND Y.COMI THEN
	   COMI = ""
	END
    RETURN

    END

