*----------------------------------------------------------------------------------------------------------------
SUBROUTINE JBWW.B.XX.MOVEFT(Y.FT.LIST)
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the run routine of the multi thread job that moves the FT application
* records placed in INAU and with processing date less than today
*----------------------------------------------------------------------------------------------------------------
* Attached: to
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: Y.FT.LIST � record id's of the FT Application
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date               who              Reference            Description
* 05-07-2018        Smitha           DAY15-1072           Initial Version
* 16-07-2018        Smitha           Day15-2708           Bug Fix
* 08-11-2023	    Benjamin	     GBLBB-945		      Refactoring for OFS Call Bulk Manager - JB.R.EB.OFSRESPONSEPARSE added
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.DATES
    $INSERT I_JBWW.B.XX.MOVEFT.COMMON
*-----------------------------------------------------------------------------------------------------------------
	

    R.FT.NAU = "" ; FT.NAU.ERR = ""
    CALL F.READ(FN.FUNDS.TRANSFER$NAU,Y.FT.LIST,R.FT.NAU,F.FUNDS.TRANSFER$NAU,FT.NAU.ERR)
    IF R.FT.NAU NE " " THEN
        R.FT.NAU<FT.PROCESSING.DATE> = TODAY
    END
   
    Y.OFS.PROCESS = "PROCESS"
    Y.OFS.APP.NAME = "FUNDS.TRANSFER"
    Y.OFS.SOURCE = "JBWW.D.UNAUTHFT.OFS"
    Y.OFS.INPUT.FUN = "I"
    Y.OFS.VERSION = "FUNDS.TRANSFER,JBWW.V.SC.MOVEFT.INP"

***Day15-2708 -Start
	R.FT.NAU.TEMP = ''
	R.FT.NAU.TEMP<FT.PROCESSING.DATE> = TODAY
***Day15-2708-End
    CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.INPUT.FUN,Y.OFS.PROCESS,Y.OFS.VERSION,'','',Y.FT.LIST,R.FT.NAU.TEMP,Y.BUILT.OFS)

    CALL OFS.CALL.BULK.MANAGER(Y.OFS.SOURCE,Y.BUILT.OFS,Y.REQ.MSG,Y.RESP)
*GBLBB-945 START
    Y.OFS.RESPONSE = Y.REQ.MSG
    OFS.ERR.RESPONSE = ""
    TXN.ID   = ""
    SUCCESS.FLG = ""
    Y.RESP.OFS.ERROR = ""
    CALL JB.R.EB.OFSRESPONSEPARSE(Y.OFS.RESPONSE,OFS.ERR.RESPONSE,TXN.ID,SUCCESS.FLG,Y.RESP.OFS.ERROR,'')
	
*	IF Y.REQ.MSG['/',3,1] LT 1 THEN
    IF SUCCESS.FLG LT 1 THEN
*		Y.RESP.OFS.ERROR = Y.REQ.MSG['/',4,1]
*GBLBB-945 START
		Y.RESP.FOLD.MSG = FOLD(Y.RESP.OFS.ERROR,35)
	END

    IF Y.RESP.OFS.ERROR THEN
        CALL OCOMO(Y.RESP.OFS.ERROR)
    END
*GBLBB-945 END
RETURN
*----------------------------------------------------------------------------------

END
