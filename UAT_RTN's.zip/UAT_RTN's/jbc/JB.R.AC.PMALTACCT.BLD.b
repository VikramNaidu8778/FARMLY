*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.AC.PMALTACCT.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*This routine is used to filter the alternate account for BJB account.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*
* Date              Author                         Reference                     Description
*----------------------------------------------------------------------------------------------
* 23-08-2016        PuthumaiSamy                   Payments                 Initial Version
* 18-04-2017		Balaji Pushparaj			   JB2A-31241               Throw an error if selection is not provided.
* 11-01-2022        Anitha                         T24-17816                SEL command corrected to avoid TAFJ error due to quotes
***********************************************************************************
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_ENQUIRY.COMMON
$INSERT I_F.ACCOUNT
$INSERT I_F.CURRENCY
$INSERT I_F.ALTERNATE.ACCOUNT

*-----------------------------------------------------------------------------
    
	GOSUB INIT
    GOSUB PROCESS

    RETURN
*-------------------------------------------------------------------	
  INIT:
  *****
    ALTACCT.IDS = ''
	Y.PMTXN.FLAG = ''
	Y.PMCCY.FLAG = ''
	Y.PMALTACT.IDS = ''
	Y.NON.PMALTACT.IDS = ''
	
    FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)
	
	FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
	F.ALTERNATE.ACCOUNT = ''
	CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
	
	FN.CURRENCY = 'F.CURRENCY'
	F.CURRENCY = ''
	CALL OPF(FN.CURRENCY,F.CURRENCY)
	
	Y.SEL.OPRND = ENQ.DATA<3>
	Y.FILTER.VALUE = ENQ.DATA<4>

*For ACPM & OT60 edge transaction screen , the filter string would be passed like this �Id startwith(�<txntype>_<Portfolio No>�)� to determine the PM screen
    Y.NO.OF.FILTER = DCOUNT(Y.FILTER.VALUE,'_')
	IF Y.NO.OF.FILTER EQ 2 THEN 
		Y.TXN.TYPE = FIELD(Y.FILTER.VALUE,'_',1)
		Y.SEL.VALUE = FIELD(Y.FILTER.VALUE,'_',2)
		ENQ.DATA<4,1> = Y.SEL.VALUE
	END ELSE
        Y.SEL.VALUE = Y.FILTER.VALUE
    END

	*S-JB2A-31241
		IF Y.SEL.VALUE EQ "" OR Y.SEL.VALUE EQ "..." THEN
		ENQ.ERROR = "EB-PORTFOLIO.MISSING"
		RETURN
		END
	*E-JB2A-31241
 	
	IF Y.TXN.TYPE EQ 'ACPM' OR Y.TXN.TYPE EQ 'OT60' OR Y.TXN.TYPE EQ 'ITPM' THEN
	   Y.PMTXN.FLAG = 'YES'	   
	END 
	
  RETURN
*--------------------------------------------------------------------------  
  PROCESS:
  ********
  
   *IF Y.SEL.OPRND EQ 'LK' AND Y.SEL.VALUE NE '' THEN
   
   IF Y.SEL.VALUE NE '' THEN
        *SEL.CMD = "SELECT ":FN.ALTERNATE.ACCOUNT:" WITH @ID LIKE ":Y.SEL.VALUE:"..."
		 SEL.CMD = "SELECT ":FN.ALTERNATE.ACCOUNT:" WITH @ID LIKE ":'"':"'":Y.SEL.VALUE:"'...":'"'   ;*T24-17816 TAFJMATCHES
   END 
   
   *ELSE   
	*SEL.CMD = "SELECT ":FN.ALTERNATE.ACCOUNT   
   *END
   
   CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.SEL,SEL.ERR)
   LOOP
      REMOVE ALTACT.ID FROM SEL.LIST SETTING ALTACT.POS
   WHILE ALTACT.ID : ALTACT.POS
      
	  R.ALT.ACCOUNT = ''
	  ALTACCT.ERR = ''
	  Y.GLOB.ACC.NO = ''
	  CALL F.READ(FN.ALTERNATE.ACCOUNT,ALTACT.ID,R.ALT.ACCOUNT,F.ALTERNATE.ACCOUNT,ALTACCT.ERR)
	  IF R.ALT.ACCOUNT THEN
		Y.GLOB.ACC.NO = R.ALT.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
        CALL F.READ(FN.ACCOUNT,Y.GLOB.ACC.NO,R.ACCOUNT,F.ACCOUNT,ACCT.ERR)
	    ALT.ACCT.TYPE = R.ACCOUNT<AC.ALT.ACCT.TYPE>
		Y.ACCT.CCY = R.ACCOUNT<AC.CURRENCY>
		ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
		LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
		    Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
			IF ALTACT.ID EQ Y.AC.ALT.ID THEN
			    CALL F.READ(FN.CURRENCY,Y.ACCT.CCY,R.CURRENCY,F.CURRENCY,CCY.ERR)				
				Y.PMCCY.FLAG = R.CURRENCY<EB.CUR.PRECIOUS.METAL>
				
				IF Y.PMCCY.FLAG EQ 'YES' THEN
				    IF NOT(Y.PMALTACT.IDS) THEN
				      Y.PMALTACT.IDS = ALTACT.ID
					END ELSE 
					   Y.PMALTACT.IDS<-1> = ALTACT.ID
					END
				*END ELSE
				*    IF NOT(Y.NON.PMALTACT.IDS) THEN
                *       Y.NON.PMALTACT.IDS = ALTACT.ID
				*	END ELSE
                *       Y.NON.PMALTACT.IDS<-1> = ALTACT.ID
                *    END					
                END	
				
			END
		END
	 END
	  
   REPEAT
   
        IF Y.PMTXN.FLAG EQ 'YES' THEN
           ALTACCT.IDS = Y.PMALTACT.IDS
		*END ELSE 
		*   ALTACCT.IDS = Y.NON.PMALTACT.IDS 
	    END
		
		CHANGE FM TO ' ' IN ALTACCT.IDS
		ENQ.DATA<2,-1> = '@ID'
		ENQ.DATA<3,-1> = 'EQ'
		ENQ.DATA<4,-1> = ALTACCT.IDS

RETURN
*----------------------------------------------------
END