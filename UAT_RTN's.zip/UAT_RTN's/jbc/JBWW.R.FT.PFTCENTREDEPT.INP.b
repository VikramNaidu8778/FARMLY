SUBROUTINE JBWW.R.FT.PFTCENTREDEPT.INP
*-----------------------------------------------------------------------------------------
* Description: This is a input routine attached in the version FUNDS.TRANSFER,JBWW.V.FT.NORTRANS.INP to avoid 
*		    	Validation error while approving FT after providing Profit Centre Department 
*-----------------------------------------------------------------------------------------
* Revision History:
*------------------
*    Date             who   	         Reference                 Description
* 24-Jul-2018     Rajagopalan R          DAY15-2974            To avoid Validation error while approving FT after providing Profit Centre Department
*----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER

    GOSUB INIT
    GOSUB PROCESS

    RETURN
*----------------------------------------------------------------------------------------
INIT:
*****
	
	Y.DEBIT.ACNO = '' ; Y.CREDIT.ACNO = ''
	Y.DEBIT.ACPL = '' ; Y.CREDIT.ACPL = ''
	
	Y.DEBIT.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CREDIT.ACNO = R.NEW(FT.CREDIT.ACCT.NO)
	
	Y.DEBIT.ACPL = Y.DEBIT.ACNO[1,2]
	Y.CREDIT.ACPL = Y.CREDIT.ACNO[1,2]
    
	RETURN
	
PROCESS:
********
		
		IF (R.NEW(FT.PROFIT.CENTRE.CUST) EQ '') AND (R.NEW(FT.PROFIT.CENTRE.DEPT) EQ '') THEN
			IF Y.DEBIT.ACPL EQ 'PL' OR Y.CREDIT.ACPL EQ 'PL' THEN
				ETEXT = 'EB-PRO.CEN.DEPT.ENTERED'
       	        CALL STORE.END.ERROR
			END
		END 
	RETURN
END

