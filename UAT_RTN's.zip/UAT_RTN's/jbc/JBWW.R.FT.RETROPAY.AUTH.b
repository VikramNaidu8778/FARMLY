*--------------------------------------------------------------------------------------------
* <Rating>-30</Rating>
*--------------------------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.RETROPAY.AUTH
*--------------------------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------------------
* Modification History :
*
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 18/07/2016    priyadarshni.priyanka@cognizant.com    PMT043_PMT044         Initial Version
*--------------------------------------------------------------------------------------------
* Description : Routine is used update the Deleted/Authorized FT tranasaction ID to file
* 				JBWW.H.FT.RETROPAY
* Attached to : VERSION> FUNDS.TRANSFER,JBWW.V.FT.ACRTOTRT.DEL
*				VERISON> FUNDS.TRANSFER,JBWW.V.FT.ACRTOTRT.AUTH
*--------------------------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER
$INSERT	I_F.JBWW.H.FT.RETROPAY	

*--------------------------------------------------------------------------------------------
 
GOSUB INIT
GOSUB GET.LOCAL.FIELD
GOSUB PROCESS

RETURN

INIT:
*---

REC.RETRO.DATA = ''
FN.JBWW.H.FT.RETROPAY = 'F.JBWW.H.FT.RETROPAY'
F.JBWW.H.FT.RETROPAY = ''
CALL OPF(FN.JBWW.H.FT.RETROPAY,F.JBWW.H.FT.RETROPAY)

RETURN

GET.LOCAL.FIELD:
*--------------

Y.APP.NAME = 'FUNDS.TRANSFER'
Y.FLD.NAME = 'L.XX.RETRO.REF'
Y.FLD.POS = ''
CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
Y.RETRO.REF.POS = Y.FLD.POS<1,1>

RETURN

PROCESS:
*------

Y.TODAY = TODAY
Y.TIME = TIME()
Y.RETRO.REF.VALUE = R.NEW(FT.LOCAL.REF)<1,Y.RETRO.REF.POS>
Y.RETRO.REF.ID = FIELD(Y.RETRO.REF.VALUE,'-',1)


IF Y.RETRO.REF.ID THEN
CALL F.READ(FN.JBWW.H.FT.RETROPAY,Y.RETRO.REF.ID,REC.RETRO.DATA,F.JBWW.H.FT.RETROPAY,ERR.JBWW.H.FT.RETROPAY)

REC.RETRO.DATA<RTR.PAY.T24.TXN.REF.ID> =  ID.NEW

IF V$FUNCTION EQ 'D' THEN
REC.RETRO.DATA<RTR.PAY.TECH.STATUS> = "CANCEL"
REC.RETRO.DATA<RTR.PAY.ERROR.TEXT> = "Payment Cancelled by User"
END

IF V$FUNCTION EQ 'A' THEN
REC.RETRO.DATA< RTR.PAY.TECH.STATUS> = "PROCESSED"
REC.RETRO.DATA<RTR.PAY.DATE.AUTH> = Y.TODAY
REC.RETRO.DATA<RTR.PAY.TIME.AUTH> = Y.TIME
END

CALL F.WRITE(FN.JBWW.H.FT.RETROPAY,Y.RETRO.REF.ID,REC.RETRO.DATA)

END
RETURN

END
