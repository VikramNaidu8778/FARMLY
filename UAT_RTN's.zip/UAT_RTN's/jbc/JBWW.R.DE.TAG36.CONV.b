*----------------------------------------------------------------------------------
SUBROUTINE JBWW.R.DE.TAG36.CONV(FORMAT.SWIFT.REC,MESSAGE.REC,SWIFT.FIELD.VALUE,PASS.VALUE,ERR.MSG)
*----------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------
* This is a conversion routine attached to CONVERSION field.
* DE.FORMAT.SWIFT -> 103.1.1 on TAG36
*----------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: FORMAT.SWIFT.REC, MESSAGE.REC,SWIFT.FIELD.VALUE
* OUT: PASS.VALUE ,ERR.MSG
* Revision History:
*----------------------------------------------------------------------------------
* Date               who               Reference          Description
* 06-09-2022         Senthil K         T24-18462     	  T24 - The exchange rate length in outgoing MT103 exceeds swift rule
*
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE 

*-----------------------------------------------------------------------------------
	
    Y.EXCH.RATE = '' ; Y.LENTH = '' 

    Y.EXCH.RATE = SWIFT.FIELD.VALUE
    Y.LENTH = LEN(Y.EXCH.RATE)
    IF Y.LENTH GT 12 THEN
        Y.EXCH.RATE = DROUND(Y.EXCH.RATE,8)
        SWIFT.FIELD.VALUE = Y.EXCH.RATE
    END
    CHANGE '.' TO ',' IN SWIFT.FIELD.VALUE
RETURN

END
