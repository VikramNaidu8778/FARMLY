*-----------------------------------------------------------------------------
* <Rating>4961</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.B.TRANS.FT.COMM.TYPE.OPT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------

    GOSUB INITIALIZE
*  GOSUB OPENFILES
*  GOSUB OPENSEQFILE
*  GOSUB PROCESS
*  GOSUB CLOSESEQFILE

    RETURN

*-----------------------------------------------------------------------------
INITIALIZE:
*-----------------------------------------------------------------------------
    Y.COMP = ID.COMPANY[1,2]

    Y.T24.FILE = Y.COMP:'-FTCOMMT24.csv'
    Y.TRANS.FILE = Y.COMP:'-FTCOMMTRNS.csv'
    Y.FT.CRM.FILE = Y.COMP:'-FTCRM.csv'

    GOSUB OPENFILES
    GOSUB OPENSEQFILE
    GOSUB PROCESS
    Y.T24.FILE = 'FTCOMM-':Y.COMP:'-MNL.csv'
    GOSUB OPENFILES
    GOSUB PROCESS
    Y.FINAL.ARRAY = Y.HEADER:FM:Y.FINAL.ARRAY.TEMP
    GOSUB WRITE.T24FTCOM.FILE
    GOSUB CLOSESEQFILE

    RETURN

*-----------------------------------------------------------------------------
OPENFILES:
*-----------------------------------------------------------------------------
    FN.VOC = 'VOC'
    F.VOC =''
    CALL OPF(FN.VOC,F.VOC)

    CALL F.READ(FN.VOC,'JBSHMIG', R.VOC, F.VOC, Y.ERR)

    Y.BASE.PATH = R.VOC<2>


    IF Y.COMP EQ 'SG' THEN
        FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHTRAN.T24/SGPRICING'
        OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
            ERRFLAG = 1
        END
    END

    IF Y.COMP EQ 'HK' THEN
        FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHTRAN.T24/HKPRICING'
        OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
            ERRFLAG = 1
        END
    END
    IF Y.T24.FILE EQ 'FTCOMM-':Y.COMP:'-MNL.csv' THEN
        FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHIN.OLY/PRICING'
        OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
            ERRFLAG = 1
        END
    END
    RETURN

*-----------------------------------------------------------------------------
OPENSEQFILE:
*-----------------------------------------------------------------------------
    IF Y.COMP EQ 'SG' THEN
        Y.TRANSDIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/SGPRICING'
    END
    IF Y.COMP EQ 'HK' THEN
        Y.TRANSDIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/HKPRICING'
    END
    IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
        DELETESEQ Y.TRANSDIR.NAME,Y.TRANS.FILE THEN
    END
    DELETESEQ Y.TRANSDIR.NAME,Y.FT.CRM.FILE THEN
    END

    OPENSEQ Y.TRANSDIR.NAME,Y.TRANS.FILE TO Y.TRANS.POINTER ELSE
        CREATE Y.TRANS.POINTER ELSE
        RETURN
    END
    END

    OPENSEQ Y.TRANSDIR.NAME,Y.FT.CRM.FILE TO Y.CRM.POINTER ELSE
        CREATE Y.CRM.POINTER ELSE
        RETURN
    END
    END
    END
    RETURN

*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
    READ R.REC FROM F.FILE.DIR,Y.T24.FILE THEN
        IF Y.T24.FILE NE 'FTCOMM-':Y.COMP:'-MNL.csv' THEN
            Y.B = '0000133'
            Y.O = '0000004'
            Y.F = '0000003'
        END
        LOOP
            REMOVE SEQ.REC FROM R.REC SETTING Y.POS

            GOSUB ASSIGN.NULL.VALUES

        WHILE SEQ.REC:Y.POS
            Y.FTCOMM.VAL = SEQ.REC<1>
            Y.FTCOMM.ID =  FIELD(Y.FTCOMM.VAL,',',1)
            Y.CATEGORY.CDE = FIELD(Y.FTCOMM.VAL,',',4)
            Y.CR.TXN.CDE = FIELD(Y.FTCOMM.VAL,',',5)
            Y.DR.TXN.CDE = FIELD(Y.FTCOMM.VAL,',',6)
            Y.CAL.BASIS = FIELD(Y.FTCOMM.VAL,',',7)
            *CHANGE 'NULL' TO '' IN Y.CAL.BASIS                   ;*11/05/17 commented to display NULL values
            Y.CCY = FIELD(Y.FTCOMM.VAL,',',8)
            Y.FLAT.AMT = FIELD(Y.FTCOMM.VAL,',',9)
            Y.CALC.TYPE = FIELD(Y.FTCOMM.VAL,',',10)
            *CHANGE 'NULL' TO '' IN Y.CALC.TYPE                    ;*06/03/17 ;*11/05/17 commented to display NULL values
            Y.PERCENTAGE = FIELD(Y.FTCOMM.VAL,',',11)
            Y.UNIT.CHR = FIELD(Y.FTCOMM.VAL,',',12)
            Y.UPTO.AMT = FIELD(Y.FTCOMM.VAL,',',13)
            *CHANGE 'NULL' TO '' IN Y.UPTO.AMT                     ;*11/05/17 commented to display NULL values
            Y.MIN.AMT = FIELD(Y.FTCOMM.VAL,',',14)
            *CHANGE 'NULL' TO '' IN Y.MIN.AMT                       ;*11/05/17 commented to display NULL values
            Y.MAX.AMT = FIELD(Y.FTCOMM.VAL,',',15)
            *CHANGE 'NULL' TO '' IN Y.MAX.AMT                       ;*11/05/17 commented to display NULL values
            Y.MNTHLY.AMORT = FIELD(Y.FTCOMM.VAL,',',16)
            Y.DFLT.CCY = FIELD(Y.FTCOMM.VAL,',',17)
            IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                Y.TB.CODE = FIELD(Y.FTCOMM.VAL,',',18)
            END
            Y.B.O.F = Y.FTCOMM.ID[1,1]

            Y.VALUES = Y.CAL.BASIS:':':Y.CCY:':':Y.FLAT.AMT:':':Y.CALC.TYPE:':':Y.PERCENTAGE:':':Y.UNIT.CHR:':':Y.UPTO.AMT:':':Y.MIN.AMT:':':Y.MAX.AMT
            Y.HEADER = 'Id':',':'Description':',':'Short Descr':',':'Category account':',':'Txn code cr':',':'Txn code dr':',':'Calculation basis':',':'Currency':',':'Flat amt':',':'Calc type':',':'Percentage':',':'Unit charage':',':'Upto amt':',':'Overall min amt':',':'Overall max amt':',':'Mthly amortisation':',':'Default ccy'
            BEGIN CASE

                CASE Y.B.O.F EQ 'B'

                    LOCATE Y.VALUES IN Y.VALUES.ARRAY.B SETTING Y.VAL.POS.B THEN
                    Y.TRANS.FT.ID = Y.TRANS.ARRAY.B<Y.VAL.POS.B>
*******************03/03/17*********************************
                    IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                        Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
                    END ELSE
                        Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
                    END
*******************03/03/17*********************************
                END ELSE
                    Y.VALUES.ARRAY.B<-1> = Y.VALUES
                    Y.TRANS.FT.ID = "BRK":Y.B
                    Y.TRANS.ARRAY.B<-1> = Y.TRANS.FT.ID

                    Y.TRANS.ARRAY<-1> = Y.TRANS.FT.ID
*******************03/03/17*********************************
                    IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                        Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
                    END ELSE
                        Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
                    END
*******************03/03/17*********************************
                    GOSUB FORM.DESC.SHRT.DESC

                    Y.FINAL.ARRAY.TEMP<-1> = Y.TRANS.FT.ID:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CATEGORY.CDE:',':Y.CR.TXN.CDE:',':Y.DR.TXN.CDE:',':Y.CAL.BASIS:',':Y.CCY:',':Y.FLAT.AMT:',':Y.CALC.TYPE:',':Y.PERCENTAGE:',':Y.UNIT.CHR:',':Y.UPTO.AMT:',':Y.MIN.AMT:',':Y.MAX.AMT:',':Y.MNTHLY.AMORT:',':Y.DFLT.CCY
                    Y.B = Y.B + '0000001'
                    Y.B = FMT(Y.B,"R%7")
                END

            CASE Y.B.O.F EQ 'O'

                LOCATE Y.VALUES IN Y.VALUES.ARRAY.O SETTING Y.VAL.POS.O THEN
                Y.TRANS.FT.ID = Y.TRANS.ARRAY.O<Y.VAL.POS.O>
*******************03/03/17*********************************
                IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                    Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
                END ELSE
                    Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
                END
*******************03/03/17*********************************
            END ELSE
                Y.VALUES.ARRAY.O<-1> = Y.VALUES
                Y.TRANS.FT.ID = "OPT":Y.O
                Y.TRANS.ARRAY.O<-1> = Y.TRANS.FT.ID

                Y.TRANS.ARRAY<-1> = Y.TRANS.FT.ID
*******************03/03/17*********************************
                IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                    Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
                END ELSE
                    Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
                END
*******************03/03/17*********************************
                GOSUB FORM.DESC.SHRT.DESC

********************22/12/17 DEFAULT.CCY should blank if CCY is CHF*******************************
             IF Y.CCY EQ 'CHF' THEN
                Y.FINAL.ARRAY.TEMP<-1> = Y.TRANS.FT.ID:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CATEGORY.CDE:',':Y.CR.TXN.CDE:',':Y.DR.TXN.CDE:',':Y.CAL.BASIS:',':Y.CCY:',':Y.FLAT.AMT:',':Y.CALC.TYPE:',':Y.PERCENTAGE:',':Y.UNIT.CHR:',':Y.UPTO.AMT:',':Y.MIN.AMT:',':Y.MAX.AMT:',':Y.MNTHLY.AMORT:',':'NULL'
                Y.O = Y.O + '0000001'
                Y.O = FMT(Y.O,"R%7")
             END ELSE 
                Y.FINAL.ARRAY.TEMP<-1> = Y.TRANS.FT.ID:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CATEGORY.CDE:',':Y.CR.TXN.CDE:',':Y.DR.TXN.CDE:',':Y.CAL.BASIS:',':Y.CCY:',':Y.FLAT.AMT:',':Y.CALC.TYPE:',':Y.PERCENTAGE:',':Y.UNIT.CHR:',':Y.UPTO.AMT:',':Y.MIN.AMT:',':Y.MAX.AMT:',':Y.MNTHLY.AMORT:',':Y.DFLT.CCY
                Y.O = Y.O + '0000001'
                Y.O = FMT(Y.O,"R%7")
             END 

********************22/12/17 *******************************
            END

        CASE Y.B.O.F EQ 'F'

            LOCATE Y.VALUES IN Y.VALUES.ARRAY.F SETTING Y.VAL.POS.F THEN
            Y.TRANS.FT.ID = Y.TRANS.ARRAY.F<Y.VAL.POS.F>
*******************03/03/17*********************************
            IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
            END ELSE
                Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
            END
*******************03/03/17*********************************
        END ELSE
            Y.VALUES.ARRAY.F<-1> = Y.VALUES
            Y.TRANS.FT.ID = "FUT":Y.F
            Y.TRANS.ARRAY.F<-1> = Y.TRANS.FT.ID

            Y.TRANS.ARRAY<-1> = Y.TRANS.FT.ID
*******************03/03/17*********************************
            IF Y.T24.FILE EQ Y.COMP:'-FTCOMMT24.csv' THEN
                Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID:',':Y.TB.CODE
            END ELSE
                Y.TRANS.CRM.ID<-1> = Y.FTCOMM.ID:',':Y.TRANS.FT.ID
            END
*******************03/03/17*********************************
            GOSUB FORM.DESC.SHRT.DESC
********************22/12/17 DEFAULT.CCY should blank if CCY is CHF*******************************
          IF Y.CCY EQ 'CHF' THEN
            Y.FINAL.ARRAY.TEMP<-1> = Y.TRANS.FT.ID:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CATEGORY.CDE:',':Y.CR.TXN.CDE:',':Y.DR.TXN.CDE:',':Y.CAL.BASIS:',':Y.CCY:',':Y.FLAT.AMT:',':Y.CALC.TYPE:',':Y.PERCENTAGE:',':Y.UNIT.CHR:',':Y.UPTO.AMT:',':Y.MIN.AMT:',':Y.MAX.AMT:',':Y.MNTHLY.AMORT:',':'NULL'

            Y.F = Y.F + '0000001'
            Y.F = FMT(Y.F,"R%7")
         END ELSE 
                Y.FINAL.ARRAY.TEMP<-1> = Y.TRANS.FT.ID:',':Y.DESC:',':Y.SHRT.DESC:',':Y.CATEGORY.CDE:',':Y.CR.TXN.CDE:',':Y.DR.TXN.CDE:',':Y.CAL.BASIS:',':Y.CCY:',':Y.FLAT.AMT:',':Y.CALC.TYPE:',':Y.PERCENTAGE:',':Y.UNIT.CHR:',':Y.UPTO.AMT:',':Y.MIN.AMT:',':Y.MAX.AMT:',':Y.MNTHLY.AMORT:',':Y.DFLT.CCY
            Y.F = Y.F + '0000001'
            Y.F = FMT(Y.F,"R%7")
         END 

        END

    END CASE
    REPEAT
    END
    RETURN

*-----------------------------------------------------------------------------
ASSIGN.NULL.VALUES:
*-----------------------------------------------------------------------------
    Y.TRANS.FT.ID = ''; Y.DESC = ''; Y.SHRT.DESC = ''; Y.CATEGORY.CDE = ''; Y.CR.TXN.CDE = ''
    Y.DR.TXN.CDE = ''; Y.CAL.BASIS = ''; Y.CCY = ''; Y.FLAT.AMT = ''; Y.CALC.TYPE = ''
    Y.PERCENTAGE = ''; Y.UNIT.CHR = ''; Y.UPTO.AMT = ''; Y.MIN.AMT = ''; Y.MAX.AMT = ''
    Y.MNTHLY.AMORT = ''; Y.DFLT.CCY = '' ; Y.TB.CODE = ''

    RETURN
*-----------------------------------------------------------------------------
FORM.DESC.SHRT.DESC:
*-----------------------------------------------------------------------------

    Y.PER.CNT = DCOUNT(Y.PERCENTAGE,'!!')
    IF Y.CALC.TYPE NE 'FLAT' AND Y.CALC.TYPE NE 'LOT' THEN
        IF Y.PER.CNT GT '1' THEN
            Y.PER.POS1 = FIELD(Y.PERCENTAGE,'!!',1)
            Y.PER.POS2 = FIELD(Y.PERCENTAGE,'!!',Y.PER.CNT)
            Y.PER.POS1 = Y.PER.POS1 * 100
            Y.PER.POS2 = Y.PER.POS2 * 100

            *  IF Y.MIN.AMT NE '' AND Y.MAX.AMT EQ '' THEN
            IF Y.MIN.AMT NE 'NULL' AND Y.MAX.AMT EQ 'NULL' THEN                          ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS2:'-':Y.PER.POS1:' bps Min ':Y.MIN.AMT
                Y.SHRT.DESC = Y.PER.POS2:'-':Y.PER.POS1:'bps Mn':Y.MIN.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS2:'-':Y.PER.POS1:' bps Min ':Y.MIN.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS2:'-':Y.PER.POS1:'Mn':Y.MIN.AMT
                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END
            *IF Y.MIN.AMT NE '' AND Y.MAX.AMT NE '' THEN
            IF Y.MIN.AMT NE 'NULL' AND Y.MAX.AMT NE 'NULL' THEN                          ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS2:'-':Y.PER.POS1:' bps Min ':Y.MIN.AMT:' Max ':Y.MAX.AMT
                Y.SHRT.DESC = Y.PER.POS2:'-':Y.PER.POS1:'bps Mn':Y.MIN.AMT:'Mx':Y.MAX.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS2:'-':Y.PER.POS1:' bps Min ':Y.MIN.AMT:' Max ':Y.MAX.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS2:'-':Y.PER.POS1:'Mn':Y.MIN.AMT:'Mx':Y.MAX.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END
            *IF Y.MAX.AMT NE '' AND Y.MIN.AMT EQ '' THEN
            IF Y.MAX.AMT NE 'NULL' AND Y.MIN.AMT EQ 'NULL' THEN                           ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS2:'-':Y.PER.POS1:' bps Max ':Y.MAX.AMT
                Y.SHRT.DESC = Y.PER.POS2:'-':Y.PER.POS1:'bps Mx':Y.MAX.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS2:'-':Y.PER.POS1:' bps Max ':Y.MAX.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS2:'-':Y.PER.POS1:'Mx':Y.MAX.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END

            *IF Y.MIN.AMT EQ '' AND Y.MAX.AMT EQ '' THEN
            IF Y.MIN.AMT EQ 'NULL' AND Y.MAX.AMT EQ 'NULL' THEN                          ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS2:'-':Y.PER.POS1:' bps'
                Y.SHRT.DESC = Y.PER.POS2:'-':Y.PER.POS1:'bps'
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS2:'-':Y.PER.POS1:' bps'
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS2:'-':Y.PER.POS1
                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END
        END ELSE
            Y.PER.POS1 = Y.PERCENTAGE
            Y.PER.POS1 = Y.PER.POS1 * 100
            *IF Y.MIN.AMT NE '' AND Y.MAX.AMT EQ '' THEN
            IF Y.MIN.AMT NE 'NULL' AND Y.MAX.AMT EQ 'NULL' THEN                          ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS1:' bps Min ':Y.MIN.AMT
                Y.SHRT.DESC = Y.PER.POS1:'bps Mn':Y.MIN.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS1:' bps Min ':Y.MIN.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS1:'Mn':Y.MIN.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END

            *IF Y.MAX.AMT NE '' AND Y.MIN.AMT EQ '' THEN
            IF Y.MAX.AMT NE 'NULL' AND Y.MIN.AMT EQ 'NULL' THEN                               ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS1:' bps Max ':Y.MAX.AMT
                Y.SHRT.DESC = Y.PER.POS1:'bps Mx':Y.MAX.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS1:' bps Max ':Y.MAX.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS1:'Mx':Y.MAX.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END

            *IF Y.MIN.AMT NE '' AND Y.MAX.AMT NE '' THEN
            IF Y.MIN.AMT NE 'NULL' AND Y.MAX.AMT NE 'NULL' THEN                              ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS1:' bps Min ':Y.MIN.AMT:' Max ':Y.MAX.AMT
                Y.SHRT.DESC = Y.PER.POS1:'bps Mn':Y.MIN.AMT:'Mx':Y.MAX.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.PER.POS1:' bps Min ':Y.MIN.AMT:' Max ':Y.MAX.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.PER.POS1:'Mn':Y.MIN.AMT:'Mx':Y.MAX.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END

            *IF Y.MIN.AMT EQ '' AND Y.MAX.AMT EQ '' THEN
            IF Y.MIN.AMT EQ 'NULL' AND Y.MAX.AMT EQ 'NULL' THEN                             ;*11/05/17 changed since updating NULL
                Y.DESC = 'Brokerage ':Y.PER.POS1:' bps'
                Y.SHRT.DESC = Y.PER.POS1:'bps'
            END
        END
    END
    IF Y.CALC.TYPE EQ 'FLAT' THEN
        Y.DESC = 'Brokerage flat ':Y.FLAT.AMT
        Y.SHRT.DESC = 'Flat ':Y.FLAT.AMT
    END

    IF Y.CALC.TYPE EQ 'LOT' THEN
        *IF Y.MIN.AMT NE '' AND Y.MAX.AMT EQ '' THEN
        IF Y.MIN.AMT NE 'NULL' AND Y.MAX.AMT EQ 'NULL' THEN                                 ;*11/05/17 changed since updating NULL
            IF Y.CCY NE 'CHF' THEN
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT Min ':Y.CCY:' ':Y.MIN.AMT
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT Mn':Y.CCY:Y.MIN.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.UNIT.CHR:'/LOT Min ':Y.CCY:' ':Y.MIN.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.UNIT.CHR:'/LOT Mn':Y.MIN.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END ELSE
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT Min ':Y.MIN.AMT
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT Mn':Y.MIN.AMT
            END
        END

        *IF Y.MAX.AMT NE '' AND Y.MIN.AMT EQ '' THEN
        IF Y.MAX.AMT NE 'NULL' AND Y.MIN.AMT EQ 'NULL' THEN                                 ;*11/05/17 changed since updating NULL
            IF Y.CCY NE 'CHF' THEN
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT Max ':Y.CCY:' ':Y.MAX.AMT
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT Mx':Y.CCY:Y.MAX.AMT
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.UNIT.CHR:'/LOT Max ':Y.CCY:' ':Y.MAX.AMT
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.UNIT.CHR:'/LOT Mx':Y.MAX.AMT

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END ELSE
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT Max ':Y.MAX.AMT
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT Mx':Y.MAX.AMT
            END
        END

        *IF Y.MAX.AMT EQ '' AND Y.MIN.AMT EQ '' THEN
        IF Y.MAX.AMT EQ 'NULL' AND Y.MIN.AMT EQ 'NULL' THEN                               ;*11/05/17 changed since updating NULL
            IF Y.CCY NE 'CHF' THEN
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT ':Y.CCY
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT':Y.CCY
**************23/03/17*****************
                Y.DES.LEN = LEN(Y.DESC)
                Y.SHRT.LEN = LEN(Y.SHRT.DESC)
                IF Y.DES.LEN GT '35' THEN
                    Y.DESC = Y.UNIT.CHR:'/LOT ':Y.CCY
                END
                IF Y.SHRT.LEN GT '15' THEN
                    Y.SHRT.DESC.1 = Y.UNIT.CHR:'/LOT'

                    Y.SHRT1.LEN = LEN(Y.SHRT.DESC.1)
                    IF Y.SHRT1.LEN GT '15' THEN
                        Y.SHRT.DESC = 'See Description'
                    END ELSE
                        Y.SHRT.DESC = Y.SHRT.DESC.1
                    END
                END
**************23/03/17*****************
            END ELSE
                *Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT ':Y.MAX.AMT
                Y.DESC = 'Brokerage ':Y.UNIT.CHR:'/LOT'                                     ;*11/05/17 changed since updating NULL
                Y.SHRT.DESC = Y.UNIT.CHR:'/LOT'
            END
        END
    END
    RETURN
*-----------------------------------------------------------------------------
WRITE.T24FTCOM.FILE:
*-----------------------------------------------------------------------------
    CHANGE FM TO CHARX(10) IN Y.FINAL.ARRAY
    WRITESEQ Y.FINAL.ARRAY APPEND TO Y.TRANS.POINTER THEN
    END

    CHANGE FM TO CHARX(10) IN Y.TRANS.CRM.ID
    WRITESEQ Y.TRANS.CRM.ID APPEND TO Y.CRM.POINTER THEN
    END

    RETURN
*-----------------------------------------------------------------------------
CLOSESEQFILE:
*-----------------------------------------------------------------------------

    CLOSESEQ Y.TRANS.POINTER
    CLOSESEQ Y.CRM.POINTER

    RETURN

    END

