* @ValidationCode : MToyOTM5OTU4Mjc6SVNPLTg4NTktMToxNDkzMzU3NTYwMDg4OjQxOTk4ODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 28 Apr 2017 11:02:40
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 419988
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.STO.RECBKCHK.INPUT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER
*-----------------------------------------------------------------------------

    GOSUB MAIN.PROCESS
    RETURN

MAIN.PROCESS:
*------------
    Y.PAY.METHOD = R.NEW(STO.PAY.METHOD)
    Y.REC.BANK   = R.NEW(STO.RECEIVER.BANK)

    IF Y.PAY.METHOD EQ "OT12" AND Y.REC.BANK EQ "" THEN
        AF = STO.RECEIVER.BANK
        ETEXT = "EB-STO.ERR.RECBK"
        CALL STORE.END.ERROR

    END

    RETURN

    END
