* @ValidationCode : MToxMDY0MTc4OTgzOlVURi04OjE1Mjg4MTIwMTkxMzU6MjMzMTYzOi0xOi0xOjA6MDpmYWxzZTpOL0E=
* @ValidationInfo : Timestamp         : 18 April 2024 19:30:19
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PORLCTCA.AFTUNAU
*----------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing FT Version Control Routine JBWW.R.FT.RLCTCA.AFTUNAU and incorporated with TPH Payment order application Logic.
*----------------------------------------------------------------------------------------------------------------------------------------------------
*
* Attached to  :Version Control of PAYMENT.ORDER
*
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer          Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
* 17/04/2024      Amala P            CBPAY-302                     Capture of soft Blocks and Updating JBWW.H.XX.SOFTBLOCK table and email trigerring based on soft block groups.
*
* 27/02/2025      Amala P            CBPAY-1841                    Facing overrride with IHLD status When transaction amount is null/zero.
* 15/04/2025      Amala P            CBPAY-1402                    Facing overrride with IHLD status When Debit amount is null/zero.
*-------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.OVERRIDE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.ERROR
    $INSERT I_GTS.COMMON
    $INSERT I_F.COMPANY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JBWW.L.XX.RLCSOFTBLOCK.LOG
    $INSERT I_F.JBWW.H.EB.BLOCKTAGDETS
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PAYMENT.ORDER.PRODUCT
	
    IF ID.OLD NE '' THEN RETURN

*	IF R.NEW(FT.TRANSACTION.TYPE) EQ 'ACSL' AND PGM.VERSION EQ ',JBWW.V.FT.UPD' THEN RETURN ;* SLBA-6485 - No RLC block validation if FT posting by SLB version with txn type is ACSL
	
    IF V$FUNCTION EQ 'R' OR V$FUNCTION EQ 'D' THEN RETURN

    GOSUB INIT

    IF Y.FT.MAKER.CHECK NE 'MAKER' THEN
        IF Y.FT.MAKER.CHECK NE 'CHECKER' THEN
            IF Y.OVERALL.STATUS EQ '' THEN
                GOSUB FETCH.PORTFOLIO.DETAILS
                GOSUB HARD.BLOCK.PROCESS
                GOSUB PROCESS.MA.BP.BLOCKS
                GOSUB OVERRIDES
                GOSUB CREDIT.CONSTRAINTS

                IF R.HARD.BLOCKS EQ '' THEN
                    GOSUB UPDATE.SOFT.BLOCKS.TABLE
                END

                IF R.SOFT.BLOCKS EQ '' AND R.HARD.BLOCKS EQ '' THEN RETURN

                GOSUB TRIGGER.MAIL.TO.RM.HARD.BLOCK
				
* "IT" type is applicable only for PP.ORDER.ENTRY
*                IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'IT' AND R.SOFT.BLOCKS NE '' AND Y.REC.STATUS EQ 'INAU' AND OFS$SOURCE.ID NE 'IRISPA' THEN
*                    GOSUB RAISE.OFS.PAY.PORTAL
*                END
            END
        END
    END

    IF Y.FT.MAKER.CHECK EQ 'MAKER' THEN
        GOSUB FETCH.PORTFOLIO.DETAILS
        GOSUB FETCH.CUSTOMER.DETAILS
        GOSUB PROCESS.MAKER.CHECKER
    END
RETURN
*-----------------------------------------------------------------------------

INIT:
************
    F.PAYMENT.ORDER.PRODUCT = ''
    FN.PAYMENT.ORDER.PRODUCT = 'F.PAYMENT.ORDER.PRODUCT'
    CALL OPF(FN.PAYMENT.ORDER.PRODUCT,F.PAYMENT.ORDER.PRODUCT)

    F.SC.INC.ACCOUNT = ''
    FN.SC.INC.ACCOUNT = 'F.SC.INC.ACCOUNT'
    CALL OPF(FN.SC.INC.ACCOUNT,F.SC.INC.ACCOUNT)

    F.DEPT.ACCT.OFFICER = ''
    FN.DEPT.ACCT.OFFICER = 'F.DEPT.ACCT.OFFICER'
    CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)

    F.JBWW.H.EB.BLOCKTAGDETS = ''
    FN.JBWW.H.EB.BLOCKTAGDETS = 'F.JBWW.H.EB.BLOCKTAGDETS'
    CALL OPF(FN.JBWW.H.EB.BLOCKTAGDETS,F.JBWW.H.EB.BLOCKTAGDETS)

    F.JBWW.L.XX.RLCSOFTBLOCK.LOG = ''
    FN.JBWW.L.XX.RLCSOFTBLOCK.LOG = 'F.JBWW.L.XX.RLCSOFTBLOCK.LOG'
    CALL OPF(FN.JBWW.L.XX.RLCSOFTBLOCK.LOG,F.JBWW.L.XX.RLCSOFTBLOCK.LOG)

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.EB.ERROR = ''
    FN.EB.ERROR = 'F.EB.ERROR'
    CALL OPF(FN.EB.ERROR,F.EB.ERROR)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.OVERRIDE = ''
    FN.OVERRIDE = 'F.OVERRIDE'
    CALL OPF(FN.OVERRIDE,F.OVERRIDE)

    F.OVERRIDE = ''
    FN.OVERRIDE = 'F.OVERRIDE'
    CALL OPF(FN.OVERRIDE,F.OVERRIDE)

    F.PAYMENT.ORDER = ''
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    F.PAYMENT.ORDER$NAU = ''
    FN.PAYMENT.ORDER$NAU = 'F.PAYMENT.ORDER$NAU'
    CALL OPF(FN.PAYMENT.ORDER$NAU,F.PAYMENT.ORDER$NAU)

    F.SEC.TRADE = ''
    FN.SEC.TRADE = 'F.SEC.TRADE'
    CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)

    F.JBWW.H.XX.SOFTBLOCK = ''
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    F.CUSTOMER = ''
    FN.CUSTOMER = 'F.CUSTOMER'
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    APPL = 'PAYMENT.ORDER':FM:'OVERRIDE':FM:'CUSTOMER':FM:'SEC.ACC.MASTER'

    F.JBWW.H.EB.GENERICPARAMETER = ''
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    Y.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    Y.RLC.MAIL.PARAM.ID = 'RLC.EMAIL.ATTRIBUTE':'.':Y.MNEMONIC

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.RLC.MAIL.PARAM.ID,R.GEN.PARAM,F.JBWW.H.EB.GENERICPARAMETER,'')
    IF R.GEN.PARAM NE '' THEN
        Y.FIELD.NAME = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        CONVERT VM TO FM IN Y.FIELD.NAME
        Y.FIELD.VALUE =  R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        Y.BLOCK.TYPE.POS = ''
        FIND 'BLOCK.TYPE' IN Y.FIELD.NAME SETTING Y.BLOCK.TYPE.POS ELSE Y.BLOCK.TYPE.POS = ''
        Y.BLOCK.TYPE.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.BLOCK.TYPE.POS,1>
        Y.BLCK.SWITCH.POS = ''
        FIND 'BLOCK.SWITCH' IN Y.FIELD.NAME SETTING Y.BLCK.SWITCH.POS ELSE Y.BLCK.SWITCH.POS = ''
        Y.SWITCH.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.BLCK.SWITCH.POS,1>
        Y.APPR.MA.POS = ''
        FIND 'APPROVE.MA' IN Y.FIELD.NAME SETTING Y.APPR.MA.POS ELSE Y.APPR.MA.POS = ''
        Y.APPROVE.MA = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.APPR.MA.POS,1>

        Y.APPR.BP.POS = ''
        FIND 'APPROVE.BP' IN Y.FIELD.NAME SETTING Y.APPR.BP.POS ELSE Y.APPR.BP.POS = ''
        Y.APPROVE.BP = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.APPR.BP.POS,1>

        Y.HB.TYPE.POS = ''
        FIND 'HB.TYPE' IN Y.FIELD.NAME SETTING Y.HB.TYPE.POS ELSE Y.HB.TYPE.POS = ''
        Y.HB.BLOCK.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.HB.TYPE.POS,1>

        Y.HB.SWITCH.POS = ''
        FIND 'HB.SWITCH' IN Y.FIELD.NAME SETTING Y.HB.SWITCH.POS ELSE Y.HB.SWITCH.POS = ''
        Y.HB.SWITCH.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.HB.SWITCH.POS,1>
    END

    LREF.FLD = 'L.XX.BLK.MSG':VM:'L.XX.BLK.CODE':VM:'L.XX.BLK.CATEG':VM:'L.XX.BLK.TYPE':VM:'L.XX.DONE.DEAL':VM:'L.XX.TC.DONE':VM:'L.FT.VALDT.CHKD':VM:'L.XX.FO.SOURCE':FM:'L.ST.BLK.APRVR':FM:'L.ST.OFFCR.TYPE':VM:'L.ST.OFFICER.ID':FM:'L.XX.TAG.BLK.ID':VM:'L.XX.TAG.ID'
    Y.POS = ''
    Y.TC.DONE.POS = ''
    Y.BLK.CATEG.POS = ''
    Y.BLK.TYPE.POS = ''
    Y.BLK.CODE.POS = ''
    Y.BLK.MSG.POS = ''
    Y.BLK.APR.POS = ''
    Y.DONE.DEAL.POS = ''
    Y.L.FT.VALDT.CHKD.POS = ''
    Y.OFFICER.TYPE.POS = ''
    Y.OFFICER.ID.POS = ''
    Y.TAG.BLK.POS = ''
    Y.TAG.ID.POS = ''
    Y.FO.SRC.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)

    Y.BLK.MSG.POS = Y.POS<1,1>
    Y.BLK.CODE.POS = Y.POS<1,2>
    Y.BLK.CATEG.POS = Y.POS<1,3>
    Y.BLK.TYPE.POS  = Y.POS<1,4>
    Y.DONE.DEAL.POS = Y.POS<1,5>
    Y.TC.DONE.POS = Y.POS<1,6>
    Y.L.FT.VALDT.CHKD.POS = Y.POS<1,7>
    Y.FO.SRC.POS = Y.POS<1,8>

    Y.BLK.APR.POS = Y.POS<2,1>
    Y.OFFICER.TYPE.POS = Y.POS<3,1>
    Y.OFFICER.ID.POS = Y.POS<3,2>
    Y.TAG.BLK.POS = Y.POS<4,1>
    Y.TAG.ID.POS = Y.POS<4,2>

    Y.BLK.CATEG = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS>
    Y.CREDIT.BLOCKS = Y.BLK.CATEG
    Y.MESSAGE.IDS = R.SOFT.BLOCKS<JHXS.BLOCK.ID>
    CHANGE VM TO FM IN Y.MESSAGE.IDS
    CHANGE SM TO FM IN Y.CREDIT.BLOCKS
    Y.POS.CNT = DCOUNT(Y.BLK.CATEG,SM)
    CALL F.READ(FN.PAYMENT.ORDER$NAU,ID.NEW,R.PP.NAU,F.PAYMENT.ORDER$NAU,'')
    Y.REC.STATUS = R.PP.NAU<PO.RECORD.STATUS>
    R.SOFT.BLOCKS = ''
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW,R.SOFT.BLOCKS,F.JBWW.H.XX.SOFTBLOCK,'')
    Y.BLOCK.ID = R.SOFT.BLOCKS<JHXS.BLOCK.ID>
    Y.OVERALL.STATUS = R.SOFT.BLOCKS<JHXS.OVERALL.STATUS>
    Y.BLOCK.CNT = DCOUNT(Y.BLOCK.ID,VM)

    R.HARD.BLOCKS = ''
    Y.HB.ID = 'HB':ID.NEW
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,Y.HB.ID,R.HARD.BLOCKS,F.JBWW.H.XX.SOFTBLOCK,'')
    IF R.HARD.BLOCKS NE '' THEN
        CALL F.DELETE(FN.JBWW.H.XX.SOFTBLOCK,Y.HB.ID)
    END
    R.HARD.BLOCKS = ''

    Y.HB.BLOCK.CNT = ''

    Y.DONE.DEAL = R.NEW(PO.LOCAL.REF)<1,Y.DONE.DEAL.POS>
    Y.TC.DONE = R.NEW(PO.LOCAL.REF)<1,Y.TC.DONE.POS>
    X = OCONV(DATE(),'D4-')
    TIME.STAMP = TIMEDATE()

    Y.FT.MAKER.CHECK = R.NEW(PO.LOCAL.REF)<1,Y.L.FT.VALDT.CHKD.POS>
    Y.REC.STATUS = R.NEW(PO.RECORD.STATUS)
    Y.TODAY = TODAY
    Y.TODAY =  OCONV(ICONV(Y.TODAY,"D2E"),"D4E")
    Y.TIME = OCONV(TIME(),"MTS")
    DATE.TIME = Y.TODAY:' ':Y.TIME
    UID = OPERATOR
    Y.FO.SOURCE = R.NEW(PO.LOCAL.REF)<1,Y.FO.SRC.POS>
    Y.TRN.TYPE = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    R.PP.TXN.COND = ''
    CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,Y.TRN.TYPE,R.PP.TXN.COND,F.PAYMENT.ORDER.PRODUCT,'')
    Y.TXN.TYPE = R.PP.TXN.COND<POP.DESCRIPTION>
	Y.DEBIT.VALDATE = ''
	
	BEGIN CASE
        CASE R.NEW(PO.DEBIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.DEBIT.VALUE.DATE)
	    CASE R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE)
		CASE R.NEW(PO.CREDIT.VALUE.DATE) NE ''
            Y.DEBIT.VALDATE = R.NEW(PO.CREDIT.VALUE.DATE)
	END CASE

RETURN

HARD.BLOCK.PROCESS:
********************
    Y.BLOCK.ERRORS = GTSERROR
    Y.HB.ERR.REC.CNT = DCOUNT(Y.BLOCK.ERRORS,FM)
    Y.HB.FLAG = ''
    Y.I = 0
    LOOP
        Y.I = Y.I + 1
    WHILE Y.I LE Y.HB.ERR.REC.CNT
        Y.HARD.BLOCK.ID = Y.BLOCK.ERRORS<Y.I>
        Y.MSG.ID = FIELD(Y.HARD.BLOCK.ID,'-',2)

        IF Y.MSG.ID[1,2] EQ 'HB' THEN
            GOSUB READ.EB.ERROR
            IF R.EB.REC NE '' THEN
                IF Y.DONE.DEAL EQ 'Y' OR PGM.VERSION EQ ',INWARD' THEN
                    Y.HB.FLAG = '1'
                    Y.HB.CKTYPE<-1> = 'HB'
                    Y.HB.MESSAGE<-1> = Y.MSG.VAL
                    Y.HB.SB.ID<-1> = Y.HARD.BLOCK.ID
                    Y.CHECK.TYPE = 'HB'

                    R.PP.NAU<PO.LOCAL.REF,Y.BLK.CATEG.POS,Y.POS.CNT> = 'HB'
                    R.PP.NAU<PO.LOCAL.REF,Y.BLK.TYPE.POS,Y.POS.CNT>  =  'HARD_BLOCK'
                    R.PP.NAU<PO.LOCAL.REF,Y.BLK.CODE.POS,Y.POS.CNT> =  Y.MSG.ID
                    R.PP.NAU<PO.LOCAL.REF,Y.BLK.MSG.POS,Y.POS.CNT> = Y.MSG.VAL[1,65]

                    GOSUB UPDATE.TCA.HARD.BLOCKS
                END
            END
        END
    REPEAT

    IF Y.HB.FLAG THEN
        GOSUB UPDATE.HARD.BLOCKS.TABLE
        CALL F.WRITE(FN.PAYMENT.ORDER$NAU,ID.NEW,R.PP.NAU)
    END
RETURN

READ.EB.ERROR:
**************
    R.EB.REC = ''
    CALL F.READ(FN.EB.ERROR,Y.HARD.BLOCK.ID,R.EB.REC,F.EB.ERROR,'')
    Y.MSG.VAL = R.EB.REC<EB.ERR.ERROR.MSG>
RETURN

UPDATE.TCA.HARD.BLOCKS:
*************************

    Y.HB.BLOCK.CNT += 1
    IF R.HARD.BLOCKS<JHXS.BLOCK.ID> EQ '' THEN

        R.HARD.BLOCKS<JHXS.BLOCK.ID,1> = Y.MSG.ID
        R.HARD.BLOCKS<JHXS.BLOCK.MSG,1> = Y.MSG.VAL
        R.HARD.BLOCKS<JHXS.BLOCK.DEPT,1> = Y.CHECK.TYPE
        R.HARD.BLOCKS<JHXS.BLOCK.USER.ID> = OPERATOR
    END ELSE
        R.HARD.BLOCKS<JHXS.BLOCK.ID,Y.HB.BLOCK.CNT> = Y.MSG.ID
        R.HARD.BLOCKS<JHXS.BLOCK.MSG,Y.HB.BLOCK.CNT> = Y.MSG.VAL
        R.HARD.BLOCKS<JHXS.BLOCK.DEPT,Y.HB.BLOCK.CNT> = Y.CHECK.TYPE

    END
RETURN

UPDATE.HARD.BLOCKS.TABLE:
**************************

    GOSUB GET.CUSTOMER.PORTFOLIO.HARD.BLOCK.DETAILS
    Y.TRANSACTION.ID = 'HB':ID.NEW
    R.HARD.BLOCKS<JHXS.APPLICATION> = APPLICATION
    R.HARD.BLOCKS<JHXS.ISIN.IDENTIFIER> = ''
    R.HARD.BLOCKS<JHXS.TRADE.DATE> = TODAY
    R.HARD.BLOCKS<JHXS.VALUE.DATE> = Y.DEBIT.VALDATE
    R.HARD.BLOCKS<JHXS.DATE.TIME> = DATE.TIME
    IF Y.DONE.DEAL EQ 'Y' OR Y.FO.SOURCE NE '' THEN
        R.HARD.BLOCKS<JHXS.DONE.DEAL> = 'Y'
    END ELSE
        R.HARD.BLOCKS<JHXS.DONE.DEAL> = 'N'
    END

    Y.MA.POS = ''
    FIND 'MA' IN Y.CREDIT.BLOCKS SETTING Y.MA.POS ELSE Y.MA.POS = ''
    Y.CC.POS = ''
    FIND 'CC' IN Y.CREDIT.BLOCKS SETTING Y.CC.POS ELSE Y.CC.POS = ''

    IF (Y.MA.POS NE '' OR Y.BLK.APR NE '')  AND  Y.CC.POS EQ '' THEN
        R.HARD.BLOCKS<JHXS.CREDIT.READY> = 'NO'
    END

    IF Y.CC.POS NE '' THEN
        R.HARD.BLOCKS<JHXS.CREDIT.READY> = 'YES'
    END
    GOSUB UPDATE.HARD.BLOCK.AUDIT.FIELDS

RETURN

GET.CUSTOMER.PORTFOLIO.HARD.BLOCK.DETAILS:
******************************************
    Y.PAY.AMT = ''
    Y.SOO.CUSTOMER = R.NEW(PO.ORDERING.CUSTOMER)
    Y.CUSTOMER.ID = Y.SOO.CUSTOMER
    
    GOSUB GET.PAYMENT.AMOUNT

    IF R.HARD.BLOCKS<JHXS.CLIENT.ID> EQ '' THEN
        R.HARD.BLOCKS<JHXS.CLIENT.ID,1> =  Y.CUST.NO
        R.HARD.BLOCKS<JHXS.PORTFOLIO.ID,1> = Y.SEC.ACCNT
        GOSUB READ.CUSTOMER
        R.HARD.BLOCKS<JHXS.REL.MANAGER,1> = Y.DAO
        R.HARD.BLOCKS<JHXS.ACCT.OFFICER,1> = Y.OTHER.OFFICER
        R.HARD.BLOCKS<JHXS.TRANSACTION.TYPE,1> = Y.TXN.TYPE
        R.HARD.BLOCKS<JHXS.CURRENCY,1> = R.NEW(PO.DEBIT.CCY)
        R.HARD.BLOCKS<JHXS.QUANTITY,1> = ''
        R.HARD.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
    END ELSE
		IF NOT(R.HARD.BLOCKS<JHXS.AMOUNT,1>) THEN
			R.HARD.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
        END
	END

RETURN

UPDATE.HARD.BLOCK.AUDIT.FIELDS:
*******************************

    IF R.HARD.BLOCKS NE '' THEN
        X = OCONV(DATE(),'D4-')
        TIME.STAMP = TIMEDATE()
*        DATE.TIME = X[9,2]:X[1,2]:X[4,2]:TIME.STAMP[1,2]:TIME.STAMP[4,2]
        R.HARD.BLOCKS<JHXS.INPUTTER> = TNO:'_':OPERATOR

        R.HARD.BLOCKS<JHXS.CURR.NO> = '1'

        R.HARD.BLOCKS<JHXS.AUTHORISER> = TNO:'_':OPERATOR

        R.HARD.BLOCKS<JHXS.AUDIT.DATE.TIME> = DATE.TIME

        R.HARD.BLOCKS<JHXS.CO.CODE> = ID.COMPANY
        Y.TRANSACTION.ID = 'HB':ID.NEW
        WRITE R.HARD.BLOCKS ON F.JBWW.H.XX.SOFTBLOCK,Y.TRANSACTION.ID ON ERROR
            PRINT "CANT WRITE HARD BLOCKS":Y.TRANSACTION.ID
        END

    END

RETURN

PROCESS.MA.BP.BLOCKS:
********************
    IF  Y.TC.DONE[1,1] EQ 'Y' THEN RETURN
    IF R.SOFT.BLOCKS EQ '' OR Y.FT.MAKER.CHECK EQ 'MAKER' THEN
        CALL F.READ(FN.JBWW.L.XX.RLCSOFTBLOCK.LOG,ID.NEW,R.SOFT.BLOCK.LOG,F.JBWW.L.XX.RLCSOFTBLOCK.LOG,'')
        Y.CALJ.CC.TYPE = 'checkType'
        Y.CALJ.MSG.ID = 'msgId'
        Y.CALJ.MSG.TEXT = 'msgTxt'
        Y.CALJ.RESPONSE.CATEG = 'responseCategory'

        Y.CALL.J.RESPONSE = R.SOFT.BLOCK.LOG<RLG.CALLJ.RESPONSE>
        Y.CAL.J.RESP.CNT = DCOUNT(Y.CALL.J.RESPONSE,'|')

        IF Y.CAL.J.RESP.CNT GT '0' THEN
            Y.CJ = 0
            LOOP

                Y.CJ = Y.CJ + 1

            WHILE Y.CJ LE Y.CAL.J.RESP.CNT
                Y.CALJ.REC = FIELD(Y.CALL.J.RESPONSE,'|',Y.CJ)
                GOSUB UPDATE.MA.BP.DATA
            REPEAT

        END ELSE

            Y.CALJ.REC = Y.CALL.J.RESPONSE
            GOSUB UPDATE.MA.BP.DATA
        END

    END

RETURN

UPDATE.MA.BP.DATA:
******************

    Y.CALJ.FIELD = Y.CALJ.REC
    CHANGE '&&' TO FM IN Y.CALJ.FIELD
    Y.COUNT = DCOUNT(Y.CALJ.FIELD,FM)
    I = 0
    LOOP
        I = I + 1
    WHILE I LE Y.COUNT

        Y.CHECK.TYPE = Y.CALJ.FIELD<I>
        Y.CALJ.TAG.NAME = FIELD(Y.CHECK.TYPE,'=',1)
        Y.CALJ.VALUE = FIELD(Y.CHECK.TYPE,'=',2)

        IF Y.CALJ.CC.TYPE  EQ Y.CALJ.TAG.NAME THEN
            Y.CH.TYPE = UPCASE(Y.CALJ.VALUE)
        END

        IF Y.CALJ.MSG.ID EQ Y.CALJ.TAG.NAME THEN
            Y.MSG.ID = UPCASE(Y.CALJ.VALUE)
        END

        IF Y.CALJ.MSG.TEXT EQ Y.CALJ.TAG.NAME THEN
            Y.MSG.VAL = Y.CALJ.VALUE
        END

        IF Y.CALJ.RESPONSE.CATEG EQ Y.CALJ.TAG.NAME THEN
            Y.RESPONSE.CATEGORY = UPCASE(Y.CALJ.VALUE)
        END
    REPEAT

    IF Y.FT.MAKER.CHECK NE 'MAKER' THEN
        IF Y.FT.MAKER.CHECK NE 'CHECKER' THEN
            IF Y.RESPONSE.CATEGORY EQ 'SOFT_BLOCK' THEN
***
                Y.ID.BLOCKS = R.SOFT.BLOCKS<JHXS.BLOCK.ID>
                CHANGE VM TO FM IN Y.ID.BLOCKS
                Y.MSG.BLK.ID.POS = ''
                FIND Y.MSG.ID IN Y.ID.BLOCKS SETTING Y.MSG.BLK.ID.POS ELSE Y.MSG.BLK.ID.POS = ''
***
                IF Y.MSG.BLK.ID.POS EQ '' THEN
                    Y.SLBK.FLAG = '1'
                    Y.BLOCK.CNT += 1
                    R.SOFT.BLOCKS<JHXS.BLOCK.ID,Y.BLOCK.CNT> = Y.MSG.ID
                    R.SOFT.BLOCKS<JHXS.BLOCK.MSG,Y.BLOCK.CNT> = Y.MSG.VAL
                    R.SOFT.BLOCKS<JHXS.BLOCK.DEPT,Y.BLOCK.CNT> = Y.CH.TYPE

                    Y.SB.MAIL.ID<-1> = Y.MSG.ID
                    Y.SB.MAIL.MESSAGE<-1> = Y.MSG.VAL
                    Y.SB.MAIL.CHECK.TYPE<-1> = Y.CH.TYPE
                    GOSUB MA.CC.SB.MAIL.MSG.DETAILS
                END
            END

            IF Y.RESPONSE.CATEGORY EQ 'HARD_BLOCK' THEN
                Y.HB.MAIL.ID<-1> = Y.MSG.ID
                Y.HB.MAIL.MESSAGE<-1> = Y.MSG.VAL
                Y.HB.MAIL.CHECK.TYPE<-1> = Y.CH.TYPE
                GOSUB MA.CC.HB.MAIL.MSG.DETAILS
            END
        END
    END

    IF Y.FT.MAKER.CHECK EQ 'MAKER' THEN
        IF Y.RESPONSE.CATEGORY EQ 'SOFT_BLOCK' THEN
            Y.ID.BLOCKS = R.SOFT.BLOCKS<JHXS.BLOCK.ID>
            CHANGE VM TO FM IN Y.ID.BLOCKS
            Y.MSG.BLK.ID.POS = ''
            FIND Y.MSG.ID IN Y.ID.BLOCKS SETTING Y.MSG.BLK.ID.POS ELSE Y.MSG.BLK.ID.POS = ''
            IF Y.MSG.BLK.ID.POS NE '' THEN
                R.SOFT.BLOCKS<JHXS.BLOCK.MSG,Y.MSG.BLK.ID.POS> = Y.MSG.VAL
            END

            IF Y.MSG.BLK.ID.POS EQ '' THEN
                Y.BLOCK.CNT += 1
                R.SOFT.BLOCKS<JHXS.BLOCK.ID,Y.BLOCK.CNT> = Y.MSG.ID
                R.SOFT.BLOCKS<JHXS.BLOCK.MSG,Y.BLOCK.CNT> = Y.MSG.VAL
                R.SOFT.BLOCKS<JHXS.BLOCK.DEPT,Y.BLOCK.CNT> = Y.CH.TYPE
                Y.SB.MAIL.ID<-1> = Y.MSG.ID
                Y.SB.MAIL.MESSAGE<-1> = Y.MSG.VAL
                Y.SB.MAIL.CHECK.TYPE<-1> = Y.CH.TYPE
                GOSUB MA.CC.SB.MAIL.MSG.DETAILS
            END
        END
    END
    Y.MSG.ID = ''
    Y.MSG.VAL = ''
    Y.CH.TYPE = ''

RETURN


OVERRIDES:
********************

    IF R.HARD.BLOCKS NE '' THEN RETURN
    IF Y.FT.MAKER.CHECK NE 'MAKER' THEN
        IF Y.FT.MAKER.CHECK NE 'CHECKER' THEN
            Y.OVERIDES = R.NEW(PO.OVERRIDE)
            Y.OVERRIDES.CNT = DCOUNT(Y.OVERIDES,VM)

            YY = 0

            LOOP

                YY = YY + 1

            WHILE YY LE Y.OVERRIDES.CNT
                Y.OVERRIDE = ''
                Y.BLK.APR = ''
                Y.OVERRIDE = R.NEW(PO.OVERRIDE)<1,YY>
                Y.OVERRIDE.ID<-1> = Y.OVERRIDE['}',1,1]
                Y.OVERRIDE.DESC<-1> = Y.OVERRIDE['}',2,999]
                Y.OVE.ID = Y.OVERRIDE['}',1,1]
                Y.PREV.SB.BLOCKS = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS>
                CONVERT SM TO VM IN Y.PREV.SB.BLOCKS
                CONVERT VM TO FM IN Y.PREV.SB.BLOCKS

                Y.OVE.ID.POS = ''
                FIND Y.OVE.ID IN Y.PREV.SB.BLOCKS SETTING Y.OVE.ID.POS ELSE Y.OVE.ID.POS = ''

                GOSUB READ.OVERRIDE
                IF Y.BLK.APR NE '' THEN
                    IF Y.OVE.ID.POS EQ '' THEN
                        Y.OVER.ID.ARR<-1> =  Y.OVE.ID
                        Y.RESPONSE.CATEG = 'SB'
                        Y.BLK.APR.FLAG = '1'
                        Y.MSG.ID =  Y.OVE.ID
                        Y.MSG.VAL = Y.OVERRIDE['}',2,1]
                        Y.CHECK.TYPE = Y.BLK.APR
                        GOSUB UPDATE.LOCAL.FIELDS
                    END
                END
            REPEAT

            IF R.PP.NAU NE '' THEN
                CALL F.WRITE(FN.PAYMENT.ORDER$NAU,ID.NEW,R.PP.NAU)
            END
        END
    END
RETURN

READ.OVERRIDE:
***************
    R.OVERRIDE = ''
    CALL F.READ(FN.OVERRIDE,Y.OVE.ID,R.OVERRIDE,F.OVERRIDE,'')
    IF R.OVERRIDE THEN
        Y.BLK.APR = R.OVERRIDE<EB.OR.LOCAL.REF,Y.BLK.APR.POS>
    END

RETURN

UPDATE.LOCAL.FIELDS:
**********************
    Y.POS.CNT += 1

    R.PP.NAU<PO.LOCAL.REF,Y.BLK.CATEG.POS,Y.POS.CNT> = Y.CHECK.TYPE
    R.PP.NAU<PO.LOCAL.REF,Y.BLK.TYPE.POS,Y.POS.CNT>  =  Y.RESPONSE.CATEG
    R.PP.NAU<PO.LOCAL.REF,Y.BLK.CODE.POS,Y.POS.CNT> =  Y.MSG.ID
    R.PP.NAU<PO.LOCAL.REF,Y.BLK.MSG.POS,Y.POS.CNT> = Y.MSG.VAL[1,65]

    Y.DAO.CHKTYPE<-1> = Y.CHECK.TYPE
    Y.DAO.SB.ID<-1> = Y.MSG.ID
    Y.DAO.MESSAGE<-1> = Y.MSG.VAL
    Y.DAO.BLK.TYPE<-1> = 'SB'

    GOSUB UPDATE.MESSAGE.BLOCKS
RETURN

UPDATE.MESSAGE.BLOCKS:
*******************
    Y.BLOCK.CNT += 1

    IF Y.CHECK.TYPE NE 'MA' AND Y.CHECK.TYPE NE 'CC' THEN

        R.SOFT.BLOCKS<JHXS.BLOCK.ID,Y.BLOCK.CNT> = Y.MSG.ID
        R.SOFT.BLOCKS<JHXS.BLOCK.MSG,Y.BLOCK.CNT> = Y.MSG.VAL
        R.SOFT.BLOCKS<JHXS.BLOCK.DEPT,Y.BLOCK.CNT> = Y.CHECK.TYPE
        Y.TAGMESSAGE.VALUES<-1> = Y.MSG.VAL
        Y.TAGOWNER.VALUES<-1> = Y.CHECK.TYPE
    END
RETURN


UPDATE.SOFT.BLOCKS.TABLE:
***********************
    IF R.SOFT.BLOCKS NE '' THEN
        GOSUB GET.CUSTOMER.PORTFOLIO.SOFT.BLOCK.DETAILS
        Y.TRANSACTION.ID = ID.NEW
        R.SOFT.BLOCKS<JHXS.APPLICATION> = APPLICATION

        R.SOFT.BLOCKS<JHXS.ISIN.IDENTIFIER> = ''
        R.SOFT.BLOCKS<JHXS.TRADE.DATE> = TODAY
        R.SOFT.BLOCKS<JHXS.VALUE.DATE> = Y.DEBIT.VALDATE
*        R.SOFT.BLOCKS<JHXS.DATE.TIME> = DATE.TIME
        IF Y.DONE.DEAL EQ 'Y' THEN
            R.SOFT.BLOCKS<JHXS.DONE.DEAL> = 'Y'
        END ELSE
            R.SOFT.BLOCKS<JHXS.DONE.DEAL> = 'N'
        END
        Y.RLC.FLAG = ''
        Y.MA.POS = ''
        FIND 'MA' IN Y.CREDIT.BLOCKS SETTING Y.MA.POS ELSE Y.MA.POS = ''
        Y.CC.POS = ''
        FIND 'CC' IN Y.CREDIT.BLOCKS SETTING Y.CC.POS ELSE Y.CC.POS = ''

        IF Y.MA.POS NE '' OR Y.BLK.APR.FLAG NE '' THEN
            R.SOFT.BLOCKS<JHXS.CREDIT.READY> = 'NO'
            Y.RLC.FLAG = '1'
        END

        IF Y.CC.POS NE '' AND Y.RLC.FLAG EQ '' THEN
            R.SOFT.BLOCKS<JHXS.CREDIT.READY> = 'CHECKER'
        END
        IF Y.FT.MAKER.CHECK NE 'MAKER' THEN
            Y.TRANSACTION.ID = ID.NEW
            GOSUB UPDATE.AUDIT.FIELDS
        END

    END

RETURN

GET.CUSTOMER.PORTFOLIO.SOFT.BLOCK.DETAILS:
*****************************************
    Y.PAY.AMT = ''
    Y.SOO.CUSTOMER = R.NEW(PO.ORDERING.CUSTOMER)
    Y.CUSTOMER.ID = Y.SOO.CUSTOMER
    GOSUB GET.PAYMENT.AMOUNT
    IF R.SOFT.BLOCKS<JHXS.CLIENT.ID> EQ '' THEN
        R.SOFT.BLOCKS<JHXS.CLIENT.ID,1> = Y.CUST.NO
        R.SOFT.BLOCKS<JHXS.PORTFOLIO.ID,1> = Y.SEC.ACCNT
        GOSUB READ.CUSTOMER
        R.SOFT.BLOCKS<JHXS.REL.MANAGER,1> = Y.DAO
        R.SOFT.BLOCKS<JHXS.ACCT.OFFICER,1> = Y.OTHER.OFFICER
        R.SOFT.BLOCKS<JHXS.TRANSACTION.TYPE,1> = Y.TXN.TYPE
        R.SOFT.BLOCKS<JHXS.CURRENCY,1> = R.NEW(PO.DEBIT.CCY)
        R.SOFT.BLOCKS<JHXS.QUANTITY,1> = ''
        R.SOFT.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
    END ELSE
		IF NOT(R.SOFT.BLOCKS<JHXS.AMOUNT,1>) THEN
			R.SOFT.BLOCKS<JHXS.AMOUNT,1> = Y.PAY.AMT
		END
	END

RETURN

READ.CUSTOMER:
*************
    R.CUS = ''
    CALL F.READ(FN.CUSTOMER,Y.CUSTOMER.ID,R.CUS,F.CUSTOMER,'')
    IF R.CUS THEN
        Y.DAO = R.CUS<EB.CUS.ACCOUNT.OFFICER>
        GOSUB READ.DEPT.ACCT.OFFICER
        Y.OFFICER.TYPE = R.CUS<EB.CUS.LOCAL.REF,Y.OFFICER.TYPE.POS>
        Y.OFFICER.ID = R.CUS<EB.CUS.LOCAL.REF,Y.OFFICER.ID.POS>
        CHANGE SM TO VM IN Y.OFFICER.ID
        CHANGE SM TO VM IN Y.OFFICER.TYPE
        CHANGE VM TO FM IN Y.OFFICER.TYPE
        Y.CO.POS = ''
        FIND 'CO' IN Y.OFFICER.TYPE SETTING Y.CO.POS ELSE Y.CO.POS = ''
        IF Y.CO.POS THEN
            Y.OTHER.OFFICER = Y.OFFICER.ID<1,Y.CO.POS>
        END
    END

RETURN

READ.DEPT.ACCT.OFFICER:
**********************
    R.DAO = ''
    CALL F.READ(FN.DEPT.ACCT.OFFICER,Y.DAO,R.DAO,F.DEPT.ACCT.OFFICER,'')
    IF R.DAO NE '' THEN
        Y.DAO.NAME = R.DAO<EB.DAO.NAME>
    END
RETURN


UPDATE.AUDIT.FIELDS:
**********************

    COMMON.V.SAVE = V
    V = JHXS.AUDIT.DATE.TIME
    Y.CO.CODE.POS = V-3
    Y.SAVE = R.NEW(Y.CO.CODE.POS)
    CALL S.UPDATE.AUDIT.FIELDS(R.SOFT.BLOCKS)
    R.NEW(Y.CO.CODE.POS) = Y.SAVE
    V = COMMON.V.SAVE

    CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK,Y.TRANSACTION.ID,R.SOFT.BLOCKS)

RETURN

MAIL.DATA:
*************
    IF R.HARD.BLOCKS NE '' THEN RETURN
    IF Y.TC.DONE[1,1] EQ 'Y' THEN
        Y.CHECKTYPES.OESA<-1> = R.NEW(PO.LOCAL.REF)<1,Y.BLK.CATEG.POS>
        Y.BLK.TYPE.OESA<-1> =  R.NEW(PO.LOCAL.REF)<1,Y.BLK.TYPE.POS>
        Y.SB.ID.OESA<-1> =  R.NEW(PO.LOCAL.REF)<1,Y.BLK.CODE.POS>
        Y.MESSAGE.OESA<-1> = R.NEW(PO.LOCAL.REF)<1,Y.BLK.MSG.POS>
        CHANGE SM TO FM IN Y.CHECKTYPES.OESA
        CHANGE SM TO FM IN Y.BLK.TYPE.OESA
        CHANGE SM TO FM IN Y.SB.ID.OESA
        CHANGE SM TO FM IN Y.MESSAGE.OESA
        Y.CHKTYPE.CNT = DCOUNT(Y.CHECKTYPES.OESA,FM)
        J = 0
        LOOP
            J = J +1
        WHILE J LE Y.CHKTYPE.CNT
            Y.BLK.TYPE = ''
            Y.BLK.TYPE = Y.BLK.TYPE.OESA<J>
            Y.BLK.TYPE = UPCASE(Y.BLK.TYPE)
            IF Y.BLK.TYPE[1,4] EQ 'SOFT' THEN
                Y.CHECKTYPES<-1> = Y.CHECKTYPES.OESA<J>
                Y.SB.ID<-1> =  Y.SB.ID.OESA<J>
                Y.MESSAGE<-1> = Y.MESSAGE.OESA<J>

                Y.MSG.ID =  Y.SB.ID.OESA<J>
                Y.MSG.VAL = Y.MESSAGE.OESA<J>
                Y.CH.TYPE = Y.CHECKTYPES.OESA<J>
                GOSUB MA.CC.SB.MAIL.MSG.DETAILS
            END
        REPEAT
    END ELSE
        Y.CHECKTYPES<-1> = Y.SB.MAIL.CHECK.TYPE
        Y.SB.ID<-1> =  Y.SB.MAIL.ID
        Y.MESSAGE<-1> =  Y.SB.MAIL.MESSAGE
    END

    IF Y.DAO.CHKTYPE NE '' THEN

        GOSUB EXTRACT.DETAILS.FOR.DAO

        IF Y.OWNER NE '' THEN
            Y.CHECKTYPES<-1> = Y.OWNER
        END
        IF Y.TAG.NOTES NE '' THEN
            Y.NOTES<-1> = TRIM(Y.TAG.NOTES," ","B")
        END
        IF Y.TAG.ID.ARR NE '' THEN
            Y.SB.ID<-1> = Y.TAG.ID.ARR
        END
        IF Y.TAG.MESSAGE NE '' THEN
            Y.MESSAGE<-1> = Y.TAG.MESSAGE
        END
    END
RETURN

TRIGGER.MAIL.TO.RM:
*******************
    IF R.HARD.BLOCKS NE '' THEN RETURN
    GOSUB MAIL.DATA

    CHANGE FM TO SM IN Y.CHECKTYPES
    CHANGE FM TO SM IN Y.SB.ID
    CHANGE FM TO SM IN Y.MESSAGE
    CHANGE FM TO SM IN Y.BLK.TYPE
    CHANGE FM TO VM IN Y.NOTES
    CHANGE VM TO SM IN Y.NOTES

    GOSUB GET.TRANSACTION.MAIL.DETAILS
    IF Y.BLOCK.TYPE.POS NE '' AND Y.SWITCH.VALUE EQ 'ON' THEN
        TYPE = Y.BLOCK.TYPE.VALUE
        ENTITY.TYPE<1,1> = 'PORTFOLIO'
        CONVERT FM TO VM IN Y.SEC.ACCNT
        CONVERT VM TO SM IN Y.SEC.ACCNT
        ENTITY.ID<1,1,-1> = Y.SEC.ACCNT


        Y.NAME<1,1> = 'Transaction Number'
        Y.VALUE<1,1,-1> = ID.NEW
        Y.NAME<1,2> = 'Soft Block ID'
        Y.VALUE<1,2,-1> = Y.SB.ID
        Y.NAME<1,3> = 'Soft Block Message'
        Y.VALUE<1,3,-1> = Y.MESSAGE
        Y.NAME<1,4> = 'Soft Block Owner'
        Y.VALUE<1,4,-1> = Y.CHECKTYPES
        Y.NAME<1,5> = 'Tag Notes'
        Y.VALUE<1,5,-1> = Y.NOTES
*-----------------------------------------------------------------------------
        CHANGE FM TO SM IN Y.CUST.NO
        CHANGE FM TO SM IN Y.SEC.ACCNT
        Y.NAME<1,6> = 'Customer Number'
        Y.VALUE<1,6,-1> = Y.CUST.NO
        Y.NAME<1,7> = 'Portfolio Number'
        Y.VALUE<1,7,-1> = Y.SEC.ACCNT
        Y.NAME<1,8> = 'Transaction Type'
        Y.VALUE<1,8,-1> = Y.TXN.TYPE
        Y.NAME<1,9> = 'Quantity'
        Y.VALUE<1,9,-1> = Y.MAIL.NO.NOMINAL
        Y.NAME<1,10> = 'Currency'
        Y.VALUE<1,10,-1> = Y.MAIL.SET.CCY
        Y.NAME<1,11> = 'Amount'
        Y.VALUE<1,11,-1> = Y.MAIL.TRANS.AMT
        Y.NAME<1,12> = 'Security identifier'
        Y.VALUE<1,12,-1> = Y.MAIL.SECURITY.NO
        Y.NAME<1,13> = 'Trade Date'
        Y.VALUE<1,13,-1> = Y.MAIL.TRADE.DATE
        Y.NAME<1,14> = 'Value Date'
        Y.VALUE<1,14,-1> = Y.MAIL.VALUE.DATE

        Y.NAME<1,15> = 'RelManager'
        Y.VALUE<1,15,-1> = Y.DAO.NAME
        Y.NAME<1,16> = 'Inputter'
        Y.OPERATOR = OPERATOR
        CONVERT FM TO SM IN Y.OPERATOR
        Y.VALUE<1,16,-1> = Y.OPERATOR
        Y.NAME<1,17> = 'Date Time'
        Y.VALUE<1,17,-1> = DATE.TIME

        CONVERT FM TO VM IN Y.NAME
        GOSUB TRIGGER.EMAIL

    END
RETURN

TRIGGER.MULTIPLE.MAILS:
******************************
    GOSUB MAIL.TO.MA.APPROVER
    GOSUB MAIL.TO.BP.APPROVER
    IF R.HARD.BLOCKS NE '' THEN RETURN
    GOSUB MAIL.TO.DAO.APPROVER
    GOSUB MAIL.DAO.FORM.TAG.DETAILS
RETURN

MAIL.DAO.FORM.TAG.DETAILS:
***************************
    IF R.BLOCKTAGDETS EQ '' THEN
        Y.SAM.ID = Y.PORTFOLIO
        GOSUB READ.SAM
        Y.TAG.ID.ARR = R.SAM.REC<SC.SAM.LOCAL.REF,Y.TAG.ID.POS>
        Y.TAG.OVE.IDS = R.SAM.REC<SC.SAM.LOCAL.REF,Y.TAG.BLK.POS>
        CHANGE SM TO VM IN Y.TAG.ID.ARR
        CHANGE VM TO FM IN Y.TAG.ID.ARR
        CHANGE SM TO VM IN Y.TAG.OVE.IDS
        CHANGE VM TO FM IN Y.TAG.OVE.IDS
        Y.TAG.ID.ARR.CNT = DCOUNT(Y.TAG.ID.ARR,FM)

        I = 0
        LOOP
            I = I + 1
        WHILE I LE Y.TAG.ID.ARR.CNT
            Y.OVE.ID =  Y.TAG.OVE.IDS<I>
            GOSUB READ.OVERRIDE
            Y.TAG.ID = Y.TAG.ID.ARR<I>
            Y.TAG.MESSAGE = R.OVERRIDE<EB.OR.MESSAGE,1>
            Y.OWNER = Y.BLK.APR
            GOSUB MAIL.TO.DAO
            Y.TAG.ID = ''
            Y.TAG.MESSAGE = ''
            Y.OWNER = ''
        REPEAT
    END
RETURN

MAIL.TO.DAO.APPROVER:
************************
    Y.TAG.ID = ''
    Y.TAG.MESSAGE = ''
    Y.OWNER = ''
    Y.NOTES = ''
    Y.TAG.NOTES = ''
    Y.BLOCK.OWNER = ''
    Y.PORTFOLIO.ID = Y.PORTFOLIO
    CALL F.READ(FN.JBWW.H.EB.BLOCKTAGDETS,Y.PORTFOLIO.ID,R.BLOCKTAGDETS,F.JBWW.H.EB.BLOCKTAGDETS,'')
    IF R.BLOCKTAGDETS THEN
        Y.TAG.IDS = R.BLOCKTAGDETS<BTD.TAG.ID>
        Y.BLOCK.OWNER = R.BLOCKTAGDETS<BTD.OWNER>
        Y.TAG.CNT = DCOUNT(Y.TAG.IDS,VM)
        I = 0
        LOOP
            I = I + 1
        WHILE I LE Y.TAG.CNT
            Y.TAG.BLOCKIDS = ''
            Y.TAG.ID = ''
            Y.TAG.ID = Y.TAG.IDS<1,I>
            Y.TAG.BLOCKIDS = R.BLOCKTAGDETS<BTD.BLOCK.ID,I>
            CHANGE SM TO FM IN Y.TAG.BLOCKIDS
            Y.TAG.BLOCKIDS.CNT = DCOUNT(Y.TAG.BLOCKIDS,FM)
            J = 0
            LOOP
                J = J + 1
            WHILE J LE Y.TAG.BLOCKIDS.CNT
                Y.TAG.OVERRIDE = Y.TAG.BLOCKIDS<J>
                Y.TAG.OVE.POS = ''

                FIND Y.TAG.OVERRIDE IN Y.OVER.ID.ARR SETTING Y.TAG.OVE.POS ELSE Y.TAG.OVE.POS = ''
                IF Y.TAG.OVE.POS THEN
                    Y.OWNER = Y.BLOCK.OWNER<1,I>
                    Y.TAG.NOTES<-1> = R.BLOCKTAGDETS<BTD.NOTES,I,J>
                    Y.OVE.ID = Y.TAG.OVERRIDE
                    GOSUB READ.OVERRIDE
                    Y.TAG.MESSAGE<-1> = R.OVERRIDE<EB.OR.MESSAGE,1>
                    IF Y.OVE.ID[1,2] EQ 'HB' THEN
                        Y.HARD.BLOCK.ID = Y.OVE.ID
                        GOSUB READ.EB.ERROR
                        Y.DAO.TYPE = Y.OWNER
                        Y.TAG.MESSAGE<-1> = Y.MSG.VAL
                    END
                END
            REPEAT
            GOSUB MAIL.TO.DAO
            Y.TAG.ID = ''
            Y.TAG.MESSAGE = ''
            Y.OWNER = ''
            Y.NOTES = ''
            Y.TAG.NOTES = ''
        REPEAT
    END

RETURN

MAIL.TO.MA.APPROVER:
********************
    IF Y.MA.CHKTYPE  NE ''  THEN

        TYPE =  Y.APPROVE.MA
        ENTITY.TYPE<1,1> = 'PORTFOLIO'
        ENTITY.ID = Y.SEC.ACCNT
        Y.NAME = ''
        Y.VALUE = ''
        RETVAR = ''
        CONVERT FM TO VM IN Y.MA.CHKTYPE
        CONVERT VM TO SM IN Y.MA.CHKTYPE
        CONVERT FM TO VM IN Y.MA.SB.ID
        CONVERT VM TO SM IN Y.MA.SB.ID
        CONVERT FM TO VM IN Y.MA.MESSAGE
        CONVERT VM TO SM IN Y.MA.MESSAGE
        GOSUB GET.TRANSACTION.MAIL.DETAILS

        TYPE = Y.APPROVE.MA

        CONVERT FM TO VM IN Y.SEC.ACCNT
        CONVERT  VM TO SM IN Y.SEC.ACCNT

        Y.NAME<1,1> = 'Transaction Number'
        Y.VALUE<1,1,-1> = ID.NEW
        Y.NAME<1,2> = 'Soft Block ID'
        Y.VALUE<1,2,-1> = Y.MA.SB.ID
        Y.NAME<1,3> = 'Soft Block Message'
        Y.VALUE<1,3,-1> = Y.MA.MESSAGE
        Y.NAME<1,4> = 'Soft Block Owner'
        Y.VALUE<1,4,-1> = Y.MA.CHKTYPE

        CHANGE FM TO SM IN Y.CUST.NO
        CHANGE FM TO SM IN Y.SEC.ACCNT

        Y.NAME<1,5> = 'Customer Number'
        Y.VALUE<1,5,-1> = Y.CUST.NO
        Y.NAME<1,6> = 'Portfolio Number'
        Y.VALUE<1,6,-1> = Y.SEC.ACCNT
        Y.NAME<1,7> = 'Transaction Type'
        Y.VALUE<1,7,-1> = Y.TXN.TYPE
        Y.NAME<1,8> = 'Quantity'
        Y.VALUE<1,8,-1> = Y.MAIL.NO.NOMINAL
        Y.NAME<1,9> = 'Currency'
        Y.VALUE<1,9,-1> = Y.MAIL.SET.CCY
        Y.NAME<1,10> = 'Amount'
        Y.VALUE<1,10,-1> = Y.MAIL.TRANS.AMT
        Y.NAME<1,11> = 'Security identifier'
        Y.VALUE<1,11,-1> = Y.MAIL.SECURITY.NO
        Y.NAME<1,12> = 'Trade Date'
        Y.VALUE<1,12,-1> = Y.MAIL.TRADE.DATE
        Y.NAME<1,13> = 'Value Date'
        Y.VALUE<1,13,-1> = Y.MAIL.VALUE.DATE

        Y.NAME<1,14> = 'RelManager'
        Y.VALUE<1,14,-1> = Y.DAO.NAME
        Y.NAME<1,15> = 'Inputter'
        Y.OPERATOR = OPERATOR
        CONVERT FM TO SM IN Y.OPERATOR
        Y.VALUE<1,15,-1> = Y.OPERATOR
        Y.NAME<1,16> = 'Date Time'
        Y.VALUE<1,16,-1> = DATE.TIME
        CONVERT FM TO VM IN Y.NAME
        GOSUB TRIGGER.EMAIL
    END
RETURN

MAIL.TO.BP.APPROVER:
*********************
    IF Y.BP.CHKTYPE NE ''  THEN

        TYPE =  Y.APPROVE.BP
        ENTITY.TYPE<1,1> = 'PORTFOLIO'
        ENTITY.ID = Y.SEC.ACCNT
        Y.NAME = ''
        Y.VALUE = ''
        RETVAR = ''
        CONVERT FM TO VM IN Y.BP.CHKTYPE
        CONVERT VM TO SM IN Y.BP.CHKTYPE

        CONVERT FM TO VM IN Y.BP.SB.ID
        CONVERT VM TO SM IN Y.BP.SB.ID

        CONVERT FM TO VM IN Y.BP.MESSAGE
        CONVERT VM TO SM IN Y.BP.MESSAGE

        TYPE = Y.APPROVE.BP

        CONVERT FM TO VM IN Y.SEC.ACCNT
        CONVERT VM TO SM IN Y.SEC.ACCNT
        GOSUB GET.TRANSACTION.MAIL.DETAILS

        Y.NAME<1,1> = 'Transaction Number'
        Y.VALUE<1,1,-1> = ID.NEW
        Y.NAME<1,2> = 'Soft Block ID'
        Y.VALUE<1,2,-1> = Y.BP.SB.ID
        Y.NAME<1,3> = 'Soft Block Message'
        Y.VALUE<1,3,-1> = Y.BP.MESSAGE
        Y.NAME<1,4> = 'Soft Block Owner'
        Y.VALUE<1,4,-1> = Y.BP.CHKTYPE

        CHANGE FM TO SM IN Y.CUST.NO
        CHANGE FM TO SM IN Y.SEC.ACCNT
        Y.NAME<1,5> = 'Customer Number'
        Y.VALUE<1,5,-1> = Y.CUST.NO
        Y.NAME<1,6> = 'Portfolio Number'
        Y.VALUE<1,6,-1> = Y.SEC.ACCNT
        Y.NAME<1,7> = 'Transaction Type'
        Y.VALUE<1,7,-1> = Y.TXN.TYPE
        Y.NAME<1,8> = 'Quantity'
        Y.VALUE<1,8,-1> = Y.MAIL.NO.NOMINAL
        Y.NAME<1,9> = 'Currency'
        Y.VALUE<1,9,-1> = Y.MAIL.SET.CCY
        Y.NAME<1,10> = 'Amount'
        Y.VALUE<1,10,-1> = Y.MAIL.TRANS.AMT
        Y.NAME<1,11> = 'Security identifier'
        Y.VALUE<1,11,-1> = Y.MAIL.SECURITY.NO
        Y.NAME<1,12> = 'Trade Date'
        Y.VALUE<1,12,-1> = Y.MAIL.TRADE.DATE
        Y.NAME<1,13> = 'Value Date'
        Y.VALUE<1,13,-1> = Y.MAIL.VALUE.DATE

        Y.NAME<1,14> = 'RelManager'
        Y.VALUE<1,14,-1> = Y.DAO.NAME
        Y.NAME<1,15> = 'Inputter'
        Y.OPERATOR = OPERATOR
        CONVERT FM TO SM IN Y.OPERATOR
        Y.VALUE<1,15,-1> = Y.OPERATOR
        Y.NAME<1,16> = 'Date Time'
        Y.VALUE<1,16,-1> = DATE.TIME
        CONVERT FM TO VM IN Y.NAME
        GOSUB TRIGGER.EMAIL
    END
RETURN

MAIL.TO.DAO:
************
    Y.DAO.VALUES = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    CHANGE VM TO FM IN Y.DAO.VALUES

    Y.DAO.POS = ''
    FIND Y.BLK.APR IN Y.DAO.VALUES SETTING Y.DAO.POS ELSE Y.DAO.POS = ''
    Y.DAO.TYPE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.DAO.POS,1>
    IF Y.DAO.POS EQ '' THEN
        Y.DAO.TYPE = Y.BLOCK.OWNER<1,I>
    END

    ENTITY.TYPE = ''
    ENTITY.ID = ''
    ENTITY.TYPE<1,1> = 'PORTFOLIO'
    ENTITY.ID = Y.SEC.ACCNT
    Y.NAME = ''
    Y.VALUE = ''
    RETVAR = ''
    Y.NAME = ''
    Y.VALUE = ''
    TYPE =  Y.DAO.TYPE

    IF Y.TAG.ID EQ '' THEN RETURN
    GOSUB GET.TRANSACTION.MAIL.DETAILS
    CONVERT FM TO VM IN Y.SEC.ACCNT
    CONVERT VM TO SM IN Y.SEC.ACCNT

    Y.DAO.TAG.ID = Y.TAG.ID
    Y.DAO.TAG.MESSAGE = Y.TAG.MESSAGE
    Y.DAO.OWNER = Y.OWNER
    Y.DAO.NOTES = Y.TAG.NOTES
    CHANGE FM TO VM IN Y.DAO.TAG.ID
    CHANGE VM TO SM IN Y.DAO.TAG.ID
    CHANGE FM TO VM IN Y.DAO.TAG.MESSAGE
    CHANGE VM TO SM IN Y.DAO.TAG.MESSAGE
    CHANGE FM TO VM IN Y.DAO.OWNER
    CHANGE VM TO SM IN Y.DAO.OWNER
    CHANGE FM TO VM IN Y.DAO.NOTES
    CHANGE VM TO SM IN Y.DAO.NOTES

    Y.NAME<1,1> = 'Transaction Number'
    Y.VALUE<1,1,-1> = ID.NEW
    Y.NAME<1,2> = 'Soft Block ID'
    Y.VALUE<1,2,-1> = Y.DAO.TAG.ID
    Y.NAME<1,3> = 'Soft Block Message'
    Y.VALUE<1,3,-1> = Y.DAO.TAG.MESSAGE
    Y.NAME<1,4> = 'Soft Block Owner'
    Y.VALUE<1,4,-1> = Y.DAO.OWNER
    Y.NAME<1,5> = 'Tag Notes'
    Y.VALUE<1,5,-1> = Y.DAO.NOTES
*-----------------------------------------------------------------------------
    CHANGE FM TO SM IN Y.CUST.NO
    CHANGE FM TO SM IN Y.SEC.ACCNT
    Y.NAME<1,6> = 'Customer Number'
    Y.VALUE<1,6,-1> = Y.CUST.NO
    Y.NAME<1,7> = 'Portfolio Number'
    Y.VALUE<1,7,-1> = Y.SEC.ACCNT
    Y.NAME<1,8> = 'Transaction Type'
    Y.VALUE<1,8,-1> = Y.TXN.TYPE
    Y.NAME<1,9> = 'Quantity'
    Y.VALUE<1,9,-1> = Y.MAIL.NO.NOMINAL
    Y.NAME<1,10> = 'Currency'
    Y.VALUE<1,10,-1> = Y.MAIL.SET.CCY
    Y.NAME<1,11> = 'Amount'
    Y.VALUE<1,11,-1> = Y.MAIL.TRANS.AMT
    Y.NAME<1,12> = 'Security identifier'
    Y.VALUE<1,12,-1> = Y.MAIL.SECURITY.NO
    Y.NAME<1,13> = 'Trade Date'
    Y.VALUE<1,13,-1> = Y.MAIL.TRADE.DATE
    Y.NAME<1,14> = 'Value Date'
    Y.VALUE<1,14,-1> = Y.MAIL.VALUE.DATE

    Y.NAME<1,15> = 'RelManager'
    Y.VALUE<1,15,-1> = Y.DAO.NAME
    Y.NAME<1,16> = 'Inputter'
    Y.OPERATOR = OPERATOR
    CONVERT FM TO SM IN Y.OPERATOR
    Y.VALUE<1,16,-1> = Y.OPERATOR
    Y.NAME<1,17> = 'Date Time'
    Y.VALUE<1,17,-1> = DATE.TIME
    CONVERT FM TO VM IN Y.NAME
    GOSUB TRIGGER.EMAIL
RETURN

FETCH.TAG.DETS.FROM.PORTFOLIO:
*****************************

    IF R.SAM.REC NE '' THEN
        Y.HB.TAG.ID.ARR = R.SAM.REC<SC.SAM.LOCAL.REF,Y.TAG.ID.POS>
        Y.HB.OVE.ID.ARR = R.SAM.REC<SC.SAM.LOCAL.REF,Y.TAG.BLK.POS>
        CHANGE SM TO FM IN Y.HB.TAG.ID.ARR
        CHANGE SM TO FM IN Y.HB.OVE.ID.ARR
        Y.HB.OVE.ID.ARR.CNT = DCOUNT(Y.HB.OVE.ID.ARR,FM)
        IF Y.HB.TAG.ID.ARR NE '' THEN
            I = 0
            LOOP
                I = I + 1
            WHILE I LE  Y.HB.OVE.ID.ARR.CNT
                Y.HBBLOCK.ID = Y.HB.SB.ID<I>
                Y.HB.ID.POS = ''
                FIND Y.HBBLOCK.ID IN Y.HB.OVE.ID.ARR SETTING Y.HB.ID.POS ELSE Y.HB.ID.POS = ''
                IF Y.HB.ID.POS THEN
                    IF Y.HBBLOCK.ID[1,3] EQ 'ST-' THEN
                        Y.SB.ID<-1> = Y.HB.TAG.ID.ARR<Y.HB.ID.POS>
                    END
                END
            REPEAT
        END
    END
RETURN

RETURN

TRIGGER.MAIL.TO.RM.HARD.BLOCK:
*******************************

    IF R.HARD.BLOCKS EQ '' THEN RETURN
    Y.CHECKTYPES = ''
    Y.SB.ID = ''
    Y.MESSAGE = ''
    GOSUB FETCH.TAG.DETS.FROM.PORTFOLIO
    Y.CHECKTYPES<-1> = Y.HB.CKTYPE
    IF Y.SB.ID EQ '' THEN
        Y.SB.ID<-1> = Y.HB.SB.ID
    END
    Y.MESSAGE<-1> = Y.HB.MESSAGE
    Y.CHECKTYPES = ''
    CHANGE FM TO SM IN Y.SB.ID
    CHANGE FM TO SM IN Y.MESSAGE
    CHANGE FM TO SM IN Y.BLK.TYPE
    CHANGE FM TO VM IN Y.NOTES
    CHANGE VM TO SM IN Y.NOTES

    GOSUB GET.TRANSACTION.MAIL.DETAILS
    IF Y.HB.TYPE.POS  NE '' AND Y.HB.SWITCH.VALUE EQ 'ON' THEN
        TYPE = Y.HB.BLOCK.VALUE
        ENTITY.TYPE<1,1> = 'PORTFOLIO'
        CONVERT FM TO VM IN Y.SEC.ACCNT
        CONVERT VM TO SM IN Y.SEC.ACCNT
        ENTITY.ID<1,1,-1> = Y.SEC.ACCNT

        Y.NAME<1,1> = 'Transaction Number'
        Y.VALUE<1,1,-1> = ID.NEW
        Y.NAME<1,2> = 'Soft Block ID'
        Y.VALUE<1,2,-1> = Y.SB.ID
        Y.NAME<1,3> = 'Soft Block Message'
        Y.VALUE<1,3,-1> = Y.MESSAGE
        Y.NAME<1,4> = 'Soft Block Owner'
        Y.VALUE<1,4,-1> = Y.CHECKTYPES
        Y.NAME<1,5> = 'Tag Notes'
        Y.VALUE<1,5,-1> = Y.NOTES
*-----------------------------------------------------------------------------
        CHANGE FM TO SM IN Y.CUST.NO
        CHANGE FM TO SM IN Y.SEC.ACCNT
        Y.NAME<1,6> = 'Customer Number'
        Y.VALUE<1,6,-1> = Y.CUST.NO
        Y.NAME<1,7> = 'Portfolio Number'
        Y.VALUE<1,7,-1> = Y.SEC.ACCNT
        Y.NAME<1,8> = 'Transaction Type'
        Y.VALUE<1,8,-1> = Y.TXN.TYPE
        Y.NAME<1,9> = 'Quantity'
        Y.VALUE<1,9,-1> = Y.MAIL.NO.NOMINAL
        Y.NAME<1,10> = 'Currency'
        Y.VALUE<1,10,-1> = Y.MAIL.SET.CCY
        Y.NAME<1,11> = 'Amount'
        Y.VALUE<1,11,-1> = Y.MAIL.TRANS.AMT
        Y.NAME<1,12> = 'Security identifier'
        Y.VALUE<1,12,-1> = Y.MAIL.SECURITY.NO
        Y.NAME<1,13> = 'Trade Date'
        Y.VALUE<1,13,-1> = Y.MAIL.TRADE.DATE
        Y.NAME<1,14> = 'Value Date'
        Y.VALUE<1,14,-1> = Y.MAIL.VALUE.DATE

        Y.NAME<1,15> = 'RelManager'
        Y.VALUE<1,15,-1> = Y.DAO.NAME
        Y.NAME<1,16> = 'Inputter'
        Y.OPERATOR = OPERATOR
        CONVERT FM TO SM IN Y.OPERATOR
        Y.VALUE<1,16,-1> = Y.OPERATOR
        Y.NAME<1,17> = 'Date Time'
        Y.VALUE<1,17,-1> = DATE.TIME
        CONVERT FM TO VM IN Y.NAME
        GOSUB TRIGGER.EMAIL

    END
RETURN

FETCH.CUSTOMER.DETAILS:
***********************
    GOSUB READ.CUSTOMER
    Y.CUST.NO = R.CUS<EB.CUS.MNEMONIC>
RETURN

FETCH.PORTFOLIO.DETAILS:
************************
    Y.DR.AC.NO = R.NEW(PO.DEBIT.ACCOUNT)
    Y.ACCT.NO =  Y.DR.AC.NO
    GOSUB READ.AC
    Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID = Y.PORTFOLIO<1,1>
    IF Y.SAM.ID EQ '' THEN
        GOSUB READ.SC.INC.ACCOUNT
    END
    GOSUB READ.SAM
    IF R.SAM.REC NE '' THEN
        Y.SEC.ACCNT = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
        Y.CUSTOMER.ID = FIELD(Y.SAM.ID,'-',1)
        GOSUB FETCH.CUSTOMER.DETAILS
    END
    Y.TAG.BLK.ID =  Y.TAG.BLK.IDS<1>
    Y.DR.BLK.POS = ''
    FIND Y.TAG.BLK.ID IN Y.TAG.BLK.IDS SETTING Y.DR.BLK.POS ELSE Y.DR.BLK.POS = ''
    IF Y.DR.BLK.POS NE '' THEN
        Y.DR.CUST.PORT.FLAG = '1'
    END

RETURN
READ.AC:
*************
    R.AC = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.NO,R.AC,F.ACCOUNT,'')

RETURN

READ.SC.INC.ACCOUNT:
********************
    R.INC = ''
    CALL F.READ(FN.SC.INC.ACCOUNT,Y.ACCT.NO,R.INC,F.SC.INC.ACCOUNT,'')
    Y.SAM.ID = R.INC<1>
RETURN
READ.SAM:
*********
    Y.BULK.TAG.IDS = ''
    Y.TAG.BLK.IDS = ''

    Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID = Y.PORTFOLIO<1,1>
    R.SAM.REC = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
    IF R.SAM.REC THEN
        Y.SEC.ACCNT = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
        Y.BULK.TAG.IDS = R.SAM.REC<SC.SAM.LOCAL.REF>
        Y.TAG.BLK.IDS = Y.BULK.TAG.IDS<1,Y.TAG.BLK.POS>
        CHANGE SM TO FM IN Y.TAG.BLK.IDS
    END

RETURN

PROCESS.MAKER.CHECKER:
**************************
    Y.CR.BLOCK.POS = ''
    FIND 'CC' IN Y.CREDIT.BLOCKS SETTING Y.CR.BLOCK.POS ELSE Y.CR.BLOCK.POS = ''
    IF Y.CR.BLOCK.POS NE '' AND R.SOFT.BLOCKS NE '' THEN

        R.SOFT.BLOCKS<JHXS.VALUE.DATE> = Y.DEBIT.VALDATE

        GOSUB PROCESS.MA.BP.BLOCKS
        CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW,R.SOFT.BLOCKS)
    END

    IF Y.CR.BLOCK.POS NE '' AND  R.SOFT.BLOCKS EQ '' THEN
        GOSUB GET.CUSTOMER.PORTFOLIO.SOFT.BLOCK.DETAILS
        Y.TRANSACTION.ID = ID.NEW
        R.SOFT.BLOCKS<JHXS.APPLICATION> = APPLICATION

        R.SOFT.BLOCKS<JHXS.ISIN.IDENTIFIER> = ''
        R.SOFT.BLOCKS<JHXS.TRADE.DATE> = TODAY
        R.SOFT.BLOCKS<JHXS.VALUE.DATE> = Y.DEBIT.VALDATE
        IF Y.DONE.DEAL EQ 'Y' THEN
            R.SOFT.BLOCKS<JHXS.DONE.DEAL> = 'Y'
        END
        GOSUB PROCESS.MA.BP.BLOCKS
        COMMON.V.SAVE = V
        V = JHXS.AUDIT.DATE.TIME
        Y.CO.CODE.POS = V-3
        Y.SAVE = R.NEW(Y.CO.CODE.POS)
        CALL S.UPDATE.AUDIT.FIELDS(R.SOFT.BLOCKS)
        R.NEW(Y.CO.CODE.POS) = Y.SAVE
        V = COMMON.V.SAVE

        CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK,Y.TRANSACTION.ID,R.SOFT.BLOCKS)

    END

RETURN

EXTRACT.DETAILS.FOR.DAO:
***********************
    Y.PORTFOLIO.ID = Y.PORTFOLIO
    CALL F.READ(FN.JBWW.H.EB.BLOCKTAGDETS,Y.PORTFOLIO.ID,R.BLOCKTAGDETS,F.JBWW.H.EB.BLOCKTAGDETS,'')
    IF R.BLOCKTAGDETS THEN
        Y.TAG.IDS = R.BLOCKTAGDETS<BTD.TAG.ID>
        Y.BLOCK.OWNER = R.BLOCKTAGDETS<BTD.OWNER>
        Y.TAG.CNT = DCOUNT(Y.TAG.IDS,VM)
        I = 0
        LOOP
            I = I + 1
        WHILE I LE Y.TAG.CNT
            Y.TAG.BLOCKIDS = ''
            Y.TAG.ID = Y.TAG.IDS<1,I>
            Y.TAG.BLK.OWNER = Y.BLOCK.OWNER<1,I>
            Y.TAG.BLOCKIDS = R.BLOCKTAGDETS<BTD.BLOCK.ID,I>
            CHANGE SM TO FM IN Y.TAG.BLOCKIDS
            Y.TAG.BLOCKIDS.CNT = DCOUNT(Y.TAG.BLOCKIDS,FM)
            J = 0
            LOOP
                J = J + 1
            WHILE J LE Y.TAG.BLOCKIDS.CNT
                Y.TAG.OVERRIDE = Y.TAG.BLOCKIDS<J>
                Y.TAG.OVE.POS = ''
                FIND Y.TAG.OVERRIDE IN Y.OVER.ID.ARR SETTING Y.TAG.OVE.POS ELSE Y.TAG.OVE.POS = ''
                IF Y.TAG.OVE.POS THEN
                    IF Y.TAG.ID NE Y.LAST.TAG THEN
                        Y.LAST.TAG = Y.TAG.ID
                        Y.TAG.ID.ARR<-1> = Y.LAST.TAG
                        Y.OWNER<-1> = Y.TAG.BLK.OWNER
                    END
                    Y.TAG.NOTES<-1> = R.BLOCKTAGDETS<BTD.NOTES,I,J>
                    Y.OVE.ID = Y.TAG.OVERRIDE
                    GOSUB READ.OVERRIDE
                    Y.TAG.MESSAGE<-1> = R.OVERRIDE<EB.OR.MESSAGE,1>
                    IF Y.OVE.ID[1,2] EQ 'HB' THEN
                        Y.HARD.BLOCK.ID = Y.OVE.ID
                        GOSUB READ.EB.ERROR
                        Y.TAG.MESSAGE<-1> = Y.MSG.VAL
                    END
                END
            REPEAT
        REPEAT
    END
    IF R.BLOCKTAGDETS EQ '' THEN
        GOSUB EXTRACT.TAG.DETAILS
    END
RETURN

EXTRACT.TAG.DETAILS:
********************
    Y.SAM.ID = Y.PORTFOLIO
    GOSUB READ.SAM
    Y.TAG.ID.ARR = R.SAM.REC<SC.SAM.LOCAL.REF,Y.TAG.ID.POS>
    CHANGE SM TO VM IN Y.TAG.ID.ARR
    CHANGE VM TO FM IN Y.TAG.ID.ARR
    Y.TAG.MESSAGE = Y.TAGMESSAGE.VALUES
    Y.OWNER = Y.TAGOWNER.VALUES
RETURN

CREDIT.CONSTRAINTS:
**************************
    IF Y.SLBK.FLAG EQ '' AND Y.DR.CUST.PORT.FLAG EQ '' THEN
        Y.CR.AC.NO = R.NEW(PO.CREDIT.ACCOUNT)
        Y.ACCT.NO = Y.CR.AC.NO
        GOSUB READ.AC
        Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
        Y.SAM.ID = Y.PORTFOLIO<1,1>

        IF Y.SAM.ID EQ '' THEN
            GOSUB READ.SC.INC.ACCOUNT
        END

        GOSUB READ.SAM
        IF R.SAM.REC NE '' THEN
            IF Y.TAG.BLK.IDS NE '' THEN
                Y.SEC.ACCNT = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
                Y.CUSTOMER.ID = FIELD(Y.SAM.ID,'-',1)
                GOSUB FETCH.CUSTOMER.DETAILS
            END
        END
    END

RETURN
GET.TRANSACTION.MAIL.DETAILS:
*****************************
    Y.MAIL.TRANS.CODE = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    Y.MAIL.NO.NOMINAL = ''
    Y.MAIL.SET.CCY = R.NEW(PO.DEBIT.CCY)
	Y.PAY.AMT = ''
    GOSUB GET.PAYMENT.AMOUNT
    Y.MAIL.TRANS.AMT = Y.PAY.AMT
    Y.MAIL.TRANS.AMT = Y.MAIL.TRANS.AMT
    Y.MAIL.SECURITY.NO = ''
    Y.MAIL.TRADE.DATE = TODAY
    Y.MAIL.TRADE.DATE = OCONV(ICONV(Y.MAIL.TRADE.DATE,"D2E"),"D4E")
    Y.MAIL.VALUE.DATE =  Y.DEBIT.VALDATE
    Y.MAIL.VALUE.DATE = OCONV(ICONV(Y.MAIL.VALUE.DATE,"D2E"),"D4E")
    CHANGE VM TO SM IN Y.MAIL.TRANS.CODE
    CHANGE VM TO SM IN Y.MAIL.NO.NOMINAL
    CHANGE VM TO SM IN Y.MAIL.SET.CCY
    CHANGE VM TO SM IN Y.MAIL.TRANS.AMT
    CHANGE FM TO SM IN Y.MAIL.SECURITY.NO
    CHANGE FM TO SM IN Y.MAIL.TRADE.DATE
    CHANGE FM TO SM IN Y.MAIL.VALUE.DATE

RETURN

MA.CC.SB.MAIL.MSG.DETAILS:
***********************
    IF Y.CH.TYPE EQ 'CC' THEN
        Y.BP.CHKTYPE<-1> = Y.CH.TYPE
        Y.BP.SB.ID<-1> = Y.MSG.ID
        Y.BP.MESSAGE<-1> = Y.MSG.VAL
    END
    IF Y.CH.TYPE EQ 'MA' THEN
        Y.MA.CHKTYPE<-1> = Y.CH.TYPE
        Y.MA.SB.ID<-1> = Y.MSG.ID
        Y.MA.MESSAGE<-1> = Y.MSG.VAL
    END

RETURN
MA.CC.HB.MAIL.MSG.DETAILS:
**************************
    IF Y.CH.TYPE EQ 'CC' THEN
        Y.BP.HB.CHKTYPE<-1> = Y.CH.TYPE
        Y.BP.HB.SB.ID<-1> = Y.MSG.ID
        Y.BP.HB.MESSAGE<-1> = Y.MSG.VAL
    END

    IF Y.CH.TYPE EQ 'MA' THEN
        Y.MA.HB.CHKTYPE<-1> = Y.CH.TYPE
        Y.MA.HB.SB.ID<-1> = Y.MSG.ID
        Y.MA.HB.MESSAGE<-1> = Y.MSG.VAL
    END

RETURN

TRIGGER.EMAIL:
*************
* Email Trigger Alert will be handled separately for TPH.

*    CALL JBWW.R.XX.NOTIFICATION.UPDATE(TYPE,ENTITY.TYPE,ENTITY.ID,Y.NAME,Y.VALUE,UID,'',RETVAR,'','')  ;*CBPAY-838
RETURN

*RAISE.OFS.PAY.PORTAL:
*********************

*    OFS.APP.NAME  = 'PAYMENT.ORDER'
*    OFS.INPUT.FUN = 'A'
*    OFS.PROCESS   = 'PROCESS'
*    OFS.VERSION   = 'PAYMENT.ORDER,JB.V.PP.RLCVD.AUTH'
*    OFS.GTS.MODE  = ''
*    OFS.NO.AUTH   = ''
*    TRANSACTION.ID = ID.NEW
*    CALL OFS.BUILD.RECORD(OFS.APP.NAME,OFS.INPUT.FUN,OFS.PROCESS,OFS.VERSION,OFS.GTS.MODE,OFS.NO.AUTH,TRANSACTION.ID,R.FT,OFS.RESPONSE)

*    OFS.MSG.ID = ''
*    OPTION = ''
*    OFS.SRC = 'JBWW.D.XX.RLSOFTBLK'
*    OPTION = 'AUTHORISER'
*    CALL OFS.POST.MESSAGE(OFS.RESPONSE,OFS.MSG.ID,OFS.SRC,OPTION)

*RETURN

* CBPAY-1841 To Avoid payment to place in IHLD status
GET.PAYMENT.AMOUNT:

    BEGIN CASE
        CASE (R.NEW(PO.DEBIT.AMOUNT) NE '') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0.00') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0')
            Y.PAY.AMT = R.NEW(PO.DEBIT.AMOUNT)
        CASE R.NEW(PO.PAYMENT.AMOUNT) NE ''
            Y.PAY.AMT = R.NEW(PO.PAYMENT.AMOUNT)
    END CASE
RETURN
* CBPAY-1841
