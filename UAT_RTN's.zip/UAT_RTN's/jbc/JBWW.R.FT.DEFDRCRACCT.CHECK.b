* @ValidationCode : MTo1NDc1MTAxODI6SVNPLTg4NTktMToxNTE4MDg5NDg1NTMwOmEzODI5MTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 08 Feb 2018 19:31:25
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38291
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0

    SUBROUTINE JBWW.R.FT.DEFDRCRACCT.CHECK
*------------------------------------------------------------------------------------------------------------------------------------
*
*** <region name= Description>
*** <desc>Task of the sub-routine</desc>
*
*Development Details:
*-------------------*
*
* Company Name : Bank Julius Baer
* Developed by : Venkat.S
* Development  : OTC Equity Options
* Project Code : P2955
*
*Program Description:
*-------------------*
* T24 Version Check routine to default the Debit / Credit Account.  
*             
*                                            
*              
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name = Modification History>
*** <desc>Modification Summary</desc>
*
* Modification History:
*---------------------*
*Date          By                  Project / Dev / Bug Ref.              Comments
*2017-Mar-22   Venkat.S            JB2A-28983                            Get Nostro Account for the counterparty trades from the NOSTRO.ACCOUNT instead of reading from CUSTOMER.ACCOUNT.
*
*05-Oct-2017   Venkat.S            JB2A-43077                            For the Counterparty Trade the Profit Cust Centre should be the Counterparty.
*
*2018-Jan-17   S.Venkat            JB2A-47582                            Changed the nostro account default logic by calling T24 Core API to get the nostro account based on effective date.
*
*2018-Feb-08   S.Venkat            JB2A-47980                            FT Transaction Type "ACOP" default CR for FT raised for Premium Posting.
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Inserts>
*** <desc>Inclue the required Libraries</desc>
*------------------------------------------------------------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_GTS.COMMON
	$INSERT I_F.ACCOUNT
	$INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.JBWW.H.XX.MARKETSPARAM
	$INSERT I_F.JBWW.H.XX.MKTERR.LOG
*-----------------------------------------------------------------------------
    
    IF OFS$BROWSER EQ '0' OR OFS$BROWSER EQ '' THEN
        GOSUB INIT.AND.OPEN
*JB2A-47980 - Start        
        GOSUB DEF.FT.TXN.TYPE
*JB2A-47980 - End        
        GOSUB DEFAULT.FT.ACCOUNTS
    END
    
    RETURN

*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Inserts>
*** <desc>Inclue the required Libraries</desc>
*------------------------------------------------------------------------------------------------------------------------------------
    
INIT.AND.OPEN:
    
    INCOMING.REQUEST = OFS$PARENT.REQ
    
    FN.JBWW.H.XX.MARKETSPARAM = 'F.JBWW.H.XX.MARKETSPARAM'
    F.JBWW.H.XX.MARKETSPARAM = ''
    CALL OPF(FN.JBWW.H.XX.MARKETSPARAM,F.JBWW.H.XX.MARKETSPARAM)
    
    CALL CACHE.READ(FN.JBWW.H.XX.MARKETSPARAM,'OTC.EQUITY',R.MKT.PARAM,PARAM.ERR)
    
    IF PARAM.ERR THEN
        AF = FT.DEBIT.ACCT.NO
        ETEXT = 'EB-JBWW.D.XX.PARAM.CHK':FM:'OTC.EQUITY'
        CALL STORE.END.ERROR
    END
    
    OTC.PROP.DR.CATEG = 'PL':R.MKT.PARAM<MKT.PARAM.OTC.DR.PLCATEG>
    OTC.PROP.CR.CATEG = 'PL':R.MKT.PARAM<MKT.PARAM.OTC.CR.PLCATEG>
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    FN.MNEMONIC.CUSTOMER = 'F.MNEMONIC.CUSTOMER'
    F.MNEMONIC.CUSTOMER = ''
    CALL OPF(FN.MNEMONIC.CUSTOMER,F.MNEMONIC.CUSTOMER)
    
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    
    FN.JBWW.OTC.ALT.INDEX = 'F.JBWW.OTC.ALT.INDEX'
    F.JBWW.OTC.ALT.INDEX = ''
    CALL OPF(FN.JBWW.OTC.ALT.INDEX,F.JBWW.OTC.ALT.INDEX)
    
    FN.JBWW.H.XX.MKTERR.LOG = 'F.JBWW.H.XX.MKTERR.LOG'
    F.JBWW.H.XX.MKTERR.LOG = ''
    CALL OPF(FN.JBWW.H.XX.MKTERR.LOG,F.JBWW.H.XX.MKTERR.LOG)
    
    RETURN
    
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= DEF.FT.TXN.TYPE>
*** <desc>Default FT Txn Type Condition.</desc>
*------------------------------------------------------------------------------------------------------------------------------------
DEF.FT.TXN.TYPE:
    
    DX.REFERENCE = FIELD(FIELD(FIELD(OFS$PARENT.REQ,'L.XX.FO.REF',2),'=',2),',',1)

    IF DX.REFERENCE ELSE
        RETURN
    END

    ALT.INDEX.ID = 'ARENAREF.':DX.REFERENCE
    
    CALL F.READ(FN.JBWW.OTC.ALT.INDEX,ALT.INDEX.ID,R.RECORD.ARR,F.JBWW.OTC.ALT.INDEX,ERR.INDEX)
    
    IF R.RECORD.ARR EQ '' THEN
        RETURN
    END
    
    T24.DX.TRD.ID = R.RECORD.ARR<1>
    MKT.LOG.ID = 'DX.TRADE-':T24.DX.TRD.ID:'-I'
    CALL F.READ(FN.JBWW.H.XX.MKTERR.LOG,MKT.LOG.ID,R.LOG.ARR,F.JBWW.H.XX.MKTERR.LOG,ERR.MKT.LOG) 
    GET.TRADE.MSG = R.LOG.ARR<MKT.ERR.REQ.MSG>
    
    GET.TRADE.FO.REF = FIELD(FIELD(FIELD(GET.TRADE.MSG,'L.XX.FO.REF',2),'=',2),',',1)
    CHANGE "'" TO '' IN GET.TRADE.FO.REF
    CHANGE '"' TO '' IN GET.TRADE.FO.REF
    
    IF GET.TRADE.FO.REF EQ 'NEW_OTC_OPTION' THEN
        R.NEW(FT.TRANSACTION.TYPE) = 'ACOP'
    END
    
    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= DEFAULT.FT.ACCOUNTS>
*** <desc>Default FT Accounts.</desc>
*------------------------------------------------------------------------------------------------------------------------------------
    
DEFAULT.FT.ACCOUNTS:
    
    CPARTY.FLAG = ''
    
    GET.CR.DATE = FIELD(INCOMING.REQUEST,'CREDIT.VALUE.DATE',2)
    GET.CR.DATE = FIELD(GET.CR.DATE,'=',2)
    GET.CR.DATE = FIELD(GET.CR.DATE,',',1)
    
    CHANGE '"' TO '' IN GET.CR.DATE
    CHANGE "'" TO "'" IN GET.CR.DATE
    
    R.NEW(FT.DEBIT.VALUE.DATE) = GET.CR.DATE
    
    GET.FO.CPARTY = FIELD(INCOMING.REQUEST,'L.XX.FO.CPARTY',2)
    GET.FO.CPARTY = FIELD(GET.FO.CPARTY,'=',2)
    GET.FO.CPARTY = FIELD(GET.FO.CPARTY,',',1)
    
    CHANGE '"' TO '' IN GET.FO.CPARTY
    CHANGE "'" TO "'" IN GET.FO.CPARTY
    
*    IF GET.FO.CPARTY[1,1] EQ 'C' THEN
    IF GET.FO.CPARTY[1,2] NE ID.COMPANY[1,2] THEN
        CALL F.READ(FN.MNEMONIC.CUSTOMER,GET.FO.CPARTY,R.MNE.CUST,F.MNEMONIC.CUSTOMER,ERR.MNE.CUST)
	    IF R.MNE.CUST THEN
	        GET.FO.CPARTY = R.MNE.CUST<1>
	    END ELSE
	        AF = FT.TRANSACTION.TYPE
	        ETEXT = 'EB-JBWW.D.FT.CUSTID.CHK':FM:GET.FO.CPARTY
	        CALL STORE.END.ERROR
	        RETURN
	    END
	    CPARTY.FLAG = '1'
    END
    
    GET.FO.PREMIUM = FIELD(INCOMING.REQUEST,'L.XX.FO.PREMIUM',2)
    GET.FO.PREMIUM = FIELD(GET.FO.PREMIUM,'=',2)
    GET.FO.PREMIUM = FIELD(GET.FO.PREMIUM,',',1)
    
    GET.DR.CCY = FIELD(INCOMING.REQUEST,'DEBIT.CURRENCY',2)
    GET.DR.CCY = FIELD(GET.DR.CCY,'=',2)
    GET.DR.CCY = FIELD(GET.DR.CCY,',',1)
    
    GET.CR.CCY = FIELD(INCOMING.REQUEST,'CREDIT.CURRENCY',2)
    GET.CR.CCY = FIELD(GET.CR.CCY,'=',2) 
    GET.CR.CCY = FIELD(GET.CR.CCY,',',1)
    
    CHANGE '"' TO '' IN GET.FO.PREMIUM
    CHANGE "'" TO "'" IN GET.FO.PREMIUM
    
    CHANGE '"' TO '' IN GET.DR.CCY
    CHANGE "'" TO "'" IN GET.DR.CCY
    
    CHANGE '"' TO '' IN GET.CR.CCY
    CHANGE "'" TO "'" IN GET.CR.CCY
    
            
    IF GET.FO.PREMIUM GT 0 THEN
        AF = FT.DEBIT.ACCT.NO
        ACCT.CCY = GET.DR.CCY
        CUST.ID = GET.FO.CPARTY
        IF CPARTY.FLAG EQ '' THEN 
            GOSUB GET.ACCT.FROM.SAM
        END ELSE
*JB2A-43077 - Start        
            R.NEW(FT.PROFIT.CENTRE.CUST) = CUST.ID
*JB2A-43077 - End            
            GOSUB FIND.ACCT.ID
        END
        R.NEW(FT.DEBIT.ACCT.NO) = ASSIGN.ACCT.ID
        
        R.NEW(FT.CREDIT.ACCT.NO) = OTC.PROP.CR.CATEG
    END ELSE
        AF = FT.CREDIT.ACCT.NO
        ACCT.CCY = GET.CR.CCY
        CUST.ID = GET.FO.CPARTY
        IF CPARTY.FLAG EQ '' THEN 
            GOSUB GET.ACCT.FROM.SAM
* To be removed - start            
*            R.NEW(FT.ORDERING.BANK) = 'BJB'
*            R.NEW(FT.PROFIT.CENTRE.DEPT) = '1'
* To be removed - end           
        END ELSE
            GOSUB FIND.ACCT.ID
            R.NEW(FT.PROFIT.CENTRE.CUST) = CUST.ID
* To be removed - start            
*            R.NEW(FT.ORDERING.BANK) = 'BJB'
*            R.NEW(FT.PROFIT.CENTRE.DEPT) = '1'
* To be removed - end
        END
        
        R.NEW(FT.CREDIT.ACCT.NO) = ASSIGN.ACCT.ID 
        
        R.NEW(FT.DEBIT.ACCT.NO) = OTC.PROP.DR.CATEG
    END
                
    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Get Cash Account From SAM>
*** <desc>Default FT Accounts.</desc>
*------------------------------------------------------------------------------------------------------------------------------------
   
GET.ACCT.FROM.SAM:
    
    FN.SEC.ACC.MASTER.ACCOUNT.NAME = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ACCOUNT.NAME = ''
    CALL OPF(FN.SEC.ACC.MASTER.ACCOUNT.NAME,F.SEC.ACC.MASTER.ACCOUNT.NAME)

* Read the alternate key from the concat table and assign it to COMI.
    
    CALL F.READ(FN.SEC.ACC.MASTER.ACCOUNT.NAME,CUST.ID,R.ALT.PORTFOLIO,F.SEC.ACC.MASTER.ACCOUNT.NAME,ERR.CODE)
    IF R.ALT.PORTFOLIO NE '' THEN 
        CUST.ID = FIELD(R.ALT.PORTFOLIO<1>,'*',2)
    END ELSE
        ETEXT = 'EB-JBWW.D.FT.ACCTCCY.CHK':FM:CUST.ID:VM:ACCT.CCY
        CALL STORE.END.ERROR
    END 
    
    CALL F.READ(FN.SEC.ACC.MASTER,CUST.ID,R.SAM.ARRAY,F.SEC.ACC.MASTER,ERR.SEC.ARR)
    
    GET.SAM.ACCT.CCY = R.SAM.ARRAY<SC.SAM.ACCOUNT.CCY>
    GET.SAM.ACCT.NOS = R.SAM.ARRAY<SC.SAM.ACCOUNT.NOS>
    
    LOCATE ACCT.CCY IN GET.SAM.ACCT.CCY<1,1> SETTING SAM.ACT.POS THEN
        ASSIGN.ACCT.ID = GET.SAM.ACCT.NOS<1,SAM.ACT.POS>                
    END ELSE
        ETEXT = 'EB-JBWW.D.FT.ACCTCCY.CHK':FM:CUST.ID:VM:ACCT.CCY
        CALL STORE.END.ERROR
    END
    
    RETURN
    
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Get CParty Nostro Account>
*** <desc>Default FT Accounts.</desc>
*------------------------------------------------------------------------------------------------------------------------------------
     
FIND.ACCT.ID:
    
    ASSIGN.ACCT.ID = ''

*JB2A-28983 - Start. Get Nostro Account for the counterparty trades from the NOSTRO.ACCOUNT instead of reading from CUSTOMER.ACCOUNT.   
*JB2A-47582 - Start    
*Removed the existing logic to read the Nostro Account table.
*Replaced with below by calling wrapper routine which will internally use T24 Core api to get the nostro account based on effective date.    
     
    PRODUCT.CODE = 'DX'
    ERROR.CODE = ''
    ACCT.ID = ''
    TRADE.VALUE.DATE = GET.CR.DATE
    PREM.CCY.ID = ACCT.CCY
    
    IF TRADE.VALUE.DATE LT TODAY THEN
        TRADE.VALUE.DATE = TODAY
    END
    
    CALL JBWW.R.XX.GETNOSTROACCT.CALL(PRODUCT.CODE,PREM.CCY.ID,TRADE.VALUE.DATE,ACCT.ID,ERROR.CODE)
    
    ASSIGN.ACCT.ID = ACCT.ID
*JB2A-47582 - End  
    
*JB2A-28983 - End.    
    RETURN
    
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------

END