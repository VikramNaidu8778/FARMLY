*-----------------------------------------------------------------------------
* <Rating>-42</Rating>
*-----------------------------------------------------------------------------
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.B.TRANS.CRM.FT.OPT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*22/06/2017 : changed ZEROCHG TO ZEROCHG4 as per Guomeng suggestion
*15/09/2017 : changed in GOSUB UPDATE.NEW.FTCOM.ID - JIRA - 41845 - dependency for JBSO.B.OLY.BRKRFEE routine
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------

    GOSUB INITIALIZE
    RETURN

*-----------------------------------------------------------------------------
INITIALIZE:
*-----------------------------------------------------------------------------
    Y.COMP = ID.COMPANY[1,2]

    Y.T24.FILE = Y.COMP:'-BRKRFEE.csv'
    Y.FTCRM.FILE = Y.COMP:'-FTCRM.csv'
    Y.TRANS.FILE = Y.COMP:'-CRMBRKFEE.csv'

    GOSUB OPENFILES
    GOSUB OPENSEQFILE
    GOSUB PROCESS
    GOSUB WRITE.T24FTCOM.FILE
    GOSUB CLOSESEQFILE

    RETURN

*-----------------------------------------------------------------------------
OPENFILES:
*-----------------------------------------------------------------------------
    FN.VOC = 'VOC'
    F.VOC =''
    CALL OPF(FN.VOC,F.VOC)

    CALL F.READ(FN.VOC,'JBSHMIG', R.VOC, F.VOC, Y.ERR)

    Y.BASE.PATH = R.VOC<2>


    IF Y.COMP EQ 'SG' THEN
        *FN.FILE.DIR = "./JBSHTRAN.T24/SGPRICING"
        FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHTRAN.T24/SGPRICING'
        OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
            ERRFLAG = 1
        END
    END

    IF Y.COMP EQ 'HK' THEN
        FN.FILE.DIR = Y.BASE.PATH:'/':'JBSHTRAN.T24/HKPRICING'
        *FN.FILE.DIR = "./JBSHTRAN.T24/HKPRICING"
        OPEN FN.FILE.DIR TO F.FILE.DIR ELSE
            ERRFLAG = 1
        END
    END
    RETURN

*-----------------------------------------------------------------------------
OPENSEQFILE:
*-----------------------------------------------------------------------------
    IF Y.COMP EQ 'SG' THEN
        Y.TRANSDIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/SGPRICING'
        *Y.TRANSDIR.NAME = "./JBSHTRAN.T24/SGPRICING"
    END
    IF Y.COMP EQ 'HK' THEN
        Y.TRANSDIR.NAME = Y.BASE.PATH:'/':'JBSHTRAN.T24/HKPRICING'
        *Y.TRANSDIR.NAME = "./JBSHTRAN.T24/HKPRICING"
    END

    DELETESEQ Y.TRANSDIR.NAME,Y.TRANS.FILE THEN
    END

    OPENSEQ Y.TRANSDIR.NAME,Y.TRANS.FILE TO Y.TRANS.POINTER ELSE
        CREATE Y.TRANS.POINTER ELSE
        RETURN
    END
    END
    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------

    READ R.REC FROM F.FILE.DIR,Y.T24.FILE THEN
        LOOP
            REMOVE SEQ.REC FROM R.REC SETTING Y.POS
            GOSUB ASSIGN.NULL.VALUES

        WHILE SEQ.REC:Y.POS
            Y.CRM.VAL = SEQ.REC<1>
            Y.CRM.ID = FIELD(Y.CRM.VAL,',',1)
            Y.TRADE.ACT = FIELD(Y.CRM.VAL,',',2)
            Y.TRANS.TYPE = FIELD(Y.CRM.VAL,',',3)
            Y.TRADE.TYPE = FIELD(Y.CRM.VAL,',',4)
            Y.ASSET.TYPE = FIELD(Y.CRM.VAL,',',5)
            Y.GEO.BLOCK = FIELD(Y.CRM.VAL,',',6)
            Y.FT.COMM = FIELD(Y.CRM.VAL,',',7)
            Y.PERCENT = FIELD(Y.CRM.VAL,',',8)

            GOSUB GET.NEW.FTCOM.ID
            GOSUB UPDATE.NEW.FTCOM.ID
            Y.FINAL.ARRAY.TEMP<-1> = Y.CRM.ID:',':Y.TRADE.ACT:',':Y.TRANS.TYPE:',':Y.TRADE.TYPE:',':Y.ASSET.TYPE:',':Y.GEO.BLOCK:',':Y.FINAL.FTCOM:',':Y.PERCENT
        REPEAT
    END
    Y.HEADER = 'Id':',':'Trade activity':',':'Trans type':',':'Trade type':',':'Asset type':',':'Geo block':',':'Ft Comm code':',':'Percentage'
    Y.FINAL.ARRAY = Y.HEADER:FM:Y.FINAL.ARRAY.TEMP

    RETURN
*-----------------------------------------------------------------------------
ASSIGN.NULL.VALUES:
*-----------------------------------------------------------------------------

    Y.CRM.VAL = ''; Y.CRM.ID = ''; Y.TRADE.ACT = ''; Y.TRANS.TYPE = ''
    Y.TRADE.TYPE = '';  Y.ASSET.TYPE = ''; Y.GEO.BLOCK = ''; Y.FT.COMM = ''; Y.PERCENT = ''
    Y.FTCOMM.ID = '' ; Y.NEW.FT.ID = ''; Y.FTCRM.VAL = ''

    RETURN
*-----------------------------------------------------------------------------
GET.NEW.FTCOM.ID:
*-----------------------------------------------------------------------------
    READ R.FTCRM.REC FROM F.FILE.DIR,Y.FTCRM.FILE THEN
    END
    LOOP

        REMOVE FTCRM.REC FROM R.FTCRM.REC SETTING Y.FTCRM.POS

    WHILE FTCRM.REC:Y.FTCRM.POS

        Y.FTCRM.VAL = FTCRM.REC<1>
        Y.FTCOMM.ID<-1> = FIELD(Y.FTCRM.VAL,',',1)
        Y.NEW.FT.ID<-1> = FIELD(Y.FTCRM.VAL,',',2)

    REPEAT
    RETURN
*-----------------------------------------------------------------------------
UPDATE.NEW.FTCOM.ID:
*-----------------------------------------------------------------------------

    Y.FT.COMM.TEMP = ''
    Y.FINAL.FTCOM = ''
    Y.B.TEMP = ''
    Y.FT.COMM.TEMP = Y.FT.COMM

    Y.VM.CNT = DCOUNT(Y.FT.COMM.TEMP,'::')

    IF Y.CRM.ID EQ '029' OR Y.CRM.ID EQ '230' THEN
        *Y.VM = 1
		 Y.VM = 2                     ;*15/09/2017 - JIRA -41845
    END ELSE
        *Y.VM = 2
		 Y.VM = 3                     ;*15/09/2017 - JIRA -41845
    END

    LOOP
    WHILE Y.VM LE Y.VM.CNT

        Y.FTCOM.VM = FIELD(Y.FT.COMM.TEMP,'::',Y.VM)

        Y.SM.CNT = DCOUNT(Y.FTCOM.VM,'!!')
        Y.SM = 1
        LOOP
        WHILE Y.SM LE Y.SM.CNT
            Y.FTCOM.SM = FIELD(Y.FTCOM.VM,'!!',Y.SM)
            *IF Y.FTCOM.SM NE 'ZEROCHG' THEN
			IF Y.FTCOM.SM NE 'ZEROCHG4' THEN
                LOCATE Y.FTCOM.SM IN Y.FTCOMM.ID SETTING Y.SM.POS THEN
                Y.A = Y.NEW.FT.ID<Y.SM.POS>
                Y.B<-1> = Y.A
            END

        END ELSE
            Y.B<-1> = Y.FTCOM.SM
        END
        Y.SM = Y.SM + 1
    REPEAT
    CHANGE FM TO '!!' IN Y.B
    Y.B.TEMP<-1> = Y.B
    Y.B = ''
    Y.VM = Y.VM + 1
    REPEAT
    CHANGE FM TO '::' IN Y.B.TEMP

    IF Y.CRM.ID EQ '230' OR Y.CRM.ID EQ '029' THEN
        *Y.FINAL.FTCOM<-1> = Y.B.TEMP
		 Y.FINAL.FTCOM<-1> = 'ZEROCHG4::':Y.B.TEMP                        ;*15/09/2017 - JIRA -41845
    END ELSE
        *Y.FINAL.FTCOM<-1> = 'ZEROCHG::':Y.B.TEMP
		*Y.FINAL.FTCOM<-1> = 'ZEROCHG4::':Y.B.TEMP
		 Y.FINAL.FTCOM<-1> = 'ZEROCHG4::':'ZEROCHG4::':Y.B.TEMP           ;*15/09/2017 - JIRA -41845
    END
    CHANGE FM TO ',' IN Y.FINAL.FTCOM
    RETURN
*-----------------------------------------------------------------------------
WRITE.T24FTCOM.FILE:
*-----------------------------------------------------------------------------
    CHANGE FM TO CHARX(10) IN Y.FINAL.ARRAY
    WRITESEQ Y.FINAL.ARRAY APPEND TO Y.TRANS.POINTER THEN
    END

    RETURN
*-----------------------------------------------------------------------------
CLOSESEQFILE:
*-----------------------------------------------------------------------------

    CLOSESEQ Y.TRANS.POINTER

    RETURN

    END
