SUBROUTINE JB.R.PP.BACKOFFREMARKS.AUTO
*-----------------------------------------------------------------------------
* Description : Routine to clear / Delete the Existing Multi Value in L.PP.BO.USRCOM so that user can input new comments
*               Upon Opening the record for amendment , the field will be Null.
* Attached to : All Versions of PAYMENT.ORDER & PP.ORDER.ENTRY
* Attached as : Check Rec Routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 30-May-2024   CTS                                    CBPAY_20_38_40
*
* 24-Feb-2025   P Amala                                CBPAY-1014
*
* 26-03-2025         Prabhu D S           CBPAY-1616        Default CVD as DVD for Incoming pacs.004 incase DVD is null
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY

    GOSUB INIT
    GOSUB PROCESS

RETURN
*----
INIT:
*----

    BEGIN CASE
    
        CASE APPLICATION EQ 'PAYMENT.ORDER'
            APPL = '' ; Y.POS = ''  ; LREF.FLD = ''
            Y.L.PP.BO.USRCOM.POS = '' ; Y.LOC.FLD.VAR = '' ; Y.L.PP.BP.HISTCOM.POS = ''
            APPL = 'PAYMENT.ORDER'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PO.LOCAL.REF
    
        CASE APPLICATION EQ 'PP.ORDER.ENTRY'
            APPL = '' ; Y.POS = ''  ; LREF.FLD = ''
            Y.L.PP.BO.USRCOM.POS = '' ; Y.LOC.FLD.VAR = '' ; Y.L.PP.BP.HISTCOM.POS = ''
            APPL = 'PP.ORDER.ENTRY'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PP.OEYG.LOCAL.REF
    
    END CASE

RETURN
*-------
PROCESS:
*-------
*
    YFLD = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS>
    YFLD1 = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
	
    IF YFLD EQ '' THEN
        R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS> = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
    END ELSE
	
        IF YFLD1 THEN
            R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS,-1> = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
        END
    END

    Y.USER.CMT = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
    Y.CNT = DCOUNT(Y.USER.CMT,SM)

    Y.CHK1 = R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,1>
    IF Y.CHK1 THEN
        R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,1> = ''
*   R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,1> = ''
    END

    IF Y.CNT GE '2' THEN
        FOR Y.LOOP.CNT = Y.CNT TO 2 STEP -1
            R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,Y.LOOP.CNT> = ''
            DEL R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,Y.LOOP.CNT>     ; *Delete should happen from Reverse Order.
            DEL R.NEW.LAST(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS,Y.LOOP.CNT>
        NEXT
    END
* For Incoming pacs.004, Debit Value Date is not empty and it is not allowed to commit the transaction
* so defaulting CVD as DVD
    IF APPLICATION EQ 'PP.ORDER.ENTRY' THEN
       IF R.NEW(PP.OEYG.CreditValueDate) NE '' AND R.NEW(PP.OEYG.DebitValueDate) EQ '' THEN
          R.NEW(PP.OEYG.DebitValueDate) = R.NEW(PP.OEYG.CreditValueDate)
       END
    END


RETURN
*-----------------------------------------------------------------------------
END
