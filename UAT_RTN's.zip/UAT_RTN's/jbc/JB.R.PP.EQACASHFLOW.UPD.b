*-----------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.EQACASHFLOW.UPD
*-----------------------------------------------------------------------------------
* Description:
* The purpose of the routine is to update the Payment amount in local table
* JB.L.PP.CASHFLOWDATA which will be used for Cash Flow Report.
* Input routine attached in version control EB.QUERIES.ANSWERS.
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date                Developer           Reference           Description
*-----------------------------------------------------------------------------------
* 10/05/2025         P Amala              CBPAY-65          Initial Version
*-----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.EB.QUERIES.ANSWERS
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.JB.L.PP.CASHFLOWDATA
    $INSERT I_F.JBWW.H.AC.NOSTCASHFLOW
    $USING PP.PaymentWorkflowDASService

*------------------------------------------------------------------------------

    IF R.NEW(EB.QA.DIRECTION) EQ 'OUTWARD' AND R.NEW(EB.QA.ISO.MSG.TYPE) EQ 'camt.056' THEN
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END
	
RETURN

*------------------------------------------------------------------------------
OPEN.FILES:
**********
       
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA)
    
    FN.AC.NOSTROCASHFLOW = 'F.JBWW.H.AC.NOSTCASHFLOW'
    F.AC.NOSTROCASHFLOW = ''
    CALL OPF(FN.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW)
	
    F.EB.QUERIES.ANSWERS = ''
    FN.EB.QUERIES.ANSWERS = 'F.EB.QUERIES.ANSWERS'
    CALL OPF(FN.EB.QUERIES.ANSWERS,F.EB.QUERIES.ANSWERS)
	
    F.POR.TRANSACTION = ''
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
    
    R.AC.NOSTROCASHFLOW = '' ; ERR.AC.NOSTROCASHFLOW = ''
    NST.ACCT.TEMP = '' ; Y.PP.ID = '' ; R.PP.CASHFLOWDATA = ''
    Y.PP.EXCDATE = '' ; DB.ACCT.POS = '' ; CR.ACCT.POS = ''
    Y.CR.AC.NO = '' ; Y.DB.AC.NO = '' ; Y.PP.CSHFLW.ERR = ''
    R.POR.TRANSACTION = ''
	
    POR.TRAN.ID = R.NEW(EB.QA.ORIG.FT.NUMBER)
    CALL F.READ(FN.POR.TRANSACTION,POR.TRAN.ID,R.POR.TRANSACTION,F.POR.TRANSACTION,'')
	
RETURN

*------------------------------------------------------------------------------
PROCESS:
********
	
    Y.DB.AC.NO = R.POR.TRANSACTION<PPPTX.CreditMainAccount>
    Y.CR.AC.NO = R.POR.TRANSACTION<PPPTX.DebitMainAccount>
    Y.PP.EXCDATE = R.NEW(EB.QA.REQ.EXEC.DATE)
    Y.PP.ID = ID.NEW

    CALL F.READ(FN.AC.NOSTROCASHFLOW,'SYSTEM',R.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW,ERR.AC.NOSTROCASHFLOW)
    IF R.AC.NOSTROCASHFLOW NE '' THEN
        NST.ACCT.TEMP = R.AC.NOSTROCASHFLOW<JB.NOSACCT.CSHFLW.NOSTRO.ACCOUNT>
        CONVERT SM TO VM IN NST.ACCT.TEMP
        CONVERT VM TO FM IN NST.ACCT.TEMP
        Y.NST.CSHFLW.ACCT = '' ; Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
	GOSUB CHECK.DB.ACC
        GOSUB CHECK.CR.ACC
    END
RETURN

*------------------------------------------------------------------------------
CHECK.DB.ACC:
*************

    LOCATE Y.DB.AC.NO IN NST.ACCT.TEMP SETTING DB.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.DB.AC.NO
        Y.PP.AMT = R.POR.TRANSACTION<PPPTX.DebitMainAmount>
        IF V$FUNCTION EQ 'D' THEN
            CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END ELSE
            CALL JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END
    END

RETURN

*------------------------------------------------------------------------------
CHECK.CR.ACC:
*************
    Y.NST.CSHFLW.ACCT = '' ; Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
    LOCATE Y.CR.AC.NO IN NST.ACCT.TEMP SETTING CR.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.CR.AC.NO
        Y.PP.AMT = R.POR.TRANSACTION<PPPTX.CreditMainAmount>
        Y.PP.AMT = Y.PP.AMT*(-1)
        IF V$FUNCTION EQ 'D' THEN
            CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END ELSE
            CALL JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END
    END

RETURN

*------------------------------------------------------------------------------
END
