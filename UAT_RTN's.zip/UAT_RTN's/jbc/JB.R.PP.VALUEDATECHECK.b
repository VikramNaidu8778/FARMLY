*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.VALUEDATECHECK
*-------------------------------------------------------------------------
**
*--------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                Reference               Description
*------------------------------------------------------------------------------------------------
*11-12-2024     Resmi.R                 CBPAY-1426               To make 4 eyes check for vaue date amendment
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    
RETURN

*******
INIT:
*******
    Y.APP = ''
    Y.ID = ID.NEW
    Y.LOCFIELD = ''
    Y.LOCFIELD.POS = ''
    Y.LOCPOS = ''
    Y.LFT.VLDT.CHKD = ''
    Y.INPUT = ''
    Y.INPUT1 = ''
    Y.AUTH = ''

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

   
RETURN
***********************************************************************
PROCESS:
***************************************************************************

    CALL F.READ(FN.PAYMENT.ORDER, Y.ID,R.PO,F.PAYMENT.ORDER,R.PO.ERR)
    Y.APP = APPLICATION
    Y.LOCFIELD = 'L.FT.VALDT.CHKD'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.LOCFIELD.POS =  Y.LOCPOS<1,1>
    Y.LFT.VLDT.CHKD = R.NEW(PO.LOCAL.REF)<1,Y.LOCFIELD.POS>
	
	
    Y.INPUT = R.NEW(PO.INPUTTER)
    Y.INPUT1 = FIELD(Y.INPUT,'_',2)
    Y.AUTH = OPERATOR
	 
    IF Y.LFT.VLDT.CHKD EQ 'CHECKER' THEN
        IF Y.INPUT1 EQ Y.AUTH THEN
            ETEXT = 'EB-SAMEINPUTTER'
            CALL STORE.END.ERROR
        END
	
    END

RETURN

***********************************************************************
END