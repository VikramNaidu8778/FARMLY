*-------------------------------------------------------------------------
SUBROUTINE JB.L.PP.CASHFLOWDATA
*-------------------------------------------------------------------------
*<doc>
* TODO add a description of the application here.
* @author
* @stereotype Application
* @package TODO define the product group and product, e.g. infra.eb
* </doc>
*-------------------------------------------------------------------------
* TODO - You MUST write a .FIELDS routine for the field definitions
* ------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------------
* Date                   Developer              Reference           Description
*--------------------------------------------------------------------------------------------------
* 19/11/2024           	 P Amala                CBPAY-1262        Initial Version
*---------------------------------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_Table
* </region>
*-------------------------------------------------------------------------
    Table.name = 'JB.L.PP.CASHFLOWDATA'       ;* Full application name
    Table.title = 'JB.L.PP.CASHFLOWDATA'      ;* Screen title
    Table.stereotype = 'L'    		;* H, U, L, W or T
    Table.product = 'EB'      		;* Must be on EB.PRODUCT
    Table.subProduct = ''     		;* Must be on EB.SUB.PRODUCT
    Table.classification = 'FIN'       ;* As per FILE.CONTROL
    Table.systemClearFile = 'Y'        ;* As per FILE.CONTROL
    Table.relatedFiles = ''   		;* As per FILE.CONTROL
    Table.isPostClosingFile = ''       ;* As per FILE.CONTROL
    Table.equatePrefix = 'JB.PPCASH'       ;* Use to create I_F.EB.LOG.PARAMETER
*-------------------------------------------------------------------------
    Table.idPrefix = ''       		;* Used by EB.FORMAT.ID if set
    Table.blockedFunctions = ''        ;* Space delimited list of blocked
    Table.trigger = ''        		;* Trigger field used for OPERATION style
*-------------------------------------------------------------------------

RETURN
END