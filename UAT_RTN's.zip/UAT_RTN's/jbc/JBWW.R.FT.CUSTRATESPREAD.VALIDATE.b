    SUBROUTINE JBWW.R.FT.CUSTRATESPREAD.VALIDATE
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the VALIDATE ROUTINE attached to the VERSION.CONTROL of FUNDS.TRANSFER for field CUSTOMER.RATE.
* It is CREDIT.CURRENCY & DEBIT.CURRENCY is same then CUSTOMER.SPREAD value is set to null, if not CUSTOMER.SPREAD is set to 0.
* It is TREASURY.RATE is not null then then, CUSTOMER.RATE is set with values from TREASURY.RATE AND CUSTOMER.SPREAD.
*---------------------------------------------------------------------------------------------
* Attached: to versions FUNDS.TRANSFER,JBWW.V.FT.ODFCY.INP ,FUNDS.TRANSFER,JBWW.V.FT.OD110.INP ,FUNDS.TRANSFER,JBWW.V.FT.OD103.INP  
* ,FUNDS.TRANSFER,JBWW.V.FT.OT102.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT103.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT103PLUS.INP 
* ,FUNDS.TRANSFER,JBWW.V.FT.OT103REMIT.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT103COVER.INP ,FUNDS.TRANSFER,JBWW.V.FT.OT400.INP 
* ,FUNDS.TRANSFER,JBWW.V.FT.OT400202.INP ,FUNDS.TRANSFER,JBWW.V.FT.ITLCYVOST.INP ,FUNDS.TRANSFER,JBWW.V.FT.ITFCYNOST.INP 
* FUNDS.TRANSFER,JBWW.V.FT.ACTR.INP and FUNDS.TRANSFER,JBWW.V.FT.INW.INP 
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               who                  Reference                 Description
* 27-06-2016         NEERAJ               PMT-001_PMT-065           Initial Version
*------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	
    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
***********
INITIALISE:
***********

	Y.DR.CCY  = ''
	Y.CR.CCY  = ''
   
    Y.CR.CCY = R.NEW(FT.CREDIT.CURRENCY)
	Y.DR.CCY = R.NEW(FT.DEBIT.CURRENCY)
	Y.CUSTOMER.RATE = COMI
    CUS.SPREAD = R.NEW(FT.CUSTOMER.SPREAD)
	TREAS.RATE = R.NEW(FT.TREASURY.RATE)
    RETURN
	
***********
PROCESS:
***********

   IF Y.CR.CCY EQ Y.DR.CCY THEN
	 R.NEW(FT.CUSTOMER.SPREAD)=''
   END ELSE
   IF CUS.SPREAD THEN
	R.NEW(FT.CUSTOMER.SPREAD)=0
	END
   END
	
	IF TREAS.RATE NE '' THEN
		COMI = TREAS.RATE + CUS.SPREAD
  	END
  RETURN
END