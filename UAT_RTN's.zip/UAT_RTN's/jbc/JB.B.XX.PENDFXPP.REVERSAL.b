SUBROUTINE JB.B.XX.PENDFXPP.REVERSAL
*------------------------------------------------------------------------------------------------------------------------
* This is a service routine to initiate Cancellation request for FX contracts. TPH Payments may not completed it's
*  process while reversal initiated from MUREX or Transact for FX contracts. Those references will be stored in concat
* table to reverse here in service routine.
*------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------
*Date               Developer             Reference
*------------------------------------------------------------------------------------------------------------------------
*16-04-2025       Lakshmi Priya           CBPAY -1435      Cancellation is Initiated for the FT Reference of FX,
*                                                             available in the concat table JB.L.XX.PEND.FXPP.REVERSAL
*                                                            When service SGD/JB.L.XX.PEND.FXPP.REVERSAL is Initiated .
*------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.QUERIES.ANSWERS
    $INSERT I_F.FOREX
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JB.XX.FXPPPEND.REVERSAL
    $INSERT I_F.POR.TRANSACTION
    
    GOSUB INIT
    GOSUB PROCESS
    
RETURN

*-----
INIT:
*-----
  
    FN.JB.XX.FXPPPEND.REVERSAL = 'F.JB.XX.FXPPPEND.REVERSAL'
    F.JB.XX.FXPPPEND.REVERSAL = ''
    CALL OPF(FN.JB.XX.FXPPPEND.REVERSAL,F.JB.XX.FXPPPEND.REVERSAL)   
            
   FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    FV.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
    
RETURN
 
*-------
PROCESS:
*-------

    SEL.CMD = "SELECT ":FN.JB.XX.FXPPPEND.REVERSAL:" WITH RETRY.STATUS EQ FAILURE"
    CALL EB.READLIST(SEL.CMD,Y.SEL.LIST,'',Y.SEL.CNT,'')
    IF Y.SEL.LIST THEN
        LOOP
            REMOVE Y.SEL.ID FROM Y.SEL.LIST SETTING Y.SEL.POS
        WHILE Y.SEL.ID : Y.SEL.POS
        R.JB.XX.FXPPPEND.REVERSAL = '' ;
            CALL F.READ(FN.JB.XX.FXPPPEND.REVERSAL,Y.SEL.ID,R.JB.XX.FXPPPEND.REVERSAL,F.JB.XX.FXPPPEND.REVERSAL,ERR.JB.XX.FXPPPEND.REVERSAL)
            IF R.JB.XX.FXPPPEND.REVERSAL THEN
                GOSUB APPLICATION.FX
            END
    
        REPEAT
    END

RETURN
*--------------
APPLICATION.FX:
*---------------
  
    GOSUB FORM.PP.CR.REQUEST
    IF OUT.ARRAY THEN
        GOSUB SEND.PP.CR.REQUEST
        R.JB.XX.FXPPPEND.REVERSAL<JB.XX.RETRY.STATUS> = "SUCCESS"
        CALL F.WRITE(FN.JB.XX.FXPPPEND.REVERSAL,Y.SEL.ID,R.JB.XX.FXPPPEND.REVERSAL)
    END ELSE
        YCnt =  R.JB.XX.FXPPPEND.REVERSAL<JB.XX.RETRY.CNT>
       YNewCnt = YCnt + 1        
        Y.TODAY = TODAY
        Y.TODAY =  OCONV(ICONV(Y.TODAY,"D2E"),"D4E")
        Y.TIME = OCONV(TIME(),"MTS")
        DATE.TIME = Y.TODAY:' ':Y.TIME        
        IF YNewCnt GT '3' THEN
            R.JB.XX.FXPPPEND.REVERSAL<JB.XX.RETRY.STATUS> = 'RETRYEXCEEDED' ;
        END ELSE 
        R.JB.XX.FXPPPEND.REVERSAL<JB.XX.RETRY.CNT> = YNewCnt
        R.JB.XX.FXPPPEND.REVERSAL<JB.XX.RETRY.TIME,YNewCnt> = DATE.TIME
        END 
        CALL F.WRITE(FN.JB.XX.FXPPPEND.REVERSAL,Y.SEL.ID,R.JB.XX.FXPPPEND.REVERSAL)
    END

RETURN

**------------------
FORM.PP.CR.REQUEST:
*-------------------

    OUT.ARRAY = '' ; R.POR.TRANSACTION = '' ; POR.ERR = '' ; YChannel = '' ;
    CALL F.READ(FN.POR.TRANSACTION,Y.SEL.ID,R.POR.TRANSACTION,FV.POR.TRANSACTION,POR.ERR)
    YChannel = R.POR.TRANSACTION<PPPTX.OutputChannel>
  
  R.EBQA.REC = '' ;      
    IF YChannel EQ 'NOSTRO' THEN
        GOSUB FORM.EQA.NOSTRO
    END ELSE
*For Other module integration, if PO / TPH is created for CHATSMX, then we need to initiate cancellation using RTGS Menu.
* Enquiry - PPT.RTGSOUTCANCELREQBANK
        GOSUB FORM.EQA.CHATSMX
    END
    
RETURN

*--------------
FORM.EQA.NOSTRO:
*--------------

    ENQ.SELECTION<1,1> = "SWIFTMX.OUT.CANCEL.BANK"
    ENQ.SELECTION<2,1> = "FTNumber"
    ENQ.SELECTION<3,1> = "EQ"
    ENQ.SELECTION<4,1> = Y.SEL.ID
    CALL E.NOFILE.PP.SWCR.RECALL.INITIATED(OUT.ARRAY)
        
    R.EBQA.REC<EB.QA.CLEARING.ID> = "SWIFTMX"
    GOSUB EQA.COMMON.MAPPING

RETURN
*------------------
EQA.COMMON.MAPPING:
*------------------

    R.EBQA.REC<EB.QA.REL.REFERENCE> = FIELD(OUT.ARRAY,"*",2,1)
    R.EBQA.REC<EB.QA.ORIG.MSG.TYPE> = FIELD(OUT.ARRAY,"*",12,1)
    R.EBQA.REC<EB.QA.ORIG.TXN.TYPE> = FIELD(OUT.ARRAY,"*",13,1)
    R.EBQA.REC<EB.QA.ORIG.MSG.REFERENCE> = FIELD(OUT.ARRAY,"*",31,1)
    R.EBQA.REC<EB.QA.ORIG.INTBK.SET.AMT> = FIELD(OUT.ARRAY,"*",16,1)
    R.EBQA.REC<EB.QA.ORIG.INTBK.SET.AMT.CCY> = FIELD(OUT.ARRAY,"*",17,1)
    R.EBQA.REC<EB.QA.ORIG.INTBK.SET.DTE> = FIELD(OUT.ARRAY,"*",7,1)
    R.EBQA.REC<EB.QA.END.TO.END.ID> = FIELD(OUT.ARRAY,"*",4,1)
    R.EBQA.REC<EB.QA.UETR.REF> = FIELD(OUT.ARRAY,"*",24,1)
    R.EBQA.REC<EB.QA.ORIG.CREDITOR.ACCOUNT> = FIELD(OUT.ARRAY,"*",9,1)
    R.EBQA.REC<EB.QA.ORIG.DEBTOR.ACCOUNT> = FIELD(OUT.ARRAY,"*",3,1)
    R.EBQA.REC<EB.QA.ORIG.TXN.REFERENCE> = FIELD(OUT.ARRAY,"*",35,1)
    R.EBQA.REC<EB.QA.CREATOR.BIC> = FIELD(OUT.ARRAY,"*",15,1)
    R.EBQA.REC<EB.QA.RECEIVER.LEI> = FIELD(OUT.ARRAY,"*",34,1)
    R.EBQA.REC<EB.QA.RECEIVER.CLRGSYSID> = FIELD(OUT.ARRAY,"*",32,1)
    R.EBQA.REC<EB.QA.RECEIVER.CLRGMEMID> = FIELD(OUT.ARRAY,"*",33,1)
    R.EBQA.REC<EB.QA.ISO.CANCEL.REASON.CODE> = "TECH"
    R.EBQA.REC<EB.QA.APPLICATION.ID> = "PP"
    R.EBQA.REC<EB.QA.ISO.MSG.TYPE> = "camt.056"
    R.EBQA.REC<EB.QA.REQ.EXEC.DATE> = TODAY
    R.EBQA.REC<EB.QA.CNCL.INITIATED.BY> = "B"
    R.EBQA.REC<EB.QA.CREATOR.TYPE> = "A"
    R.EBQA.REC<EB.QA.DIRECTION> = "OUTWARD"
    R.EBQA.REC<EB.QA.STATUS> = "NEW"
    Y.CREDITOR.BIC = FIELD(OUT.ARRAY,"*",8,1)
    Y.ASSIGNEE.BIC = FIELD(OUT.ARRAY,"*",28,1)
    R.EBQA.REC<EB.QA.RECEIVER.BIC> = Y.ASSIGNEE.BIC
    IF Y.CREDITOR.BIC THEN
        R.EBQA.REC<EB.QA.ORIG.CREDITOR.AGENT.BIC> = Y.CREDITOR.BIC
    END ELSE
        R.EBQA.REC<EB.QA.ORIG.CREDITOR.AGENT.BIC> = Y.ASSIGNEE.BIC
    END

RETURN
*-----------------
FORM.EQA.CHATSMX:
*-----------------
     
    ENQ.SELECTION<1,1> = "PPT.RTGSOUTCANCELREQBANK"
    ENQ.SELECTION<2,-1> = "FTNumber"
    ENQ.SELECTION<3,-1> = "EQ"
    ENQ.SELECTION<4,-1> = Y.SEL.ID
    ENQ.SELECTION<2,-1> = "OutputChannel"
    ENQ.SELECTION<3,-1> = "EQ"
    ENQ.SELECTION<4,-1> = YChannel
    CALL E.NOFILE.PP.RTGS.BANK.INITIATED.RECALL(OUT.ARRAY)
        
    R.EBQA.REC<EB.QA.CLEARING.ID> = "CHATSMX"
    GOSUB EQA.COMMON.MAPPING
    
RETURN
*-------------------
SEND.PP.CR.REQUEST:
*-------------------
   
    Y.OFS.APP.NAME = "EB.QUERIES.ANSWERS"
    Y.OFS.PROCESS = "PROCESS"
    Y.OFS.FUNCTION = "I"
    Y.OFS.VERSION = "EB.QUERIES.ANSWERS,JB.SWMX.B.CANCL.OFS"
    Y.EBQA.ID = ""
    Y.OFS.SOURCE = 'JBWW.D.XX.PAYREV.OFS'

    CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.FUNCTION,Y.OFS.PROCESS,Y.OFS.VERSION,'','',Y.EBQA.ID,R.EBQA.REC,Y.OFS.REQUEST)
    CALL OFS.POST.MESSAGE(Y.OFS.REQUEST,Y.RET.OFS.MSG,Y.OFS.SOURCE,'')



RETURN
*------------------------------------------

END

