*-----------------------------------------------------------------------------
$PACKAGE TAXGST.Foundation
SUBROUTINE JB.R.PP.GSTREFUND.PSAAPI(SourceData)
*-----------------------------------------------------------------------------
* This subroutine is to update below list of fields in the TAXREG.GST.DETAILS record
* CUSTOMER with Customer Number to which GST is Refunded
* DR.ACCOUNT with Customer Account Number to which GST is Refunded
* COMM.AMT with value of TXN.AMT
* COMM.CCY with value of TXN.CCY
* This routine attached in the PP.STATUS.ACTION>999.* record.
* PP.PROGRAM.CHARACTERISTIC>JB.D.PP.UPDGSTREFUND defined for this routine.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          who          Reference          Description
*
* 22-Jun-2025   u40786       CBPAY-3028         Initial Version
*
*-----------------------------------------------------------------------------
*
    $USING PP.TRIPService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentWorkflowGUI
    $USING PI.Contract

    PaymentRecord = SourceData<PP.TRIPService.StatusAction.paymentRecord>  ;* retrive the payment record
    PaymentRecordDets = RAISE(PaymentRecord) ;* To fetch payment details
    PaymentOrderRef = PaymentRecordDets<PP.PaymentWorkflowDASService.PorTransaction.PpptxFtnumber> ;* Payment transaction ID

    PaymentOrderId = '' ;* Initialising Payment order/ Order Entry ID
    SupplementaryInfoRecord = '' ;* Payment supplementary info
    PorTransactionError = '' ;* Error detail
    PP.PaymentWorkflowGUI.getSupplementaryInfo('POR.PAYMENTFLOWDETAILS',PaymentOrderRef,'', SupplementaryInfoRecord, PorTransactionError) ;* API to get supplementary details
    OeList = DCOUNT(SupplementaryInfoRecord<32>,@VM) ;* OE list
    PaymentOrderId = SupplementaryInfoRecord<32,OeList> ;* Since retun value of SupplementaryInfoRecord contains multiple application's record, fetching with position


    IF NOT(PaymentOrderId) THEN ;* PO transaction
        PaymentOrderId = PaymentRecordDets<PP.PaymentWorkflowDASService.PaymentRecord.sendersReferenceIncoming> ;*get the payment order id
    END

    TaxRegDets = '' ;* GST details
    GstHistTableFlag = '' ;* initialising
    TAXGST.Foundation.TaxgstReadGstDetails(PaymentOrderRef, TaxRegDets, GstHistTableFlag) ;* Read record from live or hist table

    IF TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsDrAccount,1>[1,2] EQ 'PL' AND TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsCrAccount,1>[4,5] EQ '17100' THEN
* For Refund case
        TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsCustomer,1> = PaymentRecordDets<PP.PaymentWorkflowDASService.PaymentRecord.creditClientID>
        TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsDrAccount,1> = PaymentRecordDets<PP.PaymentWorkflowDASService.PaymentRecord.creditMainAccount>
        TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsCommAmt,1> = TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsTxnAmt,1>
        TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsCommCcy,1> = TaxRegDets<TAXGST.Foundation.RegGstDetails.GstDetailsTxnCcy,1>


        ErrorMessage = '' ;* Error detail
        TransactionRefs = PaymentOrderRef :@FM: PaymentOrderId ;* Payment transaction ID and reference
        TAXGST.Foundation.TaxgstRegGstDetailsWriteApi(TransactionRefs, TaxRegDets, ErrorMessage) ;* To update TAXREG.GST.DETAILS
    END
*
RETURN
*
END
*
