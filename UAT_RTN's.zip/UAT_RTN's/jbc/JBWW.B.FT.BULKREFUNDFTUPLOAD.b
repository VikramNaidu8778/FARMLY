* @ValidationCode : MTotMTM5NDMzNTQxNDpJU08tODg1OS0xOjE1MTc4MjQ3MjQ5NjI6MzExODQ5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-----------------------------------------------------------------------------
* <Rating></Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.B.FT.BULKREFUNDFTUPLOAD(Y.FT.LIST)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer                         Reference              Description
*-----------------------------------------------------------------------------
*----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_T24.UPLOAD.PROCESS.COMMON
    $INSERT I_F.EB.FILE.UPLOAD.PARAM
    $INSERT I_F.EB.FILE.UPLOAD.TYPE
    $INSERT I_F.EB.FILE.UPLOAD
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_JBWW.B.FT.BULKREFUNDFTUPLOAD.COMMON
*-----------------------------------------------------------------------------

    GOSUB PROCESS

	RETURN 
*-----------------------------------------------------------------------------

PROCESS:
********

	R.RECORD = ''
	Y.FM.CNT = DCOUNT(FT.FIELD.POS.LIST,FM)
	Y.LOOP.CNT = Y.FM.CNT - 1
	FOR Y.I = 1 TO Y.LOOP.CNT
		Y.FT.FLD.POS = FT.FIELD.POS.LIST<Y.I>
		IF DCOUNT(Y.FT.FLD.POS,",") GT 1 THEN
			Y.LOC.FLD.POS = FIELD(Y.FT.FLD.POS,",",2)
			Y.VALUE = TRIM(FIELD(Y.FT.LIST,",",Y.I),'"', 'B')
			CONVERT '/' TO VM IN Y.VALUE
			CONVERT '^' TO SM IN Y.VALUE
			R.RECORD<FT.LOCAL.REF,Y.LOC.FLD.POS> = Y.VALUE
		END ELSE
			Y.VALUE = TRIM(FIELD(Y.FT.LIST,",",Y.I),'"', 'B')
			CONVERT '/' TO VM IN Y.VALUE
			CONVERT '^' TO SM IN Y.VALUE
			R.RECORD<Y.FT.FLD.POS>	= Y.VALUE
		END
	NEXT Y.I

	Y.FT.FLD.POS = FT.FIELD.POS.LIST<Y.FM.CNT>
	Y.LOC.FLD.POS = FIELD(Y.FT.FLD.POS,",",2)
	R.RECORD<FT.LOCAL.REF,Y.LOC.FLD.POS> = Y.UPLD.TYPE:'*':Y.PROCESS.ID

** Suppress SWIFT message	
	Y.TRANSACTION.TYPE = TRIM(FIELD(Y.FT.LIST,",",1),'"', 'B')
	IF NOT(INDEX('AC_DW',Y.TRANSACTION.TYPE[1,2],1)) THEN
		R.RECORD<FT.SEND.PAYMENT.Y.N> = 'NO'
	END
	
	GOSUB POST.OFS
	
RETURN	
*------------------------------------------------------------------------------

POST.OFS:
*********
    Y.APPL.NAME = 'FUNDS.TRANSFER'
    Y.OFS.FUNC = 'I'
    Y.OFS.PROCESS = 'PROCESS'
    Y.OFS.VER = FT.VERSION
    Y.GTSMODE = '1'
    Y.NO.OF.AUTH = ''
	Y.TRANS.ID = ''
    OFS.MSG = ''
    
    CALL OFS.BUILD.RECORD(Y.APPL.NAME,Y.OFS.FUNC,Y.OFS.PROCESS,Y.OFS.VER,Y.GTSMODE,Y.NO.OF.AUTH,Y.TRANS.ID,R.RECORD,OFS.MSG)

    OFS.MSG.ID = ''
    OFS.SOURCE.ID = 'JBWW.D.BULKFT.OFS'
    OPTIONS = ''
    CALL OFS.POST.MESSAGE(OFS.MSG, OFS.MSG.ID, OFS.SOURCE.ID, OPTIONS)

    RETURN
*------------------------------------------------------------------------------
    END
