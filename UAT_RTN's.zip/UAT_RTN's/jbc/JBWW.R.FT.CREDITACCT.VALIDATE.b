*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.CREDITACCT.VALIDATE
*-----------------------------------------------------------------------------
* This routine is used to default the PROFIT.CENTRE.CUST fields as "CUSTOMER" IF Debit account number is Nostro account
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.ACCOUNT

	FN.ACCOUNT = 'F.ACCOUNT'
	F.ACCOUNT = ''
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)

	R.DRACC = ''
	ACC.ERR = ''
	Y.DEBIT.ACCT = R.NEW(FT.DEBIT.ACCT.NO)
	CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT,R.DRACC,F.ACCOUNT,ACC.ERR)
	Y.ACC.CATEG = R.DRACC<AC.CATEGORY>
	
	IF Y.ACC.CATEG GE '5000' AND Y.ACC.CATEG LE '5999' THEN
        Y.CREDIT.ACCT = COMI		    
        R.CRACC = ''
		CALL F.READ(FN.ACCOUNT,Y.CREDIT.ACCT,R.CRACC,F.ACCOUNT,ACC.ERR)
        Y.CUSTOMER = R.CRACC<AC.CUSTOMER> 
		IF Y.CUSTOMER THEN
			R.NEW(FT.PROFIT.CENTRE.CUST) = Y.CUSTOMER
        END
	END
	
	RETURN

END