* @ValidationCode : MToxODcyOTMxNjUzOklTTy04ODU5LTE6MTU0NTY1NjA2NDkzMjphNDUzMjg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 24 Dec 2018 20:54:24
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.ASNCCYTXNAUTH.INP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 24-12-2018        Sakthivel S           JIRA-P3369                Input routine attached
*                                                                   to update the NO.OF.AUTH as 1 for SAP Asian currency FT's record.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.VERSION
    $INSERT I_GTS.COMMON

*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
* To Initialise variables and to open necessary files.

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    GEN.PAR.ID = '' ; R.GEN.RECORD = '' ; ERROR.COM = ''
    GEN.FIELD.NAME = '' ;  ASN.CCY.POS = ''
    Y.ASN.CCY.LIST = ''


    RETURN

PROCESS:
* To add the filter for asian currency SAP transactions
    GEN.PAR.ID = "JBWW.D.FT.ASN.CCY"

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GEN.PAR.ID,R.GEN.RECORD,F.JBWW.H.EB.GENERICPARAMETER,ERROR.COM)
    GEN.FIELD.NAME = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE "ASIAN.CURRENCY" IN GEN.FIELD.NAME<1,1> SETTING ASN.CCY.POS THEN
    Y.ASN.CCY.LIST = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.VALUE,ASN.CCY.POS>
    CHANGE SM TO VM IN Y.ASN.CCY.LIST
    END

    IF R.NEW(FT.DEBIT.CURRENCY) MATCHES Y.ASN.CCY.LIST AND OFS$BROWSER EQ 1 THEN
        R.VERSION(EB.VER.NO.OF.AUTH) = '1'
    END
    RETURN

    END
