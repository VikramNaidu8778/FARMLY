* @ValidationCode : MjoxMjA4NDgyMzMwOkNwMTI1MjoxNzEyODk3NzkxNDk4OjIxMTcwNzg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAyMzEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 12 Apr 2024 10:26:31
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved..
*--------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.OUTBOUNDFEEAPI.HOOK(iAPIInputParameter,oFeeAmount)
*-----------------------------------------------------------------------------
* This is a Fee Determination API attached in PP.FEETYPE>OUTBOUNDOURCHARGE to
* consider Correspondent Bank Charge populated/inputted in local ref field
* PAYMENT.ORDER>L.PO.CORR.BANK field. If there is no value (i.e. NULL) then consider
* TPH configured value (if any) for calculating charges.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
** Date              Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
*13-MAY-2024       Lakshmi Priya              CBPAY - 99         Fee Determination API attached in PP.FEETYPE to consider Correspondent Bank Charge in PO.
*18-JAN-2025       Prabhu D S                 CBPAY-1557         Charges should not apply If PL or Internal account involved in Debit Side
*05-APR-2025       Prabhu D S                 CBPAY-1895 /       Fee amount for each currency is now configured in PP.BANKCHARGES by creating separate
*                                             CBPAY-2123         records. So removing logic for currency coversion.
*29-APR-2025      Prabhu D S                  CBPAY-2274         User provided amount should converted to Charge Account Currency
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FT.CHARGE.TYPE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $USING EB.SystemTables
    $USING PI.Contract
    $USING PP.FeeDeterminationService
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentWorkflowDASService

    GOSUB INIT
    GOSUB PROCESS

RETURN
   
******
INIT:
******

    FN.FT.CHARGE.TYPE = 'F.FT.CHARGE.TYPE'
    FV.FT.CHARGE.TYPE = ''
    CALL OPF(FN.FT.CHARGE.TYPE,FV.FT.CHARGE.TYPE)

    FN.JBWW.GPM = 'F.JBWW.H.EB.GENERICPARAMETER'
    FV.JBWW.GPM = ''
    CALL OPF(FN.JBWW.GPM,FV.JBWW.GPM)

    CALL F.READ(FN.JBWW.GPM,'JB.D.PP.TPH.CONFIG',R.JBWW.GPM.REC,FV.JBWW.GPM,GPM.READ.ERR)
    Y.CORR.BANK.NAME = R.JBWW.GPM.REC<JBWW.GEN.PAR.FIELD.NAME>

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    FV.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, FV.POR.SUPPLEMENTARY.INFO)

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    FV.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, FV.POR.TRANSACTION)

    CALL GET.LOC.REF("PAYMENT.ORDER","L.PO.CORR.BANK",Y.L.CORR.BANK)

    CONVERT @VM TO @FM IN iAPIInputParameter
    
    Y.FT.NO = iAPIInputParameter<PP.FeeDeterminationService.APIInputParameter.ftNumber>
    CALL F.READ(FN.POR.TRANSACTION, Y.FT.NO, R.POR.TRANSACTION, FV.POR.TRANSACTION, POR.ERR)
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPLEMENTARY.INFO,POR.ERR)
    
    Y.CCY = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxTransactioncurrencycode>
    Y.CHG.AC.CCY = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxDebitchargeaccountcurrencycode>
    Y.L.CORR.BANK.NAME = R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdLocFieldName>

    LOCATE 'L.PO.CORR.BANK' IN Y.L.CORR.BANK.NAME<1,1> SETTING Y.SINFO.FLD.POS THEN
        Y.L.CORR.BANK.CHG = R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdLocFieldValue,Y.SINFO.FLD.POS>
    END

    Y.PL.INT.FLAG = 0
    LOCATE 'D' IN R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdMainOrChargeAccountType,1> SETTING Y.AC.POS THEN
        IF R.POR.SUPPL.INFO.REC<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdAccountType,Y.AC.POS> MATCHES 'PL':@VM:'I' THEN
             Y.PL.INT.FLAG = 1
        END
    END

RETURN

********
PROCESS:
********

    BEGIN CASE

        CASE Y.PL.INT.FLAG
            oFeeAmount = 0

        CASE Y.L.CORR.BANK.CHG EQ ''
            GOSUB GET.FT.CHG.TYPE

        CASE 1
            GOSUB EXCH.CLNT.CHG
            oFeeAmount = Y.L.CORR.BANK.CHG

    END CASE

RETURN

****************
GET.FT.CHG.TYPE:
****************

    LOCATE 'FT.CHARGE.TYPE' IN Y.CORR.BANK.NAME<1,1> SETTING Y.GPM.FLD.POS THEN
        Y.CORR.BANK.TYPE = R.JBWW.GPM.REC<JBWW.GEN.PAR.FIELD.VALUE,Y.GPM.FLD.POS>
        CALL F.READ(FN.FT.CHARGE.TYPE,Y.CORR.BANK.TYPE,R.FT.CHARGE.TYPE,FV.FT.CHARGE.TYPE,CHG.ERR)
        IF R.FT.CHARGE.TYPE THEN
            Y.TPH.FLD.NAMES = R.FT.CHARGE.TYPE<FT5.CURRENCY>
            LOCATE Y.CCY IN R.FT.CHARGE.TYPE<FT5.CURRENCY,1> SETTING Y.SUB.ASSET.POS THEN
                oFeeAmount = R.FT.CHARGE.TYPE<FT5.FLAT.AMT,Y.SUB.ASSET.POS>
            END ELSE
                oFeeAmount = "CORE"
            END
        END
    END

RETURN

**************
EXCH.CLNT.CHG:
**************

*User given value should be converted to local currency.
    Y.CCY.MKT = '1'
    IF Y.CHG.AC.CCY THEN
       Y.BUY.CCY = Y.CHG.AC.CCY
    END ELSE
       Y.BUY.CCY = Y.CCY
    END
    Y.BUY.AMT = Y.L.CORR.BANK.CHG
    Y.SELL.CCY = LCCY
    Y.SELL.AMT = ''
    Y.BASE.CCY = ''
    Y.EXCHANGE.RATE = ''
    Y.DIFFERENCE = ''
    Y.LCY.AMT = ''
    Y.RETURN.CODE = ''

    CALL EXCHRATE(Y.CCY.MKT,Y.BUY.CCY,Y.BUY.AMT,Y.SELL.CCY,Y.SELL.AMT,Y.BASE.CCY,Y.EXCHANGE.RATE,Y.DIFFERENCE,Y.L.CORR.BANK.CHG,Y.RETURN.CODE)


RETURN

END


