*-----------------------------------------------------------------------------
* <Rating>-7</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.XX.NOTIFICATION.REQ.FIELDS
*-----------------------------------------------------------------------------
*<doc>
* Template for field definitions routine JB.XX.NOTIFICATION.REQ.FIELDS
*
* @author tcoleman@temenos.com
* @stereotype fields template
* @uses Table
* @public Table Creation
* @package infra.eb
* </doc>
*-----------------------------------------------------------------------------
* Modification History :
*----------------------
*  Date       Resource         JIRA Ref          Description
* 20/11/2024  Prabhu D S       CBPAY-1252        Initial draft
*
*-----------------------------------------------------------------------------
*** <region name= Header>
*** <desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
    ID.F = "@ID"
    ID.N = "35"
    ID.T = "A"
*-----------------------------------------------------------------------------
    CALL Table.addFieldDefinition('EVENT.SHORT.NAME' ,'255','ANY','')
    CALL Table.addFieldDefinition('TITLE' ,'255','A','')
    CALL Table.addFieldDefinition('DESCRIPTION' ,'500','A','')
    CALL Table.addFieldDefinition('LANGUAGE' ,'2','A','')
    CALL Table.addFieldDefinition('BOOKING.CENTER' ,'2','A','')
    CALL Table.addFieldDefinition('SOURCE.APPLN' ,'20','A','')
    CALL Table.addFieldDefinition('TARGET.APPLN' ,'20','A','')
    CALL Table.addFieldDefinition('PORTFOLIO.NUMBER' ,'25','ANY','')
    CALL Table.addFieldDefinition('TRIGGER.USER' ,'10','ANY','')
    CALL Table.addFieldDefinition('XX<NAME' ,'65','ANY','')
    CALL Table.addFieldDefinition('XX>XX.VALUE' ,'500','ANY','')
    CALL Table.addFieldDefinition('TIMESTAMP','30','ANY','')
    CALL Table.addFieldDefinition('XX<IAUDIENCE.SECTION', '140', 'ANY', '')
    CALL Table.addFieldDefinition('XX-XX<IAUDIENCE.TYPE', '140', 'ANY', '')
    CALL Table.addFieldDefinition('XX>XX>IAUDIENCE.VALUE', '140', 'ANY', '')
    CALL Table.addFieldDefinition('XX<EAUDIENCE.TYPE', '140', 'ANY', '')
    CALL Table.addFieldDefinition('XX>EAUDIENCE.VALUE', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.15', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.14', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.13', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.12', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.11', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.10', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.9', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.8', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.7', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.6', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.5', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.4', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.3', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.2', '140', 'ANY', '')
    CALL Table.addFieldDefinition('RESERVED.1', '140', 'ANY', '')
*-----------------------------------------------------------------------------
RETURN
*-----------------------------------------------------------------------------
END
*
