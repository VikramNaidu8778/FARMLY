*-----------------------------------------------------------------------------
* <Rating>-3</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.L.PP.CASHFLOWDATA.FIELDS
*-----------------------------------------------------------------------------
*<doc>
* Template for field definitions routine YOURAPPLICATION.FIELDS
*
* @author
* @stereotype fields template
* @uses Table
* @public Table Creation
* @package infra.eb
* </doc>
*-----------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------------
* Date                   Developer                 Reference           Description
*--------------------------------------------------------------------------------------------------
* 19/11/2024           	 P Amala                   CBPAY-1262        Initial Version
*---------------------------------------------------------------------------------------------------
*** <region name= Header>
*** <desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
    CALL Table.defineId("@ID", T24_String) ;* Define Table id

    ID.F = "@ID"
    ID.N = "35"
    ID.T = 'A'

*-----------------------------------------------------------------------------

    fieldName = "XX<TRANS.REF"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX-PROC.DATE"
    fieldLength = "12"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX>TRANS.AMOUNT"
    fieldLength = "19"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')
   
    fieldName = "RESERVED.4"
    fieldLength = "35"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.3"
    fieldLength = "35"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.2"
    fieldLength = "35"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.1"
    fieldLength = "35"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

*    CALL Table.addFieldWithEbLookup(fieldName,virtualTableName,neighbour) ;* Specify Lookup values
*    CALL Field.setDefault(defaultValue) ;* Assign default value
*-----------------------------------------------------------------------------
*   CALL Table.setAuditPosition ;* Poputale audit information
*-----------------------------------------------------------------------------
RETURN
*-----------------------------------------------------------------------------
END
