SUBROUTINE JB.R.PP.TRHUPDSTATUS.AFTNAU
*-----------------------------------------------------------------------------
* This is an After UnAuth routine to update JBWW.L.XX.TRH.TRADES & 
* JBWW.H.XX.TRH.TRADES tables with record status and curr no of Payment Order
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  01-JUL-2024   Prabhu D S         CBPAY-549         Initial Draft
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.L.XX.TRH.TRADES
    $INSERT I_F.JBWW.H.XX.TRH.TRADES
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.VERSION
*-----------------------------------------------------------------------------
    GOSUB INIT.AND.OPEN
    GOSUB UPDATE.CONCAT.AND.TRADE.TABLES
 
RETURN
 
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Initialise and Open>
*** <desc>Do the required OPF</desc>
*------------------------------------------------------------------------------------------------------------------------------------
************** 
INIT.AND.OPEN:
**************

    FN.JBWW.L.XX.TRH.TRADES = 'F.JBWW.L.XX.TRH.TRADES'
    F.JBWW.L.XX.TRH.TRADES  = ''
    CALL OPF(FN.JBWW.L.XX.TRH.TRADES,F.JBWW.L.XX.TRH.TRADES)
 
    FN.JBWW.H.XX.TRH.TRADES = 'F.JBWW.H.XX.TRH.TRADES'
    F.JBWW.H.XX.TRH.TRADES  = ''
    CALL OPF(FN.JBWW.H.XX.TRH.TRADES,F.JBWW.H.XX.TRH.TRADES)
 
    TRX.ID = ID.NEW
 
    FUNCTION.VAL  = V$FUNCTION
    NO.AUTH.VAL   = R.VERSION(EB.VER.NO.OF.AUTH)
    STATUS.VALUE = R.NEW(PO.RECORD.STATUS)    
 
RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------------------------
*** <region name= Initialise and Open>
*** <desc>Update the concat table </desc>
*------------------------------------------------------------------------------------------------------------------------------------
******************************* 
UPDATE.CONCAT.AND.TRADE.TABLES:
*******************************

    IF (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ 0) OR FUNCTION.VAL EQ 'A' OR (FUNCTION.VAL EQ 'R' AND NO.AUTH.VAL EQ 0) THEN
        STATUS.VALUE = ''
    END
 
    CALL F.READ(FN.JBWW.L.XX.TRH.TRADES, TRX.ID, R.JWW.L.XX.TRH.TRADES, F.JBWW.L.XX.TRH.TRADES, JBWW.L.XX.TRH.TRADES.ERR)
    IF NOT(JBWW.L.XX.TRH.TRADES.ERR) AND R.NEW(PO.RECORD.STATUS) NE 'RNAU' THEN
        R.JBWW.L.XX.TRH.TRADES<JB.TRHTRD.rec.Status> = STATUS.VALUE
        R.JBWW.L.XX.TRH.TRADES<JB.TRHTRD.curr.Number> = R.NEW(PO.CURR.NO)
        CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES, TRX.ID, R.JBWW.L.XX.TRH.TRADES)
 
        CALL F.READ(FN.JBWW.H.XX.TRH.TRADES, TRX.ID, R.JBWW.H.XX.TRH.TRADES, F.JBWW.H.XX.TRH.TRADES, JBWW.H.XX.TRH.TRADES.ERR)
        IF NOT(JBWW.H.XX.TRH.TRADES.ERR) AND R.NEW(PO.RECORD.STATUS) NE 'RNAU' THEN
            R.JBWW.H.XX.TRH.TRADES<JB.TRHTRD.rec.Status> = STATUS.VALUE
            R.JBWW.H.XX.TRH.TRADES<JB.TRHTRD.curr.Number> = R.NEW(PO.CURR.NO)
            CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES, TRX.ID, R.JBWW.H.XX.TRH.TRADES)
        END
    END
 
RETURN

END
