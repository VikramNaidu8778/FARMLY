* @ValidationCode : MToxMTUxMTQ2NjQ0OklTTy04ODU5LTE6MTUyNzE2OTI4NDMyMjphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjEx
* @ValidationInfo : Timestamp         : 24 May 2018 21:41:24
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.R.XX.CLEARERRORSTATUS.CHECK
*-----------------------------------------------------------------------------
* This routine is attached as Check Record Routine in the version JBWW.H.FT.RETROPAY,JBWW.V.FT.PAYERROR.INPUT
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
*
* 24-05-2018 - JB2A-51978
*              Clear the fields TECH.STATUS, PROCESSING.STATUS and ERROR.STATUS as setting up
*              AUT.OLD.CONTENT in Version did not work. 
*
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.JBWW.H.FT.RETROPAY 
*-----------------------------------------------------------------------------
* <region>
    
    R.NEW(RTR.PAY.TECH.STATUS) = ''
    R.NEW(RTR.PAY.PROCESSING.STATUS) = ''
    R.NEW(RTR.PAY.ERROR.TEXT) = ''

    RETURN
    
* </region>
*-----------------------------------------------------------------------------    
END
