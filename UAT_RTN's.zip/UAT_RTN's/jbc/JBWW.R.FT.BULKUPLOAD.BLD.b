
SUBROUTINE JBWW.R.FT.BULKUPLOAD.BLD(ENQ.DATA)
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
*    Date       Developer             Reference               Description
*-------------------------------------------------------------------------
* 05/06/2018     Arjun. S             DAY15-11              Initial version
* 04/07/2018     Balaji               DAY15-870             To add Upload Date and Debit/Credit Alternate Accounts in Selection
* 20/10/2022     Madhu               P-3998                Added the GST bulk upload for Refund, Fee Charges & Internal
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.MNEMONIC.CUSTOMER
    $INSERT I_F.CUSTOMER.ACCOUNT
    $INSERT I_F.ACCOUNT.CLOSURE
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.EB.FILE.UPLOAD
*-----------------------------------------------------------------------------
    GOSUB INIT
    
    LOCATE 'L.FT.FILEUPD.ID' IN ENQ.DATA<2,1> SETTING Y.POS1 THEN
        Y.UPLOAD.ID = ENQ.DATA<4,Y.POS1>
    END
   
    LOCATE '@ID' IN ENQ.DATA<2,1> SETTING Y.POS2 THEN
        Y.FT.ID= ENQ.DATA<4,Y.POS2>
    END

*S - DAY15-870
    LOCATE 'DATE.TIME' IN ENQ.DATA<2,1> SETTING DATE.POS THEN
        Y.DATE = ENQ.DATA<4,DATE.POS>
    END

    LOCATE 'DEBIT.ACCT.NO' IN ENQ.DATA<2,1> SETTING DR.AC.POS THEN
        Y.DEBIT.ACCT.NO = ENQ.DATA<4,DR.AC.POS>
    END
    
    LOCATE 'CREDIT.ACCT.NO' IN ENQ.DATA<2,1> SETTING CR.AC.POS THEN
        Y.CREDIT.ACCT.NO = ENQ.DATA<4,CR.AC.POS>
    END
*E - DAY15-870
    
    GOSUB PROCESS
  
RETURN

INIT:
*****


    FN.FT.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FT.NAU = ''
    CALL OPF(FN.FT.NAU,F.FT.NAU)
    
    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
    
    FN.EB.FILE.UPLOAD = 'F.EB.FILE.UPLOAD'
    F.EB.FILE.UPLOAD = ''
    CALL OPF(FN.EB.FILE.UPLOAD,F.EB.FILE.UPLOAD)
    
    Y.POS1 = ''
    Y.POS2=''
    Y.CNT = '1'
    Y.BOTH.SEL=0
    Y.UPLOAD.ID=''
    UPLOAD.TYPE = ''
    ERR.EB.FILE.UPLOAD = ''
    R.EB.FILE.UPLOAD = ''
    Y.ID=ENQ.DATA<1>

RETURN

PROCESS:
********

    BEGIN CASE
        CASE Y.ID EQ 'JBWW.E.FT.BULKREFUND-NAU.AUTH' OR Y.ID EQ 'JBWW.E.FT.BULKREFUND-HLD.AUTH'
            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTREFUND*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTREFUND' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTREFUND*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTREFUND' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTREFUND*':Y.UPLOAD.ID
                        END
                    END
        
                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2
        

                CASE Y.UPLOAD.ID AND Y.FT.ID
        
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTREFUND*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTREFUND' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTREFUND*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTREFUND' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTREFUND*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID
      
                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTREFUND*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'

            END CASE

        CASE Y.ID EQ 'JBWW.E.FT.BULKFEECHG-NAU.AUTH' OR Y.ID EQ 'JBWW.E.FT.BULKFEECHG-HLD.AUTH'


            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTFEECHG*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTFEECHG' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTFEECHG*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTFEECHG' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTFEECHG*':Y.UPLOAD.ID
                        END
                    END

                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2

                CASE Y.UPLOAD.ID AND Y.FT.ID

                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTFEECHG*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTFEECHG' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTFEECHG*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTFEECHG' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTFEECHG*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID

                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTFEECHG*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'

            END CASE
    
        CASE Y.ID EQ 'JBWW.E.FT.BULKINT-NAU.AUTH' OR Y.ID EQ 'JBWW.E.FT.BULKINT-HLD.AUTH'
   
            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTINT*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTINT' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTINT*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTINT' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTINT*':Y.UPLOAD.ID
                        END
                    END

                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2

                CASE Y.UPLOAD.ID AND Y.FT.ID

                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTINT*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE = 'SG.GSTBULK.FTINT' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTINT*':Y.UPLOAD.ID
                        END
                        IF UPLOAD.TYPE = 'HK.GSTBULK.FTINT' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTBULK.FTINT*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID

                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FTINT*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
            END CASE
    END CASE
        
    CHANGE FM TO ' ' IN Y.UPLD.ID
    IF Y.UPLD.ID AND NOT(Y.BOTH.SEL) THEN
*ENQ.DATA<3> = ''       ;*DAY15-870
*ENQ.DATA<4> = ''       ;*DAY15-870
        ENQ.DATA<2,Y.POS1> = Y.FLD.SEL
        ENQ.DATA<3,Y.POS1> = Y.OPRT
        ENQ.DATA<4,Y.POS1> = Y.UPLD.ID
    END

*S - DAY15-870

    IF Y.ID EQ 'JBWW.E.FT.BULKREFUND-NAU.AUTH' OR Y.ID EQ 'JBWW.E.FT.BULKFEECHG-NAU.AUTH' OR Y.ID EQ 'JBWW.E.FT.BULKINT-NAU.AUTH' THEN
        IF Y.DATE NE "" THEN
            Y.DATE = Y.DATE[3,6]
            ENQ.DATA<2,DATE.POS> = 'DATE.TIME'
            ENQ.DATA<3,DATE.POS> = 'LK'
            ENQ.DATA<4,DATE.POS> = Y.DATE:'...'
        END
    
        IF Y.DEBIT.ACCT.NO NE "" THEN
            R.ALTERNATE.ACCOUNT = '' ; ALTERNATE.ACCOUNT.ERR = ''
            CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.DEBIT.ACCT.NO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ALTERNATE.ACCOUNT.ERR)
            IF R.ALTERNATE.ACCOUNT NE "" THEN
                Y.DEBIT.ACCT.NO = R.ALTERNATE.ACCOUNT<1>
            END
            ENQ.DATA<2,DR.AC.POS> = 'DEBIT.ACCT.NO'
            ENQ.DATA<3,DR.AC.POS> = 'EQ'
            ENQ.DATA<4,DR.AC.POS> = Y.DEBIT.ACCT.NO
        END
    
        IF Y.CREDIT.ACCT.NO NE "" THEN
            R.ALTERNATE.ACCOUNT = '' ; ALTERNATE.ACCOUNT.ERR = ''
            CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.CREDIT.ACCT.NO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ALTERNATE.ACCOUNT.ERR)
            IF R.ALTERNATE.ACCOUNT NE "" THEN
                Y.CREDIT.ACCT.NO = R.ALTERNATE.ACCOUNT<1>
            END
            ENQ.DATA<2,CR.AC.POS> = 'CREDIT.ACCT.NO'
            ENQ.DATA<3,CR.AC.POS> = 'EQ'
            ENQ.DATA<4,CR.AC.POS> = Y.CREDIT.ACCT.NO
        END
    END

*E - DAY15-870

RETURN
*-----------------------------------------------------------------------------
END