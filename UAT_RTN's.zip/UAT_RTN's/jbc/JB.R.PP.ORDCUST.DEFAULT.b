*--------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.ORDCUST.DEFAULT
*--------------------------------------------------------------------------------------------------
* Description: This Validation routine is used to default Ordering Customer Strucuted Address details in following version.
* Based on the GPM>JB.D.PP.TPH.CONFIG - Field "ORD.STRUC.ADD.DEF"
* PAYMENT.ORDER,PI.API.NOSTRO103.1.0.0
* PAYMENT.ORDER,PI.API.NOSTRO202.1.0.0
* PAYMENT.ORDER,JB.V.PP.REFUNDS.INP
* PAYMENT.ORDER,JB.V.PP.FEECHRG.INP
* PAYMENT.ORDER,JB.V.PP.GSTREFUNDS.INP
* PAYMENT.ORDER,JB.V.PP.GSTFEECHG.INP
* PAYMENT.ORDER,JB.V.PP.INTERNAL.INP
* PAYMENT.ORDER,JB.V.PP.EAMSSD.API.1.0.0
* PAYMENT.ORDER,JB.V.PP.RETROPAYEXT.API.1.0.0
*---------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------
* Date          Developer   Reference           Description
*---------------------------------------------------------------------------------------------------
*
* 26-APR-2024 Lakshmi Priya CBPAY-59_151       Default ordering customer customer Address
* 29-APR-2024 Hariharan T   CBPAY_52           Adding logic for (Debit leg) Internal Account in GPM and defaulting address.
* 15-OCT-2024 Lakshmi Priya CBPAY-1072         Modified the code to default Ordering Customer Address only when debit PL, 
*                                              Internal Account or when calculo is used .
* 02-04-2025  Prabhu D S    CBPAY-2306         Orderer information should reflect for BJB entity for Nostro account as well.
* 09-04-2025  Prabhu D S    CBPAY-2451         Corr Bank Charge populated when Debit Account i Nostro/PL/Internal, So Waive Off
* 15-05-2025  Prabhu D S    CBPAY-2784         Ordering BIC should be defaulted as JB Entity for Nostro/PL/Internal
* 15-05-2025  Lakshmi Priya CBPAY-2697/2725    Changed logic to waive off charges only for Payment Order Product
*                                              'OT03' and 'OT12' if Debit Acct is not customer Account .
* 26-05-2025  Prabhu D S    CBPAY-3085         Waive All Charges should not be initialised
*--------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.ACCOUNT
    $INSERT I_F.COMPANY
    $USING PP.PaymentFrameworkService
   
*
    CALL JB.R.PP.ENRICHMENT.VAL
    GOSUB INIT
    IF R.GPM.ADD THEN
        GOSUB PROCESS
    END
*
RETURN
*
*****
INIT:
*****
    

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.GPM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.GPM = ''
    CALL OPF(FN.GPM,F.GPM)
    
    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT)

    FN.ACCOUNT = "F.ACCOUNT"
    F.ACCOUNT = ""
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)    

    TPH.FLD.NAMES = ''
    ORD.STRUCT.FLD.VALUES = ''

    GOSUB READ.GPM.ADDRESS
    GOSUB READ.GPM.TPHCONFIG
*    R.NEW(PO.WAIVE.ALL.CHARGES) = ''
    COMP.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    PP.PaymentFrameworkService.getCompanyProperties(COMP.MNEMONIC, oCompanyProperties, oGetCompPropsError)
*
RETURN
*
********
PROCESS:
********

       BEGIN CASE
        CASE R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES CALC.EAM.POPRD
            GOSUB DEFAULT.ORDERING.ADDRESS
        CASE R.NEW(PO.DEBIT.PL) NE ''
            GOSUB DEFAULT.ORDERING.ADDRESS
            IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12' THEN
               R.NEW(PO.WAIVE.ALL.CHARGES) = 'YES'
            END
        CASE R.NEW(PO.DEBIT.ACCOUNT) NE ''
            IF ISDIGIT(R.NEW(PO.DEBIT.ACCOUNT)) THEN
               GOSUB CHECK.NOSTRO.ACCOUNT
            END ELSE
                IF NOT(LEN(R.NEW(PO.DEBIT.ACCOUNT)) EQ 19) THEN
                   GOSUB DEFAULT.ORDERING.ADDRESS
                   IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12' THEN
                      R.NEW(PO.WAIVE.ALL.CHARGES) = 'YES'
                   END
                END
            END
                
    END CASE
*
RETURN
*
*****************
READ.GPM.ADDRESS:
*****************

    R.GPM.ADD = ''
    E.GPM.ADD = ''
    CALL F.READ(FN.GPM,'JB.D.XX.COM.ADDRESS',R.GPM.ADD,F.GPM,E.GPM.ADD)
    

*
RETURN
*
*******************
READ.GPM.TPHCONFIG:
*******************

    CALC.EAM.POPRD = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","ORD.STRUC.ADD.DEF",CALC.EAM.POPRD)
    CHANGE ',' TO VM IN CALC.EAM.POPRD
    CHANGE FM TO VM IN CALC.EAM.POPRD

*
RETURN
*
*************************
DEFAULT.ORDERING.ADDRESS:
*************************

    R.NEW(PO.ORDERING.CUST.NAME) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,1>
    R.NEW(PO.ORDERING.STREET.NAME) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,2>
    R.NEW(PO.ORDERING.BUILDING.NAME) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,3>
    R.NEW(PO.ORDERING.POST.CODE) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,4>
    R.NEW(PO.ORDERING.CUSTOMER.TOWN.NAME) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,5>
    R.NEW(PO.ORDERING.COUNTRY.RESIDENCE) = R.GPM.ADD<JBWW.GEN.PAR.FIELD.VALUE,1,6>
    R.NEW(PO.ORDERING.CUSTOMER.BIC) = oCompanyProperties<PP.PaymentFrameworkService.CompanyProperties.companyBIC>
   *
RETURN
*********************
CHECK.NOSTRO.ACCOUNT:
*********************

    Y.ACC = R.NEW(PO.DEBIT.ACCOUNT)
    CALL F.READ(FN.ACCOUNT, Y.ACC, R.ACC, F.ACCOUNT, '')
    IF R.ACC<AC.CATEGORY> GE 5000 AND R.ACC<AC.CATEGORY> LE 5999 THEN
       GOSUB DEFAULT.ORDERING.ADDRESS
       IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12' THEN
          R.NEW(PO.WAIVE.ALL.CHARGES) = 'YES'
       END
    END 

RETURN       
**
END
***
