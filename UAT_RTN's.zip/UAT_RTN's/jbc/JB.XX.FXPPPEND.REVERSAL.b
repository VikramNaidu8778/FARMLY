SUBROUTINE JB.XX.FXPPPEND.REVERSAL
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*This is the template routine for Exception Handling of camt.057 sent from
*other module integration transactions
*-----------------------------------------------------------------------------
* Date            Reference             Developer           Description
*
* 01-May-2024     CBPAY-1435             Kandan                 Initial Version
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_Table

    Table.name = 'JB.XX.FXPPPEND.REVERSAL'
    Table.title = 'JB.XX.FXPPPEND.REVERSAL'
    Table.stereotype = 'L'
    Table.product = 'EB'
    Table.subProduct = ''
    Table.classification = 'FIN'
    Table.systemClearFile = 'Y'
    Table.relatedFiles = ''
    Table.isPostClosingFile = ''
    Table.equatePrefix = 'JB.XX'
    Table.idPrefix = ''
    Table.blockedFunctions = ''
    Table.trigger = ''
*
RETURN
*-----------------------------------------------------------------------------
END

