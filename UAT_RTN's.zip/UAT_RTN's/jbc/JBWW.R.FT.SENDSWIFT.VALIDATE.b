    SUBROUTINE JBWW.R.FT.SENDSWIFT.VALIDATE
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the validation Routine attached to the VERSION.CONTROL of FUNDS.TRANSFER.
* To reset the bnk code if the send payment is NO.
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               Developer            Reference       Description
*09/05/2018    PuthumaiSamy          JB2A-51880        [PROD] Cash_Payments_Beneficiary Template_Unable to commit Beneficiary Template transaction without swift
*
*------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER

	Y.SEND.PAY = COMI
	Y.BNK.OP.CODE = R.NEW(FT.BK.OPERATION.CODE)
	IF Y.SEND.PAY EQ 'NO' AND Y.BNK.OP.CODE THEN
	   R.NEW(FT.BK.OPERATION.CODE) = ''
	END
	
  RETURN
*----------------------------------------------------------------------
END