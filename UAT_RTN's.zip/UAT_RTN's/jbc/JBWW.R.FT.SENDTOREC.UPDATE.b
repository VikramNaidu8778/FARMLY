* @ValidationCode : MToyMDgyODA3ODU1OklTTy04ODU5LTE6MTU0NjQyNDU2MjcyODphNDUzMjg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 02 Jan 2019 18:22:42
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.SENDTOREC.UPDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 24-12-2018        Sakthivel S           JIRA-P3369                Auto new content routine attached 
*                                                                   to update the BK.TO.BK.INFO in SAP FT's record.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    IF R.NEW(FT.DEBIT.CURRENCY) EQ "SGD" THEN
        COMI = "/REC/FULLPAY/"
    END

    RETURN
    END
