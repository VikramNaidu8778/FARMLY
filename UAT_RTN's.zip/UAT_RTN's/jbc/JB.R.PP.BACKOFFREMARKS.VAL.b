SUBROUTINE JB.R.PP.BACKOFFREMARKS.VAL
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 30-May-2024   CTS                                    CBPAY_20_38_40
*
* Description : Routine to populate the latest BO Remarks comments in local field L.PP.BP.HISTCOM
*               All History BO Remarks will be stored in L.PP.BP.HISTCOM
* Attached to : All Versions of PAYMENT.ORDER & PP.ORDER.ENTRY
* Attached as : Validation Routine
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
   


IF MESSAGE NE 'VAL' THEN    ; *To Trigger only during field Val
    GOSUB INIT
    GOSUB PROCESS
END
    
RETURN
*----
INIT:
*----

    BEGIN CASE
    
        CASE APPLICATION EQ 'PAYMENT.ORDER'
            APPL = 'PAYMENT.ORDER'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PO.LOCAL.REF
    
        CASE APPLICATION EQ 'PP.ORDER.ENTRY'
            APPL = 'PP.ORDER.ENTRY'
            LREF.FLD = 'L.PP.BO.USRCOM':VM:'L.PP.BP.HISTCOM'
            CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
            Y.L.PP.BO.USRCOM.POS = Y.POS<1,1>
            Y.L.PP.BP.HISTCOM.POS = Y.POS<1,2>
            Y.LOC.FLD.VAR = PP.OEYG.LOCAL.REF
    
    END CASE

RETURN
*-------
PROCESS:
*-------

Y.CURR.VAL = R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BO.USRCOM.POS>
 

 
  IF COMI THEN      
        IF R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS> THEN
            R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS,-1> = COMI
        END ELSE
            R.NEW(Y.LOC.FLD.VAR)<1,Y.L.PP.BP.HISTCOM.POS> = COMI
        END

    END
RETURN
*-----------------------------------------------------------------------------
END

