
* @ValidationCode : MTotMTU3NjY2MTgyMzpJU08tODg1OS0xOjE1NDI4MDAwNTI2Njk6NTUwMzUwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 21 Nov 2018 17:04:12
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 550350
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
    SUBROUTINE JBWW.R.FT.TXNTYPEDROPDOWN.NOF(LIST.ARRY)
*-----------------------------------------------------------------------------
** Description:
*-------------------------------------------------------------------------
* This is no-file enquiry routine attached to enquiry JBWW.E.FT.TXNTYPE.DROPDOWN
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: LIST.ARRY
* Dependencies:
*---------------
* NA
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*----------------------------------------------------------------------------------------------
* 12/12/2016    Rajesh.Kopparapu@cognizant.com            CR-138                 Version 0.3
* 10-Oct-2018   Rajagopalan R            DAY15-4245 & DAY15-4482     updated the code to filter FT Transaction Types for CASH and SECURITIES User Roles
* 20-Nov-2018   Naveen H                 DAY15-4877 & DAY15-4878     updated the code to avoid repeated transaction type in dropdown enquiry
* 22-Jan-2019   Balaji	                 DAY15-170  & DAY15-4878     updated the code to restrict txn types based on cash user roles
*-----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.EB.USER.ROLES
    $INSERT I_F.USER
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------------
INIT:
*****

    JBWW.GEN.PAR.FN = ''   ; JBWW.GEN.PAR.FV = ''
    FT.TXN.CNT     = ''    ; FT.TXN.ID       = ''
    FT.TXN.DESC    = ''    ; FV.CNT          = ''
    FT.TXN.CNT     = ''    ; GP.ERR.MSG      = ''
    R.FT.TXN       = ''    ; R.GEN.REC.ROLE  = ''
    FT.ERR         = ''    ; VER.POS         = ''
    VER.NAME       = ''    ; R.GEN.REC.CASH  = ''
    R.GEN.REC.SEC  = ''

    LOCATE "VER.NAME" IN D.FIELDS<-1> SETTING VER.POS THEN
    VER.NAME = D.RANGE.AND.VALUE<VER.POS>
    CHANGE "'" TO "" IN VER.NAME
    END

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.FT.TXN.TYPE.CONDITION = 'F.FT.TXN.TYPE.CONDITION'
    F.FT.TXN.TYPE.CONDITION  = ''
    CALL OPF(FN.FT.TXN.TYPE.CONDITION,F.FT.TXN.TYPE.CONDITION)

    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)

    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    RETURN
*---------------------------------------------------------------------------------
PROCESS:
*********

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.GEN.REC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASHSEC.ROLES.FN = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.NAME>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.AC.CASH.TXNTYPES",R.GEN.REC.CASH,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASH.TXNTYPES.FN = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.NAME>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.SC.SEC.TXNTYPES",R.GEN.REC.SEC,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.SEC.TXNTYPES.FN = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.NAME>


    LOCATE "CASH.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
    Y.CASH.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
    LOCATE VER.NAME IN Y.CASH.TXNTYPES.FN<1,1> SETTING CASHTXN.POS THEN
    Y.CASH.TXNTYPES.FV = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,CASHTXN.POS>
    END
	
    LOCATE "SEC.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
    Y.SEC.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>
    LOCATE VER.NAME IN Y.SEC.TXNTYPES.FN<1,1> SETTING SECTXN.POS THEN
    Y.SEC.TXNTYPES.FV = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.VALUE,SECTXN.POS>
    END
    END
    IF Y.CASH.TXNTYPES.FV = "" AND Y.SEC.TXNTYPES.FV = "" THEN
        GOSUB OTHER.USER.CHK
        RETURN
    END

    GOSUB GET.USER.ROLES
    GOSUB CASH.USER.ROLE.CHK

    RETURN

GET.USER.ROLES:
***************
    Y.INP.USER = OPERATOR
    CALL F.READ(FN.USER,Y.INP.USER,R.USER,F.USER,USR.ERR)
    Y.USER.ROLES.LIST = R.USER<EB.USE.USER.ROLES>
    IF Y.USER.ROLES.LIST EQ '' THEN
        GOSUB OTHER.USER.CHK
        RETURN
    END

    RETURN

CASH.USER.ROLE.CHK:
*******************

    LOOP
        REMOVE Y.USER.ROLES FROM Y.USER.ROLES.LIST SETTING ROLE.POS
    WHILE Y.USER.ROLES:ROLE.POS
        LOCATE Y.USER.ROLES IN Y.CASH.USER.ROLES<1,1,1> SETTING FV.CASH.ROLE.POS THEN
        LIST.ARRY = ""
        CASH.FT.TXN.CNT = DCOUNT(Y.CASH.TXNTYPES.FV,SM)
        CASH.FT.CNT = 1
        LOOP
        WHILE CASH.FT.CNT LE CASH.FT.TXN.CNT
            FTTXNTYPE.POS = ""
            CASH.FT.TXN.ID = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,CASHTXN.POS,CASH.FT.CNT>
            CALL F.READ(FN.FT.TXN.TYPE.CONDITION,CASH.FT.TXN.ID,R.FT.TXN,F.FT.TXN.TYPE.CONDITION,CASH.FT.ERR)
            CASH.FT.TXN.DESC = R.FT.TXN<FT6.DESCRIPTION>
			LOCATE USER.ROLE IN Y.CASH.TXNTYPES.FN<1,1> SETTING ROLE.TXN.POS THEN
				Y.ROLE.TXN.LIST = R.GEN.REC.CASH<JBWW.GEN.PAR.FIELD.VALUE,ROLE.TXN.POS>
				LOCATE CASH.FT.TXN.ID IN Y.ROLE.TXN.LIST<1,1,1> SETTING REST.TXN.POS ELSE
					LIST.ARRY<-1> = CASH.FT.TXN.ID:"*":CASH.FT.TXN.DESC
				END
			END ELSE
				LIST.ARRY<-1> = CASH.FT.TXN.ID:"*":CASH.FT.TXN.DESC
			END
            CASH.FT.CNT += 1
        REPEAT
    END ELSE
        GOSUB SEC.USER.ROLE.CHK
    END
    Y.USER.ROLES = ''
    REPEAT
    RETURN

SEC.USER.ROLE.CHK:
******************
ROLE.POS = ""
    LOOP
        REMOVE Y.USER.ROLES FROM Y.USER.ROLES.LIST SETTING ROLE.POS
    WHILE Y.USER.ROLES:ROLE.POS

        LOCATE Y.USER.ROLES IN Y.SEC.USER.ROLES<1,1,1> SETTING FV.SEC.ROLE.POS THEN
        LIST.ARRY = ""
        SEC.FT.TXN.CNT = DCOUNT(Y.SEC.TXNTYPES.FV,SM)
        SEC.FT.CNT = 1
        LOOP
        WHILE SEC.FT.CNT LE SEC.FT.TXN.CNT
            FTTXNTYPE.POS = ""
            SEC.FT.TXN.ID = R.GEN.REC.SEC<JBWW.GEN.PAR.FIELD.VALUE,SECTXN.POS,SEC.FT.CNT>
            CALL F.READ(FN.FT.TXN.TYPE.CONDITION,SEC.FT.TXN.ID,R.FT.TXN,F.FT.TXN.TYPE.CONDITION,SEC.FT.ERR)
            SEC.FT.TXN.DESC = R.FT.TXN<FT6.DESCRIPTION>
            LIST.ARRY<-1> = SEC.FT.TXN.ID:"*":SEC.FT.TXN.DESC
            SEC.FT.CNT += 1
        REPEAT
    END ELSE
        GOSUB OTHER.USER.CHK
    END
    Y.USER.ROLES = ''
    REPEAT
    RETURN

OTHER.USER.CHK:
***************

*    SEL.AUTH = "SELECT ":FN.FUNDS.TRANSFER
    Y.FTTXN.TYPE = ''
    Y.TXNTYPE.DESC = ''
    LIST.ARRY = ""
    SEL.AUTH = "SELECT ":FN.FT.TXN.TYPE.CONDITION
    CALL EB.READLIST(SEL.AUTH,SEL.AUTH.LIST,'',SEL.AUTH.CNT,SEL.AUTH.ERR)
    LOOP
        REMOVE Y.FT FROM SEL.AUTH.LIST SETTING FT.POS
    WHILE Y.FT:FT.POS
        CALL F.READ(FN.FT.TXN.TYPE.CONDITION,Y.FT,R.FT.TXN,F.FT.TXN.TYPE.CONDITION,CASH.FT.ERR)
        Y.TXNTYPE.DESC = R.FT.TXN<FT6.DESCRIPTION>
        Y.FTTXN.TYPE = Y.FT
        LIST.ARRY<-1> = Y.FTTXN.TYPE:"*":Y.TXNTYPE.DESC
    REPEAT

    RETURN
    END
