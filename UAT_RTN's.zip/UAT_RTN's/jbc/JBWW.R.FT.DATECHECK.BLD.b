*-----------------------------------------------------------------------------
*-----------------------------------------------------------------------------
* <Rating>-79</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.DATECHECK.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 27/07/2016    priyadarshni.priyanka@cognizant.com     PMT003                    Initial Version
* 21/05/2018    Karthik                               JB2A-51921                User is unable to change/correct once VD is inputted from Valude date amendment queue
* 23/08/2018    Kalyani								  DAY15-1738                Updated to fetch the transaction type from FT record
*--------------------------------------------------------------------------------------------
* Description : Routine is used to filter the transaction for configured
*               TRANSACTION.CODE in generic parameter
* Attached to : ENQUIRY>JBWW.E.FT.DATECHECK.LIST
* Attached as : BUILD.ROUTINE
**----------------------------------------------------------------------------------------------
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.XX.CCYCUTOFF.RULE
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    GOSUB DISP.ERR

    RETURN

INIT:
*****
* !! Initialise and open the necessary files ;

    Y.SOFTBLOCK.ARRAY = ''
    REC.GEN.FT.DATA = ''
    REC.CCY.RULE = ''
    REC.FT.DATA = ''
    REC.FT = ''
    ERR.FT = ''

    FN.JBWW.H.XX.CCYCUTOFF.RULE = 'F.JBWW.H.XX.CCYCUTOFF.RULE'
    F.JBWW.H.XX.CCYCUTOFF.RULE = ''
    CALL OPF(FN.JBWW.H.XX.CCYCUTOFF.RULE,F.JBWW.H.XX.CCYCUTOFF.RULE)

    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    F.JBWW.H.XX.SOFTBLOCK = ''
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)
* JB2A-59121 S
    Y.APPL = 'FUNDS.TRANSFER'
    Y.FLD =  'L.FT.VALDT.CHKD'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.FLD,Y.FLD.POS)
    Y.VALDT.CHKD.POS = Y.FLD.POS<1,1>
* JB2A-51921 E

    RETURN

*-----------------------------------------------------------------------------

PROCESS:
*******

*!! Read and fetch necessary field values.

    Y.CCYCUTOFF.RULE.ID = 'SYSTEM'
    Y.GENERICPARAM.ID = 'FT.DATE.CHECK.TRANS.TYPE'

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.GENERICPARAM.ID,REC.GEN.FT.DATA,F.JBWW.H.EB.GENERICPARAMETER,ERR.GENPARAM)

    IF REC.GEN.FT.DATA THEN
        Y.GEN.PARAM.TRANS.TYPE = REC.GEN.FT.DATA<JBWW.GEN.PAR.FIELD.VALUE>
    END


    CALL F.READ(FN.JBWW.H.XX.CCYCUTOFF.RULE,Y.CCYCUTOFF.RULE.ID,REC.CCY.RULE,F.JBWW.H.XX.CCYCUTOFF.RULE,ERR.CUTOFF)

    IF REC.CCY.RULE THEN
        Y.CUTOFF.CCY = REC.CCY.RULE<JHXCR.CURRENCY>
        CCY.CUT.OFF.VAL = REC.CCY.RULE<JHXCR.CUT.OFF.RULE>
    END

    SEL.CMD = "SELECT ":FN.JBWW.H.XX.SOFTBLOCK:" WITH OVERALL.STATUS NE 'REJECT' AND APPLICATION EQ 'FUNDS.TRANSFER' AND CREDIT.READY EQ 'YES' "

    LOCATE "@ID" IN ENQ.DATA<2,1> SETTING Y.POS THEN
    Y.TRANS.ID = ENQ.DATA<4,Y.POS>
    IF Y.TRANS.ID THEN
        SEL.CMD := " AND @ID EQ ":Y.TRANS.ID
    END
    END

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)

    IF SEL.LIST THEN
        LOOP
            REMOVE Y.SOFTBLOCK.ID FROM SEL.LIST SETTING Y.POS
        WHILE Y.SOFTBLOCK.ID:Y.POS
            GOSUB MAIN.PROCESS

        REPEAT
        GOSUB FORM.FINAL.DATA
    END
    RETURN
*-----------------------------------------------------------------------------

MAIN.PROCESS:
************
* !! check the transaction type of selected records;

    Y.TODAY = TODAY
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,Y.SOFTBLOCK.ID,REC.FT.DATA,F.JBWW.H.XX.SOFTBLOCK,ERR.FT)

* (S) - DAY15-1738
*    Y.TRANSACTION.TYPE = REC.FT.DATA<JHXS.TRANSACTION.TYPE>
* (E) - DAY15-1738

    Y.VALUE.DATE = REC.FT.DATA<JHXS.VALUE.DATE>
    Y.CURR = REC.FT.DATA<JHXS.CURRENCY>

* (S) - DAY15-1738
	CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.SOFTBLOCK.ID,REC.FT,F.FUNDS.TRANSFER.NAU,ERR.FTT)
	Y.TRANSACTION.TYPE = REC.FT<FT.TRANSACTION.TYPE>
* (E) - DAY15-1738
	
    LOCATE Y.TRANSACTION.TYPE IN Y.GEN.PARAM.TRANS.TYPE<1,1,1> SETTING Y.TRANS.POS THEN
      GOSUB CHECK.FT.REC.STATUS
*    GOSUB CHECK.DATA
    END
    RETURN

*-----------------------------------------------------------------------------

CHECK.FT.REC.STATUS:
*******************
* GOSUB introduced as a part of RL- 160  requirement

* (S) - DAY15-1738
*    CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.SOFTBLOCK.ID,REC.FT,F.FUNDS.TRANSFER.NAU,ERR.FTT)
* (E) - DAY15-1738

    Y.FT.STATUS = REC.FT<FT.RECORD.STATUS>
* JB2A-51921 S
*    IF Y.FT.STATUS EQ 'INA2' THEN
    Y.VALDT.CHKD = ''
    Y.VALDT.CHKD = REC.FT<FT.LOCAL.REF,Y.VALDT.CHKD.POS>
    IF (Y.FT.STATUS EQ 'INA2' AND Y.VALDT.CHKD EQ "") OR (Y.FT.STATUS EQ 'INAU' AND Y.VALDT.CHKD EQ "MAKER") THEN
        * JB2A-51921 E
        GOSUB CHECK.DATA
    END
    RETURN

*-----------------------------------------------------------------------------

CHECK.DATA:
**********
* !! check the currency of selected records

    LOCATE Y.CURR IN Y.CUTOFF.CCY<1,1> SETTING Y.CUR.POS THEN
    CCY.RULE.VAL = CCY.CUT.OFF.VAL<1,Y.CUR.POS>

    IF CCY.RULE.VAL EQ '0' THEN
        CUT.OFF.DATE = Y.VALUE.DATE
    END ELSE
        VAL.DATE = CCY.RULE.VAL
        VAL.DATE = '-':VAL.DATE:'W'
        CUT.OFF.DATE = Y.VALUE.DATE
        CALL CDT("",CUT.OFF.DATE,VAL.DATE)
    END
    IF CUT.OFF.DATE LT Y.TODAY THEN
        Y.SOFTBLOCK.ARRAY<-1> = Y.SOFTBLOCK.ID

    END
    END ELSE
    Y.SOFTBLOCK.ARRAY<-1> = Y.SOFTBLOCK.ID
    END

    RETURN
*-----------------------------------------------------------------------------

FORM.FINAL.DATA:
****************
* !! Form final data array to be displayed in enquiry.

    CHANGE FM TO ' ' IN Y.SOFTBLOCK.ARRAY
    ENQ.DATA<2,1> = '@ID'
    ENQ.DATA<3,1> = 'EQ'
    ENQ.DATA<4,1> =  Y.SOFTBLOCK.ARRAY
    RETURN

*-----------------------------------------------------------------------------

DISP.ERR:
********
* !! Display error when no records are selected.

    IF Y.SOFTBLOCK.ARRAY EQ '' THEN
        ENQ.ERROR = 'NO RECORDS FOUND MATCHING THE SELECTION CRITERIA'
    END
    RETURN
*-----------------------------------------------------------------------------
    END

