SUBROUTINE JB.R.PP.ENRICHMENT.ID
*----------------------------------------------------------------------------------------------------------------------
* This is an ID routine attached for Payment Order & Order Entry at version control
* level to enrich Short Title from account table for Debit Account field
* Attached in VERSION.CONTROL>PAYMENT ORDER & PP.ORDER.ENTRY
*----------------------------------------------------------------------------------------------------------------------
* Modification History :
*----------------------------------------------------------------------------------------------------------------------
* Date         Resource           JIRA Ref          Remarks
*
* 01-Mar-2025  u40786             CBPAY-2085        Initial Version
*
* 01-Apr-2025  Prabhu D S         CBPAY-2161        Enrichment not populated when user input CRM ref instead of T24 ref
*
* 02-Apr-2025  Prabhu D S         CBPAY-2208        Enrichment for Charge Bearer populated for Checker to know BEN/OUR/SHA
*
* 03-May-2025  u40786             CBPAY-2266        Enchanced to support 2 pattern of GPM definition
*                                                   Pattern.1 PrimaryApplicationFieldNo*AlternateApplicationName*SecondaryApplicationName*SecondaryApplicationField
*                                                   Pattern.2 PrimaryApplicationFieldNo**SecondaryApplicationName*SecondaryApplicationField
*
* 17-May-2025   Resmi R           CBPAY-2898        Fixed the logic where enrichment for charge bearer to be populated for Checker
*
* 19-Jun-2025   Vikram Pavuluru   CBPAY-3336        Enchanced the logic for POR.POSTING.REVERSAL APPLICATION for 'I' Function.
*
* 26-Jun-2025   Vikram Pavuluru   CBPAY-3336        Removed Enrichment for ordering account for reversal of payments.
*----------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.STANDARD.SELECTION      ; * CBPAY-2266 - S/E
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.POSTING.REVERSAL
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CATEGORY
    
    
    
    YFUNCTION = 'S':@VM:'R':@VM:'A':@VM:'I':@VM:'D'
    IF V$FUNCTION MATCHES YFUNCTION AND GTSACTIVE AND OFS$SOURCE.REC<OFS.SRC.SOURCE.TYPE> EQ 'SESSION' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
    
* CBPAY-3336 - Enhancement of logic for POR.POSTING.REVERSAL for V$FUNCTION Equals to "I"
    IF APPLICATION EQ 'POR.POSTING.REVERSAL' AND V$FUNCTION EQ 'I' THEN
        
        FN.POR.POSTING.REVERSAL = "F.POR.POSTING.REVERSAL"
        FV.POR.POSTING.REVERSAL = ""
        FN.POR.TRANSACTION = "F.POR.TRANSACTION"
        FV.POR.TRANSACTION = ""
        FN.ACCOUNT = "F.ACCOUNT"
        FV.ACCOUNT = ""
        FN.CATEGORY = "F.CATEGORY"
        FV.CATEGORY = ""
            
        CALL OPF(FN.POR.POSTING.REVERSAL,FV.POSTING.REVERSAL)
        CALL OPF(FN.POR.TRANSACTION,FV.POR.TRANSACTION)
        CALL OPF(FN.ACCOUNT,FV.ACCOUNT)
        CALL OPF(FN.CATEGORY,FV.CATEGORY)
        Y.FT.NO = FIELD(COMI,"-",2)
        CALL F.READ(FN.POR.POSTING.REVERSAL,Y.FT.NO,R.POST.REV.REC,FV.POR.POSTING.REVERSAL,PORR.ERR)
        CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FN.POR.TRANSACTION,PORT.ERR)
        IF R.POR.TRANSACTION.REC THEN
            Y.CREDIT.ACC = R.POR.TRANSACTION.REC<PPPTX.CreditMainAccount>
            Y.DEBIT.ACC = R.POR.TRANSACTION.REC< PPPTX.DebitMainAccount>
            GOSUB ACCT.SHORT.TITLE
        END
    END
*
RETURN
*
****************
ACCT.SHORT.TITLE:
****************
    CALL F.READ(FN.ACCOUNT,Y.CREDIT.ACC,R.CRACC.REC,FV.ACCOUNT,ACC.ERR)
    CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACC,R.DRACC.REC,FV.ACCOUNT,ACC.ERR)
    
    BEGIN CASE
        
        CASE Y.DEBIT.ACC[1,2] EQ 'PL' AND Y.CREDIT.ACC[1,2] NE 'PL'
            OFS$ENRI<PPPRP.CreditMainAccount> = R.CRACC.REC<AC.SHORT.TITLE>
            Y.DEBT.LEN = LEN(Y.DEBIT.ACC)
            Y.DEBT.PL = Y.DEBIT.ACC[3,Y.DEBT.LEN]
            CALL F.READ(FN.CATEGORY,Y.DEBT.PL,R.DRCATEGORY.REC,FV.CATEGORY,CAT.ERR)
            OFS$ENRI<PPPRP.DebitMainAccount> = R.DRCATEGORY.REC<EB.CAT.SHORT.NAME>
            
        CASE  Y.DEBIT.ACC[1,2] NE 'PL' AND Y.CREDIT.ACC[1,2] EQ 'PL'
            OFS$ENRI<PPPRP.DebitMainAccount> = R.DRACC.REC<AC.SHORT.TITLE>
            Y.CRED.LEN = LEN(Y.CREDIT.ACC)
            Y.CRED.PL = Y.CREDIT.ACC[3,Y.CRED.LEN]
            CALL F.READ(FN.CATEGORY,Y.CRED.PL,R.CRCATEGORY.REC,FV.CATEGORY,CAT.ERR)
            OFS$ENRI<PPPRP.CreditMainAccount> = R.CRCATEGORY.REC<EB.CAT.SHORT.NAME>
            
        CASE Y.DEBIT.ACC[1,2] EQ 'PL' AND Y.CREDIT.ACC[1,2] EQ 'PL'
            Y.DEBT.LEN = LEN(Y.DEBIT.ACC)
            Y.CRED.LEN = LEN(Y.CREDIT.ACC)
            Y.DEBT.PL = Y.DEBIT.ACC[3,Y.DEBT.LEN]
            Y.CRED.PL = Y.CREDIT.ACC[3,Y.CRED.LEN]
            CALL F.READ(FN.CATEGORY,Y.DEBT.PL,R.CRCATEGORY.REC,FV.CATEGORY,CAT.ERR)
            CALL F.READ(FN.CATEGORY,Y.CRED.PL,R.DRCATEGORY.REC,FV.CATEGORY,CAT.ERR)
            OFS$ENRI<PPPRP.CreditMainAccount> = R.CRCATEGORY.REC<EB.CAT.SHORT.NAME>
            OFS$ENRI<PPPRP.DebitMainAccount> = R.DRCATEGORY.REC<EB.CAT.SHORT.NAME>
            
        CASE Y.DEBIT.ACC[1,2] NE 'PL' AND Y.CREDIT.ACC[1,2] NE 'PL'
            OFS$ENRI<PPPRP.CreditMainAccount> = R.CRACC.REC<AC.SHORT.TITLE>
            OFS$ENRI<PPPRP.DebitMainAccount> = R.DRACC.REC<AC.SHORT.TITLE>
        
    END CASE
       
RETURN

* CBPAY-3336

*****
INIT:
*****
    
    GPM.PARAM.NAME = APPLICATION
    
    FN.APPLN = 'F.':APPLICATION
    F.APPLN = ''
    CALL OPF(FN.APPLN,F.APPLN)
    
    FN.APPLN.NAU = 'F.':APPLICATION:'$NAU'
    F.APPLN.NAU = ''
    CALL OPF(FN.APPLN.NAU,F.APPLN.NAU)
    
    APPLN.ID = COMI
    
    R.APPLN = ''
    E.APPLN = ''
    CALL F.READ(FN.APPLN,APPLN.ID,R.APPLN,F.APPLN,E.APPLN)
    
    IF NOT(R.APPLN) THEN
        R.APPLN = ''
        E.APPLN.NAU = ''
        CALL F.READ(FN.APPLN.NAU,APPLN.ID,R.APPLN,F.APPLN.NAU,E.APPLN.NAU)
    END
    
    GPM.PARAM.VALUE = ''
    CALL JBWW.R.EB.GETGENPARM.VAL('JB.D.PP.TPH.ENRICH',GPM.PARAM.NAME,GPM.PARAM.VALUE)
    
    CONVERT @VM TO "#" IN GPM.PARAM.VALUE       ; * CBPAY-2266 - S
    GPM.PARAM.VALUE = EREPLACE(GPM.PARAM.VALUE,"|#","")
    CONVERT "#" TO @VM IN GPM.PARAM.VALUE
    
    Y.APPLICATION = APPLICATION
    R.SS = ''
    CALL GET.STANDARD.SELECTION.DETS(Y.APPLICATION,R.SS)
    Y.LOGICAL.ORDER = R.SS<SSL.LOGICAL.ORDER>
    Y.PHYSICAL.ORDER = R.SS<SSL.PHYSICAL.ORDER>
    CHANGE " " TO @VM IN Y.LOGICAL.ORDER
    CHANGE " " TO @VM IN Y.PHYSICAL.ORDER   ; * CBPAY-2266 - E
    
    PREVIOUS.ALTERNATE.APPL = ''
*
RETURN
*
********
PROCESS:
********

    FLD.COUNT = DCOUNT(GPM.PARAM.VALUE,@VM)

    FOR CNT = 1 TO FLD.COUNT
        
        FLD.NAME = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',1)
        ALTERNATE.APPL = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',2)
        ENRICH.APPL = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',3)
        ENRICH.FLD = FIELD(GPM.PARAM.VALUE<1,CNT>,'*',4)
                
        FLD.ERR = ''
        APPLN.NAME = GPM.PARAM.NAME
        FLD.POS = ''
        CALL JBWW.B.XX.GET.FIELDPOS(APPLN.NAME,FLD.NAME,FLD.POS,FLD.ERR)

        LOCATE FLD.POS IN Y.PHYSICAL.ORDER<1,1> SETTING Y.PHYSICAL.FLD.POS THEN     ; * CBPAY-2266 - S
*FLD.VALUE = R.APPLN<FLD.POS>
            FLD.VALUE = R.APPLN<Y.PHYSICAL.FLD.POS>
        END
    
        IF (APPLICATION EQ "PP.ORDER.ENTRY" OR APPLICATION EQ "POR.POSTING.REVERSAL") AND FLD.VALUE[1,2] EQ "PL" AND ENRICH.APPL THEN
            Y.GPM.PARAM.NAME = FLD.VALUE[1,2]
            Y.GPM.PARAM.VALUE = ''
            CALL JBWW.R.EB.GETGENPARM.VAL('JB.D.PP.TPH.ENRICH',Y.GPM.PARAM.NAME,Y.GPM.PARAM.VALUE)
            FLD.VALUE = FLD.VALUE[3,LEN(FLD.VALUE)]
            ALTERNATE.APPL = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',2)
            ENRICH.APPL = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',3)
            ENRICH.FLD = FIELD(Y.GPM.PARAM.VALUE<1,1>,'*',4)
        END      ; * CBPAY-2266 - E

        BEGIN CASE
*CASE ALTERNATE.APPL    ; * CBPAY-2266 - S
            CASE ALTERNATE.APPL AND FLD.VALUE       ; * CBPAY-2266 - E
                GOSUB ENRICH.PATTERN.1
*CASE NOT(ALTERNATE.APPL)       ; * CBPAY-2266 - S
            CASE NOT(ALTERNATE.APPL) AND FLD.VALUE      ; * CBPAY-2266 - E
                GOSUB ENRICH.PATTERN.2
        END CASE
        
    NEXT CNT
    
    GOSUB PO.CHG.SPECIALHANDLING
*
RETURN
*
*****************
ENRICH.PATTERN.1:
*****************

*IF ALTERNATE.APPL NE PREVIOUS.ALTERNATE.APPL THEN; * CBPAY-2266 - S/E
    FN.ALTERNATE.APPL = 'F.':ALTERNATE.APPL
    F.ALTERNATE.APPL = ''
    CALL OPF(FN.ALTERNATE.APPL,F.ALTERNATE.APPL)
    CALL F.READ(FN.ALTERNATE.APPL,FLD.VALUE,YR.ENRICH.APPL,F.ALTERNATE.APPL,E.ENRICH.APPL)
    IF YR.ENRICH.APPL THEN
        FLD.VALUE = YR.ENRICH.APPL<1>
    END
*END    ; * CBPAY-2266 - S/E
    
    IF ENRICH.APPL THEN     ; * CBPAY-2266 - S/E
        GOSUB ENRICH.PATTERN.2
    END     ; * CBPAY-2266 - S/E
    PREVIOUS.ALTERNATE.APPL = ALTERNATE.APPL
*
RETURN
*
*****************
ENRICH.PATTERN.2:
*****************

    FN.ENRICH.APPL = 'F.':ENRICH.APPL
    F.ENRICH.APPL = ''
    CALL OPF(FN.ENRICH.APPL,F.ENRICH.APPL)
    
    YR.ENRICH.APPL = ''
    E.ENRICH.APPL = ''
    CALL F.READ(FN.ENRICH.APPL,FLD.VALUE,YR.ENRICH.APPL,F.ENRICH.APPL,E.ENRICH.APPL)
    IF YR.ENRICH.APPL THEN      ; * CBPAY-2266 - S/E
        FLD.ERR = ''
        APPLN.NAME = ENRICH.APPL
        ENRICH.FLD.POS = ''
        CALL JBWW.B.XX.GET.FIELDPOS(APPLN.NAME,ENRICH.FLD,ENRICH.FLD.POS,FLD.ERR)
*LOCATE FLD.POS IN Y.LOGICAL.ORDER<1,1> SETTING LOGIC.FLD.POS THEN      ; * CBPAY-2266 - S
        OFS$ENRI<FLD.POS> = YR.ENRICH.APPL<ENRICH.FLD.POS>
*OFS$ENRI<LOGIC.FLD.POS> = YR.ENRICH.APPL<ENRICH.FLD.POS>
*END
    END     ; * CBPAY-2266 - E
*
RETURN
*
***********************
PO.CHG.SPECIALHANDLING:
***********************

    CALL JBWW.B.XX.GET.FIELDPOS(APPLICATION,"CHARGE.BEARER",ENRICH.FLD.POS,FLD.ERR)

    FN.PAYMENT.ORDER = "F.PAYMENT.ORDER"
    F.PAYMENT.ORDER = ""
    CALL OPF(FN.PAYMENT.ORDER, F.PAYMENT.ORDER)

    FN.PAYMENT.ORDER.NAU = "F.PAYMENT.ORDER$NAU"
    F.PAYMENT.ORDER.NAU = ""
    CALL OPF(FN.PAYMENT.ORDER.NAU, F.PAYMENT.ORDER.NAU)

    R.PAYMENT.ORDER = ''
    PO.ID = COMI
    CALL F.READ(FN.PAYMENT.ORDER,PO.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,'')
    IF NOT(R.PAYMENT.ORDER) THEN
        CALL F.READ(FN.PAYMENT.ORDER.NAU,PO.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER.NAU,'')
    END
    IF R.PAYMENT.ORDER THEN     ; * CBPAY-2266 - S/E
        ENRI.VALUE = R.PAYMENT.ORDER<PO.CHARGE.BEARER>
    END

    OFS$ENRI<ENRICH.FLD.POS> = ENRI.VALUE

*
RETURN
*********************************************************************************************************************
END
*
