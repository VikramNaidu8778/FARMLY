SUBROUTINE JBWW.R.FT.DEFPLACCT.CCY
*-----------------------------------------------------------------------------
* Description:
* Attached as an validation routine(to both DB ACCT/CR ACCT) to defualt the customer account currency in PL side for 
* the following versions
* FUNDS.TRANSFER,JBWW.AC.REFDBNKSRVFEE.INP
* FUNDS.TRANSFER,JBWW.V.AA.ACCR.INP             
* FUNDS.TRANSFER,JBWW.V.FT.FEECHRG.INP
* FUNDS.TRANSFER,JBWW.V.FT.REFUNDS.INP
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Initial Creation
* Date         who               Reference     Description
* 20-02-2018   MaheshKumar   	 JB2A-48744    Intial
* 02-03-2018   MaheshKumar       JB2A-48744    Reviesed the to attach as hot validate rtn to DR/CR ACCT
* 15-03-2018   Maheshkumar       JB2A-49834    
*------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
*----------------------------------------------------------------------------
  IF MESSAGE NE 'VAL' THEN 
    IF V$FUNCTION EQ 'I' OR V$FUNCTION EQ 'C' THEN 
        GOSUB INIT
        GOSUB PROCESS
    END
  END
    RETURN
*-----------------------------------------------------------------------------
*****
INIT:
*****
   FN.ACCOUNT = 'F.ACCOUNT'
   F.ACCOUNT = ''
   CALL OPF(FN.ACCOUNT,F.ACCOUNT)
   RETURN
*--------------------------------------------------------------------------------
PROCESS:
******** 
   Y.ACC.ID = ''
   BEGIN CASE 
   CASE AF EQ FT.CREDIT.ACCT.NO
     IF COMI NE '' THEN 
        Y.ACC.ID  = COMI
     END ELSE 
        Y.ACC.ID  = R.NEW(FT.CREDIT.ACCT.NO)
     END
     GOSUB READ.ACCOUNT
     GOSUB POPULATE.CCY
     IF Y.ACC.ID[1,2] EQ 'PL' AND R.NEW(FT.DEBIT.CURRENCY) NE '' THEN 
      R.NEW(FT.CREDIT.CURRENCY) = R.NEW(FT.DEBIT.CURRENCY)
     END 
   CASE AF EQ FT.DEBIT.ACCT.NO
     IF COMI NE '' THEN
        Y.ACC.ID  = COMI
     END ELSE
        Y.ACC.ID  = R.NEW(FT.DEBIT.ACCT.NO)
     END
     GOSUB READ.ACCOUNT
     GOSUB POPULATE.CCY
     IF Y.ACC.ID[1,2] EQ 'PL' AND R.NEW(FT.CREDIT.CURRENCY) NE '' THEN
      R.NEW(FT.DEBIT.CURRENCY) = R.NEW(FT.CREDIT.CURRENCY)
     END
   END CASE 
   RETURN
*--------------------------------------------------------------------------------
READ.ACCOUNT:
************
   IF Y.ACC.ID THEN 
       R.ACC = '' ; Y.ACC.ERR = ''
       CALL F.READ(FN.ACCOUNT,Y.ACC.ID,R.ACC,F.ACCOUNT,Y.ACC.ERR)
	   IF R.ACC THEN
                   Y.ACC.CCY = R.ACC<AC.CURRENCY>
		   *R.NEW(FT.CREDIT.CURRENCY) = R.ACC<AC.CURRENCY>
		   *R.NEW(FT.DEBIT.CURRENCY) = R.ACC<AC.CURRENCY>
		   *CALL REBUILD.SCREEN()
	   END
   END
   RETURN
*--------------------------------------------------------------------------------
POPULATE.CCY:
*************
IF Y.ACC.CCY THEN
  BEGIN CASE
    CASE AF EQ FT.CREDIT.ACCT.NO
         IF R.NEW(FT.DEBIT.ACCT.NO)[1,2] EQ 'PL' THEN 
           R.NEW(FT.CREDIT.CURRENCY) = Y.ACC.CCY
           R.NEW(FT.DEBIT.CURRENCY) = Y.ACC.CCY
         END ELSE 
           R.NEW(FT.CREDIT.CURRENCY) = Y.ACC.CCY
         END 
    CASE AF EQ FT.DEBIT.ACCT.NO     
          IF R.NEW(FT.CREDIT.ACCT.NO)[1,2] EQ 'PL' THEN
           R.NEW(FT.CREDIT.CURRENCY) = Y.ACC.CCY
           R.NEW(FT.DEBIT.CURRENCY) = Y.ACC.CCY
          END ELSE 
            R.NEW(FT.DEBIT.CURRENCY) = Y.ACC.CCY
          END 
  END CASE
  CALL REBUILD.SCREEN()
END
  RETURN
*--------------------------------------------------------------------------------
END
