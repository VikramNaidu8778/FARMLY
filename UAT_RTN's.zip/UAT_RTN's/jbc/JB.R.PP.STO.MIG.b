SUBROUTINE JB.R.PP.STO.MIG
*-----------------------------------------------------------------------------
* Description : STO Migration Routine , to nullify the Benefiary field.
* Attached to : Version STO,JB.V.AC.OFS
* Attached as : Check Rec Routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*
* 26-Jun-2025   P Amala                                CBPAY-1935
* -----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER

*
    Y.BENE.CMT = R.NEW(STO.BENEFICIARY)
    Y.CNT = DCOUNT(Y.BENE.CMT,VM)

    R.NEW(STO.BENEFICIARY)<1,1> = ''
	   
    IF Y.CNT GE '2' THEN
        FOR Y.LOOP.CNT = Y.CNT TO 2 STEP -1
            R.NEW(STO.BENEFICIARY)<1,Y.LOOP.CNT> = ''
            DEL R.NEW(STO.BENEFICIARY)<1,Y.LOOP.CNT>     ; *Delete should happen from Reverse Order.
        NEXT
    END
RETURN
*-----------------------------------------------------------------------------
END
