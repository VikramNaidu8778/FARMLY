* @ValidationCode : MTo1NzYxOTM1NjpJU08tODg1OS0xOjE2MDMxOTk4MjY2NTg6YTQwNzcwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4w
* @ValidationInfo : Timestamp         : 20 Oct 2020 21:17:06
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40770
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.XX.DOHREFUPD.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.JBWW.L.XX.DOHREF.CONCAT
$INSERT I_F.SFCONF.CONFIRMATION.TRACKER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS

RETURN
INIT:
*****
    FN.JBWW.L.XX.DOHREF.CONCAT = 'F.JBWW.L.XX.DOHREF.CONCAT'
    F.JBWW.L.XX.DOHREF.CONCAT = ''
    CALL OPF(FN.JBWW.L.XX.DOHREF.CONCAT,F.JBWW.L.XX.DOHREF.CONCAT)

RETURN
PROCESS:
********

    DOH.ID = R.NEW(SFCONF.CNTR.OUTWARD.DEL.REF)
    DIH.ID = R.NEW(SFCONF.CNTR.INWARD.DEL.REF)

    IF DOH.ID THEN    
        R.DOHREF.ARRAY<DOHREF.CON.InwardDelRef> = DIH.ID
        CALL F.WRITE(FN.JBWW.L.XX.DOHREF.CONCAT,DOH.ID,R.DOHREF.ARRAY)        
    END

RETURN
END
