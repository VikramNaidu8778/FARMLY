*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.ACIACASHACCT.CHK
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is input routine to throw error if transaction type is equal to ACIA
* and account both are cash account.
*-------------------------------------------------------------------------
* Attached: As input routine to PAYMENT.ORDER,JB.V.PP.INTERNAL.INP
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
*
* Revision History:
*---------------------------------------------------------------------------------------------------------------------
* Date             Developer        Reference       Description
*03-06-2024        Hariharan T      CBPAY-81        Input routine attached to version PO,JB.V.PP.INTERNAL.INP to
*                                                   validate both legs of transaction as Cash Account and throw error.
*19-Apr-2025        Kandan.K        CBPAY-2535      Income Account check is applicable only if Field Debit
*                                                   and Credit Account is entered.
*---------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.PAYMENT.ORDER

    GOSUB OPEN.FILES
	
    IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) = 'ACIA' THEN
        GOSUB PROCESS
    END

RETURN

*============
OPEN.FILES:
*============
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
    
RETURN

*==============
PROCESS:
*==============

    Y.CASH.FLAG = '' ; Y.ACCOUNT = '' ; Y.DR.CASH.FLAG = '' ;
    Y.ACCOUNT = R.NEW(PO.DEBIT.ACCOUNT)
    IF Y.ACCOUNT THEN
        GOSUB CHECK.ACCOUNT.SAM
        Y.DR.CASH.FLAG = Y.CASH.FLAG
    END

    Y.ACCOUNT = '' ; Y.CASH.FLAG = '' ; Y.CR.CASH.FLAG = '' ;
    Y.ACCOUNT = R.NEW(PO.CREDIT.ACCOUNT)
    IF Y.ACCOUNT THEN
        GOSUB CHECK.ACCOUNT.SAM
        Y.CR.CASH.FLAG = Y.CASH.FLAG
    END

    IF Y.DR.CASH.FLAG EQ '1' AND Y.CR.CASH.FLAG EQ '1' THEN
        ETEXT = "FT-JBWW.D.FT.ACIA.TRANS.PORTFOLIO"
        AF = PO.DEBIT.ACCOUNT
        CALL STORE.END.ERROR
    END

RETURN

*=================
CHECK.ACCOUNT.SAM:
*================
    
    CALL JB.R.PP.GETSAMACC.RTN(Y.ACCOUNT,Y.SAM.ID)
    R.SAM = '' ; SAM.ERR = '' ; Y.CASH.FLAG = ''
    CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
    IF R.SAM NE '' THEN
        Y.CASH.ACCT.LIST = R.SAM<SC.SAM.ACCOUNT.NOS>
        INC.POS = ''
        LOCATE Y.ACCOUNT IN Y.CASH.ACCT.LIST<1,1> SETTING INC.POS THEN
            Y.CASH.FLAG = '1'
        END
    END

RETURN
********************************************************
END
