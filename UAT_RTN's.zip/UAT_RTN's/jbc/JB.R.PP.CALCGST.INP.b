SUBROUTINE JB.R.PP.CALCGST.INP
*---------------------------------------------------------------------------------------------------
* This routine is to calculate GST for GST belonging customers when they involved in Debit / credit
* and debit / credit to PL (Only for mentioned categories in Parameter table JB.R.XX.FT.GST).
* Attached in PAYMENT.ORDER,JB.V.PP.REFUNDS.INP & PAYMENT.ORDER,JB.V.PP.FEECHRG.INP
* Attached as Input Routine.
*
* Modification History
* --------------------------------------------------------------------------------------------------
*  Date        Ref             Developer           Remarks
* 04-03-2025   CBPAY-2051      Prabhu D S          Initial Draft
*---------------------------------------------------------------------------------------------------
   $INSERT I_COMMON
   $INSERT I_EQUATE
   $INSERT I_F.CUSTOMER
   $INSERT I_F.ACCOUNT
   $INSERT I_F.PAYMENT.ORDER
   $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

   GOSUB INIT
   GOSUB GET.CUSTOMER.STATUS
   GOSUB DEFAULT.MSG.PRIORITY

RETURN
*****
INIT:
*****

   FN.CUSTOMER = 'F.CUSTOMER'
   F.CUSTOMER = ''
   CALL OPF(FN.CUSTOMER,F.CUSTOMER)

   FN.ACCOUNT = 'F.ACCOUNT'
   F.ACCOUNT = ''
   CALL OPF(FN.ACCOUNT,F.ACCOUNT)
 
   FN.GPM = 'F.JBWW.H.EB.GENERICPARAMETER'
   F.GPM = ''
   CALL OPF(FN.GPM,F.GPM)

   Y.DR.ACC = ''
   R.DR.ACC = ''
   AC.ERR = ''
   Y.CUS.ID = ''
   R.CUS.REC = ''
   CUS.ERR = ''
   Y.CUS.LOC.FLD.POS = ''
   Y.CUS.BELONG.STATUS = ''
   Y.DR.ACC = R.NEW(PO.DEBIT.ACCOUNT)
   Y.CR.PL = R.NEW(PO.CREDIT.PL)
   Y.CR.ACC = R.NEW(PO.CREDIT.ACCOUNT)
   Y.DR.PL = R.NEW(PO.DEBIT.PL)

   CALL JBWW.R.EB.GETGENPARM.VAL("JB.R.XX.FT.GST","ALLOWED.FT.PL.CATEGORY",PL.CATEG.LIST)
   CHANGE ' ' TO VM IN PL.CATEG.LIST
   CHANGE FM TO VM IN PL.CATEG.LIST

   CALL MULTI.GET.LOC.REF("CUSTOMER","BELONG.STATUS",Y.CUS.LOC.FLD.POS)

RETURN
********************
GET.CUSTOMER.STATUS:
********************

  BEGIN CASE
     CASE Y.CR.PL AND Y.DR.ACC
        Y.ACC.ID = Y.DR.ACC
        Y.PL.ID = Y.CR.PL
   
     CASE Y.DR.PL AND Y.CR.ACC
        Y.ACC.ID = Y.CR.ACC
        Y.PL.ID = Y.DR.PL

  END CASE

  CALL F.READ(FN.ACCOUNT,Y.ACC.ID,R.DR.ACC,F.ACCOUNT,AC.ERR)
  IF NOT(AC.ERR) THEN
     Y.CUS.ID = R.DR.ACC<AC.CUSTOMER>
     CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUS.REC,F.CUSTOMER,CUS.ERR)
     IF NOT(CUS.ERR) THEN
        Y.CUS.BELONG.STATUS = R.CUS.REC<EB.CUS.LOCAL.REF,Y.CUS.LOC.FLD.POS>
     END
  END

RETURN
*********************
DEFAULT.MSG.PRIORITY:
*********************

  IF Y.CUS.BELONG.STATUS EQ 'Y' AND Y.PL.ID MATCHES PL.CATEG.LIST THEN
      R.NEW(PO.MESSAGE.PRIORITY) = 2
  END

RETURN
END
