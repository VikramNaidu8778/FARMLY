SUBROUTINE JB.R.PP.DEFORDTYPE.INPUT
*-----------------------------------------------------------------------------------------------------------------------
*-----------------------------------------------------------------------------------------------------------------------
*Description:
*-----------------------------------------------------------------------------------------------------------------------
* This Routine is attached in below versions for PAYMENT.ORDER & PP.ORDER.ENTRY as INPUT Routine
* Incoming Payment (PP.ORDER.ENTRY,JB.OAT.ISO.O)
* Refunds (PAYMENT.ORDER,JB.V.PP.REFUNDS.INP)
* FEECHRG (PAYMENT.ORDER,JB.V.PP.FEECHRG.INP)
* GST Refunds (PAYMENT.ORDER,JB.V.PP.GSTREFUNDS.INP)
* GST Fee Chrg (PAYMENT.ORDER,JB.V.PP.GSTFEECHG.INP)
* Internal (PAYMENT.ORDER,JB.V.PP.INTERNAL.INP)
* Account to Account Transfer (PAYMENT.ORDER,JB.V.PP.ACAC.INP)
* Incoming pacs.009 (PP.ORDER.ENTRY,JB.V.PP.INCTRCREATE.INP)
*-----------------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: N/A
* OUT: N/A
* Revision History:
*----------------------------------------------------------------------------------------------------------------------
* Date               who               Reference          Description

* 29-JUL-2024        Vikram Pavuluru      CBPAY-673         This routine is to set Order Type as "C" if either
*                                                           side of leg involves Customer account or set as "B"
* 26-Sep-2024        Prabhu DS            CBPAY-973         ACFC | PO Released from IHLD, then validating/committing the record
*                                                           and system displaying the error
* 06-Dec-2024        Lakshmi Priya ks     CBPAY-1408        Updated the code to check the sector of customer only when the payment
*                                                           is book transfer .
* 16-Jan-2025        P Amala              CBPAY-1275        Soft Block Skip for Outgoing pacs.004 for unprocessed incoming pacs.008
*
* 28-Apr-2025        Kandan               CBPAY-2550         Incoming MXCT payment will be considered as Customer Payments
*
*13-May-2025         Resmi R              CBPAY-2826         Included logic to update Transaction Type in the L.PP.DEF.INW.IT field for PP.ORDER.ENTRY
*
*14-May-2025         Lakshmi Priya        CBPAY-2875         Included logic to default Transfer Type as 'C' for all incoming pacs.008 Payments .
*17-May-2025         Prabhu D S           CBPAY-2929         Transaction Type (L.PP.DEF.INW.IT) defaulting logic made generic.
*-----------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY

    GOSUB INIT
    GOSUB PROCESS
    GOSUB UPDATE.TXNTYPE

RETURN
    
INIT:
*****

    Y.CUST.FLAG = 0
        
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
   
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","CLIENT.SECTOR.CODES",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","CUSTOMER.PAY.PRODUCT",Y.CUST.VALUE)
    CHANGE ',' TO VM IN Y.CUST.VALUE
    CHANGE FM TO VM IN Y.CUST.VALUE
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","BANK.PAY.PRODUCT",Y.BANK.VALUE)
    CHANGE ',' TO VM IN Y.BANK.VALUE
    CHANGE FM TO VM IN Y.BANK.VALUE
    
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","TIS.MSGTYPE",Y.TISMSGTYP.VAL)
    CHANGE ',' TO VM IN Y.TISMSGTYP.VAL
    CHANGE FM TO VM IN Y.TISMSGTYP.VAL
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","TIS.TXNCODE",Y.TISTXNCD.VAL)
    CHANGE ',' TO VM IN Y.TISTXNCD.VAL
    CHANGE FM TO VM IN Y.TISTXNCD.VAL
    
    
    Y.PAY.PRODUCT = R.NEW(PO.PAYMENT.ORDER.PRODUCT)

*CBPAY-1275 - Start

    Y.FIELD.VALUE = '' ; Y.RLC.SOURCE = '' ; Y.INMSG.TYPE = ''
    Y.FIELD.NAME = "INSOURCE.RLC":@FM:"INMSG.TYPE"
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.FIELD.NAME,Y.FIELD.VALUE)

    Y.RLC.SOURCE = Y.FIELD.VALUE<1>
    Y.INMSG.TYPE = Y.FIELD.VALUE<2>

    CHANGE ',' TO @VM IN Y.RLC.SOURCE
    CHANGE @FM TO @VM IN Y.RLC.SOURCE
    
    CHANGE ',' TO @VM IN Y.INMSG.TYPE
    CHANGE @FM TO @VM IN Y.INMSG.TYPE

    Y.OE.STATUS = '' ; Y.OE.SOURCE = '' ; Y.OE.DIRECTION = ''
    Y.OE.MSGTYPE = '' ; Y.OE.RETPAY = ''

*CBPAY-1275 - End


   CALL GET.LOC.REF("PP.ORDER.ENTRY","L.PP.DEF.INW.IT",Y.LOC.REF.FLDS.POS)


RETURN

PROCESS:
********

    BEGIN CASE
        CASE Y.PAY.PRODUCT MATCHES Y.CUST.VALUE
             R.NEW(PO.ORDER.TYPE) = 'CUSTOMER'

        CASE Y.PAY.PRODUCT MATCHES Y.BANK.VALUE
             R.NEW(PO.ORDER.TYPE) = 'BANK'

        CASE OTHERWISE
            GOSUB SECTOR.PROCESS

    END CASE
RETURN
                

SECTOR.PROCESS:
**************

    BEGIN CASE
        CASE APPLICATION EQ 'PAYMENT.ORDER'
            ACCOUNT.ID = R.NEW(PO.DEBIT.ACCOUNT)
            GOSUB CHECK.SECTOR
            ACCOUNT.ID = R.NEW(PO.CREDIT.ACCOUNT)
            GOSUB CHECK.SECTOR
            IF Y.CUST.FLAG THEN
                R.NEW(PO.ORDER.TYPE) = 'CUSTOMER'
            END ELSE
                R.NEW(PO.ORDER.TYPE) = 'BANK'
            END
        
        CASE APPLICATION EQ 'PP.ORDER.ENTRY'
            ACCOUNT.ID = R.NEW(PP.OEYG.CreditAccountNumber)      
            GOSUB CHECK.SECTOR
            ACCOUNT.ID = R.NEW(PP.OEYG.DebitAccountNumber)
            GOSUB CHECK.SECTOR
            IF Y.CUST.FLAG THEN
                R.NEW(PP.OEYG.TransferType) = 'C'
            END ELSE
* Skip Soft Block Check for an Outgoing pacs.004 for unprocessed incoming pacs.008
                GOSUB RLC.CHECK ;* CBPAY-1275
                
            END
    
    END CASE
    
RETURN
    
*************
CHECK.SECTOR:
*************
    
    R.ACCOUNT = ''
    R.CUSTOMER = ''
    CALL F.READ(FN.ACCOUNT, ACCOUNT.ID, R.ACCOUNT, F.ACCOUNT, ACCOUNT.ERR)
    CUSTOMER.ID = R.ACCOUNT<AC.CUSTOMER>

    CALL F.READ(FN.CUSTOMER, CUSTOMER.ID, R.CUSTOMER, F.CUSTOMER, CUSTOMER.ERR)
    Y.SECTOR = R.CUSTOMER<EB.CUS.SECTOR>
    IF Y.SECTOR MATCHES Y.GPM.VALUE THEN
        Y.CUST.FLAG = 1
    END
    
RETURN

* CBPAY-1275 - Start
**********
RLC.CHECK:
**********

* Retain TransferType as 'C' if the incoming pacs.008 message not processed successfully and return the payment with pacs.004

    Y.OE.SOURCE = R.NEW(PP.OEYG.Source)
    Y.OE.DIRECTION = R.NEW(PP.OEYG.Direction)
    Y.OE.MSGTYPE = R.NEW(PP.OEYG.IncomingMessageType)
    Y.OE.RETPAY = R.NEW(PP.OEYG.ReturnPayment)

    BEGIN CASE
        
        CASE Y.OE.DIRECTION EQ 'I' AND Y.OE.RETPAY EQ 'Return'
            IF (Y.OE.SOURCE MATCHES Y.RLC.SOURCE) AND (Y.OE.MSGTYPE MATCHES Y.INMSG.TYPE) THEN
                R.NEW(PP.OEYG.TransferType) = 'C'
            END
        CASE Y.OE.DIRECTION EQ 'I' AND Y.OE.MSGTYPE EQ 'pacs.008'
            R.NEW(PP.OEYG.TransferType) = 'C'
* Changes included as part of CBPAY-2550.
* MXCT payment will be always considered as Customer Payments.
        CASE Y.OE.MSGTYPE EQ 'MXCT'
            R.NEW(PP.OEYG.TransferType) = 'C'
    
        CASE OTHERWISE
            R.NEW(PP.OEYG.TransferType) = 'B'
    END CASE

RETURN
*CBPAY-1275 - End

***************
UPDATE.TXNTYPE:
***************

    Y.TXN.TYPE = R.NEW(PP.OEYG.ClearingTransactionType)
    Y.DIRECTION = R.NEW(PP.OEYG.Direction)
    Y.MSG.TYPE = R.NEW(PP.OEYG.IncomingMessageType)

    BEGIN CASE

        CASE Y.TXN.TYPE EQ 'RT'
            Y.MSG.TYPE = 'pacs.004'
       
        CASE Y.TXN.TYPE EQ 'RJ'
            Y.MSG.TYPE = 'pacs.002'
                               
    END CASE
            
    Y.PP.MSG.DIR = Y.MSG.TYPE:"_":Y.DIRECTION
    
    LOCATE Y.PP.MSG.DIR IN Y.TISMSGTYP.VAL<1,1> SETTING Y.POS THEN
        Y.TXN.CODE =  Y.TISTXNCD.VAL<1,Y.POS>
     R.NEW(PP.OEYG.LOCAL.REF)<1,Y.LOC.REF.FLDS.POS> = Y.TXN.CODE
    END
    	
        
RETURN

*******************************
END
