SUBROUTINE JB.R.PP.SWCRRCLPDNGRESP.NOF(OUT.ARR)
*-------------------------------------------------------------------------------------
* This a NoFile enquiry to display Completed Swift Transaction to Initiate
* Return Transfer. Core API used to get list of eligible transactions and then to filter the transactions based on CURRENT USER ROLE.
*Attached to Enquiry JB.E.PP.SWIFTMXOUTCANCELPENDGRESP.VIEW as NOFILE.JB.PP.SWCRRCLPNDG.RESP.
*-------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------
** Date         Developer           Reference       Description
* 22-OCT-2024   Vikram Pavuluru     CBPAY-974       This routine is used to fetch the cancellation records based on user role group.
*-------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.USER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS
    
    
RETURN
    
*****
INIT:
*****
* In this para of the program, the files are initialised **
   
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    FV.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)
    
    OUT.ARR = '' ; Y.ENQ.DATA = '' ; OUT.POS = ''
    Y.FT.NONO = '' ; BP.POS = '' ;  PORS.ERR = ''
    R.POR.SUPPL.INFO.REC = '' ;     Y.USR.GRP = ''

    
RETURN

GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)

    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END
    
RETURN

 
********
PROCESS:
********

    CALL E.NOFILE.PP.SWCR.RECALL.PENDING.RESPONSE(OUT.ARRAY)

    IF OUT.ARRAY THEN
    
        LOOP
            READNEXT Y.ENQ.DATA FROM OUT.ARRAY SETTING OUT.POS
        WHILE Y.ENQ.DATA
            Y.FT.NO = FIELD(Y.ENQ.DATA,"*",5)
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            IF R.POR.SUPPL.INFO.REC THEN
                LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                    Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                    IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                        OUT.ARR<-1> = Y.ENQ.DATA
                    END
                END
            END
        REPEAT

    END

RETURN
***********************************************************************************
END
