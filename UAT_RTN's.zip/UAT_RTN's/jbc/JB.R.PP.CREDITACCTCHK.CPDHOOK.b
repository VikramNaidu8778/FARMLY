* @ValidationCode : MjotMTkyNjA0NDpDcDEyNTI6MTcxNDIxODg1ODMyMjo2NzA5MDk6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjNfQU1SLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 27 Apr 2024 17:24:18
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.CREDITACCTCHK.CPDHOOK(iPaymentKey, iDetermineCreditParty, ARG3.OUT)
*-----------------------------------------------------------------------------
*This routine is used to format the incoming Credit Account number from pacs.008 into the t24 format.
*-----------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                   Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*02/05/2024     Resmi R                     CBPAY-37               Formatting the Incoming Credit Account number as per the requirement
*20/08/2024     Resmi R                     CBPAY-804              Included the logic to handle the Credit Account in case of pacs.009 for SLB Transactions
*18/10/2024     Vikram P                    CBPAY-974              Included the logic to handle Pacs.009(MT200) for SEC USER ROLES for Order Entry Application.
*20/02/2025     Resmi R                     CBPAY-1804             Included the logic to handle the format of incoming Credit Account Number as per the requirement
*                                           &CBPAY-1849
*28/02/2025     Vikram P                    CBPAY-2004             Included the logic to handle if the Incoming payment does not have a valid CCY account. Then credit account
*                                                                  should be defaulted to first account of the portfolio(SAM) in GOSUB FETCH.FIRST.ACCT.
*04/03/2025     Prabhu D S                  CBPAY-1726             Validating Credit Account to see if it is not valid (InActive, Invalid or Closed) to avoid
*                                                                  creation of duplicate OrderEntry.
*08/04/2025     Ragupathy K                 CBPAY-2315             Payment currency replaced with Account currency
*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.CreditPartyDeterminationService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentWorkflowService
    $USING PP.PaymentSTPFlowService
    $INSERT I_PaymentFrameworkService_HookApiOutputDetails
    $INSERT I_PaymentFrameworkService_HookApiResponse
    $USING PP.ComponentApiHook
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $USING PP.PaymentWorkflowGUI
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_AccountandCustomerInterfaceService_InAccountDetails
    $INSERT I_AccountandCustomerInterfaceService_OutAccCustInfo
    $INSERT I_AccountandCustomerInterfaceService_LocalReference
    $INSERT I_F.ACCOUNT
  
    GOSUB INIT
    GOSUB GET.PAYMENT.DETAILS

    IF (yCtrBtrIndicator = "C") AND (yMessageType MATCHES "pacs.008" :@VM: "pacs.004" :@VM: '103') AND (yRepairFlag = "") THEN

        GOSUB VAL.CR.ACCOUNT
        GOSUB READ.ALT.ACCT
        GOSUB VALIDATE.ACCOUNT
        OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountNumber> = yCrAccount
* Please do not send Account Company and Account Currency for invalid accounts, to avoid duplicate Order Entry creation
        IF NOT(oAccCustInfo<OutAccCustInfo.accountStatus> MATCHES 'Invalid' :@VM: 'Closed') THEN
            OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountCompanyID> = yCompany
            OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountCurrency> = yPaymentCurrency
        END
        ARG3.OUT<-1> = OHookApiOutput

    END

    yCreditsource = iDetermineCreditParty<PP.CreditPartyDeterminationService.DetermineCreditPartyInput.originatingSource>
    
    IF yMessageType = "pacs.009" THEN
       
        GOSUB PACS009.PROCESS

       
        OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountNumber> = yCrAccount
        OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountCompanyID> = yCompany
        OHookApiOutput<PP.PaymentFrameworkService.HookApiOutputDetails.accountCurrency> = yPaymentCurrency
               
        ARG3.OUT<-1> = OHookApiOutput
         
    END
    
RETURN

INIT:
****
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)
    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, F.POR.SUPPLEMENTARY.INFO)
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    FN.ALT.ACC = 'F.ALTERNATE.ACCOUNT'
    F.ALT.ACC = ''
    CALL OPF(FN.ALT.ACC, F.ALT.ACC)
    
    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)
    
    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    
    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    R.ALT.ACC = '' ; ALT.ERR = ''
    ERR.POR.TRN = ''
    ERR.POR.SUP.INFO = ''
    yCtrBtrIndicator = ''
    yPaymentCurrency = ''
    yCompany = ''
    iPaymentID = ''
    yPaymentDirection = ''
    yMessageType = ''
    yRepairFlag = ''
    yPartyRole = ''
    yCrAccount = ''
    R.POR.TRANSACTION = ''
    R.ACCOUNT = '' ; ACCT.ERR = ''
    
    
    
   
RETURN

GET.PAYMENT.DETAILS:
********************
    iPaymentID =iPaymentKey<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
           
    CALL F.READ(FN.POR.TRANSACTION,iPaymentID,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)
    
    yCompany = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxCompanyid>
    yPaymentCurrency = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxTransactioncurrencycode>
    yMessageType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxIncomingmessagetype>
    yCtrBtrIndicator = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxCtrbtrindicator>
    yRepairFlag = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxRepairflag>
    
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,iPaymentID,R.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO,ERR.POR.SUP.INFO)
      
    yPartyRole = R.POR.SUPPLEMENTARY.INFO<PORID.PARTY.ROLE>
    
    LOCATE 'BENFCY' IN yPartyRole<1,1> SETTING RolePos THEN
        IF yMessageType EQ '103' THEN
            yCrAccount = R.POR.SUPPLEMENTARY.INFO<PORID.PARTY.ACCOUNT.LINE,RolePos>
            yCrAccount = yCrAccount[2,99]
        END ELSE
            yCrAccount = R.POR.SUPPLEMENTARY.INFO<PORID.PARTY.ACCOUNT.NUMBER,RolePos>
        END
           
    END
    
       
RETURN
 
VAL.CR.ACCOUNT:
****************

    Y.HYPHEN.VAL = '' ; Y.LST.TWO.CHR = ''  ; Y.SPACE.VAL = ''
    
    GOSUB CHECK.FIRST.THREE.CHAR
    
    IF LEN(yCrAccount) GT '13'  THEN
        IF LEN(yCrAccount) EQ '16' THEN
            RETURN
        END ELSE
            GOSUB CHECK.LENGTH.IS.17
            GOSUB CHECK.LENGTH.LE.15
        END
    END
    
    BEGIN CASE
        
        CASE LEN(yCrAccount) LE '7'
            yCrAccount = yCrAccount
            
        CASE LEN(yCrAccount) EQ '9'
            Y.HYPHEN.VAL = FIELD(yCrAccount, '-', 2)
            Y.SPACE.VAL = FIELD(yCrAccount," ",2)
            
            BEGIN CASE
                CASE (Y.HYPHEN.VAL NE '' AND Y.SPACE.VAL NE '') OR (Y.SPACE.VAL NE '')
                    yCrAccount = yCompany[1,2]:'0':yCrAccount[1,7]:'-0':yCrAccount[9,1]:'-':yPaymentCurrency:'01'
            
                CASE yCrAccount[1,1] EQ '0'
                    yCrAccount = yCompany[1,2]:yCrAccount[1,8]:'-0':yCrAccount[9,1]:'-':yPaymentCurrency:'01'
            
                CASE Y.SPACE.VAL EQ ''
                    yCrAccount = yCompany[1,2]:'0':yCrAccount
                    yCrAccount = yCrAccount[1,10]:'-0':yCrAccount[12,1]:'-':yPaymentCurrency:'01'
                    
                CASE Y.HYPHEN.VAL EQ '' AND Y.SPACE.VAL EQ ''
                    yCrAccount = yCompany[1,2]:'0':yCrAccount[1,7]:'-':yCrAccount[8,2]:'-':yPaymentCurrency:'01'
                                          
            END CASE
                              
        CASE LEN(yCrAccount) EQ '10'
            Y.HYPHEN.VAL = FIELD(yCrAccount, '-', 2)
            Y.SPACE.VAL = FIELD(yCrAccount," ",2)
            BEGIN CASE
                CASE Y.HYPHEN.VAL EQ '' AND Y.SPACE.VAL NE ''
                    IF LEN(Y.SPACE.VAL) EQ '1' THEN
                        yCrAccount = yCompany[1,2]:yCrAccount[1,8]:'-0':FIELD(yCrAccount," ",2):'-':yPaymentCurrency:'01'
                    END ELSE
                        yCrAccount = yCompany[1,2]:'0':yCrAccount[1,7]:'-':yCrAccount[9,2]:'-':yPaymentCurrency:'01'
                    END
                
                CASE Y.HYPHEN.VAL NE ''
                    GOSUB HYPHEN.FORMATTED.ACCT
                
                CASE Y.HYPHEN.VAL EQ '' AND Y.SPACE.VAL EQ ''
                    yCrAccount = yCompany[1,2]:yCrAccount[1,8]:'-':yCrAccount[9,2]:'-':yPaymentCurrency:'01'
            END CASE
                                           
        CASE LEN(yCrAccount) EQ '11'
            Y.HYPHEN.VAL = FIELD(yCrAccount, '-', 2)
            Y.SPACE.VAL  = FIELD(yCrAccount," ",2)
            IF Y.HYPHEN.VAL EQ '' THEN
                IF Y.SPACE.VAL NE '' THEN
                    yCrAccount = yCompany[1,2]:yCrAccount[1,8]:'-':Y.SPACE.VAL:'-':yPaymentCurrency:'01'
                END ELSE
                    yCrAccount = yCrAccount[1,10]:'-0':yCrAccount[11,1]:'-':yPaymentCurrency:'01'
                END
            END ELSE
                yCrAccount = yCompany[1,2]:yCrAccount[1,8]:yCrAccount[9,3]:'-':yPaymentCurrency:'01'
            END
            
        CASE LEN(yCrAccount) EQ '12'
            Y.HYPHEN.VAL = FIELD(yCrAccount, '-', 2)
            Y.SPACE.VAL = FIELD(yCrAccount," ",2)
            Y.LST.TWO.CHR = yCrAccount[11,2]
            
            BEGIN CASE
                               
                CASE Y.HYPHEN.VAL EQ '' AND Y.SPACE.VAL EQ ''
                    yCrAccount = yCrAccount[1,10]:'-':Y.LST.TWO.CHR:'-':yPaymentCurrency:'01'
                
                CASE yCrAccount[3,1] NE '0' AND (Y.SPACE.VAL EQ '') AND (yCrAccount[11,1] EQ '0')
                    yCrAccount = yCrAccount[1,2]:'0': yCrAccount[3,7]:yCrAccount[10,3]:'-':yPaymentCurrency:'01'
                
                CASE Y.HYPHEN.VAL NE '' AND yCrAccount[11,1] NE '0'
                    yCrAccount = yCrAccount[1,10]:yCrAccount[11,1]:'0':Y.HYPHEN.VAL:'-':yPaymentCurrency:'01'
                
                CASE LEN(Y.SPACE.VAL) EQ '1'
                    yCrAccount = yCrAccount[1,10]:'-0': Y.SPACE.VAL:'-':yPaymentCurrency:'01'
                
            END CASE
            
           
        CASE LEN(yCrAccount) EQ '13'

            Y.HYPHEN.VAL = FIELD(yCrAccount, '-', 2)
            IF Y.HYPHEN.VAL NE '' THEN
                yCrAccount = yCrAccount:'-':yPaymentCurrency:'01'
            END ELSE
                IF FIELD(yCrAccount," ",2) THEN
                    yCrAccount = yCrAccount[1,10]:'-':yCrAccount[12,2]:'-':yPaymentCurrency:'01'
            
                END
            END
            
        CASE LEN(yCrAccount) EQ '15' OR LEN(yCrAccount) EQ '19'
            yCrAccount = yCrAccount
         
        CASE LEN(yCrAccount) EQ '18'
            yCrAccount = yCrAccount[1,13]:'-':yCrAccount[14,5]
                        
    END CASE

RETURN

CHECK.FIRST.THREE.CHAR:
***********************

    IF yCrAccount[1,3] EQ '723' OR yCrAccount[1,3] EQ '320' THEN
        yCrAccount = yCrAccount[4,99]
    END

RETURN

CHECK.LENGTH.IS.17:
******************

    IF LEN(yCrAccount) EQ '17' THEN
        yCrAccount = yCrAccount[1,10]:'-':yCrAccount[11,2]:'-':yCrAccount[13,5]
    END

RETURN

CHECK.LENGTH.LE.15:
******************
    IF LEN(yCrAccount) LE '15' AND yCrAccount[1,3] NE '123' THEN
        FINDSTR "-" IN yCrAccount SETTING yPos THEN
            yCrAccount = yCrAccount[1,13]
        END ELSE
            yCrAccount = yCrAccount[1,12]
        END
    END

RETURN


HYPHEN.FORMATTED.ACCT:
*********************
    
    IF LEN(Y.HYPHEN.VAL) EQ '1' THEN
        yCrAccount = yCompany[1,2]:yCrAccount[1,8]:'-0':Y.HYPHEN.VAL:'-':yPaymentCurrency:'01'
    END ELSE
        yCrAccount = yCompany[1,2]:'0':yCrAccount[1,7]:'-':Y.HYPHEN.VAL:'-':yPaymentCurrency:'01'
        
    END

RETURN


PACS009.PROCESS:
****************
*Logic to fetch the PL account from the parameter record.
*To identify the 'SLB' value in the PI.INFORMATION.LINE field of POR.SUPPLEMENTARY.INFO & map the credit account number

    IF yCreditsource EQ 'OE' THEN
        yCrAccount = iDetermineCreditParty<PP.CreditPartyDeterminationService.DetermineCreditPartyInput.crMainAccNumber>
    END ELSE

        GOSUB GPM.PROCESS
    
        Y.PI.INFO.CODE = R.POR.SUPPLEMENTARY.INFO<PORID.PI.INFORMATIONCODE>
    
        LOCATE 'INSSDR' IN Y.PI.INFO.CODE<1,1> SETTING INS.POS THEN
        
            Y.PI.INFO.LINE = R.POR.SUPPLEMENTARY.INFO<PORID.PI.INFORMATION.LINE,INS.POS>
        
            FINDSTR 'SLB' IN Y.PI.INFO.LINE SETTING SLB.POS THEN
    
                yCrAccount =  Y.CREDIT.ACCT.NO
    
            END
        
        END
    END
RETURN

GPM.PROCESS:
*************

    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.D.SC.SLB.PARAM","CREDIT.AC.NO.202",Y.CREDIT.ACCT.NO)
          
RETURN

****************
READ.ALT.ACCT:
****************
    
    CALL F.READ(FN.ALT.ACC,yCrAccount,R.ALT.ACC, F.ALT.ACC, ALT.ERR)
    IF R.ALT.ACC THEN
        yCrAccount = R.ALT.ACC<AAC.GLOBUS.ACCT.NUMBER>
* #CBPAY-2315 - Logic change of payment currency to Account currency
        CALL F.READ(FN.ACCOUNT,yCrAccount,R.ACCOUNT,F.ACCOUNT,ACCT.ERR)
        yPaymentCurrency  = R.ACCOUNT<AC.CURRENCY>
    END ELSE
        GOSUB FETCH.FIRST.ACCT
    END

RETURN


******************
FETCH.FIRST.ACCT:
******************
    Y.PORT1 = FIELD(yCrAccount,'-',1)
    Y.PORT2 = FIELD(yCrAccount,'-',2)
    Y.PORTFOLIO.ID = Y.PORT1:'-':Y.PORT2
    R.SAM.ALT.REC = '';SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.PORTFOLIO.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,'')
    IF R.SAM.ALT.REC NE '' THEN
        SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        CALL F.READ(FN.SEC.ACC.MASTER,SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
        yCrAccount = R.SAM.REC<SC.SAM.ACCOUNT.NOS,1>
        yPaymentCurrency = R.SAM.REC<SC.SAM.ACCOUNT.CCY,1>
    END
RETURN
*****************
VALIDATE.ACCOUNT:
*****************
*  Payment Framework creates duplicate Order Entry in case of Invalid account received in incoming payments
*  So we are validating Credit Account to avoid duplication.
    oAccCustInfo = ''
    oAccCustResponse = ''

    iAccCustInfo<InAccountDetails.uniqueReference> = iPaymentID
    iAccCustInfo<InAccountDetails.processCompany> = yCompany
    iAccCustInfo<InAccountDetails.accountOwnCompany> = yCompany
    iAccCustInfo<InAccountDetails.accountNumber> = yCrAccount
    iAccCustInfo<InAccountDetails.accountCurrency> = yPaymentCurrency
    iAccCustInfo<InAccountDetails.requestorComponent> = "CreditPartyDetermination"
    iAccCustInfo<InAccountDetails.bankSpecific,LocalReference.localRefFieldName> = "BOOK.CODE"
    iAccCustInfo<InAccountDetails.bankSpecific,LocalReference.applicationName> = "ACCOUNT"
    iAccCustInfo<InAccountDetails.creditTxnCode> = ''
    iAccCustInfo<InAccountDetails.transactionCurrencyCode> = yPaymentCurrency

    CALL AccountandCustomerInterfaceService.getAccountCustomerInfo(iAccCustInfo,oAccCustInfo,oAccCustResponse)

RETURN
********************************
END

