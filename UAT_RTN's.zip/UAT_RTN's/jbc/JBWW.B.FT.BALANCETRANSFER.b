        SUBROUTINE JBWW.B.FT.BALANCETRANSFER(ACCOUNT.ID)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 2018-11-21         Balakrishnan K          Account balance maintaining as zero for the all the accounts belongs to the category 14183.
* 2018-11-22		 Balaji 				 Parameterising the mapping values
* 2018-11-28         Balakrishnan K          DAY15-5219-Category account selected directly from account table instead of CATEG.INT.ACCT
* 2019-01-11         Balakrishnan K          T24-14541-Local credit amount must be greater than 0.01 CHF
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_BATCH.FILES
	$INSERT I_BALANCETRANSFER.COMMON
	$INSERT I_F.ACCOUNT
	
*----------------------------------------------------------------------------------------------------*
 
 
    GOSUB INIT
	
    IF WORKING.BALANCE.VAL THEN
		GOSUB PROCESS    
    END

    RETURN

*----------------------------------------------------------------------------------------------------*
INIT:
*CHF1418300010202
*PL53006


	R.ACCOUNT=''
	CALL F.READ(FN.ACCOUNT,ACCOUNT.ID , R.ACCOUNT, F.ACCOUNT, ACC.ERR)
	WORKING.BALANCE.VAL=''
	WORKING.BALANCE.VAL = R.ACCOUNT<AC.WORKING.BALANCE>
    ACC.CURRENCY = R.ACCOUNT<AC.CURRENCY>
	
	
	RETURN
*---------------------------------------------------------------------------------------------------*
PROCESS:

	 BEGIN CASE
	 CASE WORKING.BALANCE.VAL GT 0
		DEBIT.ACCOUNT = ACCOUNT.ID
		CREDIT.ACCOUNT = Y.PL.CATEG
		GOSUB CALC.LOCAL.AMOUNT
		IF TXN.AMT.LCY GT '0.01' THEN
			GOSUB BUILD.OFS.RECORD
		END 
	 CASE WORKING.BALANCE.VAL LT 0
	 	
		DEBIT.ACCOUNT = Y.PL.CATEG
		CREDIT.ACCOUNT = ACCOUNT.ID
		WORKING.BALANCE.VAL=WORKING.BALANCE.VAL[2,99]
		GOSUB BUILD.OFS.RECORD
		
	 END CASE 
	  
	RETURN


***************************************************************************************************************************************************************
BUILD.OFS.RECORD:
*---------------*
TEXT = 'BALANCE MOVED FROM THE ACCOUNT ':DEBIT.ACCOUNT:' TO ACCOUNT ':CREDIT.ACCOUNT :' TRANSFERED AMOUNT ':WORKING.BALANCE.VAL
CALL OCOMO(TEXT)				
APPL.NAME=''
 
				APPL.NAME='FUNDS.TRANSFER'
				IN.FUNCTION='I'
				PROCESS='PROCESS'
				VERSION.NAME=Y.OFS.VERSION
				GTS.CONTROL=''
				PROCESS.MSG=''
				OFS.SOURCE=Y.OFS.SOURCE
				R.FUNDS.TRANSFER=''
				R.FUNDS.TRANSFER<FT.TRANSACTION.TYPE>=Y.TRANS.TYPE
				R.FUNDS.TRANSFER<FT.DEBIT.ACCT.NO> = DEBIT.ACCOUNT
				R.FUNDS.TRANSFER<FT.DEBIT.CURRENCY> = ACC.CURRENCY
				R.FUNDS.TRANSFER<FT.DEBIT.AMOUNT> = WORKING.BALANCE.VAL
				R.FUNDS.TRANSFER<FT.CREDIT.ACCT.NO> = CREDIT.ACCOUNT
				R.FUNDS.TRANSFER<FT.ORDERING.BANK> = Y.ORDERING.BANK
				R.FUNDS.TRANSFER<FT.DEBIT.THEIR.REF> = Y.NARRATIVE
				R.FUNDS.TRANSFER<FT.CREDIT.THEIR.REF> = Y.NARRATIVE
				
				IF DEBIT.ACCOUNT[1,2] EQ 'PL' THEN
					R.FUNDS.TRANSFER<FT.PROFIT.CENTRE.DEPT> = Y.PRF.VAL
				END
				
				CALL OFS.BUILD.RECORD(APPL.NAME , IN.FUNCTION , PROCESS , VERSION.NAME , GTS.CONTROL , '' , '' , R.FUNDS.TRANSFER , PROCESS.MSG )
				OFS.RESPONSE = '' ;  REQUEST.COMMIT = ''
				CALL OFS.CALL.BULK.MANAGER(Y.OFS.SOURCE, PROCESS.MSG, OFS.RESPONSE, REQUEST.COMMIT)

RETURN
***************************************************************************************************************************************************************
CALC.LOCAL.AMOUNT:
*----------------*

	IF WORKING.BALANCE.VAL GT 0 THEN
		Y.TXN.CCY = ACC.CURRENCY
		Y.TXN.AMT = WORKING.BALANCE.VAL
		IF Y.TXN.CCY EQ LCCY THEN 
		  TXN.AMT.LCY = Y.TXN.AMT
		END ELSE 
			BUY.CCY = ACC.CURRENCY
			BUY.AMT = WORKING.BALANCE.VAL
			SELL.CCY = LCCY
			CCY.MKT = 1
			SELL.AMT = ''
			BASE.CCY = ''
			EXCH.RATE = ''
			DIFFERENCE = ''
			LCY.AMT = ''
			RETURN.CODE = ''
			CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCH.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)
			TXN.AMT.LCY = SELL.AMT
		END

	END 




	
RETURN


END



