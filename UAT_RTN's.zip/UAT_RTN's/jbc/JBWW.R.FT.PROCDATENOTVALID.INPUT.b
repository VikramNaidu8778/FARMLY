*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PROCDATENOTVALID.INPUT
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 13/08/2018	Parameshwari		DAY15-2867				Change the processing date if the FT is in IFWD and processing date is less
*															than today.
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_F.VERSION
*-------------------------------------------------------------------------

	V.FUNC = V$FUNCTION
	IF V.FUNC NE 'D' THEN
		GOSUB PROCESS
	END
	
    RETURN

*--------------------------------------------------------------------------
PROCESS:
********

	Y.PROC.DATE = R.NEW.LAST(FT.PROCESSING.DATE)
	Y.FT.STATUS = R.NEW.LAST(FT.STATUS)
	
	IF Y.FT.STATUS EQ 'IFWD' AND Y.PROC.DATE LT TODAY THEN
		R.NEW(FT.PROCESSING.DATE) = TODAY
		R.VERSION(46) = '0'
	END
	
    RETURN

*--------------------------------------------------------------------------

END