* @ValidationCode : MToxNjMwNzc4MzY6VVRGLTg6MTUzNTcyMjc3NzM0NTo1ODIxNTQ6LTE6LTE6MDowOmZhbHNlOk4vQQ==
* @ValidationInfo : Timestamp         : 31 Aug 2018 19:09:37
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : u40462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.R.FT.TRANSTYPE.CHK
*----------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------
* This routine attached in AUTO NEW CONTENT to default ACAC only for browser
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer        Reference           Description
*-----------------------------------------------------------------------------
* 31/08/2018    Subbu J           T24-13598           Initial Version
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_GTS.COMMON
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------
    IF OFS$BROWSER EQ '' OR OFS$BROWSER EQ '0' ELSE     ;* if invoked from the browser
        R.NEW(FT.TRANSACTION.TYPE) = 'ACAC'
    END

    RETURN

    END



