* @ValidationCode : MTotMTMzMjcwNjgyNDpJU08tODg1OS0xOjE1MzkwNTIyMDg5ODM6YTM4OTYwOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4xMQ==
* @ValidationInfo : Timestamp         : 09 Oct 2018 10:30:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.B.XX.RETROPAYCLEANUP.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 09-10-2018 - T24-13868
*              Re-compilation of load, select and process routine of multi threaded
*              job JBWW.B.XX.RETROPAYCLEANUP
* 13-05-2024 - T24-20805
*			   $NAU File missing for FT
*-----------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_JBWW.B.XX.RETROPAYCLEANUP.COMMON
* </region>
*-----------------------------------------------------------------------------
* <region name = Main>

    FN.JBWW.H.FT.RETROPAY = 'F.JBWW.H.FT.RETROPAY'
    F.JBWW.H.FT.RETROPAY = ''
    CALL OPF (FN.JBWW.H.FT.RETROPAY, F.JBWW.H.FT.RETROPAY)
    
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF (FN.FUNDS.TRANSFER, F.FUNDS.TRANSFER)

*T24-20805/S    
    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF (FN.FUNDS.TRANSFER.NAU, F.FUNDS.TRANSFER.NAU)
*T24-20805/E
    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF (FN.FUNDS.TRANSFER.HIS, F.FUNDS.TRANSFER.HIS)
    
    FN.DE.O.MSG.SWIFT = 'F.DE.O.MSG.SWIFT'
    F.DE.O.MSG.SWIFT = ''
    CALL OPF (FN.DE.O.MSG.SWIFT, F.DE.O.MSG.SWIFT)
    
    FN.DE.O.HISTORY = 'F.DE.O.HISTORY'
    F.DE.O.HISTORY = ''
    CALL OPF (FN.DE.O.HISTORY, F.DE.O.HISTORY)
    
    FN.DE.O.HANDOFF = 'F.DE.O.HANDOFF'
    F.DE.O.HANDOFF = ''
    CALL OPF (FN.DE.O.HANDOFF, F.DE.O.HANDOFF)
     
RETURN
* </region>
*-----------------------------------------------------------------------------
END