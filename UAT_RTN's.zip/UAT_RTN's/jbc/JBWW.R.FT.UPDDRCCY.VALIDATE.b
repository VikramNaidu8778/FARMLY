*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.UPDDRCCY.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer                Mail Id                              Reference      Description
*------------------------------------------------------------------------------------------------------
* 25/08/2016   Priyadarshni Priyanka    priyadarshni.priyanka@cognizant.com   JB2A-11620      Defect FiX
*-----------------------------------------------------------------------------
* This routine is attached as Validation Routine to the VERSION FUNDS.TRANSFER,JBWW.V.FT.UOBCC.INP to the field
* DEBIT.ACCOUNT to populate the currency in DEBIT.CURRENCY field. 
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    
    RETURN

*------------------------------------------------------------------------------

INIT:
*****


    R.ACCNT = ''
    ERR.AC = ''

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    RETURN
    
*-------------------------------------------------------------------------------

PROCESS:
*******

    Y.DEBIT.ACCNT = COMI
    IF Y.DEBIT.ACCNT THEN
        CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCNT,R.ACCNT,F.ACCOUNT,ERR.AC)
        IF R.ACCNT THEN
            Y.ACC.CURR = R.ACCNT<AC.CURRENCY>
            R.NEW(FT.DEBIT.CURRENCY) = Y.ACC.CURR
            
        END
    END
    
    RETURN

    END
