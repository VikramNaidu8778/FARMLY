* @ValidationCode : MToxNzYxMDI5NTc6SVNPLTg4NTktMToxNTI5MzQwMTcwNjcyOmEzOTM3NTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 19 Jun 2018 00:42:50
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a39375
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
SUBROUTINE JBWW.B.FT.POSTGSTENTRY.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                     Reference               Description
*-----------------------------------------------------------------------------
* 22/03/2018   Maheshkumar                   JB2A-49865
* 18/06/2018   Dinesh                        JB2A-52321
* 21/09/2018   Rajagopalan R                 DAY15-4080
* 04/10/2022   Maheshkumar                   P-3998(FSQD-64)     Amended for GST RC entry
* 14/03/2024   Jeeva/Madhu                   L1TAX GST           Modified the routine to align with L1 GST
*-----------------------------------------------------------------------------
*Description
*************
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT ; **JB2A-52321
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_JBWW.B.FT.POSTGSTENTRY.COMMON
    $INSERT I_F.JBWW.L.FT.GSTENTRY.DETAILS
    $INSERT I_F.JBWW.L.FT.GSTENTRY.PROCESSED
	$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
*** <region name= INIT>
INIT:
*** <desc>initialize variables </desc>
*
    FN.FUNDS.TRANSFER='F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
     
    FN.JBWW.L.FT.GSTENTRY.DETAILS = 'F.JBWW.L.FT.GSTENTRY.DETAILS'
    F.JBWW.L.FT.GSTENTRY.DETAILS  =  ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.DETAILS,F.JBWW.L.FT.GSTENTRY.DETAILS)
 
    FN.JBWW.L.FT.GSTENTRY.PROCESSED = 'F.JBWW.L.FT.GSTENTRY.PROCESSED'
    F.JBWW.L.FT.GSTENTRY.PROCESSED  = ''
    CALL OPF(FN.JBWW.L.FT.GSTENTRY.PROCESSED,F.JBWW.L.FT.GSTENTRY.PROCESSED)

    FN.TAXREG.GST.DETAILS = 'F.TAXREG.GST.DETAILS'
    F.TAXREG.GST.DETAILS  = ''
    CALL OPF(FN.TAXREG.GST.DETAILS,F.TAXREG.GST.DETAILS)

    FN.FUNDS.TRANSFER.NAU='F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)
**JB2A-52321
    FN.OV.ONLINE.VAL.FINAL.LIST  = 'F.OV.ONLINE.VAL.FINAL.LIST'
    FV.OV.ONLINE.VAL.FINAL.LIST = ''
    CALL OPF(FN.OV.ONLINE.VAL.FINAL.LIST,FV.OV.ONLINE.VAL.FINAL.LIST)
          
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)
**JB2A-52321

    FN.FUNDS.TRANSFER.HIS='F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)
*FSQD-64 - S

	FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
	F.JBWW.H.EB.GENERICPARAMETER = ''
	CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER, F.JBWW.H.EB.GENERICPARAMETER)

    APPL.NAME = 'STMT.ENTRY'
    APPL.FIELD = 'L.XX.ACTNG.LOC'
    CALL MULTI.GET.LOC.REF(APPL.NAME,APPL.FIELD,LRF.POS)
    Y.STMT.POS = LRF.POS<1,1>
*FSQD-64 - E
RETURN
*-----------------------------------------------------------------------------
END
