* @ValidationCode : MTotMTI5MDM1ODM4NTpJU08tODg1OS0xOjE1NDA1MjU4Mzc0MDA6YTQwOTM0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4xNg==
* @ValidationInfo : Timestamp         : 26 Oct 2018 11:50:37
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40934
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.202.SUP(TEMP.HEADER,TMP.OPERAND,TMP.CONDITION,OUT.VAR)
*-----------------------------------------------------------------------------
*Desc : This routine is to supress the swift message for MT202
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer         Reference               Description
*-------------------------------------------------------------------------------------------
* 24/10/2018    Smitha      Day15-5047		              Initial Version
*-------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.HEADER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
	
	GOSUB INIT
	GOSUB PROCESS
	RETURN
*-------------------------------------------------------------------------------------------
INIT:
*----
        FN.ACCOUNT = 'F.ACCOUNT'
        F.ACCOUNT = ''
        CALL OPF(FN.ACCOUNT,F.ACCOUNT)

        FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
	    F.FUNDS.TRANSFER = ''
	    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

	RETURN
*-------------------------------------------------------------------------------------------
PROCESS:
*-------

        Y.FT.REF = TEMP.HEADER<DE.HDR.TRANS.REF>
        CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.REF,R.FT,F.FUNDS.TRANSFER,FT.ERR)
        Y.TXN.TYPE = R.FT<FT.TRANSACTION.TYPE>
        
        Y.DEBIT.ACCT.NO = '' ; Y.DEBIT.ACCT.NO.PL = '' 
        Y.DEBIT.ACCT.NO = R.FT<FT.DEBIT.ACCT.NO>

        R.ACC.REC = ''
        CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT.NO,R.ACC.REC,F.ACCOUNT,ACC.ERR)
        IF R.ACC.REC THEN
         Y.AC.CATEGORY = R.ACC.REC<AC.CATEGORY>
        END
        Y.DEBIT.ACCT.NO.PL = ISDIGIT(Y.DEBIT.ACCT.NO)

       IF Y.TXN.TYPE EQ 'OT60' THEN 
          IF (Y.AC.CATEGORY GT 1999) OR (Y.DEBIT.ACCT.NO.PL EQ "0") THEN
		     TMP.OPERAND = 'EQUAL'
        	 TMP.CONDITION = '1'
		     OUT.VAR = '1'
	      END
       END
	
	RETURN
*-------------------------------------------------------------------------------------------
	END