*-----------------------------------------------------------------------------
* <Rating>-27</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.H.FT.STANDINGINSTR.VALIDATE
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is a .Validate routine for local template JBWW.H.FT.STANDINGINSTR, to validate
* the fields CREDIT.ACCT.NO & ACCT.WITH.BANK.
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN : NA
* OUT: NA
* Dependencies:
*-----------------------------------------------------------------------------
*  Revision History:
*-----------------------------------------------------------------------------
* Date               who                   Reference                 Desc
* 16-06-2016         Vijay GS               PMT-058             Initial Version
* 
**----------------------------------------------------------------------------
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date               who                     Reference                 Desc
*17-09-2016        Priyadarshni Priyanka      PMT-058             Modification
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.FT.STANDINGINSTR
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER

*----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
*-----

*    Y.VERSION = R.NEW(JB.FT.STNG.FT.CCPMT.VER)
    Y.CR.ACCT = R.NEW(JB.FT.STNG.CREDIT.ACCT.NO)
    Y.ACCT.WITH.BANK = R.NEW(JB.FT.STNG.ACCT.WITH.BANK)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)

    RETURN
*------------------------------------------------------------------------------------------------------------

PROCESS:


*    CONVERT VM TO FM IN Y.VERSION
    CONVERT VM TO FM IN Y.CR.ACCT
    CONVERT VM TO FM IN Y.ACCT.WITH.BANK

    FOR XX = 1 TO DCOUNT(Y.CR.ACCT,FM)

*        IF FIELD(Y.VERSION<XX>, ',', 1,1) NE 'FUNDS.TRANSFER' THEN

*           ETEXT = "FT-ONLY.Y.FT.ALLOWED"
*          AF = JB.FT.STNG.FT.CCPMT.VER
*            AV = XX
*           CALL STORE.END.ERROR
*           RETURN
*        END

        CALL F.READ(FN.ACCOUNT, Y.CR.ACCT<XX>, R.ACC, F.ACCOUNT,ERR)
        IF R.ACC THEN

            IF R.ACC<AC.CATEGORY> GE 5000 AND R.ACC<AC.CATEGORY> LE 5999 ELSE
                ETEXT = "ONLY VALID NOSTRO ACCOUNT ALLOWED"
                AF = JB.FT.STNG.CREDIT.ACCT.NO
                AV = XX
                CALL STORE.END.ERROR
                RETURN
            END
        END


        Y.CUST = Y.ACCT.WITH.BANK<XX>

        CALL F.READ(FN.CUSTOMER, Y.CUST, R.CUST, F.CUSTOMER, ERR)

        IF R.CUST THEN

            IF R.CUST<EB.CUS.SECTOR> GE 3000 AND R.CUST<EB.CUS.SECTOR> LE 3499 ELSE
                ETEXT = "ONLY BANK IS ALLOWED"
                AF = JB.FT.STNG.ACCT.WITH.BANK
                AV = XX
                CALL STORE.END.ERROR
                RETURN
            END

        END


    NEXT XX

    RETURN

    END

*-----------------------------------------------------------------------------------------------------------------------
