*-----------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
*-----------------------------------------------------------------------------------
* Description:
* The purpose of the routine is to update the payment details in the local table
* JB.L.PP.CASHFLOWDATA when it is in INAU status.
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date                Developer           Reference           Description
*-----------------------------------------------------------------------------------
* 25/03/2025          P Amala             CBPAY-65          Initial Version
*-----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JB.L.PP.CASHFLOWDATA

    GOSUB INIT.FILES
    GOSUB PROCESS

RETURN

*------------------------------------------------------------------------------
INIT.FILES:
***********
       
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA)
	
	PP.ID.POS = '' ; R.PP.CASHFLOWDATA = '' ; Y.PP.CSHFLW.ERR = ''
	PP.IDS.CNT = '' ; Y.PP.TRANS.IDS = ''
	
RETURN
*------------------------------------------------------------------------------
PROCESS:
********

    PP.ID.POS = ''
    CALL F.READ(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA,Y.PP.CSHFLW.ERR)
    IF R.PP.CASHFLOWDATA EQ '' THEN
        R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF> = Y.PP.ID
        R.PP.CASHFLOWDATA<JB.PPCASH.PROC.DATE> = Y.PP.EXCDATE
        R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.AMOUNT> = Y.PP.AMT
        CALL F.WRITE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA)
        R.PP.CASHFLOWDATA = ''
    END ELSE
        Y.PP.TRANS.IDS = R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF>
        LOCATE Y.PP.ID IN Y.PP.TRANS.IDS<1,1> SETTING PP.ID.POS THEN
            R.PP.CASHFLOWDATA<JB.PPCASH.PROC.DATE,PP.ID.POS> = Y.PP.EXCDATE
            R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.AMOUNT,PP.ID.POS> = Y.PP.AMT
            CALL F.WRITE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA)
            R.PP.CASHFLOWDATA = ''
        END ELSE
            PP.IDS.CNT = DCOUNT(R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF>,VM)
            R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.REF,PP.IDS.CNT+1> = Y.PP.ID
            R.PP.CASHFLOWDATA<JB.PPCASH.PROC.DATE,PP.IDS.CNT+1> = Y.PP.EXCDATE
            R.PP.CASHFLOWDATA<JB.PPCASH.TRANS.AMOUNT,PP.IDS.CNT+1> = Y.PP.AMT
            CALL F.WRITE(FN.JB.L.PP.CASHFLOWDATA,Y.NST.CSHFLW.ACCT,R.PP.CASHFLOWDATA)
            R.PP.CASHFLOWDATA = ''
        END
    END

RETURN

*------------------------------------------------------------------------------
END
