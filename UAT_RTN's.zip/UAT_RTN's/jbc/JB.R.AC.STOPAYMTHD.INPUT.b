SUBROUTINE JB.R.AC.STOPAYMTHD.INPUT
*----------------------------------------------------------------------------------------------------------------------------------------------------------
*----------------------------------------------------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------------------------------------------------
*  This Routine is attached to Validation Routine for Field STO.BEN.OUR.CHARGES in VERSION
*"STANDING.ORDER,JB.V.AC.STOOT03OT12"to populate 'OUR' for Pacs.009COV otherwise 'SHA' for Pacs.008.
*----------------------------------------------------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: N/A
* OUT: N/A
* Revision History:
*--------------------------------------------------------------------------------------------------------------------------------------------------------------
* Date               who               Reference          Description

*01-07-2024        vikram pavuluru    CBPAY-124 &       This routine is to set the PAYMENT.ORDER.PRODUCT and PAYMENT Order Version for the selected Pay Method,
*                                    CBPAY - 100        and set the BenOurCharges based on payment order product.
*12-02-2025        lakshmi Priya      CBPAY - 1786       The Routine is updated to Default Po Version based on STO payment method 
*                                                          Company code
*07-02-2025        Lakshmi Priya      CBPAY - 1971      Included logic to nullify charge amount , charge type and ben our charges when 
*                                                           Commission code is set to waive.
*18-APR-2025       Lakshmi Priya    CBPAY-2558/CBPAY-124 Included logic to default Commission Code based on Ben Our Charges . 
*19-JUN-2025       Prabhu D S        CBPAY-2677          Default DEBIT.VALUE.DATE.GAP field to raise value dated payments
*
*02-JUL-2025       Lakshmi Priya    CBPAY - 3458         Included logic to raise error if beneficiary length is greater than 139.
*----------------------------------------------------------------------------------------------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.STANDING.ORDER

GOSUB STO.BENNAME.LENGTHCHK
GOSUB STO.COMMISSION.WAIVE
GOSUB VERSION.DEFAULT

IF R.NEW(STO.DAYS.PRIOR) AND R.NEW(STO.DATE.ADJUSTMENT) EQ "PRECEDING" THEN
   R.NEW(STO.DEBIT.VALUE.GAP) = "+":R.NEW(STO.DAYS.PRIOR)
END

RETURN

STO.BENNAME.LENGTHCHK:
*********************
 IF LEN(R.NEW(STO.BEN.NAME)) GT 139 THEN
     AV = STO.BEN.NAME
     ETEXT = "PI-JB.D.XX.FLDLEN.EXCEEDS.MAX":FM:"139"
     CALL STORE.END.ERROR
 END

RETURN

STO.COMMISSION.WAIVE:
********************
 
Y.PAY.METHOD = R.NEW(STO.PAY.METHOD)

IF R.NEW(STO.COMMISSION.CODE) NE "WAIVE" THEN
   BEGIN CASE
      CASE R.NEW(STO.BEN.OUR.CHARGES) EQ "BEN"
         R.NEW(STO.COMMISSION.CODE) = "CREDIT LESS CHARGES"
      CASE R.NEW(STO.BEN.OUR.CHARGES) MATCHES "OUR":@VM:"SHA"
         R.NEW(STO.COMMISSION.CODE) = "DEBIT PLUS CHARGES"
   END CASE
END ELSE
   R.NEW(STO.BEN.OUR.CHARGES) = ''
END

RETURN

VERSION.DEFAULT:
***************

IF ID.COMPANY EQ 'SG0020001' THEN
    BEGIN CASE
        CASE Y.PAY.METHOD EQ 'OT03'
            R.NEW(STO.PO.VERSION) = 'PAYMENT.ORDER,JBSG.V.AC.NOSTRO103.INP'
        CASE Y.PAY.METHOD EQ 'OT12'
            R.NEW(STO.PO.VERSION) = 'PAYMENT.ORDER,JBSG.V.AC.NOST103COV.INP'
    END CASE
    
END ELSE
    IF ID.COMPANY EQ 'HK0030001' THEN
        BEGIN CASE
            CASE Y.PAY.METHOD EQ 'OT03'
                R.NEW(STO.PO.VERSION) = 'PAYMENT.ORDER,JBHK.V.AC.NOSTRO103.INP'
            CASE Y.PAY.METHOD EQ 'OT12'
                R.NEW(STO.PO.VERSION) = 'PAYMENT.ORDER,JBHK.V.AC.NOST103COV.INP'
        END CASE
    
    END
END
RETURN
***********************************
END
