* @ValidationCode : MjoxMzI4ODU4ODM2OkNwMTI1MjoxNzEyNTc0MTczNjI5OjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ
* @ValidationInfo : Timestamp         : 09 May 2024 16:32:53
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.
*----------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.CHKORDINITTYPE.INPUT
*-----------------------------------------------------------------------------------------------------
*This is the Input routine attached to the OTO3 & OT22 versions
*Attached: to version PAYMENT.ORDER,JB.V.PP.NOSTRO103.INP & PAYMENT.ORDER,JB.V.PP.NOSTRO202.INP
*-----------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*27/05/2024     Resmi R                    CBPAY-329 & CBPAY-330     ORDER.INITIATION.TYPE field check
*22/01/2025     Prabhu D S                 CBPAY-1683                Routine should not trigger for Treasury Payments
*01/03/2025     P.Amala                    CBPAY-1942                Fix to Skip Order Initiation Type check for OTKI/OTOP/TRSY type.
*--------------------------------------------------------------------------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
  
    GOSUB INIT
    GOSUB PROCESS
    
RETURN
    
INIT:
*****

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
       
    Y.COMPANY = ID.COMPANY
    
    Y.FIELD.VALUE = '' ; Y.HK.INITTYPE = '' ; Y.PO.PROD = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","HKCHAT.ORDINITTYPE",Y.FIELD.VALUE)

    Y.HK.INITTYPE = Y.FIELD.VALUE<1>

    CHANGE ',' TO @VM IN Y.HK.INITTYPE
    CHANGE @FM TO @VM IN Y.HK.INITTYPE
	
RETURN

PROCESS:
********

      Y.PO.PROD = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    IF Y.PO.PROD MATCHES Y.HK.INITTYPE THEN RETURN

    Y.ORD.INIT.TYPE = R.NEW(PO.ORDER.INITIATION.TYPE)
    Y.ORDERING.REF = R.NEW(PO.ORDERING.REFERENCE)
 
    BEGIN CASE
   
        CASE Y.COMPANY[1,2] EQ 'HK'
	
            IF Y.ORDERING.REF NE '' THEN
                GOSUB VALIDATE.STO.ORDER.INITIATION.TYPE
            END ELSE
                GOSUB VALIDATE.PO.ORDER.INITIATION.TYPE
            END
              
        CASE Y.COMPANY[1,2] EQ 'SG'
 	
            IF Y.ORD.INIT.TYPE NE 'POA' THEN
                AF = PO.ORDER.INITIATION.TYPE
                ETEXT = 'EB-JB.D.PP.ORDERINITIATION.TYPE':@FM:ID.COMPANY
                CALL STORE.END.ERROR
            END

    END CASE

RETURN

VALIDATE.PO.ORDER.INITIATION.TYPE:
******************************

    IF NOT(Y.ORD.INIT.TYPE MATCHES 'POA':@VM:'MXCHATS') THEN
        AF = PO.ORDER.INITIATION.TYPE
        ETEXT = 'EB-JB.D.PP.ORDERINITIATION.TYPE':@FM:ID.COMPANY
        CALL STORE.END.ERROR
    END

RETURN

VALIDATE.STO.ORDER.INITIATION.TYPE:
******************************

    IF NOT(Y.ORD.INIT.TYPE MATCHES 'STO':@VM:'STOMXCHATS') THEN
        AF = PO.ORDER.INITIATION.TYPE
        ETEXT = 'EB-JB.D.PP.ORDERINITIATION.TYPE':@FM:ID.COMPANY
        CALL STORE.END.ERROR
    END


RETURN

*---------------------------------------------------------------------------------------------------------
END
