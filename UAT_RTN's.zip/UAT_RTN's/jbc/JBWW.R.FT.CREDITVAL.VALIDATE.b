* @ValidationCode : MTotODcxNDg2OTA1OklTTy04ODU5LTE6MTUzNDI2MDg5NjE4NTphNDMxMzA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 14 Aug 2018 23:34:56
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a43130
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.CREDITVAL.VALIDATE
*-----------------------------------------------------------------------------------------
* Description: This routine checks the whether VALUE.DATE is more than 7 working days
*              forwarded or backdated to raise override message in the version
*-----------------------------------------------------------------------------------------
* Attached: This is the validate routine attached to FUNDS.TRANSFER versions.
*           FUNDS.TRANSFER,JBWW.V.FT.POSTCLOSE.INP and FUNDS.TRANSFER,JBWW.V.FT.NORTRANS.INP
*-----------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* Revision History:
*------------------
*    Date             who            Reference                 Description
* 08-08-2016        Rekha M          FIN-CR-40              Initial Version
* 09-02-2017	    Vidya A	     JB2A-26755             This is a copy of existing routine "JBWW.R.FT.CREDITVAL.INPUT" - Extra case is added for account validation
* 23-03-2017        Vidya A          JB2A-27882             Validation field is changed to "PROFIT.CENTRE.CUST"
* 31-03-2017        Vidya A          JB2A-27467             NULL condition checked for VALUE.DATE's
* 20-04-2017        Shathish JP      JB2A-31129             Override should be called only in the INPUT Routine so created new INPUT Routine JBWW.R.FT.CREDITVAL.OR.INP
* 04-05-2017        Vidya A          JB2A-32139             Created new gosub, if Debit and Credit are Internal accounts.
* 15-06-2017		Balaji 	     JB2A-35100			  Defaulted Profit centre Cust for Nostro - Nostro Transactions
* 28-06-2017		Balaji       JB2A-35100             Error Check with COMI variable and PROFIT.CENTRE.DEPT field.
* 27-07-2017	  Francis Xavier Raj JB2A-36954             Revok commented code to default the value in PROFILE.CENRE.DEPT for transaction B/W Internal A/c and PL Account
* 22-02-2018        Lakshmanan       JB2A-49015             Auto population of Profile centre dept and cust were commented for internal acc and Pl category case condition
* 27-07-2018        Rajagopalan R    DAY15-2974				Validation error while approving FT after providing Profit Centre Department 

*----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.VERSION
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER

    GOSUB INIT
    GOSUB PROCESS

    RETURN
*----------------------------------------------------------------------------------------
INIT:
*****

V.VERSION.FLAG = ''     ;  ** DAY15-2974-S/E
    FN.ACC = 'F.ACCOUNT'
    F.ACC = ''
    CALL OPF(FN.ACC,F.ACC)

    R.ACC1 = '' ; Y.ERR1 = ''
    R.ACC2 = '' ; Y.ERR2 = ''

* JB2A-27882 - S
    Y.PROF.CUS = ''
    Y.CR.ACOFF = '' ; Y.DR.ACOFF = ''
    Y.CR.CUS = ''   ; Y.DR.CUS = ''
    Y.DR.VDATE = '' ; Y.CR.VDATE = ''
    Y.CUST = ''     ; Y.DEPT = ''
    Y.DR.ACNO = ''  ; Y.CR.ACNO = ''
    Y.DR.ACCY = ''  ; Y.CR.ACCY = ''
    Y.CR.ACPL = ''  ; Y.DR.ACPL = ''
* JB2A-27882 - E

    RETURN
*----------------------------------------------------------------------------------------
PROCESS:
********

    Y.DR.VDATE = R.NEW(FT.DEBIT.VALUE.DATE)
    Y.CR.VDATE = R.NEW(FT.CREDIT.VALUE.DATE)

	IF Y.DR.VDATE NE "" AND Y.CR.VDATE NE "" THEN
	IF Y.DR.VDATE NE Y.CR.VDATE THEN
        AF = FT.CREDIT.VALUE.DATE
        ETEXT = 'EB-DEB.CRE.DATE.DIFF'
        CALL STORE.END.ERROR
		END
	END
	
* JB2A-27882 - S
*    Y.CUST = R.NEW(FT.PROFIT.CENTRE.CUST)
    Y.CUST = COMI
    Y.DEPT = R.NEW(FT.PROFIT.CENTRE.DEPT)

    Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)
*    Y.CR.ACNO = COMI
* JB2A-27882 - E

    Y.DR.ACCY = Y.DR.ACNO[1,3]
    Y.CR.ACCY = Y.CR.ACNO[1,3]
    Y.CR.ACPL = Y.CR.ACNO[1,2]
    Y.DR.ACPL = Y.DR.ACNO[1,2]
    BEGIN CASE
        CASE NUM(Y.DR.ACNO) AND (Y.CR.ACPL EQ 'PL')
            GOSUB PROCESS.DRAC
        CASE (Y.DR.ACPL EQ 'PL') AND NUM(Y.CR.ACNO)
            GOSUB PROCESS.CRAC
        CASE NUM(Y.DR.ACNO) AND NUM(Y.CR.ACNO)
            GOSUB PROCESS.DRAC
        CASE NUM(Y.DR.ACNO) AND NOT(NUM(Y.CR.ACCY))
            GOSUB PROCESS.DRAC
        CASE NOT(NUM(Y.DR.ACCY)) AND NUM(Y.CR.ACNO)
            GOSUB PROCESS.CRAC
            * 26755 - S
        CASE (Y.DR.ACPL EQ 'PL') AND NOT(NUM(Y.CR.ACCY))
           IF ((PGM.VERSION EQ ',JBWW.V.FT.NORTRANS.INP') OR (PGM.VERSION EQ ',JBWW.V.FT.POSTCLOSE.INP')) THEN
        ** DAY15-2974-S

	      V.VERSION.FLAG = 'Y' 

        ** DAY15-2974-E   
*           JB2A-49015
           END ELSE
             GOSUB PROCESS.PLDR   ;*JB2A-33890 / JB2A-36954_20170727  
           END
            * JB2A-27882 - S
        CASE NOT(NUM(Y.DR.ACCY)) AND (Y.CR.ACPL EQ 'PL')
           IF ((PGM.VERSION EQ ',JBWW.V.FT.NORTRANS.INP') OR (PGM.VERSION EQ ',JBWW.V.FT.POSTCLOSE.INP')) THEN
        ** DAY15-2974-S      

		V.VERSION.FLAG = 'Y' 

        ** DAY15-2974-E      
*           JB2A-49015
           END ELSE
              GOSUB PROCESS.PLCR   ;*JB2A-33890 / JB2A-36954_20170727
           END
            * JB2A-27882 - E
        CASE NOT(NUM(Y.DR.ACCY)) AND NOT(NUM(Y.CR.ACCY))
            * JB2A-32139 {S}
            GOSUB PROCESS.INACC
            * GOSUB PROCESS.DRAC
            * JB2A-32139 {E}
            * 26755 - E
    END CASE

* JB2A-27882 - S
    IF Y.CUST EQ '' THEN
        * JB2A-32139 {S}
        COMI = Y.PROF.CUS
        * R.NEW(FT.PROFIT.CENTRE.CUST) = Y.PROF.CUS
        * JB2A-32139 {E}
    END
* JB2A-27882 - E

*IF (Y.PROF.CUS EQ '') AND (Y.PROF.ACOFF EQ '') THEN 	;* Commented - JB2A-35100
** DAY15-2974-S
    IF ((Y.DR.ACPL EQ 'PL') OR (Y.CR.ACPL EQ 'PL')) AND V.VERSION.FLAG = 'Y' THEN
    END ELSE
** DAY15-2974-E
	IF (COMI EQ '') AND (R.NEW(FT.PROFIT.CENTRE.DEPT) EQ '') THEN 	;*JB2A-35100
   	     ETEXT = 'EB-PRO.CEN.DEPT.ENTERED'
             CALL STORE.END.ERROR
        END
    END

    NO.FDAYS = '+7W'
    NO.BDAYS = '-7W'

    Y.VDATE.TODAY = TODAY

    Y.DBDATE = Y.VDATE.TODAY
    Y.DFDATE = Y.VDATE.TODAY

    Y.CFDATE = Y.VDATE.TODAY
    Y.CBDATE = Y.VDATE.TODAY

    CALL CDT('',Y.DFDATE,NO.FDAYS)
    CALL CDT('',Y.DBDATE,NO.BDAYS)

    CALL CDT('',Y.CFDATE,NO.FDAYS)
    CALL CDT('',Y.CBDATE,NO.BDAYS)

* JB2A-31129 {S}
* JB2A-27467 {S}
*   IF Y.DR.VDATE THEN
*      IF (Y.DR.VDATE LT Y.DBDATE) OR (Y.DR.VDATE GT Y.DFDATE) THEN
*            AF = FT.DEBIT.VALUE.DATE
*            GOSUB VAL.OVERRIDE
*        END
*    END
*   IF Y.CR.VDATE THEN
*       IF (Y.CR.VDATE LT Y.CBDATE) OR (Y.CR.VDATE GT Y.CFDATE) THEN
*           AF = FT.CREDIT.VALUE.DATE
*
*            GOSUB VAL.OVERRIDE
*        END
*    END
* JB2A-27467 {E}
* JB2A-31129 {E}
    RETURN
*----------------------------------------------------------------------------------------
* JB2A-31129 {S}
*VAL.OVERRIDE:
*************
*    Y.DC.CURR.NO = R.NEW(DC.DC.CURR.NO)
*    CUR.NO = DCOUNT(Y.DC.CURR.NO,VM)+1
*    TEXT = 'EB-VAL.DATE.LT.7WORKDAY'
*    CALL STORE.OVERRIDE(CUR.NO)
*    RETURN
* JB2A-31129 {E}
*----------------------------------------------------------------------------------------
PROCESS.DRAC:
*************
    CALL F.READ(FN.ACC,Y.DR.ACNO,R.ACC1,F.ACC,Y.ERR1)

                Y.NOSTRO.CAT = R.ACC1<AC.CATEGORY>

                IF Y.NOSTRO.CAT GE '5000' AND Y.NOSTRO.CAT LE '5999' THEN 

                                CALL F.READ(FN.ACC,Y.CR.ACNO,R.CR.ACC,F.ACC,CR.ERR)

                                Y.NOSTRO.CAT1 = R.CR.ACC<AC.CATEGORY>

                                IF Y.NOSTRO.CAT1 LT '5000' OR Y.NOSTRO.CAT1 GT '5999' THEN 

                                   Y.PROF.CUS = R.CR.ACC<AC.CUSTOMER>

                                END
								
								IF Y.NOSTRO.CAT1 GE '5000' AND Y.NOSTRO.CAT1 LE '5999' THEN 	;*JB2A-35100
								  Y.PROF.CUS = R.ACC1<AC.CUSTOMER>
								  COMI = Y.PROF.CUS
								END

                END ELSE

                                Y.DR.CUS = R.ACC1<AC.CUSTOMER>

                                Y.PROF.CUS = Y.DR.CUS

                END

    RETURN
*----------------------------------------------------------------------------------------
PROCESS.CRAC:
*************
    CALL F.READ(FN.ACC,Y.CR.ACNO,R.ACC2,F.ACC,Y.ERR2)
    Y.CR.CUS = R.ACC2<AC.CUSTOMER>
    Y.PROF.CUS = Y.CR.CUS
    RETURN
* 26755 - S
*----------------------------------------------------------------------------------------
PROCESS.PLDR:
*************
    CALL F.READ(FN.ACC,Y.CR.ACNO,R.ACC.CR.PL,F.ACC,Y.ERR3)
    Y.CR.ACOFF = R.ACC.CR.PL<AC.ACCOUNT.OFFICER>
* JB2A-27882 - S
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(FT.PROFIT.CENTRE.DEPT) = Y.CR.ACOFF
    END
* JB2A-27882 - E
    Y.PROF.ACOFF = Y.CR.ACOFF
    RETURN
* 26755 - E
* JB2A-27882 - S
*----------------------------------------------------------------------------------------
PROCESS.PLCR:
*************
    CALL F.READ(FN.ACC,Y.DR.ACNO,R.ACC.DR.PL,F.ACC,Y.ERR4)
    Y.DR.ACOFF = R.ACC.DR.PL<AC.ACCOUNT.OFFICER>
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(FT.PROFIT.CENTRE.DEPT) = Y.DR.ACOFF
    END
    Y.PROF.ACOFF = Y.DR.ACOFF
    RETURN
* JB2A-27882 - E
*----------------------------------------------------------------------------------------
* JB2A-32139 {S}
PROCESS.INACC:
**************
    CALL F.READ(FN.ACC,Y.DR.ACNO,R.ACC.INT,F.ACC,Y.ERR4)
    Y.DR.ACOFF = R.ACC.INT<AC.ACCOUNT.OFFICER>
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(FT.PROFIT.CENTRE.DEPT) = Y.DR.ACOFF
    END
    Y.PROF.ACOFF = Y.DR.ACOFF
    RETURN
* JB2A-32139 {E}
*----------------------------------------------------------------------------------------
    END
