* @ValidationCode : MTotMTY1MTg4MjM0MDpVVEYtODoxNDgxNDUwNjM3OTk0OjIzMzE2MzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 11 Dec 2016 15:33:57
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.R.FT.RLCBLOCKTXNVER.CONV
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------

INIT:
***********

    F.FUNDS.TRANSFER$NAU = ''
    FN.FUNDS.TRANSFER$NAU = 'F.FUNDS.TRANSFER$NAU'
    CALL OPF(FN.FUNDS.TRANSFER$NAU,F.FUNDS.TRANSFER$NAU)

    F.JBWW.H.XX.SOFTBLOCK = ''
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    F.JBWW.H.EB.GENERICPARAMETER = ''
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    Y.PARAM.ID = 'FT.DATE.CHECK.TRANS.TYPE'
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.PARAM.ID,R.GEN.PARAM,F.JBWW.H.EB.GENERICPARAMETER,'')
    Y.TXN.PARAM.CODES = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE>
    CHANGE SM TO FM IN Y.TXN.PARAM.CODES
    APPL = 'FUNDS.TRANSFER'
    LREF.FLD = 'L.XX.BLK.CATEG'
    Y.POS = ''
    Y.BLK.CATEG.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)
    Y.BLK.CATEG.POS = Y.POS<1,1>
    Y.FLAG = ''
    RETURN


PROCESS:
************
    Y.FT.ID = O.DATA
    O.DATA = ''
    Y.FLAG = ''
    CALL F.READ(FN.FUNDS.TRANSFER$NAU,Y.FT.ID,R.FT.NAU,F.FUNDS.TRANSFER$NAU,'')
    IF R.FT.NAU THEN
        Y.TXN.TYPE = R.FT.NAU<FT.TRANSACTION.TYPE>
        Y.TXN.POS = ''
        FIND Y.TXN.TYPE IN Y.TXN.PARAM.CODES  SETTING Y.TXN.POS ELSE Y.TXN.POS = ''
        IF Y.TXN.POS NE '' THEN
            Y.BLK.CATEG = R.FT.NAU<FT.LOCAL.REF,Y.BLK.CATEG.POS>
            CHANGE SM TO FM IN Y.BLK.CATEG
            Y.BLK.CATEG.CNT = DCOUNT(Y.BLK.CATEG,FM)

            J = 0
            LOOP
                J = J + 1
            WHILE J LE Y.BLK.CATEG.CNT
                IF Y.BLK.CATEG<J> NE 'CC' THEN
                    Y.FLAG = '1'
                    BREAK
                END
            REPEAT
            IF Y.FLAG THEN
                O.DATA = Y.TXN.TYPE
            END
        END
    END
    RETURN
