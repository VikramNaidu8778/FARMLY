SUBROUTINE JB.R.PP.TRSYSYNC.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  10-Jun-2025   Kandan             CBPAY-2329        Initial Draft
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $USING EB.DataAccess
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.SWAP

    GOSUB INITIALISE
    GOSUB CHECK.CONDITION

RETURN
*----------
INITIALISE:
*----------

    FN.SWAP = 'F.SWAP'
    F.SWAP = ''
    CALL OPF(FN.SWAP,F.SWAP)

RETURN
*---------------
CHECK.CONDITION:
*---------------

    Y.PYMT.PRODUCT = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    Y.ORD.REF = R.NEW(PO.ORDERING.REFERENCE)
    IF Y.PYMT.PRODUCT EQ 'TRSY' AND Y.ORD.REF[1,2] EQ 'SW' THEN
        GOSUB READ.SWAP
        IF R.SWAP THEN
            BucketName = 'F.TPS.INTERNAL.CONFIGS_':ID.COMPANY
            ItemKey = 'EMBD.PMT.STP'
            EB.DataAccess.SystemDeletecache(BucketName,ItemKey,ReturnValue)
        END
    END
    
RETURN
*---------
READ.SWAP:
*---------
    R.SWAP = '' ; SWAP.ERR = '' ; Y.SWAP.TYPE = '' ;
    CALL F.READ(FN.SWAP,Y.ORD.REF,R.SWAP,F.SWAP,SWAP.ERR)
*  Y.SWAP.TYPE = R.SWAP<SW.SWAP.TYPE>

RETURN
*----------------------------------------------------
END
