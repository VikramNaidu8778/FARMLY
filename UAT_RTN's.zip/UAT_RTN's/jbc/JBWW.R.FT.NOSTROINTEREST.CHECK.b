* @ValidationCode : MTotMTcyNjA4NDk1OTpVVEYtODoxNDY2MTY5MTU2MjM4OjM0MDY3NzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 17 Jun 2016 18:42:36
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 340677
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.NOSTROINTEREST.CHECK
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*Discription  Name        Date          Description
*JB2A-24117   SUSHMITHA   30-DEC-2016
*JB2A-22896   Rajagopalan 28-Sep-2017   Using READU instead READ to resolve write issue on updating JBWW.H.FT.NOSTROINTEREST table
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.FT.NOSTROINTEREST
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------------
INITIALISE:
***********

    FN.JBWW.H.FT.NOSTROINTEREST = 'F.JBWW.H.FT.NOSTROINTEREST'
    F.JBWW.H.FT.NOSTROINTEREST = ''
    CALL OPF(FN.JBWW.H.FT.NOSTROINTEREST,F.JBWW.H.FT.NOSTROINTEREST)
	R.NOS.REC = ""

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    RETURN
*-------------------------------------------------------------------------------
PROCESS:
********
  
	Y.CNT = ""
	Y.NOST.ID = ""

* JB2A-22896 changes starts

	Y.ERR = ""
    Y.NOST.ID = R.NEW(FT.DEBIT.THEIR.REF)
	Y.CNT = R.NEW(FT.CREDIT.THEIR.REF)

    CALL F.READU(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,R.NOS.REC,F.JBWW.H.FT.NOSTROINTEREST,Y.ERR,'')
	IF R.NOS.REC THEN

		R.NOS.REC<JB.NOSINT.L.FT.ID,Y.CNT> = ID.NEW
*JB2A-24117
*********************
*END	
		R.NEW(FT.CREDIT.THEIR.REF) = ""
		CALL F.WRITE(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,R.NOS.REC)
		CALL F.RELEASE(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,F.JBWW.H.FT.NOSTROINTEREST)

* JB2A-22896 changes ends
	END
*JB2A-24117
*********************
    
    RETURN

  END
