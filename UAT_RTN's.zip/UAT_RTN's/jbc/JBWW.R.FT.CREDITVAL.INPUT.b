  SUBROUTINE JBWW.R.FT.CREDITVAL.INPUT
*-----------------------------------------------------------------------------------------
* Description: This routine checks the whether VALUE.DATE is more than 7 working days
*              forwarded or backdated to raise override message in the version
*-----------------------------------------------------------------------------------------
* Attached: This is the input routine attached to FUNDS.TRANSFER versions.
*           FUNDS.TRANSFER,JBWW.V.FT.POSTCLOSE.INP and FUNDS.TRANSFER,JBWW.V.FT.NORTRANS.INP
*-----------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* Revision History:
*------------------
*    Date             who          Reference                 Description
* 08-08-2016        Rekha M        FIN-CR-40              Initial Version
*----------------------------------------------------------------------------------------
  
 $INSERT I_COMMON
 $INSERT I_EQUATE
 $INSERT I_F.VERSION
 $INSERT I_F.ACCOUNT
 $INSERT I_F.FUNDS.TRANSFER

  GOSUB INIT
  GOSUB PROCESS	
  RETURN
*----------------------------------------------------------------------------------------
 INIT:
 *****
 
 FN.ACC = 'F.ACCOUNT'
 F.ACC = ''
 CALL OPF(FN.ACC,F.ACC)
 
 R.ACC1 = '' ; Y.ERR1 = ''
 R.ACC2 = '' ; Y.ERR2 = ''
 
 RETURN
*----------------------------------------------------------------------------------------
 PROCESS:
 ********
 
 Y.DR.VDATE = R.NEW(FT.DEBIT.VALUE.DATE)
 Y.CR.VDATE = R.NEW(FT.CREDIT.VALUE.DATE)
 
 IF Y.DR.VDATE NE Y.CR.VDATE THEN
   AF = FT.CREDIT.VALUE.DATE
   ETEXT = 'EB-DEB.CRE.DATE.DIFF'
   CALL STORE.END.ERROR
 END
 
 Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
 Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)
 Y.DR.ACCY = Y.DR.ACNO[1,3]
 Y.CR.ACCY = Y.CR.ACNO[1,3]
 Y.CR.ACPL = Y.CR.ACNO[1,2]
 Y.DR.ACPL = Y.DR.ACNO[1,2]
 
 BEGIN CASE 
 CASE NUM(Y.DR.ACNO) AND (Y.CR.ACPL EQ 'PL')
   GOSUB PROCESS.DRAC 
 CASE (Y.DR.ACPL EQ 'PL') AND NUM(Y.CR.ACNO)
     GOSUB PROCESS.CRAC  
 CASE NUM(Y.DR.ACNO) AND NUM(Y.CR.ACNO)
   GOSUB PROCESS.DRAC   
 CASE NUM(Y.DR.ACNO) AND NOT(NUM(Y.CR.ACCY))
     GOSUB PROCESS.DRAC    
 CASE NOT(NUM(Y.DR.ACCY)) AND NUM(Y.CR.ACNO)
       GOSUB PROCESS.CRAC 
  END CASE
  
  R.NEW(FT.PROFIT.CENTRE.CUST) = Y.PROF.CUS

  Y.DB.ACOFF = ''
  
  IF NOT(NUM(Y.DR.ACCY)) AND NOT(NUM(Y.CR.ACCY)) THEN
   GOSUB PROCESS.DRAC
   R.NEW(FT.PROFIT.CENTRE.DEPT) = Y.DB.ACOFF 
  END
  
  IF (Y.PROF.CUS EQ '') AND (Y.DB.ACOFF EQ '') THEN
   ETEXT = 'EB-PRO.CEN.DEPT.ENTERED'
   CALL STORE.END.ERROR
  END

  NO.FDAYS = '+7W'
  NO.BDAYS = '-7W'
  
  Y.VDATE.TODAY = TODAY

  Y.DBDATE = Y.VDATE.TODAY
  Y.DFDATE = Y.VDATE.TODAY

  Y.CFDATE = Y.VDATE.TODAY
  Y.CBDATE = Y.VDATE.TODAY

  CALL CDT('',Y.DFDATE,NO.FDAYS)
  CALL CDT('',Y.DBDATE,NO.BDAYS)

  CALL CDT('',Y.CFDATE,NO.FDAYS)
  CALL CDT('',Y.CBDATE,NO.BDAYS)
  
  IF (Y.DR.VDATE LT Y.DBDATE) OR (Y.DR.VDATE GT Y.DFDATE) THEN
       AF = FT.DEBIT.VALUE.DATE
       GOSUB VAL.OVERRIDE
  END

  IF (Y.CR.VDATE LT Y.CBDATE) OR (Y.CR.VDATE GT Y.CFDATE) THEN
       AF = FT.CREDIT.VALUE.DATE
       GOSUB VAL.OVERRIDE
  END
    
 RETURN
*----------------------------------------------------------------------------------------
VAL.OVERRIDE:
************

  CUR.NO = DCOUNT(R.NEW(DC.DC.CURR.NO),VM) + 1     
  TEXT = 'EB-VAL.DATE.LT.7WORKDAY'
  CALL STORE.OVERRIDE(CUR.NO)
  RETURN
*----------------------------------------------------------------------------------------
 PROCESS.DRAC:
 *************
  CALL F.READ(FN.ACC,Y.DR.ACNO,R.ACC1,F.ACC,Y.ERR1)
   Y.DR.CUS = R.ACC1<AC.CUSTOMER>
   Y.DB.ACOFF = R.ACC1<AC.ACCOUNT.OFFICER>
   Y.PROF.CUS = Y.DR.CUS
 RETURN
*----------------------------------------------------------------------------------------
 PROCESS.CRAC:
 *************
  CALL F.READ(FN.ACC,Y.CR.ACNO,R.ACC2,F.ACC,Y.ERR2)
  Y.CR.CUS = R.ACC2<AC.CUSTOMER>
  Y.PROF.CUS = Y.CR.CUS
 RETURN
*----------------------------------------------------------------------------------------
END