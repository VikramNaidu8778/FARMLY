SUBROUTINE JB.R.DE.GETTXNMSGS.BLD(ENQ.DATA)
*--------------------------------------------------------------------------------------------------------------------
*This Build Routine is attached to Enquiry JB.E.DE.OTHRMDL.PAYMENTS
*--------------------------------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------------------------------
* Date          Developer          Reference         Description
*
* 11-NOV-2024   Resmi R            CBPAY-1062        Routine that builds the list of transaction messages when user
*                                                    specifies other module transaction ref
* 03-FEB-2025   Prabhu D S         CBPAY-1754        Logic included to filter company specific records
* 11-FEB-2025   Prabhu D S         CBPAY-1821        Call routine JB.R.XX.GET.TPHTXN used to retrieve Payment Order
*                                                    from contract and avoided selection process
*09-Jun-2025    cts                CBPAY-3252        Included CAMT.058 Changes
*--------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.DELIVERY.REQUEST.LISTENER
    $INSERT I_F.DE.HEADER
    $USING EB.Reports
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.SY.FXSTRUCTTRADES
    $INSERT I_F.EB.QUERIES.ANSWERS


    GOSUB INIT
    GOSUB PROCESS

RETURN
******
INIT:
******

    FN.DE.O.HEADER = "F.DE.O.HEADER"
    F.DE.O.HEADER = ""
    CALL OPF(FN.DE.O.HEADER,F.DE.O.HEADER)

    FN.DE.DELIVERY.REQUEST.LISTENER = "F.DE.DELIVERY.REQUEST.LISTENER"
    F.DE.DELIVERY.REQUEST.LISTENER = ""
    CALL OPF(FN.DE.DELIVERY.REQUEST.LISTENER,F.DE.DELIVERY.REQUEST.LISTENER)
       
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER, F.PAYMENT.ORDER)

    FN.PAYMENT.ORDER.HIS = 'F.PAYMENT.ORDER$HIS'
    F.PAYMENT.ORDER.HIS = ''
    CALL OPF(FN.PAYMENT.ORDER.HIS,F.PAYMENT.ORDER.HIS)
       
    FN.JBWW.H.SY.FXSTRUCTTRADES = 'F.JBWW.H.SY.FXSTRUCTTRADES'
    F.JBWW.H.SY.FXSTRUCTTRADES = ''
    CALL OPF(FN.JBWW.H.SY.FXSTRUCTTRADES,F.JBWW.H.SY.FXSTRUCTTRADES)
    
    FN.EB.QUERIES.ANSWERS = 'F.EB.QUERIES.ANSWERS'
    F.EB.QUERIES.ANSWERS = ''
    CALL OPF(FN.EB.QUERIES.ANSWERS, F.EB.QUERIES.ANSWERS)

       
    DLVRY.IDS.LIST = '' ; TXN.ID = '' ; PAYMENT.ID = ''
    Y.PMT.FT.REF = '' ; PO.LIST = ''
   
RETURN

***********
PROCESS:
***********

    LOCATE 'TRANSACTION.REF' IN ENQ.DATA<2,1> SETTING TXN.POS THEN
        TXN.ID = ENQ.DATA<4,TXN.POS>
        
        GOSUB GET.TXN.MSG.PROCESS
        SEL.DEOH = "SELECT ":FN.DE.O.HEADER:" WITH TRANSACTION.REF EQ ":TXN.ID:" AND CO.CODE EQ ":ID.COMPANY
        CALL EB.READLIST(SEL.DEOH,DEOH.IDS.LIST,"",NO.OF.DEOH.IDS,DEOH.ERR)
                       
        LOOP
            REMOVE DELV.ID FROM DEOH.IDS.LIST SETTING DEL.POS
        WHILE DELV.ID : DEL.POS
        
            CALL F.READ(FN.DE.O.HEADER, DELV.ID, R.DE.O.HEADER.REC, F.DE.O.HEADER, DE.O.HEAD.ERR)
            Y.MSG.TYPE = R.DE.O.HEADER.REC<DE.HDR.MESSAGE.TYPE>
            IF Y.MSG.TYPE EQ "210" THEN
                Y.CARRIER.SEQ.NO = R.DE.O.HEADER.REC<DE.HDR.CAR.SEQ.NO>
                SEL.CMD = "SELECT ":FN.DE.DELIVERY.REQUEST.LISTENER:" WITH SOURCE.UNIQUE.ID EQ ":Y.CARRIER.SEQ.NO
                CALL EB.READLIST(SEL.CMD,DEL.ID,"",NO.OF.DEL.IDS,DEL.ERR)
                R.DEL.REQ.LIST.REC = ""
                CALL F.READ(FN.DE.DELIVERY.REQUEST.LISTENER, DEL.ID, R.DEL.REQ.LIST.REC, F.DE.DELIVERY.REQUEST.LISTENER, R.DEL.REQ.LIST.ERR)
                IF R.DEL.REQ.LIST.REC THEN
                    DEL.CAMT057.LIST<-1> = R.DEL.REQ.LIST.REC<DE.DERL.DELIVERY.OUT.HEADER.ID>
                END
            END ELSE
                DLVRY.IDS.LIST<-1> = DELV.ID
            END
        REPEAT
        
        IF DEL.CAMT057.LIST THEN
            DLVRY.IDS.LIST<-1> = DEL.CAMT057.LIST
        END
        DEL.CAMT058.LIST = '' ;
        GOSUB ADD.CAMT.058.REF
        IF DEL.CAMT058.LIST THEN
            DLVRY.IDS.LIST<-1> = DEL.CAMT058.LIST
        END
                    
        CHANGE FM TO ' ' IN DLVRY.IDS.LIST
        
        EB.Reports.setEnqSkipSelect('1')
        
        ENQ.DATA<2,TXN.POS> = '@ID'
        ENQ.DATA<3,TXN.POS> = 'EQ'
        ENQ.DATA<4,TXN.POS> = DLVRY.IDS.LIST
        
    END
    
RETURN

*----------------
ADD.CAMT.058.REF:
*----------------
    IF TXN.ID[1,2] EQ 'FX' THEN
        SEL.EBQA.CAMT58 = '' ; EBQA.CAMT58.ID = '' ; EBQA.CAMT58.CNT = '' ;
        SEL.EBQA.CAMT58 = "SELECT ":FN.EB.QUERIES.ANSWERS:" WITH REL.REFERENCE EQ ":TXN.ID:" AND WITH ORIGINAL.MSG.TYPE EQ 210"
        CALL EB.READLIST(SEL.EBQA.CAMT58,EBQA.CAMT58.ID,"",EBQA.CAMT58.CNT,"")
        SEL.CMD.CAMT58 = '' ; DEL.ID.CAMT58 = '' ; NO.OF.DEL.IDS.CAMT58 = '' ; DEL.ERR.CAMT58 = '' ; R.DEL.REQ.LIST.REC = '' ;
        SEL.CMD.CAMT58 = "SELECT ":FN.DE.DELIVERY.REQUEST.LISTENER:" WITH SOURCE.TRANS.REF EQ ":EBQA.CAMT58.ID
        CALL EB.READLIST(SEL.CMD.CAMT58,DEL.ID.CAMT58,"",NO.OF.DEL.IDS.CAMT58,DEL.ERR.CAMT58)
        CALL F.READ(FN.DE.DELIVERY.REQUEST.LISTENER, DEL.ID.CAMT58, R.DEL.REQ.LIST.REC, F.DE.DELIVERY.REQUEST.LISTENER, R.DEL.REQ.LIST.ERR)
        DEL.CAMT058.LIST = R.DEL.REQ.LIST.REC<DE.DERL.DELIVERY.OUT.HEADER.ID>
    END

RETURN
*********************
GET.TXN.MSG.PROCESS:
*********************

    IF TXN.ID[1,2] EQ 'SY' THEN
        GOSUB GET.SY.PMT.ID
        GOSUB GET.TPH.REF
        GOSUB GET.DOH
    END ELSE
        GOSUB SELECT.PO
        GOSUB SELECT.EBQA
    END

RETURN
**********
SELECT.PO:
**********

    CALL JB.R.XX.GET.TPHTXN(TXN.ID,R.APPLN,PO.LIST)
    LOOP
        REMOVE PO.ID FROM PO.LIST SETTING PO.POS
    WHILE PO.ID : PO.POS
        CALL F.READ(FN.PAYMENT.ORDER,PO.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,PO.ERR)
        IF NOT(R.PAYMENT.ORDER) THEN
            CALL EB.READ.HISTORY.REC(F.PAYMENT.ORDER.HIS,PO.ID,R.PAYMENT.ORDER,READ.HIS.ERR)
        END
        Y.PMT.FT.REF = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM.ID>
        GOSUB GET.DOH
    REPEAT
    
RETURN
************
SELECT.EBQA:
************

    SEL.EBQA = "SELECT ":FN.EB.QUERIES.ANSWERS:" WITH ORIG.TXN.REFERENCE EQ ":TXN.ID
    CALL EB.READLIST(SEL.EBQA,EBQA.ID,"",EBQA.CNT,"")
    
    CALL F.READ(FN.EB.QUERIES.ANSWERS,EBQA.ID,R.EB.QUERIES.ANSWERS,F.EB.QUERIES.ANSWERS,EBQA.ERR)
    
    Y.PMT.FT.REF = R.EB.QUERIES.ANSWERS<EB.QA.CANCEL.REQ.ID>
    GOSUB GET.DOH

RETURN
*********
GET.DOH:
*********
    DEOH.LIST = ''
    SEL.DE = "SELECT ":FN.DE.O.HEADER:" WITH TRANSACTION.REF EQ ":Y.PMT.FT.REF
    
    CALL EB.READLIST(SEL.DE,DEOH.LIST,"",NO.OF.IDS,DEOH.ERROR)
    IF DEOH.LIST THEN
        DLVRY.IDS.LIST<-1> = DEOH.LIST
    END
    
RETURN

**********
GET.TPH.REF:
***********

    R.PAYMENT.ORDER = ''
    CALL F.READ(FN.PAYMENT.ORDER,PAYMENT.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,PMT.ERR)
    Y.PMT.FT.REF = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM.ID>
    
RETURN

**************
GET.SY.PMT.ID:
**************
    
    FXST.ERROR = ''
    SEL.SY.CMD = "SELECT ":FN.JBWW.H.SY.FXSTRUCTTRADES:" WITH @ID LIKE ...*UNW AND SY.FX.FWD.ID EQ ":TXN.ID
    CALL EB.READLIST(SEL.SY.CMD,FXSY.ID,"",NO.OF.SYIDS,FXST.ERROR)
    R.FXSY = '' ; FXSY.ERR = ''
    CALL F.READ(FN.JBWW.H.SY.FXSTRUCTTRADES, FXSY.ID, R.FXSY, F.JBWW.H.SY.FXSTRUCTTRADES, FXSY.ERR)
    PAYMENT.ID = R.FXSY<JHSFS.TRD.FUNDS.TRANSFER.ID>


RETURN

**********************************
END
