* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.V.PP.OE.PROCESSINGDATE
*----------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing Routine JB.R.PP.PROCESSINGDATE.VALIDATE and attached in PP.ORDER.ENTRY version to default the processing date.
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
* 13/05/2024     Ragupathy K                    CBPAY-12                       Validation routine for Date Manipulation in  PP.ORDER.ENTRY versions
*                                       						 
*--------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.PP.ORDER.ENTRY
*-------------------------------------------------------------------------
    IF MESSAGE EQ 'VAL' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
 
RETURN
*--------------------------------------------------------------------------
INIT:
*****
    Y.CR.ACCT = ''  ; Y.DB.CCY = ''
    Y.CR.CCY = ''   ; Y.REGION = ''
    Y.CR.VAL.DATE = '' ; Y.DATE1 = ''
    Y.DAY.TYPE = ''  ;
    
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)
 
RETURN
*--------------------------------------------------------------------------
PROCESS:
********
    Y.CR.ACCT = R.NEW(PP.OEYG.CreditAccountNumber)
    Y.DB.CCY  = R.NEW(PP.OEYG.DebitAccountCurrency)
    Y.CR.CCY  = R.NEW(PP.OEYG.CreditAccountCurrency)
    IF ISALPHA(Y.CR.ACCT[1,3]) THEN   ; *For Book Payments.
        Y.REGION = Y.DB.CCY[1,2] : '00'
    END ELSE
        Y.REGION = Y.CR.CCY[1,2] : '00'
    END
     Y.CR.VAL.DT = R.NEW(PP.OEYG.DebitValueDate)
    IF Y.CR.VAL.DT NE '' THEN
        CALL CDT(Y.REGION,Y.CR.VAL.DT,'-2W')
        Y.DATE1 = Y.CR.VAL.DT
        CALL AWD('',Y.DATE1,Y.DAY.TYPE)
        IF Y.DAY.TYPE NE 'W' THEN
            CALL CDT('',Y.DATE1,'-1W')
        END
    END
    IF Y.DATE1 GT TODAY THEN
        R.NEW(PP.OEYG.ProcessingDate) = Y.DATE1
    END ELSE
        R.NEW(PP.OEYG.ProcessingDate) = TODAY
    END
RETURN
*--------------------------------------------------------------------------
END

