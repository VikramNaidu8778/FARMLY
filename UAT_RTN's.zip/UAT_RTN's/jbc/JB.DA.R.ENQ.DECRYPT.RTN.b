* @ValidationCode : MjoxMzI4ODU4ODM2OkNwMTI1MjoxNzEyNTc0MTczNjI5OjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 09 May 2024 16:32:53
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.DA.R.ENQ.DECRYPT.RTN(ENQ.DATA,FLD.VALUE,R.RECORD)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*20/05/2024	Resmi R			                CBPAY-394	        Masking the CID fields in Enquiry level for Non-Privileged User                       
*									 
*--------------------------------------------------------------------------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENCRYPT.COMMON
    $INSERT I_F.EB.ENC.PARAMETER
    
    R.EB.ENC.REC = ENC$R.EB.ENC.PARAM
    
    Y.ENQ.MASK.CHARS = R.EB.ENC.REC<EB.ENC.ENQ.MSK.CHARS>
    
    CALL EB.IDENTIFY.USER.PRIVILEGE(IsUserPrivilege)

    IF NOT(IsUserPrivilege) THEN
        ENQ.DATA = Y.ENQ.MASK.CHARS

    END

RETURN

END