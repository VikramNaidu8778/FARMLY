* @ValidationCode : MjotNjE3OTMyMDAxOkNwMTI1MjoxNzE1MDczMDc5MDQ0OjkxNDgxNTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDIzMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 07 May 2024 14:41:19
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 914815
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

SUBROUTINE JB.R.PP.RSTRCTNONAC.INCACT
*-------------------------------------------------------------------------
* Description:
* Logic copied existing JBWW.R.FT.RSTRCT.NONAC.INCACT routine and attached into PAYMENT.ORDER,JB.V.PP.NOSTRO103.INP
* Modification History:
*----------------------
*
*
*12/04/2024         Murali krishnan H     CBPAY-39          Input routine to block Payment Order with DR/CR acct being an Income account
*                                                          And Payment Order Product other than ACIA/ACME/ACMI
*
*
*-----------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER




    Y.FIELD.VALUES = '' ; Y.IC.TCODE = '' ; YTCODE.POS = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","PAYMENT.PRODUCT.CHK",Y.FIELD.VALUES)
    CHANGE SM TO FM IN Y.FIELD.VALUES
    CHANGE ',' TO FM IN Y.FIELD.VALUES
    PAYMENT.PROD1 =Y.FIELD.VALUES<1,1>
    PAYMENT.PROD2 =Y.FIELD.VALUES<2,1>
    PAYMENT.PROD3 =Y.FIELD.VALUES<3,1>

    IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES PAYMENT.PROD1:@VM:PAYMENT.PROD2:@VM:PAYMENT.PROD3 THEN
        RETURN
    END ELSE
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END

 
 
 
RETURN
 
*==========
OPEN.FILES:
*==========
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
 
    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)
 
    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
RETURN
 
*=======
PROCESS:
*=======
    INC.FLAG = ''
    DR.INC.FLAG = ''
    CR.INC.FLAG = ''
    DR.ACNO = R.NEW(PO.DEBIT.ACCOUNT)
    CR.ACNO = R.NEW(PO.CREDIT.ACCOUNT)
 
 
    IF DR.ACNO THEN
        ACCOUNT = R.NEW(PO.DEBIT.ACCOUNT)
        GOSUB PROCESS.FETCH.ACCNT
    END
 
    IF NOT(INC.FLAG) AND CR.ACNO THEN
        ACCOUNT = R.NEW(PO.CREDIT.ACCOUNT)
        GOSUB PROCESS.FETCH.ACCNT
    END
 
 
    IF INC.FLAG THEN
        AF = R.FIELD
        ETEXT = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        CALL STORE.END.ERROR
    END
 
RETURN
 
*=================
CHECK.ACCOUNT.SAM:
*=================
 
    R.SAM.ALT.REC = '';SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC NE'' THEN
        SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        R.SAM = '';SAM.ERR = ''
        CALL F.READ(FN.SAM,SAM.ID,R.SAM,F.SAM,SAM.ERR)
        IF R.SAM THEN
            GOSUB CHECK.SAM.INC.ACCNT
        END
    END
 
RETURN
 
*=========
PROCESS.FETCH.ACCNT:
*=========
 
    R.ACCOUNT = '';ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE"" THEN
        ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.POS THEN
            SAM.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,ALT.POS>
            SAM.ALT.ID = FIELD(SAM.ALT.ID,'-',1):'-':FIELD(SAM.ALT.ID,'-',2)
            GOSUB CHECK.ACCOUNT.SAM
        END
    END
 
RETURN
 
*==================
CHECK.SAM.INC.ACCNT:
*==================
 
 IF DR.ACNO THEN
    INC.POS = ''
    LOCATE DR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
        DR.INC.FLAG = 1
        R.FIELD = PO.DEBIT.ACCOUNT
    END
 END
 
    IF CR.ACNO THEN
        INC.POS = ''
        LOCATE CR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1>SETTING INC.POS THEN
            CR.INC.FLAG = 1
            R.FIELD = PO.CREDIT.ACCOUNT
        END

    END
    IF DR.INC.FLAG AND CR.INC.FLAG THEN
        PORT.FLAG = 1
    END
 
    IF DR.INC.FLAG OR CR.INC.FLAG THEN
        INC.FLAG = 1
    END
 
RETURN
 
END
