SUBROUTINE JB.R.PP.BULKUPLOAD.BLD(ENQ.DATA)
*-------------------------------------------------------------------------
* Modification History :
*This routine is the copy of the existing FT routine JBWW.R.FT.BULKUPLOAD.BLD
*-------------------------------------------------------------------------
*    Date       Developer             Reference               Description
*-------------------------------------------------------------------------
* 30-MAY-2025     Resmi R             CBPAY-3101              Initial version
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.MNEMONIC.CUSTOMER
    $INSERT I_F.CUSTOMER.ACCOUNT
    $INSERT I_F.ACCOUNT.CLOSURE
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.EB.FILE.UPLOAD

    GOSUB INIT        
    GOSUB PROCESS
  
RETURN

INIT:
*****

    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)
    
    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
    
    FN.EB.FILE.UPLOAD = 'F.EB.FILE.UPLOAD'
    F.EB.FILE.UPLOAD = ''
    CALL OPF(FN.EB.FILE.UPLOAD,F.EB.FILE.UPLOAD)
    
    Y.POS1 = ''
    Y.POS2=''
    Y.CNT = '1'
    Y.BOTH.SEL=0
    Y.UPLOAD.ID=''
    UPLOAD.TYPE = ''
    ERR.EB.FILE.UPLOAD = ''
    R.EB.FILE.UPLOAD = ''
    Y.ID=ENQ.DATA<1>


    LOCATE 'L.FT.FILEUPD.ID' IN ENQ.DATA<2,1> SETTING Y.POS1 THEN
        Y.UPLOAD.ID = ENQ.DATA<4,Y.POS1>
    END
   
    LOCATE '@ID' IN ENQ.DATA<2,1> SETTING Y.POS2 THEN
        Y.FT.ID = ENQ.DATA<4,Y.POS2>
    END

    LOCATE 'PAYMENT.EXECUTION.DATE' IN ENQ.DATA<2,1> SETTING DATE.POS THEN
        Y.DATE = ENQ.DATA<4,DATE.POS>
    END

    LOCATE 'DEBIT.ACCOUNT' IN ENQ.DATA<2,1> SETTING DR.AC.POS THEN
        Y.DEBIT.ACCT.NO = ENQ.DATA<4,DR.AC.POS>
    END


RETURN

PROCESS:
********

    BEGIN CASE
        CASE Y.ID EQ 'JB.E.PP.BULKREFUND-NAU.AUTH' OR Y.ID EQ 'JB.E.PP.BULKREFUND-HLD.AUTH'
            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.REFUND*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTREFUNDUPLOAD':VM:'JB.D.PP.HKGSTREFUNDUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTREFUNDUPLOAD*':Y.UPLOAD.ID
                        END
                    END
        
                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2
        

                CASE Y.UPLOAD.ID AND Y.FT.ID
        
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.REFUND*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTREFUNDUPLOAD':VM:'JB.D.PP.HKGSTREFUNDUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTREFUNDUPLOAD*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID
      
                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.REFUND*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'

            END CASE

        CASE Y.ID EQ 'JB.E.PP.BULKFEECHG-NAU.AUTH' OR Y.ID EQ 'JB.E.PP.BULKFEECHG-HLD.AUTH'


            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FEECHG*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTFEECHRGUPLOAD':VM:'JB.D.PP.HKGSTFEECHRGUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTFEECHRGUPLOAD*':Y.UPLOAD.ID
                        END
                    END

                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2

                CASE Y.UPLOAD.ID AND Y.FT.ID

                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FEECHG*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTFEECHRGUPLOAD':VM:'JB.D.PP.HKGSTFEECHRGUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTFEECHRGUPLOAD*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID

                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.FEECHG*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'

            END CASE
    
        CASE Y.ID EQ 'JB.E.PP.BULKINT-NAU.AUTH' OR Y.ID EQ 'JB.E.PP.BULKINT-HLD.AUTH'
   
            BEGIN CASE
                CASE Y.UPLOAD.ID AND Y.FT.ID EQ ''
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.INT*':Y.UPLOAD.ID
                    Y.OPRT='EQ'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTINTERNALUPLOAD':VM:'JB.D.PP.HKGSTINTERNALUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTINTERNALUPLOAD*':Y.UPLOAD.ID
                        END
                    END

                CASE Y.UPLOAD.ID EQ '' AND Y.FT.ID
                    Y.OPRT='EQ'
                    Y.UPLD.ID=Y.FT.ID
                    Y.FLD.SEL='@ID'
                    Y.POS1=Y.POS2

                CASE Y.UPLOAD.ID AND Y.FT.ID

                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.INT*':Y.UPLOAD.ID
                    Y.BOTH.SEL=1
        
                    CALL F.READ(FN.EB.FILE.UPLOAD, Y.UPLOAD.ID, R.EB.FILE.UPLOAD, F.EB.FILE.UPLOAD, ERR.EB.FILE.UPLOAD)
                    IF R.EB.FILE.UPLOAD THEN
                        UPLOAD.TYPE = R.EB.FILE.UPLOAD<EB.UF.UPLOAD.TYPE>
                        IF UPLOAD.TYPE MATCHES 'JB.D.PP.SGGSTINTERNALUPLOAD':VM:'JB.D.PP.HKGSTINTERNALUPLOAD' THEN
                            Y.UPLD.ID=Y.CUR.COM[1,2]:'.GSTINTERNALUPLOAD*':Y.UPLOAD.ID
                        END
                    END
        
                    ENQ.DATA<4,Y.POS1>=Y.UPLD.ID

                CASE NOT(Y.UPLOAD.ID) AND NOT(Y.FT.ID)
                    Y.CUR.COM=ID.COMPANY
                    Y.UPLD.ID=Y.CUR.COM[1,2]:'.BULK.INT*...'
                    Y.OPRT='LK'
                    Y.FLD.SEL='L.FT.FILEUPD.ID'
            END CASE
    
    END CASE
        
    CHANGE FM TO ' ' IN Y.UPLD.ID
    IF Y.UPLD.ID AND NOT(Y.BOTH.SEL) THEN

        ENQ.DATA<2,Y.POS1> = Y.FLD.SEL
        ENQ.DATA<3,Y.POS1> = Y.OPRT
        ENQ.DATA<4,Y.POS1> = Y.UPLD.ID
    END

    IF Y.ID EQ 'JB.E.PP.BULKREFUND-NAU.AUTH' OR Y.ID EQ 'JB.E.PP.BULKFEECHG-NAU.AUTH' OR Y.ID EQ 'JB.E.PP.BULKINT-NAU.AUTH' THEN
        IF Y.DATE NE "" THEN
            Y.DATE = Y.DATE[3,6]
            ENQ.DATA<2,DATE.POS> = 'PAYMENT.EXECUTION.DATE'
            ENQ.DATA<3,DATE.POS> = 'LK'
            ENQ.DATA<4,DATE.POS> = Y.DATE:'...'
        END
    
        IF Y.DEBIT.ACCT.NO NE "" THEN
            R.ALTERNATE.ACCOUNT = '' ; ALTERNATE.ACCOUNT.ERR = ''
            CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.DEBIT.ACCT.NO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ALTERNATE.ACCOUNT.ERR)
            IF R.ALTERNATE.ACCOUNT NE "" THEN
                Y.DEBIT.ACCT.NO = R.ALTERNATE.ACCOUNT<1>
            END
            ENQ.DATA<2,DR.AC.POS> = 'DEBIT.ACCOUNT'
            ENQ.DATA<3,DR.AC.POS> = 'EQ'
            ENQ.DATA<4,DR.AC.POS> = Y.DEBIT.ACCT.NO
        END
    
    END


RETURN
*-----------------------------------------------------------------------------
END