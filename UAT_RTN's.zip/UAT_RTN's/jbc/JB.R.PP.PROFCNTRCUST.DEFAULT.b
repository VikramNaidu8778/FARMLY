$PACKAGE PP.RoutingAndSettlementService
SUBROUTINE JB.R.PP.PROFCNTRCUST.DEFAULT
*----------------------------------------------------------------------------
* This is validation routine to default Customer Number for field CUSTOMER.FOR.PL
* Defaulting logic referred from existing routine JBWW.R.FT.CREDITVAL.VALIDATE
* Attached in VERSION.CONTROL for PAYMENT.ORDER
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer         Reference          Description
* 11-NOV-2024   Prabhu D S        CBPAY-1173         Initial version
* 24-Jan-2025   Resmi R           CBPAY-1704         Logic included to default Profit Centre Cust value when the Debit Account is PL
* 14-Feb-2025   Lakshmi Priya     CBPAY-1701         Logic modified to default CustomerforPL of the debit account,
*                                                    even when Debit Account number is changed.
* 14-Feb-2025   P Amala           CBPAY-1889         Skip the logic to default ProfitCentercust for OTOP and OTKI type of Payment.
* 28-FEB-2025   Prabhu            CBPAY-2026         Considered debit side customer for profit center cust incase of credit side is internal or PL .
* 09-APR-2025   Prabhu D S        CBPAY-2428         Profit Center Customer defaulted when Dr Intenal & Cr PL for Book Payments.
* 13-JUN-2025   Prabhu D S        CBPAY-3280         CustomerforPL should be considered from PPClearingSetting>ClearingAccountNumber for HKCHATS
* 26-JUN-2025   Vikram Pavuluru   CBPAY-3050         Enhanced code for CustomerforPL should be considered from Credit Nostro Account for SWITMX clearing in HK Company.
*-----------------------------------------------------------------------------
    $INSERT I_EQUATE
    $INSERT I_COMMON
    $INSERT I_F.ACCOUNT
    $USING PI.Contract
    $INSERT I_F.PP.LORO.NOSTRO.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $USING PP.RoutingAndSettlementService
    $USING PP.LocalClearingService

    IF R.NEW(PI.Contract.PaymentOrder.PoPaymentOrderProduct) EQ 'OTOP' OR R.NEW(PI.Contract.PaymentOrder.PoPaymentOrderProduct) EQ 'OTKI' THEN RETURN

    GOSUB INITIALISE
    GOSUB PROCESS

RETURN

***********
INITIALISE:
**********

    FN.ACCOUNT = "F.ACCOUNT"
    F.ACCOUNT = ""
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.PP.LORO.NOSTRO.ACCOUNT.CONCAT = 'F.PP.LORO.NOSTRO.ACCOUNT.CONCAT'
    F.PP.LORO.NOSTRO.ACCOUNT.CONCAT  = ''
    CALL OPF(FN.PP.LORO.NOSTRO.ACCOUNT.CONCAT,F.PP.LORO.NOSTRO.ACCOUNT.CONCAT)

    FN.PP.LORO.NOSTRO.ACCOUNT = 'F.PP.LORO.NOSTRO.ACCOUNT'
    F.PP.LORO.NOSTRO.ACCOUNT = ''
    CALL OPF(FN.PP.LORO.NOSTRO.ACCOUNT,F.PP.LORO.NOSTRO.ACCOUNT)

    HKPAYCHNL.POS = ""
    CALL MULTI.GET.LOC.REF("PAYMENT.ORDER","L.PO.HKPAY.CHNL",HKPAY.CHNL.POS)


    R.DR.ACCOUNT = ""
    R.CR.ACCOUNT = ""
    Y.DR.NOSTRO.CAT = ""
    Y.CR.NOSTRO.CAT = ""
    Y.DR.ACNO = ""
    Y.CR.ACNO = ""
    Y.DR.ACPL = ""
    Y.CR.ACPL = ""
    Y.DR.ACCY = ""
    Y.CR.ACCY = ""
    Y.ORD.TYPE = ""
    Y.CUST = COMI

    Y.DEPT = R.NEW(PI.Contract.PaymentOrder.PoAccountOfficerForPL)
    Y.DR.ACNO = R.NEW(PI.Contract.PaymentOrder.PoDebitAccount)
    Y.CR.ACNO = R.NEW(PI.Contract.PaymentOrder.PoCreditAccount)
    Y.DR.ACPL = R.NEW(PI.Contract.PaymentOrder.PoDebitPl)
    Y.CR.ACPL = R.NEW(PI.Contract.PaymentOrder.PoCreditPl)
    Y.HKPAY.CHNL = R.NEW(PI.Contract.PaymentOrder.PoLocalRef)<1,HKPAY.CHNL.POS>
    Y.ORD.TYPE = R.NEW(PI.Contract.PaymentOrder.PoOrderType)


RETURN
********
PROCESS:
********

    IF Y.DR.ACNO THEN
        Y.ACNO = Y.DR.ACNO
    END ELSE
        Y.ACNO = Y.DR.ACPL
    END
    GOSUB GET.ACCOUNT
    Y.DR.ACNO = Y.ACNO
    Y.DR.CL.FLAG = Y.CL.FLAG
    Y.DR.NR.FLAG = Y.NR.FLAG
    Y.DR.PL.FLAG = Y.PL.FLAG
    Y.DR.INT.FLAG = Y.INT.FLAG

    IF Y.CR.ACNO THEN
        Y.ACNO = Y.CR.ACNO
    END ELSE
        Y.ACNO = Y.CR.ACPL
    END
    GOSUB GET.ACCOUNT
    Y.CR.ACNO = Y.ACNO
    Y.CR.CL.FLAG = Y.CL.FLAG
    Y.CR.NR.FLAG = Y.NR.FLAG
    Y.CR.PL.FLAG = Y.PL.FLAG
    Y.CR.INT.FLAG = Y.INT.FLAG


    BEGIN CASE
        CASE Y.DR.CL.FLAG
            GOSUB PROCESS.DRAC

        CASE Y.DR.NR.FLAG AND (NOT(Y.CR.CL.FLAG) AND NOT(Y.CR.NR.FLAG) AND NOT(Y.CR.PL.FLAG) AND NOT(Y.CR.INT.FLAG))
            GOSUB PROCESS.DRAC

        CASE Y.DR.NR.FLAG AND Y.CR.CL.FLAG
            GOSUB PROCESS.CRAC
        
        CASE Y.DR.NR.FLAG AND Y.CR.NR.FLAG
            GOSUB PROCESS.DRAC
            
        CASE Y.DR.NR.FLAG AND (Y.CR.PL.FLAG OR Y.CR.INT.FLAG)
            GOSUB PROCESS.DRAC

        CASE Y.DR.PL.FLAG AND (Y.CR.CL.FLAG OR Y.CR.NR.FLAG)
            GOSUB PROCESS.CRAC
            
        CASE Y.DR.PL.FLAG AND Y.CR.INT.FLAG
            GOSUB PROCESS.PLDR
            
        CASE Y.DR.INT.FLAG AND (Y.CR.CL.FLAG OR Y.CR.NR.FLAG)
            GOSUB PROCESS.CRAC
            
        CASE Y.DR.INT.FLAG AND Y.CR.PL.FLAG
            GOSUB PROCESS.PLCR
            
        CASE (Y.DR.PL.FLAG OR Y.DR.INT.FLAG) AND (Y.CR.CL.FLAG OR Y.CR.NR.FLAG)
            GOSUB PROCESS.CRAC
            
        CASE Y.DR.INT.FLAG AND Y.CR.INT.FLAG
            GOSUB PROCESS.INACC
             
* Customer of Nostro Account configured as Preferred Correspondent for Paymet Currency should be defaulted only
* for Outgoing Payments
        CASE (Y.DR.PL.FLAG OR Y.DR.INT.FLAG) AND (NOT(Y.CR.CLNR.FLAG) AND NOT(Y.CR.PL.FLAG) AND NOT(Y.CR.INT.FLAG))
            GOSUB PROCESS.PREFCORR

    END CASE

    COMI = Y.PROF.CUS

    IF (COMI EQ '') AND (R.NEW(PI.Contract.PaymentOrder.PoAccountOfficerForPL) EQ '') THEN
        ETEXT = 'EB-PRO.CEN.DEPT.ENTERED'
        CALL STORE.END.ERROR
    END


RETURN
************
GET.ACCOUNT:
************
    Y.NR.FLAG = 0
    Y.CL.FLAG = 0
    Y.PL.FLAG = 0
    Y.INT.FLAG = 0
    IF NOT(Y.ACNO) THEN
        RETURN
    END
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.ACNO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ALT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACNO = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
    END
    CALL F.READ(FN.ACCOUNT,Y.ACNO,R.ACCOUNT,F.ACCOUNT,ACC.DR.ERR)
    BEGIN CASE
        CASE NOT(ISDIGIT(Y.ACNO))
            Y.INT.FLAG = 1

        CASE NOT(R.ACCOUNT)
            Y.PL.FLAG = 1

        CASE R.ACCOUNT<AC.CATEGORY> GE 5000 AND R.ACCOUNT<AC.CATEGORY> LE 5999
            Y.NR.FLAG = 1
               
        CASE R.ACCOUNT<AC.CATEGORY> LT 5000 OR R.ACCOUNT<AC.CATEGORY> GT 5999
            Y.CL.FLAG = 1
               
    END CASE

RETURN
*************
PROCESS.DRAC:
*************

    CALL F.READ(FN.ACCOUNT,Y.DR.ACNO,R.DR.ACCOUNT,F.ACCOUNT,ACC.DR.ERR)
    Y.PROF.CUS = R.DR.ACCOUNT<AC.CUSTOMER>
    COMI = Y.PROF.CUS

RETURN
*************
PROCESS.CRAC:
*************

    CALL F.READ(FN.ACCOUNT,Y.CR.ACNO,R.CR.ACCOUNT,F.ACCOUNT,ACC.CR.ERR)
    Y.PROF.CUS = R.CR.ACCOUNT<AC.CUSTOMER>


RETURN
*************
PROCESS.PLDR:
*************
    CALL F.READ(FN.ACCOUNT,Y.CR.ACNO,R.ACC.CR.PL,F.ACCOUNT,ACC.CR.PL.ERR)
    Y.CR.ACOFF = R.ACC.CR.PL<AC.ACCOUNT.OFFICER>
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(PI.Contract.PaymentOrder.PoAccountOfficerForPL) = Y.CR.ACOFF
    END

RETURN
*************
PROCESS.PLCR:
*************

    CALL F.READ(FN.ACCOUNT,Y.DR.ACNO,R.ACC.DR.PL,F.ACCOUNT,ACC.DR.ERR)
    Y.DR.ACOFF = R.ACC.DR.PL<AC.ACCOUNT.OFFICER>
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(PI.Contract.PaymentOrder.PoAccountOfficerForPL) = Y.DR.ACOFF
    END

RETURN
**************
PROCESS.INACC:
**************

    CALL F.READ(FN.ACCOUNT,Y.DR.ACNO,R.ACC.INT,F.ACCOUNT,AC.INACC.ERR)
    Y.DR.ACOFF = R.ACC.INT<AC.ACCOUNT.OFFICER>
    IF (Y.CUST EQ '') AND (Y.DEPT EQ '') THEN
        R.NEW(PI.Contract.PaymentOrder.PoAccountOfficerForPL) = Y.DR.ACOFF
    END

RETURN


****************
PROCESS.PREFCORR:
****************

    IF Y.HKPAY.CHNL THEN
        GOSUB PROCESS.CLEARING.SETTING
    END ELSE
        Y.CR.NOST.ACCT = R.NEW(PI.Contract.PaymentOrder.PoCreditNostroAccount)

        IF Y.CR.NOST.ACCT NE '' THEN
            CALL F.READ(FN.ACCOUNT,Y.CR.NOST.ACCT,R.CR.NOST.ACC,F.ACCOUNT,AC.ERR)
            Y.PROF.CUS = R.CR.NOST.ACC<AC.CUSTOMER>
        END ELSE
            GOSUB FETCH.PREF.CORR.ID
        END
    END

RETURN

*************************
PROCESS.CLEARING.SETTING:
*************************
*If the channel is HKCHATS & Customer transfer. Then Customer for PL will be set as PPClearingSetting>ClearingAccountNumber customer ID.
*If the channel is HKCHATS & Bank transfer. Then Customer for PL will be set as PPClearingSetting>ClearingAccountNumber customer ID.
*If the channel is SWIFTMX & Customer transfer. Then Customer for PL will be set as Credit Nostro account customer ID.
*If the channel is SWIFTMX & Bank transfer. Then Customer for PL will be set as Credit Nostro account customer ID.
*If the channel is SWIFTMX & If the Credit Nostro Account does not have customer ID. Then the customer for PL should be fetched from PreferredCorrespondent.

    BEGIN CASE
        CASE (Y.HKPAY.CHNL EQ 'HKCHATS') AND (Y.ORD.TYPE EQ 'CUSTOMER')
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingID> = "CHATSMX"
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messagePaymentType> = "pacs.008"
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messageDirection> = "S"
            GOSUB LOCAL.CLEARING.ACCOUNT
        CASE (Y.HKPAY.CHNL EQ 'HKCHATS') AND (Y.ORD.TYPE EQ 'BANK')
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingID> = "CHATSMX"
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messagePaymentType> = "pacs.009"
            iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messageDirection> = "S"
            GOSUB LOCAL.CLEARING.ACCOUNT
        CASE OTHERWISE
            Y.CR.NOST.ACCT = R.NEW(PI.Contract.PaymentOrder.PoCreditNostroAccount)
            IF Y.CR.NOST.ACCT NE '' THEN
                CALL F.READ(FN.ACCOUNT,Y.CR.NOST.ACCT,R.CR.NOST.ACC,F.ACCOUNT,AC.ERR)
                Y.PROF.CUS = R.CR.NOST.ACC<AC.CUSTOMER>
            END ELSE
                GOSUB FETCH.PREF.CORR.ID
            END
    END CASE
RETURN

**********************
LOCAL.CLEARING.ACCOUNT:
**********************
    
    iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingCurrency> = R.NEW(PI.Contract.PaymentOrder.PoPaymentCurrency)
    PP.LocalClearingService.getClearingSetting(iClearingSetting,oClearingSetting,oClearingSettingErr)
    IF NOT(oClearingSettingErr) THEN
        Y.CLR.ACC = oClearingSetting<PP.LocalClearingService.ClearingSetting.clearingAccountNumber>
        CALL F.READ(FN.ACCOUNT,Y.CLR.ACC,R.ACC.LN,F.ACCOUNT,ACC.LN.ERR)
        Y.PROF.CUS = R.ACC.LN<AC.CUSTOMER>
    END
RETURN
*******************
FETCH.PREF.CORR.ID:
*******************

    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.companyID> = R.COMPANY(EB.COM.MNEMONIC)
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.destinationCountryCode> = R.NEW(PI.Contract.PaymentOrder.PoBeneficiaryCountryCode)
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.transactionCurrency> = R.NEW(PI.Contract.PaymentOrder.PoPaymentCurrency)
    iPrefRequest<PP.RoutingAndSettlementService.PrefRequest.routingProduct> = "*"

    PP.RoutingAndSettlementService.findPPLPreferredCorrespondent(iPrefRequest, oPrefDetails, oPrefError)

    Y.PREF.CORR.ID = oPrefDetails<PP.RoutingAndSettlementService.PrefDetails.prefCorrespondentID>

    IF Y.PREF.CORR.ID THEN

        GOSUB PROCESS.PPLORONOSTRO

    END

RETURN

*********************
PROCESS.PPLORONOSTRO:
*********************

    Y.PO.CCY = R.NEW(PI.Contract.PaymentOrder.PoPaymentCurrency)

    Y.LORONOST.CONCAT.ID = Y.PREF.CORR.ID:Y.PO.CCY:"N"

    CALL F.READ(FN.PP.LORO.NOSTRO.ACCOUNT.CONCAT,Y.LORONOST.CONCAT.ID,R.LN.CONCAT,F.PP.LORO.NOSTRO.ACCOUNT.CONCAT,CONCAT.ERR)
    IF R.LN.CONCAT THEN
        Y.LORO.NOSTRO.ID = R.LN.CONCAT<4>
        CALL F.READ(FN.PP.LORO.NOSTRO.ACCOUNT,Y.LORO.NOSTRO.ID,R.LORO.NOSTRO,F.PP.LORO.NOSTRO.ACCOUNT,LORONOST.ERR)
        Y.LN.ACC.NBR = R.LORO.NOSTRO<PP.LNA.AccountNumber>
        CALL F.READ(FN.ACCOUNT,Y.LN.ACC.NBR,R.ACC.LN,F.ACCOUNT,ACC.LN.ERR)
        Y.PROF.CUS = R.ACC.LN<AC.CUSTOMER>
    END

RETURN

***********************************************************************************************************
END