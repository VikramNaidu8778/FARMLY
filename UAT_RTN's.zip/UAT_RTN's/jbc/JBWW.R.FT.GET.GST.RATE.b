*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.GET.GST.RATE(Y.CUSTOMER.ID,Y.FT.CATEG.ACC,R.JBWW.H.EB.GENERICPARAMETER,Y.PROCESSING.DATE,Y.GST.RATE,Y.GST.TYPE)
*-----------------------------------------------------------------------------
* Description:
* This routine is called from The purpose of the routine is to GST RATE & GST TYPE.
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Initial Creation
* Date         who               Reference     Description
* 20-02-2018   MaheshKumar       JB2A-48744    Intial
* 10-09-2022   Madhu             P-3998        To enchance the GST rules to hike the 8% GST for manual input FT
* 29-11-2022   Madhu             T24-18774     Changed the condition to fetch the GST rate
* 29-05-2023   Madhu             FSQD-2329     Modified for GST transition from 8% to 9%
* 07-08-2023   Madhu             FSQD-3481         Amended the routine to cater the HK GST
* 14/03/2024   Jeeva/Madhu       L1TAXGST         Modified routine to align with L1TAX GST
*------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.TAX
*------------------------------------------------------------------------------
    GOSUB OPEN.FILES
    GOSUB GET.LOCAL.FIELD
    GOSUB PROCESS
RETURN
*------------------------------------------------------------------------------
OPEN.FILES:
*----------
*
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
*
RETURN
*-----------------------------------------------------------------------------
GET.LOCAL.FIELD:
*---------------
*
    Y.APP = 'CUSTOMER'
    Y.FLD = 'BELONG.STATUS'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
    BELONG.STAT.POS = Y.POS<1,1>
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------------
*
    GOSUB CHECK.BELONG.STATUS
*
    BEGIN CASE
        CASE Y.BELONG.STATUS EQ 'Y'
            Y.BELONG.TYPE.Y = "BELONG"
            GOSUB READ.GST.PARAMETER
*
        CASE Y.BELONG.STATUS EQ 'N'
            Y.BELONG.TYPE.N = "NOT BELONG"
            GOSUB READ.GST.PARAMETER
 
    END CASE
*
RETURN
*-----------------------------------------------------------------------------
CHECK.BELONG.STATUS:
*-------------------
*
    R.CUSTOMER = '' ; CUS.ERR =''; Y.BELONG.STATUS =''
    CALL F.READ(FN.CUSTOMER,Y.CUSTOMER.ID,R.CUSTOMER,F.CUSTOMER,CUS.ERR)
    Y.BELONG.STATUS = R.CUSTOMER<EB.CUS.LOCAL.REF,BELONG.STAT.POS>
*
    FN.TAX = 'F.TAX'
    F.TAX  = ''
    CALL OPF(FN.TAX,F.TAX)
*
    Y.BK.DT.POS = '' ; Y.BK.DATE = ''
    LOCATE 'BACKDATED' IN R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME,1> SETTING Y.BK.DT.POS THEN
        Y.BK.DATE = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,Y.BK.DT.POS>
    END
*
RETURN
*-----------------------------------------------------------------------------
READ.GST.PARAMETER:
*------------------
    Y.DEBIT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
*
    BEGIN CASE
        CASE ID.COMPANY[1,2] EQ 'SG' AND Y.BELONG.STATUS EQ 'Y'
            GOSUB READ.GST.RULES.PARAM
        CASE ID.COMPANY[1,2] EQ 'SG' AND Y.BELONG.STATUS EQ 'N'
            GOSUB GET.SG.GST.DETS
        CASE ID.COMPANY[1,2] EQ 'HK' AND Y.BELONG.STATUS EQ 'Y'
            GOSUB CHECK.HK.GST.DETS
        CASE ID.COMPANY[1,2] EQ 'HK' AND Y.BELONG.STATUS EQ 'N'
            Y.GST.TYPE = "6100"
            Y.GST.RATE = "0.00"
    END CASE
*
RETURN
*-----------------------------------------------------------------------------
READ.GST.RULES.PARAM:
*--------------------
    GOSUB GET.GPM.PARAM.DET
*Default rate
    Y.GST.RATE = TRIM(FIELD(Y.DATE.LIST<1>,'>',2))
    BEGIN CASE
        CASE Y.FT.CATEG.ACC NE ''
            LOCATE Y.FT.CATEG.ACC IN Y.PL.LIST SETTING POS ELSE
                Y.GST.RATE = '0.00'
				Y.GST.TYPE = "6100"
                RETURN
            END
        CASE 1
            
    END CASE
    Y.CNT = 0
    LOOP
        Y.CNT = Y.CNT + 1
    WHILE Y.CNT LE Y.DATE.CNT
        Y.GST.RATE = ''
        Y.PARAM.DATE = FIELD(FIELD(Y.DATE.LIST<Y.CNT>,'>',2),'.',2)
        IF Y.DATE GE Y.PARAM.DATE THEN
            Y.GST.TYPE = FIELD(FIELD(Y.DATE.LIST<Y.CNT>,'>',2),'.',1)
            Y.TAX.ID = Y.GST.TYPE:".":Y.PARAM.DATE
            CALL F.READ(FN.TAX,Y.TAX.ID,R.TAX.PARAM,F.TAX,Y.ER)
            IF R.TAX.PARAM<EB.TAX.RATE> THEN
                Y.GST.RATE = R.TAX.PARAM<EB.TAX.RATE>
            END
        END
        IF Y.GST.RATE NE '' THEN
            Y.CNT = Y.DATE.CNT
        END
    REPEAT
*
RETURN
*-----------------------------------------------------------------------------
GET.SG.GST.DETS:
*------------------
    GOSUB GET.GPM.PARAM.DET
    
    BEGIN CASE
        CASE Y.FT.CATEG.ACC NE ''
            LOCATE Y.FT.CATEG.ACC IN Y.PL.BNK.SER SETTING POS ELSE
                Y.GST.RATE = '0.00'
				Y.GST.TYPE = "6100"
                RETURN
            END
        CASE 1
    END CASE
    
    Y.CNT = 0
    LOOP
        Y.CNT = Y.CNT + 1
    WHILE Y.CNT LE Y.DATE.CNT
        Y.GST.RATE = ''
        Y.PARAM.DATE = FIELD(FIELD(Y.DATE.LIST<Y.CNT>,'>',2),'.',2)
        IF Y.DATE GE Y.PARAM.DATE THEN
            Y.GST.TYPE = FIELD(FIELD(Y.DATE.LIST<Y.CNT>,'>',2),'.',1)
            Y.TAX.ID = Y.GST.TYPE:".":Y.PARAM.DATE
            CALL F.READ(FN.TAX,Y.TAX.ID,R.TAX.PARAM,F.TAX,Y.ER)
            IF R.TAX.PARAM<EB.TAX.RATE> THEN
                Y.GST.RATE = R.TAX.PARAM<EB.TAX.RATE>
            END
        END
        IF Y.GST.RATE NE '' THEN
            Y.CNT = Y.DATE.CNT
        END
    REPEAT

RETURN
*-----------------------------------------------------------------------------
GET.GPM.PARAM.DET:
*-----------------

    LOCATE 'VERSION.NAME' IN R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME,1> SETTING POS THEN
        Y.VER.NAME = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,POS>
		CHANGE SM TO FM IN Y.VER.NAME
    END

    LOCATE 'ALLOWED.FT.PL.CATEGORY' IN R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME,1> SETTING POS THEN
        Y.PL.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,POS>
        CHANGE SM TO FM IN Y.PL.LIST
        CHANGE VM TO FM IN Y.PL.LIST
        CHANGE ' ' TO FM IN Y.PL.LIST
    END

    LOCATE 'FUNDS.TRANSFER' IN R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME,1> SETTING POS THEN
        Y.DATE.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,POS>
        CHANGE SM TO FM IN Y.DATE.LIST
        CHANGE VM TO FM IN Y.DATE.LIST
        Y.DATE.CNT = DCOUNT(Y.DATE.LIST,FM)
    END
    
    LOCATE 'ALLOWED.FT.PL.BNK.SERVICE' IN R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME,1> SETTING POS THEN
        Y.PL.BNK.SER = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,POS>
        CHANGE SM TO FM IN Y.PL.BNK.SER
        CHANGE VM TO FM IN Y.PL.BNK.SER
		CHANGE ' ' TO FM IN Y.PL.BNK.SER
    END
    
    *IF PGM.VERSION MATCHES Y.VER.NAME THEN
	VER.POS =''
	LOCATE PGM.VERSION IN Y.VER.NAME SETTING VER.POS THEN
        Y.DATE = Y.DEBIT.VALUE.DATE
    END ELSE
        Y.DATE = Y.PROCESSING.DATE
    END
    
RETURN
*-----------------------------------------------------------------------------
CHECK.HK.GST.DETS:
*------------------
    IF Y.DEBIT.VALUE.DATE GE Y.BK.DATE THEN
        GOSUB READ.GST.RULES.PARAM
    END ELSE
        Y.GST.TYPE = "6100"
        Y.GST.RATE = "0.00"
    END
RETURN
*-----------------------------------------------------------------------------
END
