    SUBROUTINE JBWW.R.FT.DRAFTISSUECURR.VALIDATE 
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the validation routine attached to the field CREDIT.CURRENCY in FT Draft versions.
* It is used to default the CREDIT.CURRENCY field with DEBIT.ACCT.NO - CURRENCY value if the 
* CREDIT.CURRENCY field is empty.
*---------------------------------------------------------------------------------------------
* Attached: to versions FUNDS.TRANSFER,JBWW.V.FT.ODFCY.INP and FUNDS.TRANSFER,JBWW.V.FT.OD110.INP
*           and FUNDS.TRANSFER,JBWW.V.FT.OD103.INP   
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*-------------------------------------------------------------------------------------------
* Date               who               Reference          Description
* 26-04-2016        Rekha M             PMT-005         Initial Version
*-------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
	
    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
******************************************************************
INITIALISE:
***********

    Y.DR.ACC = ''
    Y.DR.CCY  = ''

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    
    Y.DR.ACC = R.NEW(FT.DEBIT.ACCT.NO)
	Y.CR.ACC = R.NEW(FT.CREDIT.CURRENCY)
    
    RETURN
******************************************************************
PROCESS:
***********
    IF Y.DR.ACC THEN
      CALL F.READ(FN.ACCOUNT,Y.DR.ACC,R.ACCOUNT,F.ACCOUNT,ACC.ERR)
      Y.DR.CCY = R.ACCOUNT<AC.CURRENCY>
	  
	  IF COMI EQ '' THEN
          COMI = Y.DR.CCY 
	  END
    END

    RETURN
	
********************************************************************
END	



