* @ValidationCode : MjoxMzI4ODU4ODM2OkNwMTI1MjoxNzEyNTc0MTczNjI5OjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 09 May 2024 16:32:53
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.R.PP.OTHRMDLSRVDET.INP
*-----------------------------------------------------------------------------------------------------
*Attached as Input Routine to the version>PAYMENT.ORDER,JB.V.PP.OTHERMODULE.INP
*-----------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*21/03/2025    Resmi R                       CBPAY-2192              Introduced to default Order Initiation Type value to "MXCHATS" when the Credit Nostro Account is matching the PP.CLEARING.SETTING>ClearingAccountNumber record
*
*--------------------------------------------------------------------------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $USING PP.LocalClearingService
     
    GOSUB INIT
    GOSUB PROCESS
    
RETURN

INIT:
*****

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    
    Y.CRD.NOST.ACC = R.NEW(PO.CREDIT.NOSTRO.ACCOUNT)
    Y.PMT.CCY = R.NEW(PO.PAYMENT.CURRENCY)
       
    
    Y.GPM.FLD.NAMES = "TRSY.CLEARING.CCY":@FM:"TRSY.CLEARING.MSG.TYPE"
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.FLD.NAMES,Y.GPM.VALUES)
    Y.CLRNG.CCY = Y.GPM.VALUES<1>
    Y.CLRNG.MSG.TYP = Y.GPM.VALUES<2>

    CHANGE ',' TO @VM IN Y.CLRNG.CCY
      
RETURN

PROCESS:
*********

    IF Y.PMT.CCY MATCHES Y.CLRNG.CCY THEN       
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingID>        = "CHATSMX"
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingCurrency>  = Y.PMT.CCY
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingNatureCode> = "*"
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messageDirection> = "S"
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.messagePaymentType> = Y.CLRNG.MSG.TYP
        iClearingSetting<PP.LocalClearingService.ClearingSettingRequest.clearingTransactionType> = "CT"
       
        PP.LocalClearingService.getClearingSetting(iClearingSetting, oClearingSetting, oClearingSettingErr)
    
        IF oClearingSetting NE '' THEN
            Y.CLRNG.ACCT.NBR = oClearingSetting<PP.LocalClearingService.ClearingSetting.clearingAccountNumber>
            IF Y.CRD.NOST.ACC EQ Y.CLRNG.ACCT.NBR THEN
                R.NEW(PO.ORDER.INITIATION.TYPE) = "MXCHATS"
                R.NEW(PO.PAYMENT.CATEGORY) = ''
                R.NEW(PO.PAYMENT.CATEGORYPURP.PRTY) = "IFT02"
            END
        END

    END

RETURN
***********************************************************************************************
END
    
