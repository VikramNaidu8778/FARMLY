SUBROUTINE JB.R.PP.EXTACCNO.DEFAULT
*-----------------------------------------------------------------------------
* This subroutine attached as the Validation routine to the versions
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.INP
* PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.API.1.0.0
* This routine to default the
* OUR.EXT.ACCT.NO in BeneficiaryAccount (Creditor Account) in OE
* L.XX.BIC.CODE in AccountWithInstIdentifierCode (BIC) in OE
* Attached to the field OE>DebitAccountNumber
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 15-Apr-2025 u40786             CBPAY-2086        Initial Version
*
* 24-Apr-2025 u40786             CBPAY-2086        To default the L.XX.BIC.CODE in AccountWithInstIdentifierCode (BIC) in OE
*                                CBPAY-2357        This is to generate the camt.057 for actual fund receiver
*
* 08-May-2025 u40786             CBPAY-2696        Fetch the details from PP.LORO.NOSTRO.ACCOUNT to avoid the test bic dependency in test areas
*                                                  like SIT, UAT, TST, etc.,
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COMPANY
    $INSERT I_LoroNostroAccountService_LoroNostroAccRequest
    $INSERT I_LoroNostroAccountService_LoroNostroAccList
    $INSERT I_LoroNostroAccountService_AccHldBankDet
    $INSERT I_LoroNostroAccountService_DASError
    $INSERT I_LoroNostroAccountService_AccHldBankRequest
    
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*
*****
INIT:
*****

    ID.ACCT = R.NEW(PP.OEYG.DebitAccountNumber)

    COMP.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)

    FN.ACCT = 'F.ACCOUNT'
    F.ACCT = ''
    CALL OPF(FN.ACCT, F.ACCT)
*
RETURN
*
********
PROCESS:
********

    GOSUB GET.BIC.DETS
    GOSUB GET.EXT.ACC.NO
*
RETURN
*
*************
GET.BIC.DETS:
*************
    
    I.LORONOSTRO.REQ<LoroNostroAccRequest.companyID> = COMP.MNEMONIC
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountType> = 'N'
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountNumberCompanyID> = COMP.MNEMONIC
    I.LORONOSTRO.REQ<LoroNostroAccRequest.accountNumber> = R.NEW(PP.OEYG.DebitAccountNumber)
        
    O.LORONOSTRO.DETS = ''
    O.LORONOSTRO.ERR = ''
    
    CALL LoroNostroAccountService.getLoroNostroOwningBICList(I.LORONOSTRO.REQ,O.LORONOSTRO.DETS,O.LORONOSTRO.ERR)

    BIC.CODE = O.LORONOSTRO.DETS<LoroNostroAccList.bicCode>
    R.NEW(PP.OEYG.AccountWithInstIdentifierCode) = BIC.CODE<1,1>
*
RETURN
*
***************
GET.EXT.ACC.NO:
***************
    
*    I.ACCHLDBANK.REQ<AccHldBankRequest.companyID> = COMP.MNEMONIC
*    I.ACCHLDBANK.REQ<AccHldBankRequest.accountNumberType> = 'N'
*    I.ACCHLDBANK.REQ<AccHldBankRequest.acctNumCompanyID> = COMP.MNEMONIC
*    I.ACCHLDBANK.REQ<AccHldBankRequest.accountNumber> = R.NEW(PP.OEYG.DebitAccountNumber)
*    I.ACCHLDBANK.REQ<AccHldBankRequest.bicCode> = BIC.CODE<1,1>
*    I.ACCHLDBANK.REQ<AccHldBankRequest.accountCurrency> = R.NEW(PP.OEYG.DebitAccountCurrency)
*
*    O.ACCHLDBANK.DETS = ''
*    O.ACCHLDBANK.ERR = ''
*    CALL LoroNostroAccountService.getAcctNoInHoldingBank(I.ACCHLDBANK.REQ,O.ACCHLDBANK.DETS,O.ACCHLDBANK.ERR)
    
*    EXT.ACC.NO = O.ACCHLDBANK.DETS<AccHldBankDet.accountNumberInHoldingBk>
*    R.NEW(PP.OEYG.BeneficiaryAccount) =  EXT.ACC.NO<1,1>
    
    R.ACCT = ''
    E.ACCT = ''
    CALL F.READ(FN.ACCT,ID.ACCT,R.ACCT,F.ACCT,E.ACCT)

    R.NEW(PP.OEYG.BeneficiaryAccount) = R.ACCT<AC.OUR.EXT.ACCT.NO>
*
RETURN
*
END
*