SUBROUTINE JBWW.B.FT.POSTGSTENTRY.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                     Reference               Description
*-----------------------------------------------------------------------------
* 22/03/2018   Maheshkumar                   JB2A-49865
* 02/05/2018   Maheshkumar                   JB2A-51702
*-----------------------------------------------------------------------------
*Description
*************
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER
$INSERT I_JBWW.B.FT.POSTGSTENTRY.COMMON
$INSERT I_F.GST.STMT.ENTRY.CONCAT.MB
$INSERT I_F.GST.STMT.ENTRY.MB
$INSERT I_F.JBWW.L.FT.GSTENTRY.DETAILS
$INSERT I_F.JBWW.L.FT.GSTENTRY.PROCESSED
*-----------------------------------------------------------------------------
   SEL.CMD = '';SEL.LIST = '';NO.OF.REC= '';ERR.LIST ='';FINAL.LIST ='' ;*JB2A-51702 Start
   SEL.CMD = 'SELECT ':FN.JBWW.L.FT.GSTENTRY.DETAILS 
   CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.LIST)
   LOOP
      REMOVE SEL.ID FROM SEL.LIST SETTING SEL.POS
   WHILE SEL.ID:SEL.POS
       Y.SEL.DATE = FIELD(SEL.ID,'*',1)
	   IF Y.SEL.DATE LE TODAY THEN
	      FINAL.LIST<-1> = SEL.ID
	   END
   REPEAT
   CALL BATCH.BUILD.LIST('',FINAL.LIST);*JB2A-51702 End
   RETURN
*-----------------------------------------------------------------------------
END
