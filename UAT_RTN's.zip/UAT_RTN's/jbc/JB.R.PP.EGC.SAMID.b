* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 871829
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.EGC.SAMID
*----------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is attached in EB.GC.CONSTRAINTS>PAYMENT.ORDER,PP.ORDER.ENTRY,EB.QUERIES.ANSWERS to return the block ids from
* the Portfolio.
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
* 01/07/2024     Amala P                       CBPAY-534                       Capture the Portfolio ID for the corresponding
*                                                                              Account number and pass the Block IDs.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.EB.QUERIES.ANSWERS
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.ACCOUNT
*-------------------------------------------------------------------------

    GOSUB INIT
	IF ID.NEW[1,4] = 'FMQA' THEN
        GOSUB PROCESS.FMQA
	END ELSE
        Y.ACT.NO = COMI
        CALL F.READ(FN.ACCOUNT,Y.ACT.NO,R.AC,F.ACCOUNT,'')
        Y.SAM.ID = R.AC<AC.PORTFOLIO.NO,1>
        IF Y.SAM.ID NE '' THEN
            GOSUB PROCESS
        END
    END

RETURN
*-----------------------------------------------------------------------------

INIT:
*****

    APPL = 'SEC.ACC.MASTER'
    LREF.FLD = 'L.XX.TAG.BLK.ID'
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)

    Y.BLK.IDS.POS = Y.POS<1,1>

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
	
    F.POR.TRANSACTION = ''
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)

    Y.SAM.ID = '' ; R.SAM = '' ; Y.ACT.NO = ''
	Y.PORTRN.ID = '' ; R.PORREC = ''
	
RETURN

PROCESS.FMQA:
*************

    Y.PORTRN.ID = R.NEW(EB.QA.ORIG.FT.NUMBER)
	
    CALL F.READ(FN.POR.TRANSACTION,Y.PORTRN.ID,R.PORREC,F.POR.TRANSACTION,'')
* for incoming camt.56, DebitAccount is not applicable
*	Y.ACT.NO = R.PORREC<PPPTX.DebitMainAccount>
*      GOSUB READ.AC
*      Y.SAM.ID = R.AC<AC.PORTFOLIO.NO,1>
*       IF Y.SAM.ID NE '' THEN
*         GOSUB PROCESS
*	   END
	Y.ACT.NO = R.PORREC<PPPTX.CreditMainAccount>
    GOSUB READ.AC
    Y.SAM.ID = R.AC<AC.PORTFOLIO.NO,1>
    IF Y.SAM.ID NE '' THEN
        GOSUB PROCESS
    END

RETURN

READ.AC:
********
    R.AC = ''
    CALL F.READ(FN.ACCOUNT,Y.ACT.NO,R.AC,F.ACCOUNT,'')
RETURN

PROCESS:
********

    Y.BULK.ID.CNT = '' ; BLK.VALUES = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,'')
    IF R.SAM NE '' THEN

        Y.BULK.ID = R.SAM<SC.SAM.LOCAL.REF,Y.BLK.IDS.POS>
        CONVERT SM TO VM IN Y.BULK.ID
        CONVERT VM TO FM IN Y.BULK.ID
        Y.BULK.ID.CNT = DCOUNT(Y.BULK.ID,FM)
        I = 0
        AF = 0
        LOOP
            I = I + 1
        WHILE I LE Y.BULK.ID.CNT
            BLK.VALUES<-1> = Y.BULK.ID<I>
        REPEAT
        COMI = BLK.VALUES
    END
RETURN
END
