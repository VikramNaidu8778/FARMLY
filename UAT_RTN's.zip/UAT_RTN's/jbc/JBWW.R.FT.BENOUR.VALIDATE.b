*-----------------------------------------------------------------------------
* <Rating>-24</Rating>
*------------------------------------------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.BENOUR.VALIDATE 
*------------------------------------------------------------------------------------------------------------------    
*------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------- 
* Date          Developer                           Reference               Description
*-------------------------------------------------------------------------------------------  
* 11/09/2017    SUSHMITHA.B                      JB2A-43485                 added condition to default field values COMMISION.CODE and CHARGE.CODE
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------

*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>

    Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)
	Y.BEN.CHARGES = R.NEW(FT.BEN.OUR.CHARGES)
    
*** <region name= PROCESS>
PROCESS:
****************
    
	
	IF Y.TXN.TYPE EQ "OT60" AND Y.BEN.CHARGES EQ "BEN" THEN
	
		R.NEW(FT.COMMISSION.CODE) = "CREDIT LESS CHARGES"
		R.NEW(FT.CHARGE.CODE) = "CREDIT LESS CHARGES"

	END
	
    RETURN

*** <desc>Validation process </desc>

*** </region>
*-----------------------------------------------------------------------------

    END