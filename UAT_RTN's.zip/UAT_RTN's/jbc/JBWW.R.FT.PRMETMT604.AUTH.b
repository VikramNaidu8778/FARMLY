* @ValidationCode : MTotMjAyMjY4MTkzODpJU08tODg1OS0xOjE1MTgxNzEzMzM4Njc6MzExODQ5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 09 Feb 2018 15:45:33
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-----------------------------------------------------------------------------
* <Rating>445</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PRMETMT604.AUTH

* Revision History:
*----------------------------------------------------------------------------------
* Date               who               Reference          Description
* 07-12-2016        Rekha M              CR-201             Amended
* 07/02/2017        Rekha M            JB2A-26772           Amended
* 28/FEB/2017       Mahesh J           JB2A-27844           604 MT message is getting generated for ACAC type.
*                                                           After fix, the MT 604 message generated only OT60,ACPM and the DOH key 604.2.1 changed to 604.1.1
* 25/APR/2017       Mahesh J           JB2A-31125           Changed forward slash '/' for 26C,
*17/MAY/2017        Mahesh J           JB2A-31125           tag 32F values changed to DEBIT.AMOUNT/CREDIT.AMOUNT
* 09/02/2018        Karthik            JB2A-48624           Condition included to check for field SEND.PAYMENT.Y.N. If SEND.PAYMENT.Y.N is NO then MT604 will not be generated
* 21/02/2019        Venkat JC	       T24-14585            Condition included to check for FT RECORD.STATUS RNAU. If FT RECORD.STATUS is RNAU then MT604 will not be generated.
* 23/10/2023        Rajan S            GBLBB-881            Removed hardcoded values and parameterised.
*----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COMPANY
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.USER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

*T24-14585-S
	IF R.NEW(FT.RECORD.STATUS) EQ 'RNAU' THEN
		RETURN
	END
*T24-14585-E

* JB2A-27844 - S
    IF R.NEW(FT.SEND.PAYMENT.Y.N) EQ "NO" THEN
        RETURN
    END
    GOSUB CHECK.FT.TXNTYPE
    IF GEN.PARM.FOUND THEN
        GOSUB GENERATE.MT.MESSAGES
    END

* JB2A-27844 - E

    RETURN
*-------------------------------------------------------------------------------
GENERATE.MT.MESSAGES:
**********************

    GOSUB INIT.PARA
    GOSUB PROCESS.PARA
    GOSUB CALL.APP.HANDOFF

    RETURN
*-------------------------------------------------------------------------------
INIT.PARA:
*-----------------------------------------------------------------------------

    SEND.PARTY = '' ; * Initialized the variable due to compilation error

    R.NEW(FT.RELATED.REF) = 'NEW'
    FOR I = 1 TO FT.AUDIT.DATE.TIME
        R.NEW.REC<I>=R.NEW(I)

    NEXT I

    LRF.FIELDS = 'L.FT.PM.METLOC':VM:'L.XX.PM.ALLOC':VM:'L.XX.PM.METTYPE':VM:'L.XX.PM.METID':VM:'L.XX.PM.METQTY':VM:'L.XX.PM.DENOMIN' ;**** CR-201 S/E
    LRF.APP = "FUNDS.TRANSFER"
    CALL MULTI.GET.LOC.REF(LRF.APP,LRF.FIELDS,LRF.POS)

    METLOC.POS = LRF.POS<1,1>
    PM.ALLOC.POS = LRF.POS<1,2>
    PM.MET.POS = LRF.POS<1,3>
    PM.METID.POS = LRF.POS<1,4>
    PM.METQTY.POS = LRF.POS<1,5>
    DENOMIN.POS = LRF.POS<1,6>   ;**** CR-201 S/E



    TAG26.A.INFO = R.NEW(FT.LOCAL.REF)<1,METLOC.POS>
    TAG26.B.INFO = R.NEW(FT.LOCAL.REF)<1,PM.ALLOC.POS>

* JB2A-31125 - S

    BEGIN CASE
        CASE TAG26.B.INFO EQ 'ALLOCATED'
            TAG26.B.INFO = 'ALLOC'
        CASE TAG26.B.INFO EQ 'UNALLOCATED'
            TAG26.B.INFO = 'UNALL'
    END CASE

* JB2A-31125 - E

    TAG26.C.INFO = R.NEW(FT.LOCAL.REF)<1,PM.MET.POS>
    TAG26.DENOMIN = R.NEW(FT.LOCAL.REF)<1,DENOMIN.POS> ;**** CR-201 S/E
    THRD.ARR<2> = R.NEW(FT.LOCAL.REF)<1,PM.METID.POS>
* THRD.ARR<3> = R.NEW(FT.LOCAL.REF)<1,PM.METQTY.POS>:R.NEW(FT.LOCAL.REF)<1,DENOMIN.POS> ; **** JB2A-31125 **** S/E
    THRD.ARR<4> = R.NEW(FT.DEBIT.VALUE.DATE)


    IF R.NEW(FT.DEBIT.AMOUNT) THEN
        THRD.ARR<5> = R.NEW(FT.DEBIT.AMOUNT)
    END ELSE
        THRD.ARR<5> = R.NEW(FT.CREDIT.AMOUNT)
    END

*JB2A-31125 - S

    FT.FULL.VAL = THRD.ARR<5>
    FT.FULL.VAL1 = FIELDS(FT.FULL.VAL,".",1)
    FT.FULL.VAL2 = FIELDS(FT.FULL.VAL,".",2)
    IF FT.FULL.VAL2 EQ '0' THEN
        THRD.ARR<5> = FT.FULL.VAL1
    END
*JB2A-31125 - S

    THRD.ARR<3> = R.NEW(FT.LOCAL.REF)<1,PM.METQTY.POS>:THRD.ARR<5> ; **** JB2A-31125 **** S/E

*   THRD.ARR<1> = "\":TAG26.A.INFO:"\":TAG26.B.INFO:"\":TAG26.C.INFO:"\":TAG26.DENOMIN ;**** CR-201 S/E
    THRD.ARR<1> = "/":TAG26.A.INFO:"/":TAG26.B.INFO:TAG26.C.INFO:TAG26.DENOMIN  ; ******  JB2A-26772 S/E ******  JB2A-31125 S/E
    THRD.ARR<6> = R.NEW(FT.RELATED.REF)

    RETURN

*-----------------------------------------------------------------------------
PROCESS.PARA:
*-----------------------------------------------------------------------------

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    CR.ACCT.NO.VAL = R.NEW(FT.CREDIT.ACCT.NO)
    R.ACCOUNT = ''
    ERR.ACCT = ''
    CALL F.READ(FN.ACCOUNT,CR.ACCT.NO.VAL,R.ACCOUNT,F.ACCOUNT,ERR.ACCT)
    CR.CUST.NO.VAL = R.ACCOUNT<AC.CUSTOMER>

    DR.CUSTOMER.NO   = R.NEW(FT.DEBIT.CUSTOMER)
*THRD.ARR<7> = DR.CUSTOMER.NO
    THRD.ARR<7> = CR.CUST.NO.VAL
    THRD.ARR<8> = ID.NEW

    CALL F.READ(FN.CUSTOMER,DR.CUSTOMER.NO,R.CUSTOMER,F.CUSTOMER,CUST.ERR)

    IF NOT(CUST.ERR) THEN
        THRD.ARR<9> = R.CUSTOMER<EB.CUS.LANGUAGE>
    END

    IF R.NEW(FT.CREDIT.AMOUNT) THEN

        THRD.ARR<10>=R.NEW(FT.DEBIT.CURRENCY)

    END ELSE

        THRD.ARR<10>=R.NEW(FT.CREDIT.CURRENCY)

    END

    THRD.ARR<11> = R.NEW(FT.CURRENCY.MKT.DR)

    THRD.ARR<12> = R.NEW(FT.CURRENCY.MKT.CR)

    THRD.ARR<13>=R.COMPANY(EB.COM.CUSTOMER.COMPANY)

    IF R.NEW(FT.ORDERING.CUST) THEN

        THRD.ARR<14> = R.NEW(FT.ORDERING.CUST)

    END ELSE
        THRD.ARR<14> = DR.CUSTOMER.NO

        THRD.ARR<21> = R.NEW(FT.ORDERING.BANK)

    END

    IF THRD.ARR<14> THEN

        IF THRD.ARR<14>=R.NEW(FT.ORDERING.BANK) THEN

            THRD.ARR<15>=DR.CUSTOMER.NO

        END ELSE

            THRD.ARR<15>=R.NEW(FT.ORDERING.BANK)

        END

    END ELSE

        THRD.ARR<15>=""

    END


    IF R.NEW(FT.BEN.CUSTOMER) THEN
        THRD.ARR<16> = R.NEW(FT.BEN.CUSTOMER)

    END ELSE

        IF R.NEW(FT.BEN.BANK) THEN
            THRD.ARR<16> = R.NEW(FT.BEN.BANK)
        END
    END

    THRD.ARR<17> = R.NEW(FT.INTERMED.BANK)

    IF THRD.ARR<17> THEN

        IF R.NEW(FT.IBAN.INTERMED.BANK) THEN
            THRD.ARR<18> = R.NEW(FT.IBAN.INTERMED.BANK)

        END ELSE

            THRD.ARR<18> = R.NEW(FT.INTERMED.BANK.ACC)
        END

    END ELSE

        THRD.ARR<18> = ''
    END

    THRD.ARR<19> = ""
    POS = ""

    FOR CNTR = 1 TO DCOUNT(R.NEW(FT.SEND.TO.PARTY),VM)
        IF (R.NEW(FT.MESSAGE.TYPE)<1,CNTR>[1,3] EQ MAP.KEY[1,3]) AND (R.NEW(FT.SEND.TO.PARTY)<1,CNTR> EQ SEND.PARTY<1,2>) THEN 
            THRD.ARR<19> = RAISE(R.NEW(FT.BK.TO.BK.OUT)<1,CNTR>)
        END
    NEXT CNTR

    THRD.ARR<20> = R.NEW(FT.PAYMENT.DETAILS)

    RETURN
*-----------------------------------------------------------------------------
CALL.APP.HANDOFF:
*-----------------------------------------------------------------------------

 *   MAP.KEY = '604.FT.1' ; * GBLBB-881 S/E
    ERROR.MSG = ''
    V.KEY = ''

    R.NEW.REC<FT.DEPT.CODE>= R.USER<EB.USE.DEPARTMENT.CODE>
    YPRINT.KEY = MAP.KEY[1,LEN(MAP.KEY)-7]

    CALL APPLICATION.HANDOFF(R.NEW.REC,ADD.REC,THRD.ARR,'','','','','','',MAP.KEY,V.KEY,ERROR.MSG)
     R.NEW(FT.DELIVERY.OUTREF)<1,-1>= V.KEY:"-":FORMAT.KEY:" BULLION TRADE" ;* GBLBB-881 S/E
    RETURN
*-------------------------------------------------------------------------------
CHECK.FT.TXNTYPE:
*-----------------------------------------------------------------------------
* GBLBB-881 S
    GEN.PARAM.ID = "MT604.MSG"
    Y.FIELD.ARR = "FT.TRANS.TYPE":FM:"MAP.KEY":FM:"FORMAT.KEY"
    GEN.TRANSTYPES.VAL = ''
    Y.MAP.KEY.VAL = ''
    Y.FORMAT.KEY.VAL = ''

    CALL JBWW.R.EB.GETGENPARM.VAL(GEN.PARAM.ID,Y.FIELD.ARR,Y.VALUES)

    GEN.TRANSTYPES.VAL = Y.VALUES<1>
    MAP.KEY = Y.VALUES<2>
    FORMAT.KEY = Y.VALUES<3>
* GBLBB-881 E

   GEN.POS = ''
   FT.TRANS.TYPE = R.NEW(FT.TRANSACTION.TYPE) ; GEN.PARM.FOUND = ''

    CHANGE ' ' TO FM IN GEN.TRANSTYPES.VAL

    LOCATE FT.TRANS.TYPE IN GEN.TRANSTYPES.VAL SETTING GEN.POS THEN
    GEN.PARM.FOUND = "TRUE"
    END

    RETURN

    END