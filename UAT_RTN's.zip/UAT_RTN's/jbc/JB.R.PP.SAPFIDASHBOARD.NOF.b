SUBROUTINE JB.R.PP.SAPFIDASHBOARD.NOF(OUT.ARRAY)
*-----------------------------------------------------------------------------
* Attached to Enquiry>JB.E.PP.SAPFI.DASHBOARD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer          Reference         Description
*
* 18-12-2024    Resmi.R            CBPAY-1389        NoFile routine to display the OTSA & ACSA
*                                                   transactions which are in success and failed status .
* 02-03-2025   Lakshmi Priya       CBAPY-1939       Changed selection from OFS Request Detail to Payment Order
*                                                     to Improve Performance Issue.
* 24-03-2025   Lakshmi Priya       CBPAY-2557       Removed mapping for Credit Amount and included for Debit Amount
*                                                     in OUT.ARRAY .
* 21-06-2025   Suresh D            CBPAY-3277       Added Match option in Dashboard for Date option.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.OFS.REQUEST.DETAIL
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.AUDIT.TRAIL
    $INSERT I_F.PP.ERRORCODE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
   
    GOSUB INIT
    GOSUB PROCESS.PO.LIV
    GOSUB PROCESS.PO.NAU
    
*****
INIT:
*****

    FN.OFS.REQUEST.DETAIL = 'F.OFS.REQUEST.DETAIL'
    F.OFS.REQUEST.DETAIL = ''
    CALL OPF(FN.OFS.REQUEST.DETAIL, F.OFS.REQUEST.DETAIL)
        
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)
    
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)

    FN.PP.ERRORCODE = 'F.PP.ERRORCODE'
    F.PP.ERRORCODE = ''
    CALL OPF(FN.PP.ERRORCODE,F.PP.ERRORCODE)

    FN.POR.AUDIT.TRAIL = 'F.POR.AUDIT.TRAIL'
    F.POR.AUDIT.TRAIL = ''
    CALL OPF(FN.POR.AUDIT.TRAIL,F.POR.AUDIT.TRAIL)
        
    Y.GPM.FLD.NAMES = "SAPFI.VER"
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)

    CHANGE ',' TO VM IN Y.GPM.FLD.VALUES
    CHANGE FM TO VM IN Y.GPM.FLD.VALUES
    
    LOCATE 'DATE' IN D.FIELDS<1> SETTING DATE.POS THEN
        DATE.VALUE = D.RANGE.AND.VALUE<DATE.POS>
    END
           
    LOCATE 'FT.REF' IN D.FIELDS<1> SETTING FT.POS THEN
        FT.NBR.VALUE = D.RANGE.AND.VALUE<FT.POS>
    END
       
    LOCATE 'FLAG' IN D.FIELDS<1> SETTING FLAG.POS THEN
        FLAG.VALUE = D.RANGE.AND.VALUE<FLAG.POS>
        IF NOT(FLAG.VALUE MATCHES 'Success' :@VM: 'Error') THEN
            OUT.ARRAY = "Input must be either Success or Error"
        END
    END
    
              
RETURN

**************
PROCESS.PO.LIV:
**************
    Y.PP.FT.ID = ''
    REQDT.ERROR = ''
    SEL.CMD = "SELECT ":FN.PAYMENT.ORDER:" WITH CONTEXT.VALUE LIKE ...SAP-FI..."
    IF FT.NBR.VALUE THEN
        SEL.CMD :=" AND @ID EQ " :FT.NBR.VALUE
    END
    CALL EB.READLIST(SEL.CMD,PO.REQ.LIST,"",NO.OF.REC,REQDT.ERROR)
      
    LOOP
        REMOVE PO.ID FROM PO.REQ.LIST SETTING PO.POS
    WHILE PO.ID : PO.POS
        CALL F.READ(FN.PAYMENT.ORDER,PO.ID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,PO.ERR)
        IF R.PAYMENT.ORDER THEN
            Y.PP.FT.ID = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM.ID>
            IF LEN(DATE.VALUE) LT '7' THEN ;*CBPAY-3277/S
                SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH @ID EQ ":Y.PP.FT.ID:" AND ProcessingDate LIKE ...":DATE.VALUE:"..."
*                SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH @ID EQ ":Y.PP.FT.ID
                CALL EB.READLIST(SEL.CMD,PO.TRANS.LIST,"",NO.OF.REC,REQDT.ERROR)
                REC.CNT = DCOUNT(PO.TRANS.LIST,FM)
                I = 1
                LOOP
                WHILE I LE REC.CNT
                    Y.PP.FT.ID = PO.TRANS.LIST<I>
                    GOSUB POR.TRANS.PROCESS
                    I = I + 1
                REPEAT
            END ELSE ;*CBPAY-3277/E
                GOSUB POR.TRANS.PROCESS
            END
        END
    REPEAT

RETURN

**************
PROCESS.PO.NAU:
**************
       
    REQDT.ERROR = ''
    Y.PP.FT.ID = ''
    
    SEL.CMD = "SELECT ":FN.PAYMENT.ORDER.NAU:" WITH CONTEXT.VALUE LIKE ...SAP-FI..."
    IF FT.NBR.VALUE THEN
        SEL.CMD :=" AND @ID EQ " :FT.NBR.VALUE
    END
    CALL EB.READLIST(SEL.CMD,PO.REQ.LIST,"",NO.OF.REC,REQDT.ERROR)
      
    LOOP
        REMOVE PO.ID FROM PO.REQ.LIST SETTING PO.POS
    WHILE PO.ID : PO.POS
        GOSUB READ.PO.NAU
    REPEAT

RETURN


*******************
POR.TRANS.PROCESS:
******************

    R.POR.TRANSACTION = '' ; PORT.ERR = ''
    CALL F.READ(FN.POR.TRANSACTION, Y.PP.FT.ID, R.POR.TRANSACTION, F.POR.TRANSACTION, PORT.ERR)
    Y.PORT.STATUS.CODE = R.POR.TRANSACTION<PPPTX.StatusCode>
    Y.PORT.PROC.DATE   = R.POR.TRANSACTION<PPPTX.ProcessingDate>
    
    LIKE.FLAG = ''
    IF LEN(DATE.VALUE) LT '7' AND Y.PORT.PROC.DATE[1,LEN(DATE.VALUE)] EQ DATE.VALUE THEN ;*CBPAY-3277/S/E
        LIKE.FLAG = 1
        Y.DATE.VALUE = DATE.VALUE
        DATE.VALUE = Y.PORT.PROC.DATE
    END

    
    IF R.POR.TRANSACTION THEN
        BEGIN CASE
            CASE DATE.VALUE AND FLAG.VALUE EQ 'Success'
                IF (DATE.VALUE EQ Y.PORT.PROC.DATE) AND (Y.PORT.STATUS.CODE NE '235') THEN
                    GOSUB FORM.TPH.ARRAY
                END
            
            CASE DATE.VALUE AND FLAG.VALUE EQ 'Error'
                IF (DATE.VALUE EQ Y.PORT.PROC.DATE) AND (Y.PORT.STATUS.CODE EQ '235') THEN
                    GOSUB FORM.TPH.ARRAY
                END
                
            CASE DATE.VALUE AND NOT(FLAG.VALUE)
            
                IF (DATE.VALUE EQ Y.PORT.PROC.DATE) THEN
                    GOSUB FORM.TPH.ARRAY
                END
            
            CASE NOT(DATE.VALUE) AND FLAG.VALUE
            
                IF (FLAG.VALUE EQ 'Success') AND (Y.PORT.STATUS.CODE NE '235') THEN
                    GOSUB FORM.TPH.ARRAY
                END
                 
                IF (FLAG.VALUE EQ 'Error') AND (Y.PORT.STATUS.CODE EQ '235') THEN
                    GOSUB FORM.TPH.ARRAY
                END
        
            CASE NOT(DATE.VALUE) AND NOT(FLAG.VALUE)
                GOSUB FORM.TPH.ARRAY
            
        END CASE
        
    END
    
    IF LIKE.FLAG = 1 THEN
        DATE.VALUE = Y.DATE.VALUE
    END
RETURN

************
READ.PO.NAU:
************

    PO.NAU.ERR = ''
    CALL F.READ(FN.PAYMENT.ORDER.NAU,PO.ID,R.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU,PO.NAU.ERR)
    
    IF R.PAYMENT.ORDER.NAU THEN
        BEGIN CASE
        
            CASE DATE.VALUE AND FLAG.VALUE EQ 'Error'
                IF DATE.VALUE EQ R.PAYMENT.ORDER.NAU<PO.PAYMENT.EXECUTION.DATE> THEN
                    GOSUB FORM.PO.ARRAY
                END
        
            CASE NOT(DATE.VALUE) AND FLAG.VALUE EQ 'Error'
                GOSUB FORM.PO.ARRAY
                
            CASE NOT(DATE.VALUE) AND NOT(FLAG.VALUE)
                GOSUB FORM.PO.ARRAY
            CASE LEN(DATE.VALUE) LT '7' AND FLAG.VALUE EQ 'Error' ;*CBPAY-3277/S/E
                IF DATE.VALUE EQ R.PAYMENT.ORDER.NAU<PO.PAYMENT.EXECUTION.DATE>[1,LEN(DATE.VALUE)] THEN
                    GOSUB FORM.PO.ARRAY
                END ;*CBPAY-3277/E
        END CASE

    END
    
RETURN

***************
FORM.TPH.ARRAY:
***************

    Y.FT.NBR            = R.POR.TRANSACTION<PPPTX.FTNumber>
    Y.FILE.REF          = R.POR.TRANSACTION<PPPTX.FileReferenceIncoming>
    Y.INC.MSGTYPE       = R.POR.TRANSACTION<PPPTX.IncomingMessageType>
    Y.DB.MAIN.ACCT      = R.POR.TRANSACTION<PPPTX.DebitMainAccount>
    Y.DB.MAIN.CCY       = R.POR.TRANSACTION<PPPTX.DebitMainAccountCurrencyCode>
    Y.DB.MAIN.AMT       = R.POR.TRANSACTION<PPPTX.TransactionAmount>
    Y.CR.MAIN.ACCT      = R.POR.TRANSACTION<PPPTX.CreditMainAccount>
    Y.CR.MAIN.CCY       = R.POR.TRANSACTION<PPPTX.CreditMainAccountCurrencyCode>
    Y.DB.MAIN.AMT       = R.POR.TRANSACTION<PPPTX.DebitMainAmount>
    IF Y.PORT.STATUS.CODE EQ '235' THEN
        Y.MSG = "Failed"
        GOSUB GET.ERR.MSG
    END ELSE
        Y.MSG = "Success"
        Y.PO.ERR.MSG = ''
    END
    
    Y.SAP.ORG.REF       = R.POR.TRANSACTION<PPPTX.SendersReferenceIncoming>
    Y.VIEW.VER          = "PP.ORDER.ENTRY,JB.V.PP.OTSA.VIEW S 111"
       
    OUT.ARRAY<-1> = Y.FT.NBR:"*":Y.FILE.REF:"*":Y.INC.MSGTYPE:"*":Y.DB.MAIN.ACCT:"*":Y.DB.MAIN.CCY:"*":Y.DB.MAIN.AMT:"*":Y.CR.MAIN.ACCT:"*":Y.CR.MAIN.CCY:"*":Y.DB.MAIN.AMT:"*":Y.MSG:"*":Y.PO.ERR.MSG:"*":Y.SAP.ORG.REF:"*":Y.PORT.STATUS.CODE:"*":Y.VIEW.VER
    
RETURN

************
GET.ERR.MSG:
************

    R.POR.AUDITTRAIL = '' ; ERR.AUDIT = '' ; Y.PO.ERR.MSG = ''
    CALL F.READ(FN.POR.AUDIT.TRAIL, Y.FT.NBR, R.POR.AUDITTRAIL, F.POR.AUDIT.TRAIL, ERR.AUDIT)
    Y.ERR.CODE = R.POR.AUDITTRAIL<PORAT.ERROR.CODE>
    CALL F.READ(FN.PP.ERRORCODE, Y.ERR.CODE, R.PP.ERRORCODE, F.PP.ERRORCODE, ERR.CODE)
    Y.PO.ERR.MSG = R.PP.ERRORCODE<PP.ERC.ErrorText>

RETURN

***************
FORM.PO.ARRAY:
***************
    
    Y.PO.FT.NBR       = ''
    Y.PO.FILE.REF     = PO.ID
    Y.PO.PRD.TYPE     = R.PAYMENT.ORDER.NAU<PO.PAYMENT.ORDER.PRODUCT>
    Y.PO.DB.ACCT      = R.PAYMENT.ORDER.NAU<PO.DEBIT.ACCOUNT>
    Y.PO.DB.CCY       = R.PAYMENT.ORDER.NAU<PO.DEBIT.CCY>
    Y.PO.ERR.MSG      = R.PAYMENT.ORDER.NAU<PO.STATUS.REASON.CODE>
    Y.PO.DB.AMT       = R.PAYMENT.ORDER.NAU<PO.PAYMENT.AMOUNT>
    Y.PO.CR.ACCT      = R.PAYMENT.ORDER.NAU<PO.CREDIT.ACCOUNT>
    Y.PO.CR.CCY       = R.PAYMENT.ORDER.NAU<PO.CREDIT.CURRENCY>
    Y.PO.DB.AMT       = R.PAYMENT.ORDER.NAU<PO.DEBIT.AMOUNT>
    Y.PO.SUC.FAIL     = "Failed"
    Y.PO.SAP.ORG.REF  = R.PAYMENT.ORDER.NAU<PO.INSTRUCTION.ID.REF>
    Y.PO.PMT.STAT     = ''
    Y.VIEW.VER        = "PAYMENT.ORDER,JB.V.PP.OTSA.VIEW S ":Y.PO.FILE.REF
    
    OUT.ARRAY<-1> = Y.PO.FT.NBR:"*":Y.PO.FILE.REF:"*":Y.PO.PRD.TYPE:"*":Y.PO.DB.ACCT:"*":Y.PO.DB.CCY:"*":Y.PO.DB.AMT:"*":Y.PO.CR.ACCT:"*":Y.PO.CR.CCY:"*":Y.PO.DB.AMT:"*":Y.PO.SUC.FAIL:"*":Y.PO.ERR.MSG:"*":Y.PO.SAP.ORG.REF:"*":Y.PO.PMT.STAT:"*":Y.VIEW.VER

RETURN

*****************************************************************************************

END
