* @ValidationCode : MToxOTQxMzEzMTA3OlVURi04OjE0OTg1NTg5ODg1ODA6MjMzMTYzOi0xOi0xOjA6MDp0cnVlOk4vQQ==
* @ValidationInfo : Timestamp         : 27 Jun 2017 15:53:08
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : true
*-----------------------------------------------------------------------------
* <Rating>-12</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JB.XX.PARTY.DETAILS.FIELDS
*-----------------------------------------------------------------------------
* Desc : This table will contain the details of Ordering Customer from CRM.
* Need to revisit the code to populate enrichment of account name
*-------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                      Reference               Description
*-------------------------------------------------------------------------------------------
* 30-Jul-2024    P Amala                       CBPAY-27 & 80            Initial Version
* 
* 27-Apr-2025    u40786                        CBPAY-2658               Field lengths modified as per the maximum legnth in CRM system
*                                                                       Field Address attribute changed as TEXT
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes

    C$NS.OPERATION="ALL"
    ID.F = "PORT.ID"
    ID.N = "16"
    ID.T = "ANY"

    CALL Table.defineId("PORT.ID", T24_String) ;* Define Table id

    fieldName = "PORT.NAME"
    fieldLength = "200"
    fieldType = "ANY"

    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "J.C.IDENTIFIER"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PORT.REL.TYPE"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PORT.SUB.TYPE"
    fieldLength = "250"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX<PARTY.ID"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX-LEGAL.ORG.NAME"
    fieldLength = "500"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX-PART.F.NAME"
    fieldLength = "500"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX-PART.M.NAME"
    fieldLength = "250"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX>PART.L.NAME"
    fieldLength = "250"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.ADDR.TYPE"
    fieldLength = "250"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.ADDRESS"
    fieldLength = "140"
    fieldType = "TEXT"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.POST.CODE"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.CITY"
    fieldLength = "500"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.COUNTRY"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.DEPARTMENT"
    fieldLength = "70"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.SUB.DEPT"
    fieldLength = "70"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.STREET.NAME"
    fieldLength = "70"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.BUILD.NUMBER"
    fieldLength = "16"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.BUILD.NAME"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.FLOOR"
    fieldLength = "70"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.PO.BOX.NUM"
    fieldLength = "16"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.FLAT"
    fieldLength = "70"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.TOWN.NAME"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.TOWN.LOC.NAME"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.DISTRICT.NAME"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.COUNTRY.SUBDIVISION"
    fieldLength = "35"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "PART.ADDRESS.COUNTRY"
    fieldLength = "2"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.11"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.10"
    fieldLength = "140"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.9"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.8"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.7"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.6"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.5"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.4"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.3"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.2"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "RESERVED.1"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    fieldName = "XX.OVERRIDE"
    fieldLength = "140"
    fieldType = "ANY"
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, '')

    CALL Table.setAuditPosition ;* Poputale audit information
*
    RETURN
*
    END
*
