*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.REQUESTEDDETS.VALIDATE
*-----------------------------------------------------------------------------
* This subroutine attched as validation routine will update the REQUESTED.CURRENCY & REQUESTED.AMOUNT fields
* Attached to the versin IRIS API version PAYMENT.ORDER,JB.V.PP.RETROPAYEXT.API.1.0.0
* if PAYMENT.CURRENCY is other than CHF for Calculo External Payments.
* This is to populate the equivalent MT Tags 32A, 33B in the PACS.008 message. 
* Reason is details received in the Calculo Payment File which is for Debit Currency & Debit Amount. 
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date         Developer      Reference           Description
*
* 15-May-2024  xxx            CBPAY-360           Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
*
    IF MESSAGE NE 'VAL' AND R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'OTRT' AND R.NEW(PO.PAYMENT.CURRENCY) NE 'CHF' THEN
        R.NEW(PO.REQUESTED.CURRENCY) = 'CHF'
        R.NEW(PO.REQUESTED.AMOUNT) = R.NEW(PO.PAYMENT.AMOUNT)
        R.NEW(PO.PAYMENT.AMOUNT) = ''
    END
*
RETURN
*
END
*
