*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
* @ValidationCode : MTotMTI4MDM1Njk3NDpVVEYtODoxNDcwOTA4Njk0NTAyOjIzMzE3OTotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.B.FT.BULKREFUNDFTUPLOAD.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer                     Reference            Description
*-----------------------------------------------------------------------------
* 
* ----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_T24.UPLOAD.PROCESS.COMMON
    $INSERT I_F.EB.FILE.UPLOAD.PARAM
    $INSERT I_F.EB.FILE.UPLOAD.TYPE
    $INSERT I_F.EB.FILE.UPLOAD
    $INSERT I_JBWW.B.FT.BULKREFUNDFTUPLOAD.COMMON

*-----------------------------------------------------------------------------
    GOSUB INIT
	GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------
INIT:
******
    CNT.VAR = ''
	R.CSV.REC = ''
	Y.FT.LIST = ''
	Y.CNT = ''

    RETURN
*-----------------------------------------------------------------------------

PROCESS:
********


    Y.PATH = Y.DIR : "/" : UPLOAD.DIR

    IF OS.NAME EQ "WINNT" OR OS.NAME EQ "WIN95" THEN
        CHANGE "/" TO "\" IN Y.PATH
    END ELSE
        CHANGE "\" TO "/" IN Y.PATH
    END

    OPEN Y.PATH TO Y.DIR.NAME ELSE
    END

    READ R.CSV.REC FROM Y.DIR.NAME,Y.CSV.NAME ELSE
        CALL OCOMO(" CANNOT READ CSV FILE ")
		Y.FT.LIST = ''
		RETURN
    END

    Y.CNT = DCOUNT(R.CSV.REC,FM)

    CNT.VAR='2'

    LOOP
    WHILE CNT.VAR LE Y.CNT
        Y.FT.LIST<-1> = R.CSV.REC<CNT.VAR,1>
        CNT.VAR++
    REPEAT
    CALL BATCH.BUILD.LIST("",Y.FT.LIST)
    RETURN
*-----------------------------------------------------------------------------

    END
