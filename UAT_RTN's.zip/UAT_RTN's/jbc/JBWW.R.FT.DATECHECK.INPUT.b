* @ValidationCode : MTo5NjQ0Mzc3MjM6SVNPLTg4NTktMToxNTM3OTUyNzY4ODg4OjUzNDQ2MjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNA==
* @ValidationInfo : Timestamp         : 26 Sep 2018 14:36:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 534462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------
* <Rating>-44</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.DATECHECK.INPUT
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 27/07/2016    priyadarshni.priyanka@cognizant.com    PMT003                  Initial Version
* 29/11/2017    Parameshwari						   JB2A_45958			   Value date check has been removed for Transaction
*                                                                              Type not configured in Generic Parameter.
* 01/06/2018    Lakshmanan                             T24_12873               VALUEDATE.CHECK field Error removed.
* 26/09/2018    Kalyani								   DAY15-4701			   Removed BOREMARK.CHECK error
*--------------------------------------------------------------------------------------------
* Description : Routine is used to update the field L.FT.VALDT.CHKD.
* Attached to : VERSION>FUNDS.TRANSFER,JBWW.V.FT.VALUEDATE.AMEND
* Attached as : Input routine
**----------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB GET.LOCAL.FIELDS
    GOSUB PROCESS

    RETURN

INIT:
*****
* !! Initialise and open the necessary files ;

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    RETURN

GET.LOCAL.FIELDS:
****************
* !! Fetch local field positions.

    Y.APPL = 'FUNDS.TRANSFER'
    Y.FLD = 'L.FT.BO.REMARK':VM:'L.FT.VALDT.CHKD'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.FLD,Y.FLD.POS)
    Y.BO.REMARK.STAT.POS = Y.FLD.POS<1,1>
    Y.VALDT.CHKD.POS = Y.FLD.POS<1,2>

    Y.GEN.PARAM.ID = 'FT.DATE.CHECK.TRANS.TYPE'
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.GEN.PARAM.ID,R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,PARAM.ERR)
    Y.FIELD.VALUE = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE>

    RETURN

PROCESS:
*******
* !! Main Process starts here.

    Y.BO.REMARK.STATUS = R.NEW(FT.LOCAL.REF)<1,Y.BO.REMARK.STAT.POS>
    Y.VALDT.CHKD = R.NEW(FT.LOCAL.REF)<1,Y.VALDT.CHKD.POS>
    Y.RECORD.STATUS = R.NEW(FT.RECORD.STATUS)
    Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)

***Fix for JB2A_45958_S
    IF Y.RECORD.STATUS EQ 'INAU' OR Y.RECORD.STATUS EQ 'INA2' THEN
        GOSUB CHECK.TXN.TYPE
*		GOSUB SET.FIELD

        R.NEW(FT.LOCAL.REF)<1,Y.VALDT.CHKD.POS> = "MAKER"
    END
***Fix for JB2A_45958_E

    RETURN

CHECK.TXN.TYPE:
***************

    LOCATE Y.TXN.TYPE IN Y.FIELD.VALUE<1,1,1> SETTING TYPE.POS THEN
        GOSUB SET.FIELD
    END ELSE
        RETURN
    END

    RETURN

SET.FIELD:
*********
* !! Check the value date and set the value of field Y.VALDT.CHKD.

    Y.TODAY = TODAY
    Y.DEBIT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
    Y.DEBIT.VALUE.DATE.OLD = R.NEW.LAST(FT.DEBIT.VALUE.DATE)


*	IF Y.DEBIT.VALUE.DATE LT Y.TODAY THEN
*		ETEXT = "EB-JBWW.D.FT.VALUEDATE.CHECK"
*		CALL STORE.END.ERROR
*	END

* (S) - DAY15-4701
*	IF ((Y.DEBIT.VALUE.DATE.OLD  EQ Y.DEBIT.VALUE.DATE) AND Y.BO.REMARK.STATUS EQ '') THEN
*		ETEXT = "EB-JBWW.D.FT.BOREMARK.CHECK"
*		CALL STORE.END.ERROR
*	END
* (E) - DAY15-4701

    R.NEW(FT.LOCAL.REF)<1,Y.VALDT.CHKD.POS> = "MAKER"

RETURN

END
