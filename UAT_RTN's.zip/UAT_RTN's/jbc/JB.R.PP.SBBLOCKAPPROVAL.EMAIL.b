* @ValidationCode : MToxNTU0MzQyMjg5OlVURi04OjE1Mjg3OTA4NTgzMzY6MjMzMTYzOi0xOi0xOjA6MDpmYWxzZTpOL0E=
* @ValidationInfo : Timestamp         : 06 May 2024 13:37:38
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 871829
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.SBBLOCKAPPROVAL.EMAIL
*-----------------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing FT Version Control Routine JBWW.R.FT.SBBLOCKAPPROVAL.EMAIL and incorporated with TPH application Logic.
*-----------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*---------------------------------------------------------------------------------------------------------------------------------------------------
* 06/05/2024     Amala P                       CBPAY-356                   Email genreation for softblocks when inception authorisation is done with record in INA2 status 
*                                                                          after where blocks will be available for approval.
* 06/05/2024     Amala P                       CBPAY-534                   Included Same logic for Cancellation Request. 
* 20/11/2024     Prabhu D S                    CBPAY-1252                  Routine changed from JB.R.XX.NOTIFICATION.UPDATE to JB.R.XX.INDC.NOTIFICATION.UPD
*                                                                          for updating table JB.L.XX.NOTIFICATION.REQ
* 01/03/2025     Amala P                       CBPAY-410                   Email alerts should be triggered when payment is in INA2 status.
* 25/04/2025     Amala P                       CBPAY-2661                  Fix to skip the CVD calculation for the payment which is created from STO.

*---------------------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_GTS.COMMON
    $INSERT I_F.COMPANY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.USER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
	$INSERT I_F.EB.QUERIES.ANSWERS
	$INSERT I_F.POR.TRANSACTION
	$USING PP.RoutingAndSettlementService

    GOSUB INIT
    IF V$FUNCTION EQ 'A' AND R.VERSION(EB.VER.NO.OF.AUTH) EQ '2' AND R.SOFT.BLOCKS NE '' THEN
        IF Y.OVERALL.STATUS NE '' THEN RETURN
        GOSUB FETCH.DR.PORTFOLIO.DETAILS
        GOSUB FETCH.CR.PORTFOLIO.DETAILS
        GOSUB BUILD.DATA.TO.RM
        GOSUB TRIGGER.MAIL.TO.RM
        GOSUB TRIGGER.MULTIPLE.MAILS

    END
RETURN

*-----------------------------------------------------------------------------
INIT:
*****
    F.USER = ''
    FN.USER = 'F.USER'
    CALL OPF(FN.USER,F.USER)

    F.DEPT.ACCT.OFFICER = ''
    FN.DEPT.ACCT.OFFICER = 'F.DEPT.ACCT.OFFICER'
    CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)

    F.SC.INC.ACCOUNT = ''
    FN.SC.INC.ACCOUNT = 'F.SC.INC.ACCOUNT'
    CALL OPF(FN.SC.INC.ACCOUNT,F.SC.INC.ACCOUNT)

    F.DEPT.ACCT.OFFICER = ''
    FN.DEPT.ACCT.OFFICER = 'F.DEPT.ACCT.OFFICER'
    CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.OVERRIDE = ''
    FN.OVERRIDE = 'F.OVERRIDE'
    CALL OPF(FN.OVERRIDE,F.OVERRIDE)

    F.PAYMENT.ORDER = ''
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    F.PAYMENT.ORDER$NAU = ''
    FN.PAYMENT.ORDER$NAU = 'F.PAYMENT.ORDER$NAU'
    CALL OPF(FN.PAYMENT.ORDER$NAU,F.PAYMENT.ORDER$NAU)
	
	F.PP.ORDER.ENTRY = ''
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)
	
	F.PP.ORDER.ENTRY$NAU = ''
    FN.PP.ORDER.ENTRY$NAU = 'F.PP.ORDER.ENTRY$NAU'
    CALL OPF(FN.PP.ORDER.ENTRY$NAU,F.PP.ORDER.ENTRY$NAU)
	
	F.EB.QUERIES.ANSWERS = ''
    FN.EB.QUERIES.ANSWERS = 'F.EB.QUERIES.ANSWERS'
    CALL OPF(FN.EB.QUERIES.ANSWERS,F.EB.QUERIES.ANSWERS)
	
	F.EB.QUERIES.ANSWERS$NAU = ''
    FN.EB.QUERIES.ANSWERS$NAU = 'F.EB.QUERIES.ANSWERS$NAU'
    CALL OPF(FN.EB.QUERIES.ANSWERS$NAU,F.EB.QUERIES.ANSWERS$NAU)

    F.JBWW.H.XX.SOFTBLOCK = ''
    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)
	
	F.POR.TRANSACTION = ''
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)

    F.CUSTOMER = ''
    FN.CUSTOMER = 'F.CUSTOMER'
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
	
	BEGIN CASE
	    CASE ID.NEW[1,2] EQ 'PI'
             APPL = 'PAYMENT.ORDER':FM:'OVERRIDE':FM:'CUSTOMER':FM:'SEC.ACC.MASTER'
        CASE ID.NEW[1,2] EQ 'OE'
		     APPL = 'PP.ORDER.ENTRY':FM:'OVERRIDE':FM:'CUSTOMER':FM:'SEC.ACC.MASTER'
		CASE ID.NEW[1,4] EQ 'FMQA'
		     APPL = 'EB.QUERIES.ANSWERS':FM:'OVERRIDE':FM:'CUSTOMER':FM:'SEC.ACC.MASTER' 
    END CASE
	
    F.JBWW.H.EB.GENERICPARAMETER = ''
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    R.GEN.PARAM = ''
    Y.MNEMONIC = R.COMPANY(EB.COM.MNEMONIC)
    Y.RLC.MAIL.PARAM.ID = 'JB.D.PP.RLCNOTIF.CONFIG'
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.RLC.MAIL.PARAM.ID,R.GEN.PARAM,F.JBWW.H.EB.GENERICPARAMETER,'')
    IF R.GEN.PARAM NE '' THEN
        Y.FIELD.NAME = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        CONVERT VM TO FM IN Y.FIELD.NAME
        Y.FIELD.VALUE =  R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        Y.BLOCK.TYPE.POS = ''
        FIND 'BLOCK.TYPE' IN Y.FIELD.NAME SETTING Y.BLOCK.TYPE.POS ELSE Y.BLOCK.TYPE.POS = ''
        Y.BLOCK.TYPE.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.BLOCK.TYPE.POS,1>
        Y.BLCK.SWITCH.POS = ''
        FIND 'BLOCK.SWITCH' IN Y.FIELD.NAME SETTING Y.BLCK.SWITCH.POS ELSE Y.BLCK.SWITCH.POS = ''
        Y.SWITCH.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.BLCK.SWITCH.POS,1>
        Y.APPR.MA.POS = ''
        FIND 'APPROVE.MA' IN Y.FIELD.NAME SETTING Y.APPR.MA.POS ELSE Y.APPR.MA.POS = ''
        Y.APPROVE.MA = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.APPR.MA.POS,1>

        Y.APPR.BP.POS = ''
        FIND 'APPROVE.BP' IN Y.FIELD.NAME SETTING Y.APPR.BP.POS ELSE Y.APPR.BP.POS = ''
        Y.APPROVE.BP = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.APPR.BP.POS,1>
		
		Y.NOTIF.TITLE.POS = ''
        FIND 'NOTIF.TITLE_RLC' IN Y.FIELD.NAME SETTING Y.NOTIF.TITLE.POS ELSE Y.NOTIF.TITLE.POS = ''
        Y.NOTIF.TITLE.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.NOTIF.TITLE.POS,1>
				
		Y.NOTIF.DESC.POS = ''
        FIND 'NOTIF.DESC_RLC' IN Y.FIELD.NAME SETTING Y.NOTIF.DESC.POS ELSE Y.NOTIF.DESC.POS = ''
        Y.NOTIF.DESC.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.NOTIF.DESC.POS,1>
		
		Y.SRC.APPL.POS = ''
        FIND 'SOURCE.APPL' IN Y.FIELD.NAME SETTING Y.SRC.APPL.POS ELSE Y.SRC.APPL.POS = ''
        Y.SRC.APPL.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.SRC.APPL.POS,1>
		
	    Y.TARGET.APPL.POS = ''
        FIND 'TARGET.APPL' IN Y.FIELD.NAME SETTING Y.TARGET.APPL.POS ELSE Y.TARGET.APPL.POS = ''
        Y.TARGET.APPL.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.TARGET.APPL.POS,1>
		
	    Y.T24URL.POS = ''
        FIND 'T24UrlLink' IN Y.FIELD.NAME SETTING Y.T24URL.POS ELSE Y.T24URL.POS = ''
        Y.T24URL.VALUE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.T24URL.POS,1>

    END
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,ID.NEW,R.SOFT.BLOCKS,F.JBWW.H.XX.SOFTBLOCK,'')
    Y.OVERALL.STATUS = R.SOFT.BLOCKS<JHXS.OVERALL.STATUS>
    Y.SEC.ACCNT = R.SOFT.BLOCKS<JHXS.PORTFOLIO.ID>
    Y.CUST.NO = R.SOFT.BLOCKS<JHXS.CLIENT.ID>
    Y.BLOCK.IDS = R.SOFT.BLOCKS<JHXS.BLOCK.ID>
    Y.BLOCK.MESSAGES = R.SOFT.BLOCKS<JHXS.BLOCK.MSG>
    Y.MESSAGE = Y.BLOCK.MESSAGES
    CHANGE VM TO SM IN Y.MESSAGE
    Y.BLOCK.DEPT = R.SOFT.BLOCKS<JHXS.BLOCK.DEPT>
    Y.CHECKTYPES = Y.BLOCK.DEPT
    CHANGE VM TO SM IN Y.CHECKTYPES

    CHANGE VM TO FM IN  Y.BLOCK.IDS
    CHANGE VM TO FM IN  Y.BLOCK.DEPT
    CHANGE VM TO FM IN  Y.BLOCK.MESSAGES

    LREF.FLD = 'L.XX.BLK.MSG':VM:'L.XX.BLK.CODE':VM:'L.XX.BLK.CATEG':VM:'L.XX.BLK.TYPE':VM:'L.XX.DONE.DEAL':VM:'L.XX.TC.DONE':VM:'L.FT.VALDT.CHKD':VM:'L.XX.FO.SOURCE':FM:'L.ST.BLK.APRVR':FM:'L.ST.OFFCR.TYPE':VM:'L.ST.OFFICER.ID':FM:'L.XX.TAG.BLK.ID':VM:'L.XX.TAG.ID'
    Y.POS = ''
    Y.TC.DONE.POS = ''
    Y.BLK.CATEG.POS = ''
    Y.BLK.TYPE.POS = ''
    Y.BLK.CODE.POS = ''
    Y.BLK.MSG.POS = ''
    Y.BLK.APR.POS = ''
    Y.DONE.DEAL.POS = ''
    Y.L.FT.VALDT.CHKD.POS = ''
    Y.OFFICER.TYPE.POS = ''
    Y.OFFICER.ID.POS = ''
    Y.TAG.BLK.POS = ''
    Y.TAG.ID.POS = ''
    Y.FO.SRC.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)

    Y.BLK.MSG.POS = Y.POS<1,1>
    Y.BLK.CODE.POS = Y.POS<1,2>
    Y.BLK.CATEG.POS = Y.POS<1,3>
    Y.BLK.TYPE.POS  = Y.POS<1,4>
    Y.DONE.DEAL.POS = Y.POS<1,5>
    Y.TC.DONE.POS = Y.POS<1,6>
    Y.L.FT.VALDT.CHKD.POS = Y.POS<1,7>
    Y.FO.SRC.POS = Y.POS<1,8>

    Y.BLK.APR.POS = Y.POS<2,1>
    Y.OFFICER.TYPE.POS = Y.POS<3,1>
    Y.OFFICER.ID.POS = Y.POS<3,2>
    Y.TAG.BLK.POS = Y.POS<4,1>
    Y.TAG.ID.POS = Y.POS<4,2>

    Y.TODAY = TODAY
    Y.TODAY =  OCONV(ICONV(Y.TODAY,"D2E"),"D4E")
    Y.TIME = OCONV(TIME(),"MTS")
    DATE.TIME = Y.TODAY:' ':Y.TIME

    UID = ''
	GOSUB GET.VALUES

    Y.USR.ID = Y.INPUTTER['_',2,1]
    R.USR = ''
    CALL F.READ(FN.USER,Y.USR.ID,R.USR,F.USER,'')
    UID = R.USR<EB.USE.USER.NAME>
    IF UID EQ '' THEN
        UID = OPERATOR
    END

RETURN


GET.VALUES:
***********

   Y.INPUTTER = '' ; Y.CR.AC.NO = '' ;  Y.DR.AC.NO = ''
	BEGIN CASE
	  CASE ID.NEW[1,2] EQ 'PI' 
         Y.INPUTTER = R.NEW(PO.INPUTTER)<1,1>
         Y.CR.AC.NO = R.NEW(PO.CREDIT.ACCOUNT)
         Y.DR.AC.NO = R.NEW(PO.DEBIT.ACCOUNT)
	  CASE ID.NEW[1,2] EQ 'OE'
	      Y.INPUTTER = R.NEW(PP.OEYG.INPUTTER)<1,1>
          Y.CR.AC.NO = R.NEW(PP.OEYG.CreditAccountNumber)
	      Y.DR.AC.NO = R.NEW(PP.OEYG.DebitAccountNumber)
	  CASE ID.NEW[1,4] EQ 'FMQA'
	      Y.INPUTTER = R.NEW(EB.QA.INPUTTER)<1,1>
		  Y.PORTRN.ID = R.NEW(EB.QA.ORIG.FT.NUMBER)	
          CALL F.READ(FN.POR.TRANSACTION,Y.PORTRN.ID,R.PORREC,F.POR.TRANSACTION,'')
          Y.CR.AC.NO = R.PORREC<PPPTX.CreditMainAccount>
	      Y.DR.AC.NO = R.PORREC<PPPTX.DebitMainAccount>
	END CASE

RETURN

TRIGGER.MAIL.TO.RM:
********************
    IF Y.RM.BLK.IDS EQ '' THEN RETURN
    IF Y.BLOCK.TYPE.POS NE '' AND Y.SWITCH.VALUE EQ 'ON' THEN
        GOSUB GET.TRANSACTION.MAIL.DETAILS
        TYPE = Y.BLOCK.TYPE.VALUE
        ENTITY.TYPE<1,1> = 'PORTFOLIO'
        CONVERT FM TO VM IN Y.SEC.ACCNT
        CONVERT VM TO SM IN Y.SEC.ACCNT
        ENTITY.ID<1,1,-1> = Y.SEC.ACCNT


        Y.NAME<1,1> = 'transactionNumber'
        Y.VALUE<1,1,-1> = ID.NEW
        Y.NAME<1,2> = 'softBlockID'
        Y.VALUE<1,2,-1> = Y.RM.BLK.IDS
        Y.NAME<1,3> = 'softBlockMessage'
        Y.VALUE<1,3,-1> = Y.MESSAGE
        Y.NAME<1,4> = 'softBlockOwner'
        Y.VALUE<1,4,-1> = Y.CHECKTYPES
        Y.NAME<1,5> = 'relManager'
        Y.VALUE<1,5,-1> = Y.DAO.NAME
        Y.NAME<1,6> = 'inputter'
        Y.OPERATOR = UID
        CONVERT FM TO SM IN Y.OPERATOR
        Y.VALUE<1,6,-1> = Y.OPERATOR
		
        CHANGE VM TO SM IN Y.CUST.NO
        CHANGE VM TO SM IN Y.SEC.ACCNT
        Y.NAME<1,7> = 'customerNumber'
        Y.VALUE<1,7,-1> = Y.CUST.NO
        Y.NAME<1,8> = 'portfolioNumber'
        Y.VALUE<1,8,-1> = Y.SEC.ACCNT
        Y.NAME<1,9> = 'transactionType'
        Y.VALUE<1,9,-1> = Y.TXN.TYPE
        Y.NAME<1,10> = 'quantity'
        Y.VALUE<1,10,-1> = Y.MAIL.NO.NOMINAL
        Y.NAME<1,11> = 'currency'
        Y.VALUE<1,11,-1> = Y.MAIL.SET.CCY
        Y.NAME<1,12> = 'amount'
        Y.VALUE<1,12,-1> = Y.MAIL.TRANS.AMT
        Y.NAME<1,13> = 'securityIdentifier'
        Y.VALUE<1,13,-1> = Y.MAIL.SECURITY.NO
        Y.NAME<1,14> = 'tradeDate'
        Y.VALUE<1,14,-1> = Y.MAIL.TRADE.DATE
        Y.NAME<1,15> = 'valueDate'
        Y.VALUE<1,15,-1> = Y.MAIL.VALUE.DATE
        Y.NAME<1,16> = 'dateTime'
        Y.VALUE<1,16,-1> = DATE.TIME

        CONVERT FM TO VM IN Y.NAME
        GOSUB TRIGGER.EMAIL

    END
RETURN

FETCH.DR.PORTFOLIO.DETAILS:
************************

    Y.ACCT.NO = ''
    Y.ACCT.NO =  Y.DR.AC.NO
    GOSUB READ.AC
    Y.PORTFOLIO = ''
    Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID = ''
    Y.SAM.ID = Y.PORTFOLIO<1,1>

    IF Y.SAM.ID EQ '' THEN
        GOSUB READ.SC.INC.ACCOUNT
    END
    GOSUB READ.SAM

RETURN

FETCH.CR.PORTFOLIO.DETAILS:
***************************

    Y.ACCT.NO = ''
    Y.ACCT.NO =  Y.CR.AC.NO
    GOSUB READ.AC
    Y.PORTFOLIO = ''
    Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID = ''
    Y.SAM.ID = Y.PORTFOLIO<1,1>
    IF Y.SAM.ID EQ '' THEN
        GOSUB READ.SC.INC.ACCOUNT
    END
    GOSUB READ.SAM


RETURN

READ.AC:
*************
    R.AC = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.NO,R.AC,F.ACCOUNT,'')

RETURN

READ.SC.INC.ACCOUNT:
********************
    R.INC = ''
    CALL F.READ(FN.SC.INC.ACCOUNT,Y.ACCT.NO,R.INC,F.SC.INC.ACCOUNT,'')
    Y.SAM.ID = R.INC<1>
RETURN

READ.SAM:
*********
    Y.BULK.TAG.IDS = ''
    Y.TAG.BLK.IDS = ''

    Y.PORTFOLIO = R.AC<AC.PORTFOLIO.NO>
    Y.SAM.ID = Y.PORTFOLIO<1,1>
    R.SAM.REC = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
    IF R.SAM.REC THEN
        Y.BULK.TAG.IDS = R.SAM.REC<SC.SAM.LOCAL.REF>
        Y.TAG.BLK.IDS = Y.BULK.TAG.IDS<1,Y.TAG.BLK.POS>
        Y.TAG.IDS = Y.BULK.TAG.IDS<1,Y.TAG.ID.POS>
        CHANGE SM TO FM IN Y.TAG.BLK.IDS
        CHANGE SM TO FM IN Y.TAG.IDS
        IF Y.TAG.BLK.IDS NE '' THEN
            Y.SB.ID.ARR<-1> = Y.TAG.BLK.IDS
            Y.TAG.NAME.ARR<-1> = Y.TAG.IDS
        END
    END

RETURN

BUILD.DATA.TO.RM:
*******************
    CHANGE VM TO FM IN Y.BLOCK.IDS
    CHANGE VM TO FM IN Y.BLOCK.MESSAGES
    CHANGE VM TO FM IN Y.BLOCK.DEPT
    Y.RM.BLK.IDS = ''
    Y.BLK.ID.CNT = DCOUNT(Y.BLOCK.IDS,FM)

    I = 0
    LOOP
        I = I + 1
    WHILE I LE Y.BLK.ID.CNT
        Y.BLK.DEPT = Y.BLOCK.DEPT<I>
        BEGIN CASE
            CASE Y.BLK.DEPT EQ 'CC'
                Y.RM.BLK.IDS<-1> = Y.BLOCK.IDS<I>
                Y.CC.IDS<-1> = Y.BLOCK.IDS<I>
                Y.CC.MESSAGE<-1> = Y.BLOCK.MESSAGES<I>
                Y.CC.CHECKTYPE<-1> = 'CC'

            CASE Y.BLK.DEPT EQ 'MA'
                Y.RM.BLK.IDS<-1> = Y.BLOCK.IDS<I>
                Y.MA.IDS<-1> = Y.BLOCK.IDS<I>
                Y.MA.MESSAGE<-1> = Y.BLOCK.MESSAGES<I>
                Y.MA.CHECKTYPE<-1> = 'MA'

            CASE OTHERWISE
                Y.BLK.ID = Y.BLOCK.IDS<I>
                Y.BLK.ID.POS = ''
                FIND Y.BLK.ID IN Y.SB.ID.ARR SETTING Y.BLK.ID.POS ELSE Y.BLK.ID.POS = ''
                Y.RM.BLK.IDS<-1> = Y.TAG.NAME.ARR<Y.BLK.ID.POS>
        END CASE

    REPEAT

    CHANGE FM TO SM IN Y.RM.BLK.IDS

RETURN

GET.TRANSACTION.MAIL.DETAILS:
*****************************
    Y.TXN.TYPE = R.SOFT.BLOCKS<JHXS.TRANSACTION.TYPE>

    Y.DAO = R.SOFT.BLOCKS<JHXS.REL.MANAGER>
    Y.DAO.ID = Y.DAO<1,1>
    R.DAO = ''
    CALL F.READ(FN.DEPT.ACCT.OFFICER,Y.DAO.ID,R.DAO,F.DEPT.ACCT.OFFICER,'')
    IF R.DAO NE '' THEN
        Y.DAO.NAME = R.DAO<EB.DAO.NAME>
    END
    Y.MAIL.VALUE.DATE = ''
    BEGIN CASE
	  CASE ID.NEW[1,2] EQ 'PI' 
         Y.MAIL.SET.CCY = R.NEW(PO.DEBIT.CCY)
		 Y.PAY.AMT = ''
	     GOSUB GET.PAYMENT.AMOUNT
         Y.MAIL.TRANS.AMT = Y.PAY.AMT
									   
        IF (R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12') AND NOT(R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES 'STO':VM:'STOMXCHATS')THEN
            GOSUB GET.CALCCVD.DATE
         END ELSE
            PO.VALUE.DATE = R.NEW(PO.CREDIT.VALUE.DATE)
         END
	     Y.MAIL.VALUE.DATE =  PO.VALUE.DATE
	  CASE ID.NEW[1,2] EQ 'OE' 
         Y.MAIL.SET.CCY = R.NEW(PP.OEYG.DebitAccountCurrency)
         Y.MAIL.TRANS.AMT = R.NEW(PP.OEYG.DebitAmount)
	     Y.MAIL.VALUE.DATE =  R.NEW(PP.OEYG.DebitValueDate)
	  CASE ID.NEW[1,4] EQ 'FMQA'
	      Y.MAIL.SET.CCY = R.PORREC<PPPTX.DebitMainAccountCurrencyCode>
          Y.MAIL.TRANS.AMT = R.PORREC<PPPTX.DebitMainAmount>
	      Y.MAIL.VALUE.DATE = R.PORREC<PPPTX.DebitValueDate>
	END CASE
	
    Y.MAIL.NO.NOMINAL = ''
    Y.MAIL.TRANS.AMT = Y.MAIL.TRANS.AMT
    Y.MAIL.SECURITY.NO = ''
    Y.MAIL.TRADE.DATE = TODAY
    Y.MAIL.TRADE.DATE = OCONV(ICONV(Y.MAIL.TRADE.DATE,"D2E"),"D4E")
    Y.MAIL.VALUE.DATE = OCONV(ICONV(Y.MAIL.VALUE.DATE,"D2E"),"D4E")

    CHANGE VM TO SM IN Y.MAIL.NO.NOMINAL
    CHANGE VM TO SM IN Y.MAIL.SET.CCY
    CHANGE VM TO SM IN Y.MAIL.TRANS.AMT
    CHANGE FM TO SM IN Y.MAIL.SECURITY.NO
    CHANGE FM TO SM IN Y.MAIL.TRADE.DATE
    CHANGE FM TO SM IN Y.MAIL.VALUE.DATE

RETURN

GET.PAYMENT.AMOUNT:
*******************
    BEGIN CASE
        CASE (R.NEW(PO.TOTAL.DEBIT.AMOUNT) NE '') AND (R.NEW(PO.TOTAL.DEBIT.AMOUNT) NE '0.00') AND (R.NEW(PO.TOTAL.DEBIT.AMOUNT) NE '0')
            Y.PAY.AMT = R.NEW(PO.TOTAL.DEBIT.AMOUNT)
        CASE (R.NEW(PO.DEBIT.AMOUNT) NE '') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0.00') AND (R.NEW(PO.DEBIT.AMOUNT) NE '0')
            Y.PAY.AMT = R.NEW(PO.DEBIT.AMOUNT)
	    CASE (R.NEW(PO.PAYMENT.AMOUNT) NE '') AND (R.NEW(PO.PAYMENT.AMOUNT) NE '0.00') AND (R.NEW(PO.PAYMENT.AMOUNT) NE '0')
            Y.PAY.AMT = R.NEW(PO.PAYMENT.AMOUNT)
    END CASE
RETURN

GET.CALCCVD.DATE:
*****************

    O.CHANNEL.DETS = ''
    O.CHANNEL.FXSHIFT.DETS = ''
    O.CHANNEL.RESP = ''

    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.channelName> = 'NOSTRO'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.currencyCode> = TXN.CCY
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.ctrbtrIndicator> = R.NEW(PO.ORDER.TYPE)[1,1]
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.paymentDirection> = 'O'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.priority> = R.NEW(PO.MESSAGE.PRIORITY)
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.messageType> = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.source> = R.NEW(PO.ORDER.INITIATION.TYPE)

    PMT.EXEC.DATE = R.NEW(PO.PAYMENT.EXECUTION.DATE)
    REQ.CVD = R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE)

   CALL JB.R.PP.CALCCVD.API(TXN.CCY,PMT.EXEC.DATE,REQ.CVD,I.CHANNEL.NAME,PO.VALUE.DATE)

RETURN

TRIGGER.MULTIPLE.MAILS:
***********************
    GOSUB MAIL.TO.CC.APPROVER
    GOSUB MAIL.TO.MA.APPROVER

    CHANGE VM TO FM IN  Y.BLOCK.DEPT
    Y.BLK.DEPT.CNT = DCOUNT(Y.BLOCK.DEPT,FM)
    J = 0
    LOOP
        J = J + 1
    WHILE J LE Y.BLK.DEPT.CNT

        GOSUB CUST.PORTFOLIO.EMAIL.CHECK

    REPEAT


RETURN

CUST.PORTFOLIO.EMAIL.CHECK:
**************************
    Y.CUS.SB.ID = ''
    Y.CUS.MESSAGE = ''
    Y.CUS.CHECKTYPE = ''
    TYPE = ''
    K = 0
    LOOP
        K = K + 1
    WHILE K LE Y.BLK.DEPT.CNT
        IF Y.BLOCK.DEPT<K> NE 'CC' AND  Y.BLOCK.DEPT<K> NE 'MA' THEN
            IF Y.BLOCK.DEPT<J> EQ Y.BLOCK.DEPT<K> THEN
                Y.BLK.SB.ID = ''
                Y.BLK.SB.ID = Y.BLOCK.IDS<K>
                Y.BLOCK.POS = ''
                FIND Y.BLK.SB.ID IN Y.SB.ID.ARR SETTING Y.BLOCK.POS ELSE Y.BLOCK.POS = ''
                IF Y.BLOCK.POS NE '' THEN
                    Y.CUS.SB.ID<-1> = Y.TAG.NAME.ARR<Y.BLOCK.POS>
                    Y.CUS.MESSAGE<-1> = Y.BLOCK.MESSAGES<K>
                    Y.CUS.CHECKTYPE<-1> = Y.BLOCK.DEPT<K>
                END
            END
        END
    REPEAT
    IF Y.CUS.SB.ID NE '' THEN
        Y.DAO.ID = Y.BLOCK.DEPT<J>
        Y.DAO.VALUES = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        CHANGE VM TO FM IN Y.DAO.VALUES
        Y.DAO.POS = ''
        FIND Y.DAO.ID IN Y.DAO.VALUES SETTING Y.DAO.POS ELSE Y.DAO.POS = ''
        DAO.TYPE = R.GEN.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.DAO.POS,1>
        GOSUB EMAIL.CUST.PORTFOLIO
    END
RETURN
EMAIL.CUST.PORTFOLIO:
*********************
    IF Y.CUS.SB.ID EQ '' THEN RETURN
    TYPE =  DAO.TYPE
    ENTITY.TYPE<1,1> = 'PORTFOLIO'
    ENTITY.ID = Y.SEC.ACCNT
    Y.NAME = ''
    Y.VALUE = ''
    RETVAR = ''
    CONVERT FM TO VM IN Y.CUS.SB.ID
    CONVERT VM TO SM IN Y.CUS.SB.ID

    CONVERT FM TO VM IN Y.CUS.MESSAGE
    CONVERT VM TO SM IN Y.CUS.MESSAGE

    CONVERT FM TO VM IN Y.CUS.CHECKTYPE
    CONVERT VM TO SM IN Y.CUS.CHECKTYPE


    CONVERT FM TO VM IN Y.SEC.ACCNT
    CONVERT VM TO SM IN Y.SEC.ACCNT
    GOSUB GET.TRANSACTION.MAIL.DETAILS

    Y.NAME<1,1> = 'transactionNumber'
    Y.VALUE<1,1,-1> = ID.NEW
    Y.NAME<1,2> = 'softBlockID'
    Y.VALUE<1,2,-1> = Y.CUS.SB.ID
    Y.NAME<1,3> = 'softBlockMessage'
    Y.VALUE<1,3,-1> = Y.CUS.MESSAGE
    Y.NAME<1,4> = 'softBlockOwner'
    Y.VALUE<1,4,-1> = Y.CUS.CHECKTYPE
	
	Y.NAME<1,5> = 'relManager'
    Y.VALUE<1,5,-1> = Y.DAO.NAME
    Y.NAME<1,6> = 'inputter'
    Y.OPERATOR = UID
    CONVERT FM TO SM IN Y.OPERATOR
    Y.VALUE<1,6,-1> = Y.OPERATOR

    CHANGE FM TO SM IN Y.CUST.NO
    CHANGE FM TO SM IN Y.SEC.ACCNT
    Y.NAME<1,7> = 'customerNumber'
    Y.VALUE<1,7,-1> = Y.CUST.NO
    Y.NAME<1,8> = 'portfolioNumber'
    Y.VALUE<1,8,-1> = Y.SEC.ACCNT
    Y.NAME<1,9> = 'transactionType'
    Y.VALUE<1,9,-1> = Y.TXN.TYPE
    Y.NAME<1,10> = 'quantity'
    Y.VALUE<1,10,-1> = Y.MAIL.NO.NOMINAL
    Y.NAME<1,11> = 'currency'
    Y.VALUE<1,11,-1> = Y.MAIL.SET.CCY
    Y.NAME<1,12> = 'amount'
    Y.VALUE<1,12,-1> = Y.MAIL.TRANS.AMT
    Y.NAME<1,13> = 'securityIdentifier'
    Y.VALUE<1,13,-1> = Y.MAIL.SECURITY.NO
    Y.NAME<1,14> = 'tradeDate'
    Y.VALUE<1,14,-1> = Y.MAIL.TRADE.DATE
    Y.NAME<1,15> = 'valueDate'
    Y.VALUE<1,15,-1> = Y.MAIL.VALUE.DATE

    Y.NAME<1,16> = 'dateTime'
    Y.VALUE<1,16,-1> = DATE.TIME
	Y.NAME<1,17> = 'T24UrlLink'
    Y.VALUE<1,17,-1> = Y.T24URL.VALUE
    CONVERT FM TO VM IN Y.NAME
    GOSUB TRIGGER.EMAIL
RETURN

MAIL.TO.CC.APPROVER:
*******************
    IF Y.CC.IDS EQ '' THEN RETURN
    TYPE =  Y.APPROVE.BP
    ENTITY.TYPE<1,1> = 'PORTFOLIO'
    ENTITY.ID = Y.SEC.ACCNT
    Y.NAME = ''
    Y.VALUE = ''
    RETVAR = ''
    CONVERT FM TO VM IN Y.CC.IDS
    CONVERT VM TO SM IN Y.CC.IDS

    CONVERT FM TO VM IN Y.CC.MESSAGE
    CONVERT VM TO SM IN Y.CC.MESSAGE

    CONVERT FM TO VM IN Y.CC.CHECKTYPE
    CONVERT VM TO SM IN Y.CC.CHECKTYPE

    TYPE = Y.APPROVE.BP


    CONVERT FM TO VM IN Y.SEC.ACCNT
    CONVERT VM TO SM IN Y.SEC.ACCNT
    GOSUB GET.TRANSACTION.MAIL.DETAILS

    Y.NAME<1,1> = 'transactionNumber'
    Y.VALUE<1,1,-1> = ID.NEW
    Y.NAME<1,2> = 'softBlockID'
    Y.VALUE<1,2,-1> = Y.CC.IDS
    Y.NAME<1,3> = 'softBlockMessage'
    Y.VALUE<1,3,-1> = Y.CC.MESSAGE
    Y.NAME<1,4> = 'softBlockOwner'
    Y.VALUE<1,4,-1> = Y.CC.CHECKTYPE
	
	Y.NAME<1,5> = 'relManager'
    Y.VALUE<1,5,-1> = Y.DAO.NAME
    Y.NAME<1,6> = 'inputter'
    Y.OPERATOR = UID
    CONVERT FM TO SM IN Y.OPERATOR
    Y.VALUE<1,6,-1> = Y.OPERATOR

    CHANGE FM TO SM IN Y.CUST.NO
    CHANGE FM TO SM IN Y.SEC.ACCNT
    Y.NAME<1,7> = 'customerNumber'
    Y.VALUE<1,7,-1> = Y.CUST.NO
    Y.NAME<1,8> = 'portfolioNumber'
    Y.VALUE<1,8,-1> = Y.SEC.ACCNT
    Y.NAME<1,9> = 'transactionType'
    Y.VALUE<1,9,-1> = Y.TXN.TYPE
    Y.NAME<1,10> = 'quantity'
    Y.VALUE<1,10,-1> = Y.MAIL.NO.NOMINAL
    Y.NAME<1,11> = 'currency'
    Y.VALUE<1,11,-1> = Y.MAIL.SET.CCY
    Y.NAME<1,12> = 'amount'
    Y.VALUE<1,12,-1> = Y.MAIL.TRANS.AMT
    Y.NAME<1,13> = 'securityIdentifier'
    Y.VALUE<1,13,-1> = Y.MAIL.SECURITY.NO
    Y.NAME<1,14> = 'tradeDate'
    Y.VALUE<1,14,-1> = Y.MAIL.TRADE.DATE
    Y.NAME<1,15> = 'valueDate'
    Y.VALUE<1,15,-1> = Y.MAIL.VALUE.DATE

    Y.NAME<1,16> = 'dateTime'
    Y.VALUE<1,16,-1> = DATE.TIME
	Y.NAME<1,17> = 'T24UrlLink'
    Y.VALUE<1,17,-1> = Y.T24URL.VALUE
	
    CONVERT FM TO VM IN Y.NAME
    GOSUB TRIGGER.EMAIL
RETURN

MAIL.TO.MA.APPROVER:
*******************
    IF Y.MA.IDS EQ '' THEN RETURN
    TYPE =  Y.APPROVE.MA
    ENTITY.TYPE<1,1> = 'PORTFOLIO'
    ENTITY.ID = Y.SEC.ACCNT
    Y.NAME = ''
    Y.VALUE = ''
    RETVAR = ''

    CONVERT FM TO VM IN Y.MA.CHECKTYPE
    CONVERT VM TO SM IN Y.MA.CHECKTYPE
    CONVERT FM TO VM IN Y.MA.IDS
    CONVERT VM TO SM IN Y.MA.IDS
    CONVERT FM TO VM IN Y.MA.MESSAGE
    CONVERT VM TO SM IN Y.MA.MESSAGE
    GOSUB GET.TRANSACTION.MAIL.DETAILS

    TYPE = Y.APPROVE.MA

    CONVERT FM TO VM IN Y.SEC.ACCNT
    CONVERT  VM TO SM IN Y.SEC.ACCNT

    Y.NAME<1,1> = 'transactionNumber'
    Y.VALUE<1,1,-1> = ID.NEW
    Y.NAME<1,2> = 'softBlockID'
*    Y.VALUE<1,2,-1> = Y.MA.SB.ID  ; * P3636-5690 S/E
    Y.NAME<1,3> = 'softBlockMessage'
    Y.VALUE<1,3,-1> = Y.MA.MESSAGE
    Y.NAME<1,4> = 'softBlockOwner'
*   Y.VALUE<1,4,-1> = Y.MA.CHKTYPE  ; * P3636-5690 S/E

    Y.NAME<1,5> = 'relManager'
    Y.VALUE<1,5,-1> = Y.DAO.NAME
    Y.NAME<1,6> = 'inputter'
    Y.OPERATOR = UID
    CONVERT FM TO SM IN Y.OPERATOR
    Y.VALUE<1,6,-1> = Y.OPERATOR

    CHANGE FM TO SM IN Y.CUST.NO
    CHANGE FM TO SM IN Y.SEC.ACCNT

    Y.NAME<1,7> = 'customerNumber'
    Y.VALUE<1,7,-1> = Y.CUST.NO
    Y.NAME<1,8> = 'portfolioNumber'
    Y.VALUE<1,8,-1> = Y.SEC.ACCNT
    Y.NAME<1,9> = 'transactionType'
    Y.VALUE<1,9,-1> = Y.TXN.TYPE
    Y.NAME<1,10> = 'quantity'
    Y.VALUE<1,10,-1> = Y.MAIL.NO.NOMINAL
    Y.NAME<1,11> = 'currency'
    Y.VALUE<1,11,-1> = Y.MAIL.SET.CCY
    Y.NAME<1,12> = 'amount'
    Y.VALUE<1,12,-1> = Y.MAIL.TRANS.AMT
    Y.NAME<1,13> = 'securityIdentifier'
    Y.VALUE<1,13,-1> = Y.MAIL.SECURITY.NO
    Y.NAME<1,14> = 'tradeDate'
    Y.VALUE<1,14,-1> = Y.MAIL.TRADE.DATE
    Y.NAME<1,15> = 'valueDate'
    Y.VALUE<1,15,-1> = Y.MAIL.VALUE.DATE

    Y.NAME<1,16> = 'dateTime'
    Y.VALUE<1,16,-1> = DATE.TIME
	Y.NAME<1,17> = 'T24UrlLink'
    Y.VALUE<1,17,-1> = Y.T24URL.VALUE
    CONVERT FM TO VM IN Y.NAME
    GOSUB TRIGGER.EMAIL

RETURN

TRIGGER.EMAIL:
*************
	Y.NOTIF.VALUES = Y.NOTIF.TITLE.VALUE:@VM:Y.NOTIF.DESC.VALUE:@VM:Y.SRC.APPL.VALUE:@VM:Y.TARGET.APPL.VALUE
  
	CALL JB.R.XX.INDC.NOTIFICATION.UPD(TYPE,ENTITY.TYPE,ENTITY.ID,Y.NAME,Y.VALUE,UID,Y.NOTIF.VALUES,RETVAR,'','')
RETURN

END
