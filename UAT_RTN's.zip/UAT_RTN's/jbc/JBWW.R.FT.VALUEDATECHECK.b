*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.VALUEDATECHECK
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                Reference               Description
*------------------------------------------------------------------------------------------------
* 07/08/2017    Sushmitha B             JB2A-39258               To make 4 eyes check for vaue date amendment
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN


INIT:
**************************************************************
    Y.APP = ''
    Y.ID = ID.NEW
    Y.LOCFIELD = ''
    Y.LOCFIELD.POS = ''
    Y.LOCPOS = ''
    Y.LFT.VLDT.CHKD = ''
    Y.INPUT = ''
	Y.INPUT1 = ''
    Y.AUTH = ''

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

   
    RETURN
***********************************************************************
PROCESS:
*************************************************************************** 

CALL F.READ(FN.FUNDS.TRANSFER, Y.ID,R.FUNDS,F.FUNDS.TRANSFER,R.FUNDS.TRANSFER.ERR)
    Y.APP = APPLICATION
    Y.LOCFIELD = 'L.FT.VALDT.CHKD'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.LOCFIELD.POS =  Y.LOCPOS<1,1>
    Y.LFT.VLDT.CHKD = R.NEW(FT.LOCAL.REF)<1,Y.LOCFIELD.POS>
	
	
	 Y.INPUT = R.NEW(FT.INPUTTER)
	 Y.INPUT1 = FIELD(Y.INPUT,'_',2)
	 Y.AUTH = OPERATOR
	 
 IF Y.LFT.VLDT.CHKD EQ 'CHECKER' THEN
	IF Y.INPUT1 EQ Y.AUTH THEN  
		 ETEXT = 'EB-SAMEINPUTTER'
          CALL STORE.END.ERROR 
	    END   
	
 END
    RETURN

***********************************************************************
    END