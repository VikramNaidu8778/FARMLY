SUBROUTINE JBWW.R.FT.REFUNDFEE.AUTH
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer                Mail Id                            Reference      Description
*------------------------------------------------------------------------------------------------------
* 30/05/2017   Jayanthi R         Jayanthi.Rallapalli@cognizant.com                                RE-001_ADDENDUM      Refund fees.
*-----------------------------------------------------------------------------------------------------
* Description :This is the auth routine attached to FUNDS.TRANSFER for updating
* refund of fees into the table 'JBWW.H.XX.FEECAPTURE'
*-------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.JBWW.H.XX.FEECAPTURE
    $INSERT I_F.FUNDS.TRANSFER
                
*-------------------------------------------------------------------------------------------------------
GOSUB INIT
GOSUB MAIN.PROCESS
 
RETURN
*-------------------------------------------------------------------------------------------------------  
INIT:
*----
 
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
                
    FN.JBWW.H.XX.FEECAPTURE       = 'F.JBWW.H.XX.FEECAPTURE'
    F.JBWW.H.XX.FEECAPTURE        = ''
    CALL OPF(FN.JBWW.H.XX.FEECAPTURE,F.JBWW.H.XX.FEECAPTURE)
              
                
                
                RETURN
*** </region>
*-----------------------------------------------------------------------------
MAIN.PROCESS:
*---------------------
 
 
    Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)
 
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'PRICE.REP.PARAM',R.GENPARM,F.JBWW.H.EB.GENERICPARAMETER,GENPARM.ERR)
    R.GENPARM.FN = R.GENPARM<JBWW.GEN.PAR.FIELD.NAME>
 
    LOCATE 'REFUND.FEES' IN R.GENPARM.FN<1,1> SETTING FN.POS1 THEN
                                Y.REFUND.TXN.TYPE = R.GENPARM<JBWW.GEN.PAR.FIELD.VALUE,FN.POS1>
    END
                LOCATE Y.TXN.TYPE IN Y.REFUND.TXN.TYPE<1,1,1> SETTING FV.POS1 THEN
                                GOSUB CAL.DATE
    END ELSE
                                RETURN
                END
                
RETURN
*-------------------------------------------------------------------------------------------------------  
CAL.DATE:
*--------

 
                CURR.DATE = TODAY
                COMI = CURR.DATE
                CALL LAST.DAY.OF.THIS.QUAT
                QUAT.DATE = COMI
                CURR.DATE = QUAT.DATE
                CALL CDT('',CURR.DATE,"-93C")   ;* To get the previous quarter end
                COMI = CURR.DATE
                CALL LAST.DAY.OF.THIS.QUAT
                ADJUST.DATE = COMI
                Y.FEECAP.SAFE.ID = ID.NEW
                CALL F.READ(FN.JBWW.H.XX.FEECAPTURE,Y.FEECAP.SAFE.ID,REC.FEECAP,F.JBWW.H.XX.FEECAPTURE,FEE.ERR)
                                
                BD.VAL = REC.FEECAP<FEE.BOOKING.DATE>
                BD.VAL.CNT = DCOUNT(BD.VAL,VM)
*
 *               ACT.COMM.VALS       = REC.FEECAP<FEE.ACT.CURRENCY,BD.VAL.CNT>                   ;*Will not have Comm.Code for actual price,so taking CCY for the count
 *   ACT.COMM.VALS.CNT   = DCOUNT(ACT.COMM.VALS,SM)
               
                REFUND.AMT = R.NEW(FT.DEBIT.AMOUNT)
                REC.FEECAP<FEE.BOOKING.DATE,BD.VAL.CNT+1>  = TODAY
                REC.FEECAP<FEE.ADJUSTMENT.DATE,BD.VAL.CNT+1>  = ADJUST.DATE
                REC.FEECAP<FEE.ADJUSTMENT.FLAG,BD.VAL.CNT+1>  = 'Yes'
                REC.FEECAP<FEE.ACT.PRICE,BD.VAL.CNT+1,1> = REFUND.AMT
 
                
                CALL F.WRITE(FN.JBWW.H.XX.FEECAPTURE, Y.FEECAP.SAFE.ID, REC.FEECAP)
                
RETURN
*-------------------------------------------------------------------------------------------------------