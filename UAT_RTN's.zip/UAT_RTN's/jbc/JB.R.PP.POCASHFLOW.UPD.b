*-----------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.POCASHFLOW.UPD
*-----------------------------------------------------------------------------------
* Description:
* The purpose of the routine is to update the Payment amount in local table
* JB.L.PP.CASHFLOWDATA which will be used for Cash Flow Report.
* Input routine attached in version control PAYMENT.ORDER.
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date                Developer           Reference           Description
*-----------------------------------------------------------------------------------
* 19/11/2024         P Amala             CBPAY-1262          Initial Version
* 12/12/2024         P Amala             CBPAY-1430          Included logic to remove the movement detail from the concat table
*                                                            when deleting the unauth Payment transaction.
* 19/03/2025         P Amala             CBPAY-65            Fix to check CreditNostroAccount/PPLoroNostroAccount number against cashflow nostro account.
* 16/04/2025         P Amala             CBPAY-2507          Code has been modified to pick only first field of accountnumber from PPLoroNostroAccount to check against nostrocashflow.
* 12/05/2025         P Amala             CBPAY-2687          Fix to take CVD for book payment and calculated CVD for OT03 /OT12.
*-----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JB.L.PP.CASHFLOWDATA
    $INSERT I_F.JBWW.H.AC.NOSTCASHFLOW
    $USING PP.RoutingAndSettlementService
    $USING EB.SystemTables
    $USING EB.DataAccess

*------------------------------------------------------------------------------

    GOSUB OPEN.FILES
    GOSUB PROCESS

RETURN

*------------------------------------------------------------------------------
OPEN.FILES:
***********

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
        
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA)
    
    FN.AC.NOSTROCASHFLOW = 'F.JBWW.H.AC.NOSTCASHFLOW'
    F.AC.NOSTROCASHFLOW = ''
    CALL OPF(FN.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW)
        
    FN.LN='F.PP.LORO.NOSTRO.ACCOUNT'; F.LN=''
    EB.DataAccess.Opf(FN.LN, F.LN)
    
    FN.PREFCORR = 'F.PP.PREFERREDCORRESPONDENT' ; F.PREFCORR = ''
    EB.DataAccess.Opf(FN.PREFCORR, F.PREFCORR)
    
    R.AC.NOSTROCASHFLOW = '' ; ERR.AC.NOSTROCASHFLOW = '' ; NST.ACCT.TEMP = ''
    DB.ACCT.POS = '' ; CR.ACCT.POS = '' ; CRNOST.ACC.POS = '' ; LORNST.ACC.POS = ''
    Y.CR.AC.NO = '' ; Y.DB.AC.NO = '' ; Y.CRNOST.ACC = '' ; Y.PP.CSHFLW.ERR = ''
    Y.PP.ID = ''

RETURN

*------------------------------------------------------------------------------
PROCESS:
********

    Y.CR.AC.NO = R.NEW(PO.CREDIT.ACCOUNT)
    Y.DB.AC.NO = R.NEW(PO.DEBIT.ACCOUNT)
    Y.CRNOST.ACC = R.NEW(PO.CREDIT.NOSTRO.ACCOUNT)
    TXN.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    			
    CALL F.READ(FN.AC.NOSTROCASHFLOW,'SYSTEM',R.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW,ERR.AC.NOSTROCASHFLOW)
    IF R.AC.NOSTROCASHFLOW NE '' THEN
        NST.ACCT.TEMP = R.AC.NOSTROCASHFLOW<JB.NOSACCT.CSHFLW.NOSTRO.ACCOUNT>

        CONVERT SM TO VM IN NST.ACCT.TEMP
        CONVERT VM TO FM IN NST.ACCT.TEMP
		Y.PP.ID = ID.NEW
        BEGIN CASE
            CASE (R.NEW(PO.PAYMENT.ORDER.PRODUCT)[1,2] EQ 'AC') OR (R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'ITTY')
                GOSUB CHECK.DB.ACC
                GOSUB CHECK.CR.ACC
            CASE R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'TRSY'
                GOSUB CHECK.CR.NOSTACC
            CASE R.NEW(PO.PAYMENT.ORDER.PRODUCT)[1,2] EQ 'OT'
                GOSUB CHECK.DB.ACC
                GOSUB CHECK.CR.NOSTACC
        END CASE
    END
RETURN

*------------------------------------------------------------------------------
CHECK.DB.ACC:
*************

    Y.NST.CSHFLW.ACCT = '' ; Y.PP.EXCDATE = ''
    Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
        
    LOCATE Y.DB.AC.NO IN NST.ACCT.TEMP SETTING DB.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.DB.AC.NO
        Y.PP.AMT = R.NEW(PO.DEBIT.AMOUNT)
        IF Y.PP.AMT EQ '' THEN
            Y.PP.AMT = R.NEW(PO.PAYMENT.AMOUNT)
        END
        IF (R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12') AND NOT(R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES 'STO':VM:'STOMXCHATS')THEN
            GOSUB GET.CALCCVD.DATE
        END ELSE
            Y.PP.EXCDATE = R.NEW(PO.CREDIT.VALUE.DATE)
        END
		GOSUB UPD.CASHFLOW.DETAILS
    END
RETURN

*------------------------------------------------------------------------------
CHECK.CR.ACC:
*************

    Y.NST.CSHFLW.ACCT = '' ; Y.PP.EXCDATE = ''
    Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
        
    LOCATE Y.CR.AC.NO IN NST.ACCT.TEMP SETTING CR.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.CR.AC.NO
        Y.PP.AMT = R.NEW(PO.CREDIT.AMOUNT)
        IF Y.PP.AMT EQ '' THEN
            Y.PP.AMT = R.NEW(PO.PAYMENT.AMOUNT)
        END
        Y.PP.AMT = Y.PP.AMT*(-1)
        IF (R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12') AND NOT(R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES 'STO':VM:'STOMXCHATS')THEN
            GOSUB GET.CALCCVD.DATE
        END ELSE
            Y.PP.EXCDATE = R.NEW(PO.CREDIT.VALUE.DATE)
        END
		GOSUB UPD.CASHFLOW.DETAILS
    END
RETURN

*------------------------------------------------------------------------------
CHECK.CR.NOSTACC:
*****************

    Y.NST.CSHFLW.ACCT = '' ; Y.PP.EXCDATE = ''
    Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
        
    LOCATE Y.CRNOST.ACC IN NST.ACCT.TEMP SETTING CRNOST.ACC.POS THEN
        Y.NST.CSHFLW.ACCT = Y.CRNOST.ACC
    END ELSE
        GOSUB GET.BIC.FRM.PREFCORR
        LOCATE Y.LORNST.ACC IN NST.ACCT.TEMP SETTING LORNST.ACC.POS THEN
            Y.NST.CSHFLW.ACCT = Y.LORNST.ACC
        END
    END
            
    IF Y.NST.CSHFLW.ACCT NE '' THEN
        Y.PP.AMT = R.NEW(PO.CREDIT.AMOUNT)
        IF Y.PP.AMT EQ '' THEN
            Y.PP.AMT = R.NEW(PO.PAYMENT.AMOUNT)
        END
        Y.PP.AMT = Y.PP.AMT*(-1)
        IF (R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12') AND NOT(R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES 'STO':VM:'STOMXCHATS')THEN
            GOSUB GET.CALCCVD.DATE
        END ELSE
            Y.PP.EXCDATE = R.NEW(PO.CREDIT.VALUE.DATE)
        END
		GOSUB UPD.CASHFLOW.DETAILS

    END

RETURN

*------------------------------------------------------------------------------
GET.BIC.FRM.PREFCORR:
*********************

* Read PreferedCorrespondent record for the payment currency and retrive the BIC

    Y.PAY.CCY = R.NEW(PO.PAYMENT.CURRENCY)
            
    SelPref = "SELECT ":FN.PREFCORR:" WITH TransactionCurrency EQ ":Y.PAY.CCY
    EB.DataAccess.Readlist(SelPref, SelPrfId, '', PrefCount, '')
    EB.DataAccess.FRead(FN.PREFCORR, SelPrfId, R.PREFCORR, F.PREFCORR, '')
    CorrID = R.PREFCORR<PP.RoutingAndSettlementService.Preferredcorrespondent.PctCorrespondentID>
    GOSUB GET.NOSTACC.FRM.LORONOSTRO
RETURN

*------------------------------------------------------------------------------
GET.NOSTACC.FRM.LORONOSTRO:
***************************

    Y.LORNST.ACC = ''
    SelCmd = "SELECT ":FN.LN:" WITH BICCode EQ ":CorrID:" AND AccountCurrency EQ ":Y.PAY.CCY
    EB.DataAccess.Readlist(SelCmd, SelList, '', SelCount, '')
    LOOP
        REMOVE REC.ID FROM SelList SETTING REC.POS
    WHILE REC.ID : REC.POS
        EB.DataAccess.FRead(FN.LN, REC.ID, R.LN, F.LN, '')
        Y.LORNST.ACC = R.LN<PP.RoutingAndSettlementService.LoroNostroAccount.LnaAccountnumber,1>

    REPEAT
      
RETURN

GET.CALCCVD.DATE:
*****************

    O.CHANNEL.DETS = ''
    O.CHANNEL.FXSHIFT.DETS = ''
    O.CHANNEL.RESP = ''

    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.channelName> = 'NOSTRO'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.currencyCode> = TXN.CCY
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.ctrbtrIndicator> = R.NEW(PO.ORDER.TYPE)[1,1]
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.paymentDirection> = 'O'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.priority> = R.NEW(PO.MESSAGE.PRIORITY)
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.messageType> = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.source> = R.NEW(PO.ORDER.INITIATION.TYPE)

    PMT.EXEC.DATE = R.NEW(PO.PAYMENT.EXECUTION.DATE)
    REQ.CVD = R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE)

    CALL JB.R.PP.CALCCVD.API(TXN.CCY,PMT.EXEC.DATE,REQ.CVD,I.CHANNEL.NAME,Y.PP.EXCDATE)

RETURN

UPD.CASHFLOW.DETAILS:
*********************

    IF V$FUNCTION EQ 'D' THEN
        CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
    END ELSE
        CALL JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
    END

RETURN
*------------------------------------------------------------------------------
END
