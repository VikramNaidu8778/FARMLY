SUBROUTINE JB.R.PP.GETSAMACC.RTN(Y.ACCOUNT,Y.SAM.ID)
*-----------------------------------------------------------------------------
* Modification History :
* Date              Developer               Reference                    Description
*------------------------------------------------------------------------------------------------------------------------
*10-JUN-2024       Hariharan T              CBPAY-81        Call API routine to fetch Alternate Account for Account
*                                                           and then retrieve portfolio id from SEC.ACC.MASTER.NAME table
*------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    
	
    GOSUB OPEN.FILES
    GOSUB PROCESS
    
    RETURN
       
***********
OPEN.FILES:
************
    
    Y.AC.ALT.ID = ''
    Y.ALT.ACCT.TYPE = ''
    Y.ALT.ACCT.IDS = ''

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT, F.SEC.ACC.MASTER.ALT)


RETURN
    
*********
PROCESS:
*********

    R.ACCOUNT = '' ; ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE "" THEN
        Y.ALT.ACCT.TYPE = R.ACCOUNT<AC.ALT.ACCT.TYPE>
        Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN Y.ALT.ACCT.TYPE<1,1> SETTING ALT.POS THEN
            Y.AC.ALT.ID = Y.ALT.ACCT.IDS<1,ALT.POS>
            Y.SAM.ALT.ID = FIELD(Y.AC.ALT.ID,'-',1):'-':FIELD(Y.AC.ALT.ID,'-',2)
            R.SAM.ALT.REC = '' ; SAM.ALT.ERR = ''
            CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
            IF R.SAM.ALT.REC NE '' THEN
                Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
            END
        END
    END
RETURN
********************************************************
END
