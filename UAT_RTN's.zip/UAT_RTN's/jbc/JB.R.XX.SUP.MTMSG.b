SUBROUTINE JB.R.XX.SUP.MTMSG(R.DOH,TMP.OPERAND,TMP.CONDITION,OUT.VAR)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 21/05/2025        Madhu                  CBPAY-858       Suppress the MT210, MT292 for the HK BIC, BIC code is configured in GPM
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.HEADER
    $INSERT I_F.DE.DISP.CONTROL
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    GOSUB INIT
    GOSUB PROCESS
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    Y.GPM.ID = ''
    Y.GPM.ID  = 'JB.D.PP.TPH.CONFIG'
    
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    R.GPM = '' ; YERR.GPM = ''
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER, Y.GPM.ID, R.GPM, F.JBWW.H.EB.GENERICPARAMETER, YERR.GPM)
    IF R.GPM NE '' THEN
        SUP.POS = '' ; Y.GPM.BIC.CODE = ''
        LOCATE 'SUPRESS.MT210' IN R.GPM<JBWW.GEN.PAR.FIELD.NAME,1> SETTING SUP.POS THEN
            Y.GPM.BIC.CODE = R.GPM<JBWW.GEN.PAR.FIELD.VALUE,SUP.POS>
            CHANGE SM TO ',' IN Y.GPM.BIC.CODE
            CHANGE ',' TO FM IN Y.GPM.BIC.CODE
        END
        SUP.MSG.POS = '' ; Y.GPM.MSG.TYPE = ''
        LOCATE 'SUP.MSG.TYPE' IN R.GPM<JBWW.GEN.PAR.FIELD.NAME,1> SETTING SUP.MSG.POS THEN
            Y.GPM.MSG.TYPE = R.GPM<JBWW.GEN.PAR.FIELD.VALUE,SUP.MSG.POS>
            CHANGE SM TO ',' IN Y.GPM.MSG.TYPE
            CHANGE ',' TO FM IN Y.GPM.MSG.TYPE
        END
    
        Y.MSG.TYPE = R.DOH<DE.HDR.MESSAGE.TYPE>
        Y.BIC.CODE = R.DOH<DE.HDR.TO.ADDRESS,1>[1,8]
*IF Y.MSG.TYPE MATCHES Y.GPM.MSG.TYPE AND Y.BIC.CODE MATCHES Y.GPM.BIC.CODE THEN
        LOCATE Y.MSG.TYPE IN Y.GPM.MSG.TYPE<1> SETTING Y.MSG.POS THEN
            LOCATE Y.BIC.CODE IN Y.GPM.BIC.CODE<1> SETTING Y.BIC.POS THEN
                TMP.OPERAND = 'EQUAL'
                TMP.CONDITION = '1'
                OUT.VAR = '1'
            END
        END
    END
RETURN
*-----------------------------------------------------------------------------
END