*-----------------------------------------------------------------------------
* <Rating>-3</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.T.FT.PROCESSD.IMPLICITFT.FIELDS 
*-----------------------------------------------------------------------------
* Description : A new template JBWW.T.FT.PROCESSD.IMPLICITFT to record the FT RECORD ID when the FT is processed on AUTH date
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA

* Revision History:
*------------------
* Date               who                  Reference                 Desc
* 12/07/2018        MAHESHKUMAR        JB2A-52369               Initial Version
* *-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
*-----------------------------------------------------------------------------
    ID.F = "ID"
    ID.N = "60"
    ID.T = "ANY"
*CALL Table.defineId("ID", T24_String)        ;* Define Table id

    fieldName = "RECORD.ID"
    fieldLength = "60"
    fieldType = "ANY"
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType,"")

*-----------------------------------------------------------------------------
*  CALL Table.setAuditPosition         ;* Poputale audit information
*-----------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
    END
