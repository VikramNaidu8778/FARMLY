* @ValidationCode : MTotMTcyNjA4NDk1OTpVVEYtODoxNDY2MTY5MTU2MjM4OjM0MDY3NzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 17 Jun 2016 18:42:36
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 340677
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.NOSTROINTEREST.CHECK
*-----------------------------------------------------------------------------
**
*-----------------------------------------------------------------------------
* Modification History :
*Discription  Name        Date          Description
*CBPAY-1271   Priya       05-DEC-2014   Converted FT logic to PAYMENT.ORDER Logic.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.FT.NOSTROINTEREST
*------------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
RETURN
*------------------------------------------------------------------------------
INITIALISE:
***********

    FN.JBWW.H.FT.NOSTROINTEREST = 'F.JBWW.H.FT.NOSTROINTEREST'
    F.JBWW.H.FT.NOSTROINTEREST = ''
    CALL OPF(FN.JBWW.H.FT.NOSTROINTEREST,F.JBWW.H.FT.NOSTROINTEREST)
    R.NOS.REC = ""

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF (FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

RETURN
*------------------------------------------------------------------------------
PROCESS:
********
  
    Y.CNT = ""
    Y.NOST.ID = ""

    Y.ERR = ""
    Y.NOST.ID = R.NEW(PO.ORDERING.REFERENCE)
    Y.CNT = R.NEW(PO.ADDITIONAL.INFO)

    CALL F.READU(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,R.NOS.REC,F.JBWW.H.FT.NOSTROINTEREST,Y.ERR,'')
    IF R.NOS.REC THEN
        R.NOS.REC<JB.NOSINT.L.FT.ID,Y.CNT> = ID.NEW
        R.NEW(PO.ADDITIONAL.INFO) = ""
        CALL F.WRITE(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,R.NOS.REC)
        CALL F.RELEASE(FN.JBWW.H.FT.NOSTROINTEREST,Y.NOST.ID,F.JBWW.H.FT.NOSTROINTEREST)
    END

RETURN

END
