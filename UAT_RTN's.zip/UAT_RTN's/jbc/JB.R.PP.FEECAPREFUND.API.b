SUBROUTINE JB.R.PP.FEECAPREFUND.API(iStatusAction)
*------------------------------------------------------------------------------------------------------
* This routine is to update live file JBWW.H.XX.FEECAPTURE with Actual price, Standard Price and
* Discounted Price of commission amount.
* Attached in PP.STATUS.ACTION of 999.* (Payment Completion) & 996.* (Payment Reversal).
*------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer           Reference    Description
*------------------------------------------------------------------------------------------------------
*01-JUL-2024    Resmi R             CBPAY-544    Initial Version
*16-JAN-2025    Resmi R             CBPAY-1653   FeeCapture table JBWW.H.XX.FEECAPTURE will not get updated for book payments
*------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.CUSTOMER.CHARGE
    $INSERT I_F.FT.GROUP.CONDITION
    $INSERT I_F.JBWW.H.XX.FEECAPTURE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.POR.TRANSACTION
    $USING PP.TRIPService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentSTPFlowService
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.FT.COMMISSION.TYPE
    $INSERT I_F.POR.POSTING.AND.CONFIRMATION
*-----------------------------------------------------------------------------
   
    GOSUB INIT
    GOSUB OPEN.FILES
    GOSUB MAIN.PROCESS
    GOSUB EXPORT.TO.TRIP.API
    
    
RETURN
*-----------------------------------------------------------------------------
*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>

    FN.POR.TRANSACTION      = 'F.POR.TRANSACTION'      ; F.POR.TRANSACTION = ''
    FN.PAYMENT.ORDER        = 'F.PAYMENT.ORDER'        ; F.PAYMENT.ORDER = ''
    FN.FT.COMMISSION.TYPE   = 'F.FT.COMMISSION.TYPE'   ; F.FT.COMMISSION.TYPE = ''
    FN.CUSTOMER.CHARGE      = 'F.CUSTOMER.CHARGE'      ; F.CUSTOMER.CHARGE = ''
    FN.FT.GROUP.CONDITION   = 'F.FT.GROUP.CONDITION'   ; F.FT.GROUP.CONDITION = ''
    FN.JBWW.H.XX.FEECAPTURE = 'F.JBWW.H.XX.FEECAPTURE' ;F.JBWW.H.XX.FEECAPTURE = ''
    FN.ACCOUNT              = 'F.ACCOUNT'              ; F.ACCOUNT = ''
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER  = ''
    FN.POR.POSTING.AND.CONFIRMATION = 'F.POR.POSTING.AND.CONFIRMATION'
    F.POR.POSTING.AND.CONFIRMATION = ''
    

    Y.TXN.TYPE            = '' ; FN.POS1             = '' ; FN.POS2             = ''
    R.GENPARM             = '' ; GENPARM.ERR         = '' ; R.GENPARM.FN        = ''
    Y.IN.FT.TXN.TYPE      = '' ; Y.OTH.FT.TXN.TYPE   = '' ; IN.TYPE             = ''
    OUT.TYPE              = '' ; FV.POS1             = '' ; FV.POS2             = ''
    CUST.ID               = '' ; ACCT.NO             = '' ; CHARGE.CCY          = ''
    R.CUST.CHARGE         = '' ; CUST.APPLS          = '' ; CURR.APPLICATION    = ''
    GROUP.ID              = '' ; APP.POS             = '' ; CUST.CONDITION      = ''
    PASS.DATA             = '' ; Y.FT.COMM.TYPE.ARR  = '' ; Y.FT.COMM.TYPE      = ''
    R.GRP.CONDITION       = '' ; GRP.CON.ERR         = '' ; Y.FT.COMM.TYPE.VALS = ''
    C.POS                 = '' ; COMM.F.AMT          = '' ; Y.FT.COMM.CCY.VALS  = ''
    ACCT.NO               = '' ; R.ACC               = '' ; F.ACCOUNT           = ''
    ACC.ERR               = '' ; PORTF.VALS          = '' ; PORTF.VALS.CNT      = ''
    STD.COMM.VALS         = '' ; STD.COMM.VALS.CNT   = '' ; FEE.ERR             = ''
    DISCNT.COMM.VALS      = '' ; DISCNT.COMM.VALS.CNT= '' ; TRANS.CCY           = ''
    ACT.COMM.VALS         = '' ; ACT.COMM.VALS.CNT   = '' ; PS.CCY              = ''
    FROM.STD.PRICE        = '' ; FROM.DISCNT.PRICE   = '' ; R.FEECAPTURE        = ''
    R.POR.TRANSACTION     = '' ; ERR.POR.TRN         = '' ; Y.TXN.TYPE          = ''
    Y.PYMT.DIR            = '' ; Y.CR.ACCT           = '' ; Y.DR.ACCT           = ''
    Y.CR.CCY.CODE         = '' ; Y.DR.CCY.CODE       = '' ; Y.PO.ID             = ''
    Y.STATUS.CODE        = ''  ; Y.FT.NO             = '' ; Y.CHARGE.TYPE       = ''
    Y.PO.REFUND.TXN.TYPE = ''
    
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","FEECAPTURE.CUST.CONDITION",Y.FIELD.VALUES)
    
    CHANGE ',' TO FM IN Y.FIELD.VALUES
    
    C.PERCENT = Y.FIELD.VALUES<1> ; C.CURRENCY = Y.FIELD.VALUES<2> ; C.AMOUNT = Y.FIELD.VALUES<3>
    C.MIN.AMT = Y.FIELD.VALUES<4> ; C.MAX.AMT = Y.FIELD.VALUES<5>  ; C.PREMIUM.AMT = Y.FIELD.VALUES<6>
    C.DISCOUNT.AMT = Y.FIELD.VALUES<7> ; C.MIN.MAX.CCY = Y.FIELD.VALUES<8>

    GOSUB INIT.ARRAY


RETURN
*** </region>
*-----------------------------------------------------------------------------
OPEN.FILES:
***********
*** <region name = OPEN.FILES>

    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    CALL OPF(FN.FT.COMMISSION.TYPE,F.FT.COMMISSION.TYPE)
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    CALL OPF(FN.CUSTOMER.CHARGE,F.CUSTOMER.CHARGE)
    CALL OPF(FN.FT.GROUP.CONDITION, F.FT.GROUP.CONDITION)
    CALL OPF(FN.JBWW.H.XX.FEECAPTURE,F.JBWW.H.XX.FEECAPTURE)
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
    CALL OPF(FN.POR.POSTING.AND.CONFIRMATION,F.POR.POSTING.AND.CONFIRMATION)
    
RETURN
*** </region>
*-----------------------------------------------------------------------------
*** <region name = INIT.ARRAY>
INIT.ARRAY:
*** <desc> Initializing CUST.CONDITION and PASS.DATA arrray's </desc>


    CUST.CONDITION = ''
    PASS.DATA = ''

RETURN
*** </region>
*-----------------------------------------------------------------------------
*** <region name = MAIN.PROCESS>
MAIN.PROCESS:
*** <desc> Actual process </desc>
   
    Y.STATUS.CODE = iStatusAction<PP.TRIPService.StatusAction.statusCode> ;*Get the status code for the transaction
    PaymentRecord = iStatusAction<PP.TRIPService.StatusAction.paymentRecord> ;*To get the PAYMENT.ORDER record data
    iPaymentRecord = RAISE(PaymentRecord)
     
    Y.FT.NO = iPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ftNumber>
    
    CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)

    GOSUB FETCH.POR.TRANSACTION.FLDS
 
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","PO.PRD.FEECAPTURE",Y.FIELD.VALUES)
    Y.PO.TXN.TYPE = Y.FIELD.VALUES
    
    CHANGE ',' TO VM IN Y.PO.TXN.TYPE
    CHANGE SM TO VM IN Y.PO.TXN.TYPE
    CHANGE FM TO VM IN Y.PO.TXN.TYPE

    GOSUB FEEUPDATE.PROCESS
*GOSUB REFUND.PROCESS
                
RETURN

*REFUND.PROCESS:
***************

*    IF Y.STATUS.CODE NE '993' THEN RETURN
*
*    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","PO.PRD.REFUND.FEES",Y.FIELD.VALUES)
*    Y.PO.REFUND.TXN.TYPE = Y.FIELD.VALUES
*
*    CHANGE SM TO VM IN Y.PO.REFUND.TXN.TYPE
*    CHANGE ',' TO VM IN Y.PO.REFUND.TXN.TYPE
*    CHANGE FM TO VM IN Y.PO.REFUND.TXN.TYPE
*
*    LOCATE Y.TXN.TYPE IN Y.PO.REFUND.TXN.TYPE<1,1> SETTING FV.POS1 THEN
*        GOSUB CALCULATE.DATE
*    END
*
*RETURN

FEEUPDATE.PROCESS:
******************
    
    IF Y.TXN.TYPE MATCHES Y.PO.TXN.TYPE THEN
        CALL F.READ(FN.JBWW.H.XX.FEECAPTURE, Y.FT.NO, R.FEECAPTURE, F.JBWW.H.XX.FEECAPTURE, FEE.ERR)
        
        PORTF.VALS = R.FEECAPTURE<FEE.PORTFOLIO>
        PORTF.VALS.CNT = DCOUNT(PORTF.VALS,VM)
        PORTF.VALS.CNT = PORTF.VALS.CNT + 1
        
                
        BEGIN CASE
        
            CASE Y.PYMT.DIR EQ 'O'    ;* For Outgoing transactions
                ACCT.NO = Y.DR.ACCT
                
            CASE Y.PYMT.DIR EQ 'I' ;* For Incoming transactions
                ACCT.NO = Y.CR.ACCT
                
        END CASE
                
        GOSUB READ.ACCT
        CALL JB.R.PP.GETSAMACC.RTN(ACCT.NO,Y.PORT.NO)

        CUST.ID = R.ACC<AC.CUSTOMER>
        CHARGE.CCY = Y.DR.CCY.CODE
        GOSUB INIT.ARRAY
        GOSUB FETCH.CHARGE.TYPE
        Y.CHARGE.TYPE.CNT = ''
        Y.CHARGE.TYPE.CNT = DCOUNT(Y.CHARGE.TYPE,VM)

        CNT.INT = '1'
        LOOP
        WHILE CNT.INT LE Y.CHARGE.TYPE.CNT
            
            CHARGE.TYPE = Y.CHARGE.TYPE<1,CNT.INT>
            CALL F.READ(FN.FT.COMMISSION.TYPE, CHARGE.TYPE,R.FT.COMM.TYPE, F.FT.COMMISSION.TYPE, ERR.FT.COMM.TYPE)
                                        
            IF NOT(ERR.FT.COMM.TYPE) THEN

                FROM.STD.PRICE = '1'
                GOSUB PROCESS.STD.PRICE

                GROUP.ID = 'P-':Y.PORT.NO
                FROM.STD.PRICE = ''
                FROM.DISCNT.PRICE = '1'
                GOSUB READ.GROUP.CONDITION
                FROM.DISCNT.PRICE = ''
                
            END
            
            CNT.INT+=1
        REPEAT

	GOSUB UPDATE.FEECAPTURE
    END

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = PROCESS.STD.PRICE>
PROCESS.STD.PRICE:
***<desc> Para to read CUSTOMER.CHARGE and calculate standard price </desc>

    CALL FIND.CHARGE.REC(CUST.ID,'',R.CUST.CHARGE)

    CUST.APPLS = R.CUST.CHARGE<EB.CCH.APPLICATION>
    CURR.APPLICATION = 'POR.TRANSACTION'

    LOCATE CURR.APPLICATION IN CUST.APPLS<1,1> SETTING APP.POS THEN

        GROUP.ID = R.CUST.CHARGE<EB.CCH.DEFAULT.GROUP,APP.POS>
        FROM.STD.PRICE = '1'
        GOSUB READ.GROUP.CONDITION

    END

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = READ.GROUP.CONDITION>
READ.GROUP.CONDITION:
***<desc> Para to read FT.GROUP.CONDITION </desc>

    CALL F.READ(FN.FT.GROUP.CONDITION, GROUP.ID, R.GRP.CONDITION, F.FT.GROUP.CONDITION, GRP.CON.ERR)

    Y.FT.COMM.TYPE = CHARGE.TYPE
    IF R.GRP.CONDITION<FT3.COMM.TYPE,1> EQ 'ALL' THEN
        CUST.CONDITION<C.PERCENT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PERCENT,1>
        GOSUB CALL.CALC.CHARGE
    END ELSE
        Y.FT.COMM.TYPE.VALS = R.GRP.CONDITION<FT3.COMM.TYPE>
        
        LOCATE Y.FT.COMM.TYPE IN Y.FT.COMM.TYPE.VALS<1,1> SETTING C.POS THEN
            GOSUB PROCESS.GEN.COND
            GOSUB CALL.CALC.CHARGE
        END
    END


RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = PROCESS.GEN.COND>
PROCESS.GEN.COND:
***<desc> Para to read PROCESS.GEN.COND </desc>

    Y.FT.COMM.CCY.VALS = R.GRP.CONDITION<FT3.COMM.CCY,C.POS>

    LOCATE CHARGE.CCY IN Y.FT.COMM.CCY.VALS<1,1,1> SETTING CCY.POS THEN

        CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT> = CHARGE.CCY
        COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,CCY.POS>
        IF COMM.F.AMT EQ '' THEN
            CUST.CONDITION<C.PERCENT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
            CUST.CONDITION<C.MIN.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.MAX.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.PREMIUM.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,CCY.POS>
            CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,CCY.POS>
        END ELSE
            CUST.CONDITION<C.AMOUNT,CNT.INT> = COMM.F.AMT
            CUST.CONDITION<C.CURRENCY,CNT.INT> = CHARGE.CCY
        END
        TRANS.CCY = '1'
    END ELSE
        LOCATE LCCY IN Y.FT.COMM.CCY.VALS<1,1,1> SETTING LCY.POS THEN
            CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT>= LCCY
            COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,LCY.POS>
            IF COMM.F.AMT EQ '' THEN
                CUST.CONDITION<C.PERCENT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
                CUST.CONDITION<C.MIN.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.MAX.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.PREMIUM.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,LCY.POS>
                CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,LCY.POS>
            END ELSE
                CUST.CONDITION<C.AMOUNT,CNT.INT> = COMM.F.AMT
                CUST.CONDITION<C.CURRENCY,CNT.INT> = LCCY
            END

        END ELSE
            PS.CCY = R.GRP.CONDITION<FT3.COMM.CCY,C.POS,1>
            CUST.CONDITION<C.MIN.MAX.CCY,CNT.INT> = PS.CCY
            COMM.F.AMT = R.GRP.CONDITION<FT3.COMM.F.AMT,C.POS,1>
            IF COMM.F.AMT EQ '' THEN
                CUST.CONDITION<C.PERCENT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PERCENT,C.POS>
                CUST.CONDITION<C.MIN.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MINIMUM.AMT,C.POS,1>
                CUST.CONDITION<C.MAX.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.MAXIMUM.AMT,C.POS,1>
                CUST.CONDITION<C.PREMIUM.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.PREMIUM.AMT,C.POS,1>
                CUST.CONDITION<C.DISCOUNT.AMT,CNT.INT> = R.GRP.CONDITION<FT3.COMM.DISCOUNT.AMT,C.POS,1>
            END ELSE
                CUST.CONDITION<C.AMOUNT,CNT.INT> = COMM.F.AMT
                CUST.CONDITION<C.CURRENCY,CNT.INT> = PS.CCY
            END

        END
    END

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = CALL.CALC.CHARGE>
CALL.CALC.CHARGE:
***<desc> Para to calculate commission / charge amount </desc>

    PASS.DATA<1,CNT.INT> = CHARGE.TYPE
    PASS.DATA<2,CNT.INT> = 'COM'
    INPUT.AMT = R.POR.TRANSACTION<PPPTX.DebitMainAmount>
    COMM.CCY = CHARGE.CCY
    GOSUB CAL.CCY.MKT
    Y.CROSS.RATE = ''
    Y.CROSS.CURRENCY = ''
    TOTAL.LOCAL.COMM.CHG = ''
    TOTAL.FOR.COMM.CHG = ''
    
        
    CALL CALCULATE.CHARGE(CUST.ID,INPUT.AMT,COMM.CCY,'1',Y.CROSS.RATE,Y.CROSS.CURRENCY,CHARGE.CCY,PASS.DATA,CUST.CONDITION,TOTAL.LOCAL.COMM.CHG,TOTAL.FOR.COMM.CHG)

    IF TRANS.CCY EQ '1' AND CHARGE.CCY NE LCCY THEN

        MARKET = BASE.CCY.MKT
        LAMT = TOTAL.LOCAL.COMM.CHG
        FCY = CHARGE.CCY
        CALL MIDDLE.RATE.CONV.CHECK(FAMT, FCY, RATE, MARKET, LAMT, DIF.AMT, DIF.RATE)
        TOTAL.FOR.COMM.CHG = FAMT
    END

    IF FROM.STD.PRICE EQ '1' THEN
        GOSUB UPDATE.STD.PRICE
    END

    IF FROM.DISCNT.PRICE EQ '1' THEN
        GOSUB UPDATE.DISCNT.PRICE
    END

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.STD.PRICE>
UPDATE.STD.PRICE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE with standard price </desc>

    STD.COMM.VALS = R.FEECAPTURE<FEE.STD.COMM.CODE>
    STD.COMM.VALS.CNT = DCOUNT(STD.COMM.VALS,SM)
    R.FEECAPTURE<FEE.STD.PRICE.LCY,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1> = TOTAL.LOCAL.COMM.CHG
    R.FEECAPTURE<FEE.STD.PRICE,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1> = TOTAL.FOR.COMM.CHG
    R.FEECAPTURE<FEE.STD.COMM.CODE,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1> = CHARGE.TYPE
    R.FEECAPTURE<FEE.STD.CURRENCY,PORTF.VALS.CNT,STD.COMM.VALS.CNT+1> = CHARGE.CCY
    
    GOSUB UPDATE.ACTUAL.PRICE
RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.DISCNT.PRICE>
UPDATE.DISCNT.PRICE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE with Discounted price </desc>


    DISCNT.COMM.VALS = R.FEECAPTURE<FEE.DISCNT.COMM.CODE>
    DISCNT.COMM.VALS.CNT = DCOUNT(DISCNT.COMM.VALS,SM)
    R.FEECAPTURE<FEE.DISCNT.PRICE.LCY,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = TOTAL.LOCAL.COMM.CHG
    R.FEECAPTURE<FEE.DISCNT.PRICE,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = TOTAL.FOR.COMM.CHG
    R.FEECAPTURE<FEE.DISCNT.COMM.CODE,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = CHARGE.TYPE
    R.FEECAPTURE<FEE.DISCNT.CURRENCY,PORTF.VALS.CNT,DISCNT.COMM.VALS.CNT+1> = CHARGE.CCY

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.ACTUAL.PRICE>
UPDATE.ACTUAL.PRICE:
***<desc> Updation of ACTUAL.PRICE with transaction's COMMISSION AMOUNT of each COMMISSION.TYPE </desc>

    ACT.COMM.VALS = R.FEECAPTURE<FEE.ACT.COMM.CODE>
    ACT.COMM.VALS.CNT = DCOUNT(ACT.COMM.VALS,SM)
    ACT.COMM.AMT = ''
    ACT.COMM.AMT = R.POR.POS.AND.CONF<PORPD.CHARGE.AMOUNT,CNT.INT>

    IF CHARGE.CCY NE LCCY THEN
        Y.RATE = ""
        Y.MARKET = "1"
        Y.LOC.AMT = ""
        Y.FCY = CHARGE.CCY
        Y.FORGN.AMT = ACT.COMM.AMT
        CALL MIDDLE.RATE.CONV.CHECK(Y.FORGN.AMT,Y.FCY,Y.RATE,Y.MARKET,Y.LOC.AMT,'','')
        LCY.ACT.COMM.AMT = Y.LOC.AMT
    END ELSE
        LCY.ACT.COMM.AMT = ACT.COMM.AMT
    END

    R.FEECAPTURE<FEE.ACT.PRICE,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1> = ACT.COMM.AMT
    R.FEECAPTURE<FEE.ACT.PRICE.LCY,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1> = LCY.ACT.COMM.AMT
    R.FEECAPTURE<FEE.ACT.COMM.CODE,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1> = CHARGE.TYPE
    R.FEECAPTURE<FEE.ACT.CURRENCY,PORTF.VALS.CNT,ACT.COMM.VALS.CNT+1> = CHARGE.CCY
    
RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = UPDATE.FEECAPTURE>
UPDATE.FEECAPTURE:
***<desc> Para to update JBWW.H.XX.FEECAPTURE </desc>

    R.FEECAPTURE<FEE.FEE.TYPE> = 'PAYMENT.ORDER'
    R.FEECAPTURE<FEE.PORTFOLIO,1> = Y.PORT.NO
    R.FEECAPTURE<FEE.BOOKING.DATE,1> = Y.BOOKING.DATE

    IF Y.STATUS.CODE EQ '999' THEN
        R.FEECAPTURE<FEE.TXN.STATUS> = 'LIVE'
    END

    IF Y.STATUS.CODE EQ '993' THEN
        R.FEECAPTURE<FEE.TXN.STATUS> = 'REVE'
    END

    CALL F.WRITE(FN.JBWW.H.XX.FEECAPTURE, Y.FT.NO, R.FEECAPTURE)

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = >
CAL.CCY.MKT:
***<desc> Para to find CCY.MKT </desc>

    BASE.CCY.MKT = '1'
    CALL FIND.CCY.MKT("PO" , "4" , "COMM.CHG" , CCY.MKT , BASE.CCY.MKT , RETURN.CODE , ERR.MSG)

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = FETCH.POR.TRANSACTION.FLDS>
FETCH.POR.TRANSACTION.FLDS:
***<desc> To Fetch POR.TRANSACTION field values </desc>
    
    Y.TXN.TYPE = R.POR.TRANSACTION<PPPTX.IncomingMessageType>
    Y.PYMT.DIR = R.POR.TRANSACTION<PPPTX.PaymentDirection>
    Y.CR.ACCT =  R.POR.TRANSACTION<PPPTX.CreditMainAccount>
    Y.DR.ACCT =  R.POR.TRANSACTION<PPPTX.DebitMainAccount>
    Y.CR.CCY.CODE = R.POR.TRANSACTION<PPPTX.CreditMainAccountCurrencyCode>
    Y.DR.CCY.CODE = R.POR.TRANSACTION<PPPTX.DebitMainAccountCurrencyCode>
    Y.PO.ID = R.POR.TRANSACTION<PPPTX.SendersReferenceIncoming>
    Y.DR.AMT = R.POR.TRANSACTION<PPPTX.DebitMainAmount>
    
RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = READ.ACCT>
READ.ACCT:
***<desc> To read ACCOUNT record </desc>
    
    CALL F.READ(FN.ACCOUNT, ACCT.NO, R.ACC, F.ACCOUNT, ACC.ERR)

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = FETCH.CHARGE.TYPE>
FETCH.CHARGE.TYPE:
***<desc> To Fetch charge type </desc>

    R.POR.POS.AND.CONF = '' ; ERR.POR.POST.CONF = ''
    CALL F.READ(FN.POR.POSTING.AND.CONFIRMATION, Y.FT.NO, R.POR.POS.AND.CONF, F.POR.POSTING.AND.CONFIRMATION, ERR.POR.POST.CONF)
    Y.CHARGE.TYPE = R.POR.POS.AND.CONF<PORPD.FEE.TYPE>
    Y.BOOKING.DATE = R.POR.POS.AND.CONF<PORPD.BOOKING.DATE>

RETURN
***</region>
*-----------------------------------------------------------------------------
***<region name = CALCUALTE.DATE>
*CALCULATE.DATE:
***<desc> Date Calculation </desc>

CURR.DATE = TODAY
COMI = CURR.DATE
CALL LAST.DAY.OF.THIS.QUAT
QUAT.DATE = COMI
CURR.DATE = QUAT.DATE
CALL CDT('',CURR.DATE,"-93C") ;* To get the previous quarter end
COMI = CURR.DATE
CALL LAST.DAY.OF.THIS.QUAT
ADJUST.DATE = COMI
    
CALL F.READ(FN.JBWW.H.XX.FEECAPTURE,Y.FT.NO,R.FEECAPTURE,F.JBWW.H.XX.FEECAPTURE,FEE.ERR)
    
BD.VAL = R.FEECAPTURE<FEE.BOOKING.DATE>
BD.VAL.CNT = DCOUNT(BD.VAL,VM)

REFUND.AMT = Y.DR.AMT
R.FEECAPTURE<FEE.BOOKING.DATE,BD.VAL.CNT+1> = TODAY
R.FEECAPTURE<FEE.ADJUSTMENT.DATE,BD.VAL.CNT+1> = ADJUST.DATE
R.FEECAPTURE<FEE.ADJUSTMENT.FLAG,BD.VAL.CNT+1> = 'Yes'
R.FEECAPTURE<FEE.ACT.PRICE,BD.VAL.CNT+1,1> = REFUND.AMT

RETURN

***</region>
*-----------------------------------------------------------------------------
*** <region name= EXPORT.TO.TRIP.API>
EXPORT.TO.TRIP.API:
*** <desc>To call the core API exportToTRIP in order to complete the Payment Order Process </desc>
    PP.TRIPService.exportToTRIP(iStatusAction) ;* To call the core API exportToTRIP in order to complete the Payment Order Process
RETURN
*** </region>
*-----------------------------------------------------------------------------

END

