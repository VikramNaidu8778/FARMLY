*-----------------------------------------------------------------------------
* <Rating>-24</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.H.FT.NOSTROINTEREST.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.FT.NOSTROINTEREST
    $INSERT I_F.CATEGORY
    $INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN

*-----------------------------------------------------------------------------------------
*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>
    LOOPCOUNT = ''
    FN.CATEGORY = 'F.CATEGORY'
    F.CATEGORY = ''
    CALL OPF(FN.CATEGORY, F.CATEGORY)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)


    RETURN
*** </region>
*-----------------------------------------------------------------------------------------

*** <region name= PROCESS>
PROCESS:
*** <desc>Validation process </desc>


 

    Y.PL.ACC = R.NEW(JB.NOSINT.L.FT.PL.ACC)
    Y.COUNT = DCOUNT(Y.PL.ACC,VM)
    LOOPCOUNT = '1'
    LOOP
    WHILE LOOPCOUNT LE Y.COUNT
        Y.ACC.ID = R.NEW(JB.NOSINT.L.FT.PL.ACC)<1,LOOPCOUNT>
        CALL F.READ (FN.CATEGORY,Y.ACC.ID,REC.CAT,F.CATEGORY,CAT.ERR)
        Y.CATEGORY = REC.CAT<EB.CAT.SYSTEM.IND>
        IF Y.CATEGORY NE 'PL' THEN
            AF = JB.NOSINT.L.FT.PL.ACC
            AV = JB.NOSINT.L.FT.PL.ACC
            ETEXT = "ST-MUST.BE.PL"
            CALL STORE.END.ERROR
            RETURN
        END

        Y.NOS.ACC = R.NEW(JB.NOSINT.L.FT.NOST.ACC)<1,LOOPCOUNT>
        CALL F.READ (FN.ACCOUNT,Y.NOS.ACC,REC.ACC,F.ACCOUNT,ACC.ERR)
        Y.ACC.CAT = REC.ACC<AC.CATEGORY> 
        IF Y.ACC.CAT LT '5000' OR Y.ACC.CAT GT '5999' THEN
            AF = JB.NOSINT.L.FT.NOST.ACC
            AV = JB.NOSINT.L.FT.NOST.ACC
            ETEXT = "EB-JBWW.D.FT.NOSTROACCT.CHK"
            CALL STORE.END.ERROR
            RETURN
        END ELSE
            R.NEW(JB.NOSINT.L.FT.CURRENCY)<1,LOOPCOUNT> = REC.ACC<AC.CURRENCY>

        END
        LOOPCOUNT = LOOPCOUNT+1
    REPEAT
    RETURN
*** </region>
*-----------------------------------------------------------------------------------------
    END
