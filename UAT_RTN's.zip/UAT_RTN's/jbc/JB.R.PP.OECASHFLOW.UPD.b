*-----------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.OECASHFLOW.UPD
*-----------------------------------------------------------------------------------
* Description:
* The purpose of the routine is to update the Payment amount in local table
* JB.L.PP.CASHFLOWDATA which will be used for Cash Flow Report.
* Input routine attached in version control PP.ORDER.ENTRY.
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------
* Date                Developer           Reference           Description
*-----------------------------------------------------------------------------------
* 19/11/2024         P Amala              CBPAY-65          Initial Version
* 12/05/2025         P Amala              CBPAY-2687        Fix to take CVD for incoming payment.
* 20/05/2025         P Amala              CBPAY-65          Fix to not update the local Cashflow table when positive response(pacs.004) received for camt.056.
* 17/06/2025         P Amala              CBPAY-65          Field mapping changed to fetch date and amount from processingDate and TransactionAmount for manual outgoing return pacs.004 payment.
*-----------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JB.L.PP.CASHFLOWDATA
    $INSERT I_F.JBWW.H.AC.NOSTCASHFLOW
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.POSTING.AND.CONFIRMATION
    $USING PP.TRIPService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentSTPFlowService
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentLifecycleHook
    $USING PP.StaticDataGUI
    $USING EB.SystemTables
    $USING EB.DataAccess
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*------------------------------------------------------------------------------

    GOSUB OPEN.FILES
    GOSUB PROCESS

RETURN

*------------------------------------------------------------------------------
OPEN.FILES:
**********
       
    FN.JB.L.PP.CASHFLOWDATA = 'F.JB.L.PP.CASHFLOWDATA'
    F.JB.L.PP.CASHFLOWDATA = ''
    CALL OPF(FN.JB.L.PP.CASHFLOWDATA,F.JB.L.PP.CASHFLOWDATA)
    
    FN.AC.NOSTROCASHFLOW = 'F.JBWW.H.AC.NOSTCASHFLOW'
    F.AC.NOSTROCASHFLOW = ''
    CALL OPF(FN.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW)
    
    R.AC.NOSTROCASHFLOW = '' ; ERR.AC.NOSTROCASHFLOW = ''
    NST.ACCT.TEMP = '' ; Y.PP.ID = '' ; R.PP.CASHFLOWDATA = ''
    Y.PP.EXCDATE = '' ; DB.ACCT.POS = '' ; CR.ACCT.POS = ''
    Y.CR.AC.NO = '' ; Y.DB.AC.NO = '' ; Y.PP.CSHFLW.ERR = ''
    Y.DELFLAG = '' ; Y.ORIG.TRANSID = '' ; R.POR.GET.SUPPLEMENTARY.INFO = ''
    FTNo = ''

    FN.POR.SUPPL.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    FV.POR.SUPPL.INFO = ''
    CALL OPF(FN.POR.SUPPL.INFO,FV.POR.SUPPL.INFO)

* Included logic to fetch TransactionAmount and Processing date for the outgoing return pyment(pacs.004)

	Y.OE.SOURCE = '' ; Y.OE.MSGTYPE = '' ; Y.RLC.SOURCE = ''
    Y.INMSG.TYPE = ''
	
    Y.FIELD.NAME = "INSOURCE.RLC":@FM:"RLC.RTNPAY"
    Y.FIELD.VALUE = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.FIELD.NAME,Y.FIELD.VALUE)

    Y.RLC.SOURCE = Y.FIELD.VALUE<1>
    Y.INMSG.TYPE = Y.FIELD.VALUE<2>

    CHANGE ',' TO @VM IN Y.RLC.SOURCE
    CHANGE @FM TO @VM IN Y.RLC.SOURCE
	
	CHANGE ',' TO @VM IN Y.INMSG.TYPE
    CHANGE @FM TO @VM IN Y.INMSG.TYPE
	
RETURN

*------------------------------------------------------------------------------
PROCESS:
********

    Y.CR.AC.NO = R.NEW(PP.OEYG.CreditAccountNumber)
    Y.DB.AC.NO = R.NEW(PP.OEYG.DebitAccountNumber)
    Y.PP.EXCDATE = R.NEW(PP.OEYG.CreditValueDate)
    Y.PP.ID = R.NEW(PP.OEYG.TransactionReferenceNumber)
    Y.ORIG.TRANSID = R.NEW(PP.OEYG.InstructionIdentification)
    Y.OE.SOURCE = R.NEW(PP.OEYG.Source)
    Y.OE.MSGTYPE = R.NEW(PP.OEYG.IncomingMessageType)

* Skip to update the local Cashflow table when positive response(pacs.004) received for camt.056.

    CALL F.READ(FN.POR.SUPPL.INFO,Y.ORIG.TRANSID,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
    IF R.POR.SUPPL.INFO.REC THEN
        Y.CANC.MSGREF = R.POR.SUPPL.INFO.REC<PORID.CANCEL.MSG.REFERENCE>
    
        IF Y.CANC.MSGREF[1,4] EQ 'FMQA' AND R.NEW(PP.OEYG.IncomingMessageType) EQ 'pacs.004' THEN
            RETURN
        END
    END
		
    CALL F.READ(FN.AC.NOSTROCASHFLOW,'SYSTEM',R.AC.NOSTROCASHFLOW,F.AC.NOSTROCASHFLOW,ERR.AC.NOSTROCASHFLOW)
    IF R.AC.NOSTROCASHFLOW NE '' THEN
        NST.ACCT.TEMP = R.AC.NOSTROCASHFLOW<JB.NOSACCT.CSHFLW.NOSTRO.ACCOUNT>
        CONVERT SM TO VM IN NST.ACCT.TEMP
        CONVERT VM TO FM IN NST.ACCT.TEMP
        Y.NST.CSHFLW.ACCT = '' ; Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
        GOSUB CHECK.DB.ACC
        GOSUB CHECK.CR.ACC
    END
RETURN


*------------------------------------------------------------------------------
CHECK.DB.ACC:
*************

    LOCATE Y.DB.AC.NO IN NST.ACCT.TEMP SETTING DB.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.DB.AC.NO
        Y.PP.AMT = R.NEW(PP.OEYG.DebitAmount)
		
* Included logic to fetch TransactionAmount and Processing date for the outgoing return pyment(pacs.004)

		IF (Y.OE.SOURCE MATCHES Y.RLC.SOURCE) AND (Y.OE.MSGTYPE MATCHES Y.INMSG.TYPE) AND (R.NEW(PP.OEYG.Direction) EQ 'O') THEN
            Y.PP.EXCDATE = R.NEW(PP.OEYG.ProcessingDate)
            Y.PP.AMT = R.NEW(PP.OEYG.TransactionAmount)
        END
        IF V$FUNCTION EQ 'D' THEN
            CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END ELSE
            CALL JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END
    END

RETURN

*------------------------------------------------------------------------------
CHECK.CR.ACC:
*************
    Y.NST.CSHFLW.ACCT = '' ; Y.PP.AMT = '' ; R.PP.CASHFLOWDATA = ''
    Y.DELFLAG = ''
    LOCATE Y.CR.AC.NO IN NST.ACCT.TEMP SETTING CR.ACCT.POS THEN
        Y.NST.CSHFLW.ACCT = Y.CR.AC.NO
        Y.PP.AMT = R.NEW(PP.OEYG.CreditAmount)
		
* Included logic to fetch TransactionAmount and Processing date for the outgoing return pyment(pacs.004)

		IF (Y.OE.SOURCE MATCHES Y.RLC.SOURCE) AND (Y.OE.MSGTYPE MATCHES Y.INMSG.TYPE) AND (R.NEW(PP.OEYG.Direction) EQ 'O') THEN
            Y.PP.EXCDATE = R.NEW(PP.OEYG.ProcessingDate)
            Y.PP.AMT = R.NEW(PP.OEYG.TransactionAmount)
        END
        Y.PP.AMT = Y.PP.AMT*(-1)
        IF V$FUNCTION EQ 'D' THEN
            CALL JB.R.PP.CASHFLOWTABLE.DEL(FTNo,Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END ELSE
            CALL JB.R.PP.CASHFLOWTABLE.UPD(Y.NST.CSHFLW.ACCT,Y.PP.ID,Y.PP.EXCDATE,Y.PP.AMT)
        END
    END

RETURN

*------------------------------------------------------------------------------
END
