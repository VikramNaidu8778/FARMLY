*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.SENDTORECEV.INPUT
*-----------------------------------------------------------------------------
*This routine is used to default the SEND.TO.PARTY fields as "CRCUST".
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.FUNDS.TRANSFER

*-----------------------------------------------------------------------------
    
	 Y.BK.TO.BK.OUT = R.NEW(FT.BK.TO.BK.OUT)
	 
	 IF Y.BK.TO.BK.OUT THEN
	 
	   R.NEW(FT.SEND.TO.PARTY) = "CRCUST"
	   
	 END
	
RETURN

END
