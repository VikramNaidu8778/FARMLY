*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.MSGPRIORITY.DEFAULT
*-----------------------------------------------------------------------------
* This subroutine is attached as inout routine to the below list of screens
* PAYMENT.ORDER,JB.V.PP.CALPAY.INP
* This is to default the MESSAGE.PRIORITY to 2, when user update the BO Remarks field
* This will move the payment to Non-STP based on the configurations in PP.HEAVYWEIGHTPRODUCTCOND table
* Refer the relevant records of payment order product OTRT in PP.HEAVYWEIGHTPRODUCTCOND table
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 27-May-2024 xxx                CBPAY-55          Initial Version.
*
*-----------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
*
    LRF.APPLNS = 'PAYMENT.ORDER'
    LRF.FLDS = 'L.FT.BO.REMARK'
    LRF.POS = ''
    CALL MULTI.GET.LOC.REF(LRF.APPLNS,LRF.FLDS,LRF.POS)
    BO.REMARKS.POS = LRF.POS<1,1>

    IF R.NEW(PO.LOCAL.REF)<1,BO.REMARKS.POS> NE "" THEN
        R.NEW(PO.MESSAGE.PRIORITY) = "2"
    END
*
RETURN
*
END
*
