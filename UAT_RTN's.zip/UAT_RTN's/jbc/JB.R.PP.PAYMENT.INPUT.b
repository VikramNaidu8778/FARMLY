SUBROUTINE JB.R.PP.PAYMENT.INPUT
*-----------------------------------------------------------------------------
*This routine is added as input routine in PAYMENT.ORDER version control, if the Txn Amount exceeds more that (>CHF100K) then raise Override message.
*-----------------------------------------------------------------------------
* Modification History :
* Date              Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
* 01-APR-2024       Vikram Pavuluru            CBPAY-19        JBWW.R.FT.PAYMENT.INPUT -This routine is used to raise override
*                                                                   when cross currency payment more than (>CHF100K)
* 30-SEP-2024       Lakshmi Priya              CBPAY-1007       Logic changed to consider Buy Ccy as Payment Currency when
*                                                              Debit Currency is Local Currency
* 19-Apr-2025       Kandan                     CBPAY-2512       Added additional check for OT Types of Payment.
*
* 28-MAR-2025       Prabhu D S                 CBPAY-2313       Beneficiary Name length to restrict 140 characters as per ISO format
* 20-MAY-2025       Prabhu D S                 CBPAY-2313       Bank To Bank Info length to restrict 35 characters as per ISO format
* 28-MAY-2025       u40616                     CBPAY-2989       If PAYMENT.ORDER.PRODUCT is "OT03" and L.PP.SEND.PYMT is NO and REMITTANCE.INFORMATION
*                                                               contains SGD/HKD and get the 16 digit ID and defult to L.PP.ORIG.REF
* 06-06-2025        u40616                     CBPAY-2288       User will provide the BANK.TO.BANK.INFO
*                                                                in local field L.PO.B2B.INFO and Routine will default
*                                                                back to BANK.TO.BANK.INFO field in PAYMENT.ORDER
*-------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.POR.TRANSACTION
     
    GOSUB INIT
    GOSUB PROCESS

RETURN
*------------------------------------------------------------------
INIT:
*****
    Y.DR.AMT = ''
    Y.CR.AMT = ''
    Y.DR.CCY = ''
    Y.CR.CCY = ''
    Y.TXN.LOC.AMT = ''
    Y.CURR.NO = R.NEW(PO.CURR.NO)
    FN.CURRENCY = 'F.CURRENCY'
    F.CURRENCY = ''
    CALL OPF(FN.CURRENCY,F.CURRENCY)
    Y.VLDT.CHKD.POS = ''
    Y.LFT.VLDT.CHKD = '' ; Y.ORIG.POS = '' ; Y.SND.PYMT.POS = ''
    Y.APP = 'PAYMENT.ORDER'
    Y.LOCFIELD = 'L.FT.VALDT.CHKD':VM:'L.PP.ORIG.REF':VM:'L.PP.SEND.PYMT':VM:'L.PO.B2B.INFO'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.VLDT.CHKD.POS =  Y.LOCPOS<1,1>
    Y.ORIG.POS = Y.LOCPOS<1,2>
    Y.SND.PYMT.POS = Y.LOCPOS<1,3>
    Y.B2B.INFO.POS = Y.LOCPOS<1,4>
    
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    CALL OPF(FN.POR.TRANSACTION, F.POR.TRANSACTION)

RETURN
*----------------------------------------------------------------
PROCESS:
********
    BEGIN CASE
        CASE V$FUNCTION EQ 'I'
            GOSUB RESTRICT.FIELD.LENGTH
            GOSUB RAISE.CHK100K.OVERRIDE
            GOSUB DEFAULT.ORIG.REF
        CASE V$FUNCTION EQ 'R'
            GOSUB CLEAR.VLDT.CHECKER.FLAG
    END CASE
 
RETURN
*
*----------------------------------------------------------------
RAISE.CHK100K.OVERRIDE:
***********************
    Y.CURR.NO = Y.CURR.NO + 1
    Y.BUY.CCY = R.NEW(PO.DEBIT.CCY)
    Y.CREDIT.CCY = R.NEW(PO.CREDIT.CURRENCY)
    Y.PYMT.CCY = R.NEW(PO.PAYMENT.CURRENCY)
*CBPAY-2512 Changes
    IF (Y.BUY.CCY EQ Y.CREDIT.CCY) OR (Y.BUY.CCY EQ Y.PYMT.CCY ) THEN RETURN
    Y.BUY.AMT = R.NEW(PO.DEBIT.AMOUNT)

    Y.PARAM.ID = 'JB.D.PP.CROSSCCY.LIMIT'
    PARAM.FIELD = 'CROSSCURRENCYLIMIT'
    PARAM.VALUES = ''
 
    CALL JBWW.R.EB.GETGENPARM.VAL(Y.PARAM.ID,PARAM.FIELD,PARAM.VALUES)
    CCY.LIMIT = PARAM.VALUES<1>
    Y.TXN.LOC.AMT = ''  ; Y.BUY.CCY = '' ;
    Y.BUY.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    Y.BUY.AMT = R.NEW(PO.PAYMENT.AMOUNT)
    GOSUB GET.EXCHRATE
    IF Y.TXN.LOC.AMT GE CCY.LIMIT THEN
        TEXT = 'FT-JBWW.AMT.EXCEEDS.LIMIT'

        CALL STORE.OVERRIDE(Y.CURR.NO)
    END

RETURN
*------------------------------------------------------

CLEAR.VLDT.CHECKER.FLAG:
************************
* Clear the VD Checker flag for FT which already processed on VD queue to move FT again to Auth Queue if any.
    Y.LFT.VLDT.CHKD = R.NEW(FT.LOCAL.REF)<1,Y.VLDT.CHKD.POS>
    IF Y.LFT.VLDT.CHKD EQ 'CHECKER' THEN
        R.NEW(FT.LOCAL.REF)<1,Y.VLDT.CHKD.POS> = ''
    END
    
RETURN
*------------------------------------------------------
GET.EXCHRATE:
*************
    CCY.MKT = '1'
    BUY.CCY = Y.BUY.CCY
    BUY.AMT = Y.BUY.AMT
    SELL.CCY = LCCY
    SELL.AMT = ''
    BASE.CCY = ''
    EXCHANGE.RATE = ''
    DIFFERENCE = ''
    LCY.AMT = ''
    RETURN.CODE = ''
    CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)
    Y.TXN.LOC.AMT = LCY.AMT
    
RETURN
*------------------------------------------------------------------
RESTRICT.FIELD.LENGTH:
**********************

    IF LEN(R.NEW(PO.BENEFICIARY.NAME)) GT 140 THEN
        AF = PO.BENEFICIARY.NAME
        ETEXT = "PI-JB.D.XX.FLDLEN.EXCEEDS.MAX":FM:"140"
        CALL STORE.END.ERROR
    END
    
RETURN
*------------------------------------------------------------------
DEFAULT.ORIG.REF:
*----------------
    Y.REMIT.INFO = '' ; Y.VAL = '' ; Y.ORIG = '' ; Y.ORIG.VAL = ''
    IF R.NEW(PO.PAYMENT.ORDER.PRODUCT) EQ 'OT03' AND R.NEW(PO.LOCAL.REF)<1,Y.SND.PYMT.POS> EQ 'NO' THEN
        Y.REMIT.INFO = R.NEW(PO.REMITTANCE.INFORMATION)
                
        IF ID.COMPANY[1,2] EQ 'SG' THEN
            Y.VAL = 'SGD':TODAY[3,2]
            Y.ORIG = INDEX(Y.REMIT.INFO, Y.VAL,1)
            Y.ORIG.VAL = Y.REMIT.INFO[Y.ORIG,16]
            GOSUB READ.POS.TRANS
            IF R.POS.TRANS NE '' THEN
                R.NEW(PO.LOCAL.REF)<1,Y.ORIG.POS> = Y.ORIG.VAL
            END
        END
        
        IF ID.COMPANY[1,2] EQ 'HK' THEN
            Y.VAL = 'HKD':TODAY[3,2]
            Y.ORIG = INDEX(Y.REMIT.INFO, Y.VAL,1)
            Y.ORIG.VAL = Y.REMIT.INFO[Y.ORIG,16]
            GOSUB READ.POS.TRANS
            IF R.POS.TRANS NE '' THEN
                R.NEW(PO.LOCAL.REF)<1,Y.ORIG.POS> = Y.ORIG.VAL
            END
        END
    END
RETURN
*------------------------------------------------------------------
READ.POS.TRANS:
*--------------

    R.POS.TRANS = '' ; YERR.POS = ''
    CALL F.READ(FN.POR.TRANSACTION, Y.ORIG.VAL, R.POS.TRANS, F.POR.TRANSACTION, YERR.POS)
    
RETURN
END
