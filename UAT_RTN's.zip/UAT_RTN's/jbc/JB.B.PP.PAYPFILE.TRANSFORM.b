*-----------------------------------------------------------------------------
SUBROUTINE JB.B.PP.PAYPFILE.TRANSFORM
*-----------------------------------------------------------------------------
* This is the single threaded job to transform
* the file Payment Portal File Format (extract of SQL table CID_MASTER in Payment Portal system)
* to T24 DFE Upload File Format (Records seperated by FM & Values seperated by | symbol)
* Source File Name - "paymentsData.csv" from the path "/u01/data/share/awa/BNK/BIC"
* Target File Name - "SGD_stoCid.csv" & "HKD_stoCid.csv"
* Booking Centre (BC) identification based on first digit of STANDING.ORDER reference
* 2 means SG Booking Centre
* 3 means HK Booking Centre
*
* Attached to the BATCH>BNK/JB.D.PP.PAYPFILE.TRANSFORM
*
* Source File Format
* "MESSAGE_TYPE","TAG_NAME","TAG_VALUE","TRANSACTION_REF_NUM"
* "OT03","50K#1","ORDFIRST NAME","6020000000001095.19"
* "OT03","50K#2","ORDLAST NAME","6020000000001095.19"
* "OT03","50K#3","SINGAPORE 007792","6020000000001095.19"
*
* Target File Format
* 6020000000001095.19|OT03|ORDFIRST NAME|ORDLAST NAME|SINGAPORE 007792|ORDDUMMY|123456|BENFIRST NAME|BENDUMMY1|BENDUMMY2|PAYDETS1|PAYDETS2|PAYDETS3|PAYDETS4|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP
* 6020000000001095.20|OT03|ORDFIRST NAME|ORDLAST NAME|SINGAPORE 007792|ORDDUMMY|123456|BENFIRST NAME|BENDUMMY1|BENDUMMY2|PAYDETS1|PAYDETS2|PAYDETS3|PAYDETS4|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP|/INS/BNPAFRPP
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          who          Reference          Description
*
* 12-Jun-2025   u40786       CBPAY-xxx          Initial Version
*
*-----------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE

    SESSION.ID = C$T24.SESSION.NO

    STO.REF.LIST = ''
    STO.REF.SG.LIST = ''
    STO.REF.HK.LIST = ''

    SRC.FILE.PATH = '/u01/data/share/awa/BNK/BIC'
    SRC.FILE.NAME = 'paymentsData.csv'
    OPENSEQ SRC.FILE.PATH,SRC.FILE.NAME TO SRC.FILE.PTR ELSE CREATE SRC.FILE.PTR ELSE RETURN
    CALL OCOMO('Open on the TPH STO MIG Source csv File - ':SESSION.ID)

    TGT.SG.FILE.PATH = '/u01/data/share/awa/BNK/BIC'
    TGT.SG.FILE.NAME = 'SGD_stoCid.csv'
    OPENSEQ TGT.SG.FILE.PATH,TGT.SG.FILE.NAME TO TGT.SG.FILE.PTR ELSE CREATE TGT.SG.FILE.PTR ELSE RETURN
    CALL OCOMO('Open on the TPH STO MIG Target csv File - ':SESSION.ID)

    TGT.HK.FILE.PATH = '/u01/data/share/awa/BNK/BIC'
    TGT.HK.FILE.NAME = 'HKD_stoCid.csv'
    OPENSEQ TGT.HK.FILE.PATH,TGT.HK.FILE.NAME TO TGT.HK.FILE.PTR ELSE CREATE TGT.HK.FILE.PTR ELSE RETURN
    CALL OCOMO('Open on the TPH STO MIG Target csv File - ':SESSION.ID)
            
    CRLF = CHAR(13):CHAR(10)
    READSEQ HEADER.LINE FROM SRC.FILE.PTR ELSE
        CALL OCOMO('Read on the TPH STO MIG Source csv File is Failed - ':SESSION.ID)
    END

    CNT.SG = 0
    CNT.HK = 0
    
    LOOP
        READSEQ REC.LINE FROM SRC.FILE.PTR ELSE NULL

    WHILE REC.LINE
            
        GOSUB GET.VALUES
        BEGIN CASE
            CASE STO.REF[1,1] EQ '2'
* For SG BC
                GOSUB PROCESS.SG
            CASE STO.REF[1,1] EQ '3'
* For HK BC
                GOSUB PROCESS.HK
        END CASE
    REPEAT

    CHANGE VM TO '|' IN STO.REC.SG
*    CHANGE FM TO CRLF IN STO.REC.SG
        
    CHANGE VM TO '|' IN STO.REC.HK
*    CHANGE FM TO CRLF IN STO.REC.HK
    
    WRITESEQ STO.REC.SG APPEND TO TGT.SG.FILE.PTR ELSE RETURN
    WRITESEQ STO.REC.HK APPEND TO TGT.HK.FILE.PTR ELSE RETURN
    CALL OCOMO('Write on the TPH STO MIG Target csv File - ':SESSION.ID)
    
    CLOSESEQ TGT.SG.FILE.PTR
    CLOSESEQ TGT.HK.FILE.PTR
    CLOSESEQ SRC.FILE.PTR
*
RETURN
*
***********
GET.VALUES:
***********

    STO.REF = FIELD(REC.LINE,'|',4)
    STO.REF = TRIM(STO.REF,'"','B')

    TAG.NAME = FIELD(REC.LINE,'|',2)
    TAG.NAME = TRIM(TAG.NAME,'"','B')

    TAG.VALUE = FIELD(REC.LINE,'|',3)
    TAG.VALUE = TRIM(TAG.VALUE,'"','B')
            
    TXN.TYPE = FIELD(REC.LINE,'|',1)
    TXN.TYPE = TRIM(TXN.TYPE,'"','B')
*
RETURN
*
***********
PROCESS.SG:
***********

    LOCATE STO.REF IN STO.REF.SG.LIST<1> SETTING STO.REF.SG.POS THEN
* Update
        GOSUB UPDATE.TAG.SG.1
    END ELSE
        CNT.SG = CNT.SG + 1
        STO.REF.SG.LIST<-1> = STO.REF
* New
        STO.REC.SG<CNT.SG,1> = STO.REF
        STO.REC.SG<CNT.SG,2> = TXN.TYPE
        GOSUB UPDATE.TAG.SG.2
    END
*
RETURN
*
***********
PROCESS.HK:
***********

    LOCATE STO.REF IN STO.REF.HK.LIST<1> SETTING STO.REF.HK.POS THEN
* Update
        GOSUB UPDATE.TAG.HK.1
    END ELSE
        CNT.HK = CNT.HK + 1
        STO.REF.HK.LIST<-1> = STO.REF
* New
        STO.REC.HK<CNT.HK,1> = STO.REF
        STO.REC.HK<CNT.HK,2> = TXN.TYPE
        GOSUB UPDATE.TAG.HK.2
    END
*
RETURN
*
*************
UPDATE.TAG.SG.1:
*************

    BEGIN CASE
* Tag 50K
        CASE TAG.NAME EQ '50K#1'
            STO.REC.SG<STO.REF.SG.POS,3> = TAG.VALUE
        CASE TAG.NAME EQ '50K#2'
            STO.REC.SG<STO.REF.SG.POS,4> = TAG.VALUE
        CASE TAG.NAME EQ '50K#3'
            STO.REC.SG<STO.REF.SG.POS,5> = TAG.VALUE
        CASE TAG.NAME EQ '50K#4'
            STO.REC.SG<STO.REF.SG.POS,6> = TAG.VALUE
* Tag 59
        CASE TAG.NAME EQ '59#1'
            STO.REC.SG<STO.REF.SG.POS,7> = TAG.VALUE
        CASE TAG.NAME EQ '59#2'
            STO.REC.SG<STO.REF.SG.POS,8> = TAG.VALUE
        CASE TAG.NAME EQ '59#3'
            STO.REC.SG<STO.REF.SG.POS,9> = TAG.VALUE
        CASE TAG.NAME EQ '59#4'
            STO.REC.SG<STO.REF.SG.POS,10> = TAG.VALUE
        CASE TAG.NAME EQ '59#5'
            STO.REC.SG<STO.REF.SG.POS,11> = TAG.VALUE
* Tag 70
        CASE TAG.NAME EQ '70#1'
            STO.REC.SG<STO.REF.SG.POS,12> = TAG.VALUE
        CASE TAG.NAME EQ '70#2'
            STO.REC.SG<STO.REF.SG.POS,13> = TAG.VALUE
        CASE TAG.NAME EQ '70#3'
            STO.REC.SG<STO.REF.SG.POS,14> = TAG.VALUE
        CASE TAG.NAME EQ '70#4'
            STO.REC.SG<STO.REF.SG.POS,15> = TAG.VALUE
* Tag 72
        CASE TAG.NAME EQ '72#1'
            STO.REC.SG<STO.REF.SG.POS,16> = TAG.VALUE
        CASE TAG.NAME EQ '72#2'
            STO.REC.SG<STO.REF.SG.POS,17> = TAG.VALUE
        CASE TAG.NAME EQ '72#3'
            STO.REC.SG<STO.REF.SG.POS,18> = TAG.VALUE
        CASE TAG.NAME EQ '72#4'
            STO.REC.SG<STO.REF.SG.POS,19> = TAG.VALUE
        CASE TAG.NAME EQ '72#5'
            STO.REC.SG<STO.REF.SG.POS,20> = TAG.VALUE
        CASE TAG.NAME EQ '72#6'
            STO.REC.SG<STO.REF.SG.POS,21> = TAG.VALUE
    END CASE
*
RETURN
*
*************
UPDATE.TAG.SG.2:
*************

    BEGIN CASE
* Tag 50K
        CASE TAG.NAME EQ '50K#1'
            STO.REC.SG<CNT.SG,3> = TAG.VALUE
        CASE TAG.NAME EQ '50K#2'
            STO.REC.SG<CNT.SG,4> = TAG.VALUE
        CASE TAG.NAME EQ '50K#3'
            STO.REC.SG<CNT.SG,5> = TAG.VALUE
        CASE TAG.NAME EQ '50K#4'
            STO.REC.SG<CNT.SG,6> = TAG.VALUE
* Tag 59
        CASE TAG.NAME EQ '59#1'
            STO.REC.SG<CNT.SG,7> = TAG.VALUE
        CASE TAG.NAME EQ '59#2'
            STO.REC.SG<CNT.SG,8> = TAG.VALUE
        CASE TAG.NAME EQ '59#3'
            STO.REC.SG<CNT.SG,9> = TAG.VALUE
        CASE TAG.NAME EQ '59#4'
            STO.REC.SG<CNT.SG,10> = TAG.VALUE
        CASE TAG.NAME EQ '59#5'
            STO.REC.SG<CNT.SG,11> = TAG.VALUE
* Tag 70
        CASE TAG.NAME EQ '70#1'
            STO.REC.SG<CNT.SG,12> = TAG.VALUE
        CASE TAG.NAME EQ '70#2'
            STO.REC.SG<CNT.SG,13> = TAG.VALUE
        CASE TAG.NAME EQ '70#3'
            STO.REC.SG<CNT.SG,14> = TAG.VALUE
        CASE TAG.NAME EQ '70#4'
            STO.REC.SG<CNT.SG,15> = TAG.VALUE
* Tag 72
        CASE TAG.NAME EQ '72#1'
            STO.REC.SG<CNT.SG,16> = TAG.VALUE
        CASE TAG.NAME EQ '72#2'
            STO.REC.SG<CNT.SG,17> = TAG.VALUE
        CASE TAG.NAME EQ '72#3'
            STO.REC.SG<CNT.SG,18> = TAG.VALUE
        CASE TAG.NAME EQ '72#4'
            STO.REC.SG<CNT.SG,19> = TAG.VALUE
        CASE TAG.NAME EQ '72#5'
            STO.REC.SG<CNT.SG,20> = TAG.VALUE
        CASE TAG.NAME EQ '72#6'
            STO.REC.SG<CNT.SG,21> = TAG.VALUE
    END CASE
*
RETURN
*
*************
UPDATE.TAG.HK.1:
*************

    BEGIN CASE
* Tag 50K
        CASE TAG.NAME EQ '50K#1'
            STO.REC.HK<STO.REF.HK.POS,3> = TAG.VALUE
        CASE TAG.NAME EQ '50K#2'
            STO.REC.HK<STO.REF.HK.POS,4> = TAG.VALUE
        CASE TAG.NAME EQ '50K#3'
            STO.REC.HK<STO.REF.HK.POS,5> = TAG.VALUE
        CASE TAG.NAME EQ '50K#4'
            STO.REC.HK<STO.REF.HK.POS,6> = TAG.VALUE
* Tag 59
        CASE TAG.NAME EQ '59#1'
            STO.REC.HK<STO.REF.HK.POS,7> = TAG.VALUE
        CASE TAG.NAME EQ '59#2'
            STO.REC.HK<STO.REF.HK.POS,8> = TAG.VALUE
        CASE TAG.NAME EQ '59#3'
            STO.REC.HK<STO.REF.HK.POS,9> = TAG.VALUE
        CASE TAG.NAME EQ '59#4'
            STO.REC.HK<STO.REF.HK.POS,10> = TAG.VALUE
        CASE TAG.NAME EQ '59#5'
            STO.REC.HK<STO.REF.HK.POS,11> = TAG.VALUE
* Tag 70
        CASE TAG.NAME EQ '70#1'
            STO.REC.HK<STO.REF.HK.POS,12> = TAG.VALUE
        CASE TAG.NAME EQ '70#2'
            STO.REC.HK<STO.REF.HK.POS,13> = TAG.VALUE
        CASE TAG.NAME EQ '70#3'
            STO.REC.HK<STO.REF.HK.POS,14> = TAG.VALUE
        CASE TAG.NAME EQ '70#4'
            STO.REC.HK<STO.REF.HK.POS,15> = TAG.VALUE
* Tag 72
        CASE TAG.NAME EQ '72#1'
            STO.REC.HK<STO.REF.HK.POS,16> = TAG.VALUE
        CASE TAG.NAME EQ '72#2'
            STO.REC.HK<STO.REF.HK.POS,17> = TAG.VALUE
        CASE TAG.NAME EQ '72#3'
            STO.REC.HK<STO.REF.HK.POS,18> = TAG.VALUE
        CASE TAG.NAME EQ '72#4'
            STO.REC.HK<STO.REF.HK.POS,19> = TAG.VALUE
        CASE TAG.NAME EQ '72#5'
            STO.REC.HK<STO.REF.HK.POS,20> = TAG.VALUE
        CASE TAG.NAME EQ '72#6'
            STO.REC.HK<STO.REF.HK.POS,21> = TAG.VALUE
    END CASE
*
RETURN
*
*************
UPDATE.TAG.HK.2:
*************

    BEGIN CASE
* Tag 50K
        CASE TAG.NAME EQ '50K#1'
            STO.REC.HK<CNT.HK,3> = TAG.VALUE
        CASE TAG.NAME EQ '50K#2'
            STO.REC.HK<CNT.HK,4> = TAG.VALUE
        CASE TAG.NAME EQ '50K#3'
            STO.REC.HK<CNT.HK,5> = TAG.VALUE
        CASE TAG.NAME EQ '50K#4'
            STO.REC.HK<CNT.HK,6> = TAG.VALUE
* Tag 59
        CASE TAG.NAME EQ '59#1'
            STO.REC.HK<CNT.HK,7> = TAG.VALUE
        CASE TAG.NAME EQ '59#2'
            STO.REC.HK<CNT.HK,8> = TAG.VALUE
        CASE TAG.NAME EQ '59#3'
            STO.REC.HK<CNT.HK,9> = TAG.VALUE
        CASE TAG.NAME EQ '59#4'
            STO.REC.HK<CNT.HK,10> = TAG.VALUE
        CASE TAG.NAME EQ '59#5'
            STO.REC.HK<CNT.HK,11> =TAG.VALUE
* Tag 70
        CASE TAG.NAME EQ '70#1'
            STO.REC.HK<CNT.HK,12> = TAG.VALUE
        CASE TAG.NAME EQ '70#2'
            STO.REC.HK<CNT.HK,13> = TAG.VALUE
        CASE TAG.NAME EQ '70#3'
            STO.REC.HK<CNT.HK,14> = TAG.VALUE
        CASE TAG.NAME EQ '70#4'
            STO.REC.HK<CNT.HK,15> = TAG.VALUE
* Tag 72
        CASE TAG.NAME EQ '72#1'
            STO.REC.HK<CNT.HK,16> = TAG.VALUE
        CASE TAG.NAME EQ '72#2'
            STO.REC.HK<CNT.HK,17> = TAG.VALUE
        CASE TAG.NAME EQ '72#3'
            STO.REC.HK<CNT.HK,18> = TAG.VALUE
        CASE TAG.NAME EQ '72#4'
            STO.REC.HK<CNT.HK,19> = TAG.VALUE
        CASE TAG.NAME EQ '72#5'
            STO.REC.HK<CNT.HK,20> = TAG.VALUE
        CASE TAG.NAME EQ '72#6'
            STO.REC.HK<CNT.HK,21> = TAG.VALUE
    END CASE
*
RETURN
*
END
