SUBROUTINE JBWW.R.FT.EDGEINPURL.CONV
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is the conversion routine attached with enquiries which will give input link to edge screens
* for dynamic EDGE url creation.
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
*
* Dependencies:
*---------------
*
* Revision History:
*------------------
* Date               who                    Reference                     Description
* 24-08-2016       Sahil Ghai                Payments                 Initial Version
***********************************************************************************


    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER


    GOSUB INIT
    GOSUB PROCESS
    RETURN

INIT:
******

    Y.FT.ID = O.DATA
    ENQR.NAME = ENQ.SELECTION<1>
	Y.COMP = ID.COMPANY
	
    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
	
	
    RETURN
*************************************************
PROCESS:
********

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'PAYMENT.EDGE.URL',R.GEN.PAR,F.JBWW.H.EB.GENERICPARAMETER,PAR.ERR)
    Y.GENPAR.NAME = R.GEN.PAR<JBWW.GEN.PAR.FIELD.NAME>
    Y.GENPAR.VALUE = R.GEN.PAR<JBWW.GEN.PAR.FIELD.VALUE>

    ENQ.POS = ''
    LOCATE ENQR.NAME IN Y.GENPAR.NAME<1,1> SETTING ENQ.POS THEN
    Y.KEY = Y.GENPAR.VALUE<1,ENQ.POS>
    END

    IP.POS = ''
    LOCATE "IP.PORT" IN Y.GENPAR.NAME<1,1> SETTING IP.POS THEN
    Y.IP = Y.GENPAR.VALUE<1,IP.POS>
    END

    SERVICE.POS = ''
    LOCATE "SERVICE.LINK" IN Y.GENPAR.NAME<1,1> SETTING SERVICE.POS THEN
    Y.SERVICE = Y.GENPAR.VALUE<1,SERVICE.POS>
    END
	
	Y.FLAG = 'Flag=1&'
	Y.MENU = 'MnuTyp=':Y.KEY:'&'
	Y.CO.CODE = 'CoCode=':Y.COMP
	
    Y.FINAL.URL = Y.IP:Y.SERVICE:Y.FLAG:Y.MENU:Y.CO.CODE

    O.DATA = Y.FINAL.URL

    RETURN
****************************************************

    END
