SUBROUTINE JB.R.PP.DATESCALC.INPUT
*-----------------------------------------------------------------------------
* This routine attached as Input Routine for PAYMNET.ORDER application at VERSION.CONTROL level
* This is to do the 2 following activities
* 1) To calculate the PED = RCVD - 2W (based on payment currency holiday). This is applicable only for Non-STO transactions
* 2) To raise the override message when the calculated CVD (considering the settlement shift defined in PP.CHANNEL.CUTOFF & PED)
*    is different from the user input RCVD. This is applicable only when the SEND.PAYMENT set to YES and for Non-STO transactions
* Caveat - As agreed with payment Ops users - Cut-off will not considered.
* It will be defined in PP.CHANNEL.CUTOFF with maximum time as 18:59 Server Zurich Time
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 01-Mar-2025 u40786             CBPAY-1617        Initial Version
*
* 03-Jun-2025 u40786             CBPAY-1617        Message Priority value not available in PAYMENT.ORDER R.NEW record.
*                                                  Hence hard-coded as 1, aligning the functional configurations
*                                                  in PP.CHANNEL.CUTOFF table.
*
* 11-Jun-2025 Prabhu D S         CBPAY-3238        Requirement extended to OTSA
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $USING PP.RoutingAndSettlementService

    IF V$FUNCTION EQ 'I' AND R.NEW(PO.PAYMENT.ORDER.PRODUCT) MATCHES 'OT03':@VM:'OT12':@VM:'OTSA' THEN
* This process applicable only for OT03 & OT12 payments
        GOSUB INIT
        GOSUB PROCESS
    END
*
RETURN
*
*****
INIT:
*****
 
    APPL = 'PAYMENT.ORDER'
    Y.LOC.FLD.NAMES = 'L.PP.SEND.PYMT'
    Y.LOC.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,Y.LOC.FLD.NAMES,Y.LOC.FLD.POS)
    Y.PO.FLD.POS = Y.LOC.FLD.POS<1,1>

    Y.SEND.PYMT = R.NEW(PO.LOCAL.REF)<1,Y.PO.FLD.POS>
    
    ORIG.SOURCE  = R.NEW(PO.ORDER.INITIATION.TYPE)
    TXN.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    RCVD = R.NEW(PO.REQUIRED.CREDIT.VALUE.DATE)
    
    GOSUB GET.CHANNEL.CUTOFF.DETS
*
RETURN
*
********
PROCESS:
********

    IF ORIG.SOURCE NE 'STO' AND ORIG.SOURCE NE 'STOMXCHATS' THEN
        GOSUB CALC.PD
    END
    IF RCVD AND ORIG.SOURCE NE 'STO' AND ORIG.SOURCE NE 'STOMXCHATS' AND Y.SEND.PYMT NE 'NO' THEN
        GOSUB CALC.CVD
        IF CVD NE RCVD THEN
            GOSUB RAISE.WARNING.MSG
        END
    END
*
RETURN
*
********
CALC.PD:
********
    
* Calculate the Processing Date by reducing 2W from RCVD
* If calculated date is less than TODAY, reset to TODAY

    Y.REGION = TXN.CCY[1,2]:'00'
    Y.DATE = RCVD
    Y.DAYS = '-2W'
    CALL CDT(Y.REGION,Y.DATE,Y.DAYS)

    Y.REGION = ''
    Y.DAY.TYPE = ''
    CALL AWD('',Y.DATE,Y.DAY.TYPE)

    IF Y.DAY.TYPE NE 'W' THEN
        Y.REGION = ''
        CALL CDT(Y.REGION,Y.DATE,'-1W')
    END

    IF Y.DATE LT TODAY THEN
        PD = TODAY ; *Blue
    END ELSE
        PD = Y.DATE ; *Green
    END
    
    R.NEW(PO.PAYMENT.EXECUTION.DATE) = PD
*
RETURN
*
*********
CALC.CVD:
*********

    Y.REGION = TXN.CCY[1,2]:'00'
    Y.DATE.2 = RCVD
    Y.DATE.1 = TODAY
    DIFF.DAYS = 'W'
    CALL CDD(Y.REGION,Y.DATE.1,Y.DATE.2,DIFF.DAYS)

    IF DIFF.DAYS GT 2 THEN
* If RCVD is greater than 2 days, set CVD as RCVD
        CVD = RCVD ; * Ignore SS
    END ELSE
* If RCVD is less than or equal to 2 days, consider the Setttlement Shift defined in PP.CHANNEL.CUTOFF to calculate CVD
        Y.REGION = TXN.CCY[1,2]:'00'
        Y.DATE = PD
        Y.DAYS = SS:'W'
        CALL CDT(Y.REGION,Y.DATE,Y.DAYS)
        CVD = Y.DATE

        IF CVD LT RCVD THEN
* If calculated CVD is less than RCVD, reset the CVD to RCVD
            CVD = RCVD
        END
    END
*
RETURN
*
************************
GET.CHANNEL.CUTOFF.DETS:
************************

    O.CHANNEL.DETS = ''
    O.CHANNEL.FXSHIFT.DETS = ''
    O.CHANNEL.RESP = ''
    
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.channelName> = 'NOSTRO'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.currencyCode> = TXN.CCY
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.ctrbtrIndicator> = R.NEW(PO.ORDER.TYPE)[1,1]
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.paymentDirection> = 'O'
*    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.priority> = R.NEW(PO.MESSAGE.PRIORITY)
	I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.priority> = '1'
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.messageType> = R.NEW(PO.PAYMENT.ORDER.PRODUCT)
    I.CHANNEL.NAME<PP.RoutingAndSettlementService.ChannelCutoffName.source> = R.NEW(PO.ORDER.INITIATION.TYPE)
    
    CALL PP.FIND.CHANNEL.CUTOFF(I.CHANNEL.NAME,O.CHANNEL.DETS,O.CHANNEL.FXSHIFT.DETS,O.CHANNEL.RESP)

    SS = ''
    IF O.CHANNEL.RESP EQ '' THEN
        SS = O.CHANNEL.DETS<PP.RoutingAndSettlementService.ChannelCutoffDetails.settlementShift>
    END
*
RETURN
*
******************
RAISE.WARNING.MSG:
******************
 
    Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
    Y.OVE.CNT += 1
    TEXT = 'JB.D.PP.RCVD.CHANGE':@FM:CVD:@VM:SS
    CALL STORE.OVERRIDE(Y.OVE.CNT)
*
RETURN
*
END
*
