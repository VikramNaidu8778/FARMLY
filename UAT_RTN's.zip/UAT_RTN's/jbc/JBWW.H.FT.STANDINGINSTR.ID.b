* @ValidationCode : MTotNDg2ODM5MTIyOklTTy04ODU5LTE6MTUwMDQ0Njc2NDUyNTo2MTg1MzM6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjQ=
* @ValidationInfo : Timestamp         : 19 Jul 2017 12:16:04
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 618533
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.H.FT.STANDINGINSTR.ID
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
* Dependencies:
*---------------
* NA
* Revision History:
*------------------
*   Date               who                  Reference                   Desc
* 18-JUL-2017          Mahesh J             JB2A-37042                  Initial Version
*---------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    
*------------------------------------------------------------------------------
   ID.VAL = ID.NEW
   Y.CURR.COMPANY = ID.COMPANY   

   IF ID.VAL NE Y.CURR.COMPANY THEN        
         E = 'EB-JBWW.D.FT.COMPANYID.VAL'		        
    END

    RETURN
*------------------------------------------------------------------------------

    END
