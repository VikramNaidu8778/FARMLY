* @ValidationCode : MTozMzg1MDM5NTQ6SVNPLTg4NTktMToxNjI0ODg1NzA1MjA4OmEzOTgwNDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTc=
* @ValidationInfo : Timestamp         : 28 Jun 2021 21:08:25
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a39804
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.17
SUBROUTINE JBWW.R.DE.202.RTN
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date                   who                  Reference                 Description
* 29/06/2021             Priyanka              SLBA-35            	 Initial Version
* Description : Routine to raise the FT transaction for MT202 message for SLB.
* Attached to : DE.MESSAGE>202
* 21/04/2023            Ramesh K              T24-18247              To restrict FT(Txn type - IT) creation for Non-SLB
*-----------------------------------------------------------------------------

    $USING DE.Config
    $USING FT.Delivery
    $USING FT.Contract
    $USING DE.Inward
    $USING EB.DataAccess
    $USING DE.API
    $USING EB.Interface
    $USING EB.API
    $USING DE.ModelBank
    $USING DE.Messaging
    $USING EB.SystemTables
    $USING EB.Delivery
    $INSERT I_CustomerService_NameAddress
    $INSERT I_CustomerService_Exists
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.NOSTRO.ACCOUNT

    PASSEDNO = ''
    DEFFUN CHARX(PASSEDNO)

    GOSUB INITIALISE
    GOSUB READ.GPM  ;*T24-18247 - S/E

    IF Y.DE.FLAG EQ '1' THEN
** GOSUB READ.GPM ;*T24-18247 - S/E
        GOSUB IDENTIFY.THE.SENDER
        GOSUB FETCH.TAGS
        GOSUB ADD.NON.TAG.FIELDS  ;* Specific Application Record Processing
        GOSUB CALL.OFS.BULK.MANAGER
		GOSUB STOP.THE.PROCESS
** T24-18247 - S - To restrict FT(Txn type - IT) creation for Non-SLB
    END ELSE
        IF Y.RESTRICT.NONSLB NE "YES" THEN
            CALL DE.I.MT202()
        END
    END
** T24-18247 - E

RETURN          ;* From main program
*-----------------------------------------------------------------------------
INITIALISE:

* Initialise variables

    CRT "Starting DE.I.MT202 template program"
  
    SWIFT.TAG.NO = ''
    SWIFT.TAG.DATA = ''
    MESSAGE.ERROR = ''
    TAG.ERROR.DATA = ''
    ERROR.COUNT = 1
    R.OFS.DATA = ''
    CCY = ''
    DEBIT.CURRENCY = ''
    CREDIT.CURRENCY = ''
   
    DE.I.ALL.FIELD.DATA = ''
* Open Files

    FN.DE.I.MSG = "F.DE.I.MSG"
    DE.Inward.setFDeIMsg("")
    EB.DataAccess.Opf(FN.DE.I.MSG,F.DE.I.MSG.LOC)
    DE.Inward.setFDeIMsg(F.DE.I.MSG.LOC)

    FN.DE.MESSAGE = "F.DE.MESSAGE"
    DE.Inward.setFDeMessage("")
    EB.DataAccess.Opf(FN.DE.MESSAGE,F.DE.MESSAGE.LOC)
    DE.Inward.setFDeMessage(F.DE.MESSAGE.LOC)

    FN.DE.FORMAT.SWIFT = "F.DE.FORMAT.SWIFT"
    DE.Inward.setFDeFormatSwift("")
    EB.DataAccess.Opf(FN.DE.FORMAT.SWIFT,F.DE.FORMAT.SWIFT.LOC)
    DE.Inward.setFDeFormatSwift(F.DE.FORMAT.SWIFT.LOC)

    R.DE.I.MSG = ''
    REC.ID = DE.Inward.getRKey()
    R.DE.I.MSG = DE.ModelBank.IMsg.Read(REC.ID, ER)
    EB.SystemTables.setE(ER)

    FN.NOSTRO.ACCOUNT = "F.NOSTRO.ACCOUNT"
    F.NOSTRO.ACCOUNT  = ''
    EB.DataAccess.Opf(FN.NOSTRO.ACCOUNT, F.NOSTRO.ACCOUNT)

    R.DE.MESSAGE = ''
    REC.ID = DE.Inward.getRHead(DE.Config.IHeader.HdrMessageType)
    R.DE.MESSAGE = DE.Config.Message.Read(REC.ID, ER)
    EB.SystemTables.setE(ER)
    K.VERSION = R.DE.MESSAGE<DE.Config.Message.MsgInOfsVersion>
    K.OFS.SOURCE = R.DE.MESSAGE<DE.Config.Message.MsgOfsSource>

    TEMP.APPLICATION = EB.SystemTables.getApplication()
    EB.SystemTables.setApplication(FIELD(K.VERSION,",",1))

    TXN.COMPANY = DE.Inward.getRHead(DE.Config.IHeader.HdrCompanyCode)
    OFS.PREFIX = K.VERSION:"/I,//":TXN.COMPANY:",,"

    IN.STORE.MSG = R.DE.I.MSG
    CRLF = CHARX(013):CHARX(010)
    CONVERT CRLF TO @FM IN IN.STORE.MSG
    MSG.FIELD.COUNT = DCOUNT(IN.STORE.MSG,@FM)

    Y.DE.FLAG = ''
    Y.CTR = 1
    LOOP
    WHILE Y.CTR LE MSG.FIELD.COUNT
        Y.TAG = IN.STORE.MSG<Y.CTR>
        FINDSTR ':72:' IN Y.TAG SETTING FMP THEN
            FINDSTR 'SLB' IN Y.TAG SETTING SLBFMPOS THEN
                Y.DE.FLAG = '1'
            END ELSE
                GOSUB CHECK.72.TAG
            END
        END
        Y.CTR = Y.CTR+1
    REPEAT

    RETURN.INFO = ''
    TXN.COMMITTED = ''

RETURN
  
*-----------------------------------------------------------------------------
STOP.THE.PROCESS:
*****************

    DE.Inward.setRHead(DE.Config.IHeader.HdrOfsReqDetKey, OFS.REQ.DET.ID);* Store the ofs request details id
    DE.Inward.setRHead(DE.Config.IHeader.HdrT24InwTransRef, T24.TRANS.REF);* Inward T24 trans ref
    DE.Inward.setRHead(DE.Config.IHeader.HdrDisposition, 'OFS FORMATTED')
    REC.ID = DE.Inward.getRKey()
    R.HEAD.REC = DE.Inward.getDynArrayFromRHead()
    DE.Config.IHeaderWrite(REC.ID,R.HEAD.REC,'')

    EB.SystemTables.setApplication(TEMP.APPLICATION)
RETURN
	
FETCH.TAGS:
*********

    MESSAGE.TYPE = DE.Inward.getRHead(DE.Config.IHeader.HdrMessageType)
    DE.Inward.GetMsgStructure(MESSAGE.TYPE,R.DE.I.MSG,FIELD.TAGS,MULTIPLE.TAG,SEQUENCED.TAGS,SEQUENCED.MESSAGE,MAXIMUM.REPEATS)

    TAG.FIELD.COUNT = DCOUNT(SEQUENCED.MESSAGE,@FM)
    FOR TAG.FIELD.NO = 1 TO TAG.FIELD.COUNT
        DE.TAG.ID = '' ; DE.TAG.SEQ.MSG = ''
        MULTIPLE.FIELD.NO = MULTIPLE.TAG<TAG.FIELD.NO>
        IF MULTIPLE.FIELD.NO[1,1] = 'R' THEN
            DE.TAG.ID = SEQUENCED.TAGS<TAG.FIELD.NO>[1,2]
            DE.TAG.SEQ.MSG = SEQUENCED.MESSAGE<TAG.FIELD.NO>
            GOSUB CALL.SUBROUTINE
        END ELSE
            TAG.VAL.COUNT = DCOUNT(SEQUENCED.MESSAGE<TAG.FIELD.NO>,@VM)
            FOR TAG.VAL.NO = 1 TO TAG.VAL.COUNT
                TAG.SUB.COUNT = DCOUNT(SEQUENCED.MESSAGE<TAG.FIELD.NO,TAG.VAL.NO>,@SM)
                FOR TAG.SUB.NO = 1 TO TAG.SUB.COUNT
                    IF SEQUENCED.MESSAGE<TAG.FIELD.NO,TAG.VAL.NO,TAG.SUB.NO> NE '' THEN
                        DE.TAG.ID = SEQUENCED.TAGS<TAG.FIELD.NO>[1,2]
                        DE.TAG.SEQ.MSG = SEQUENCED.MESSAGE<TAG.FIELD.NO,TAG.VAL.NO,TAG.SUB.NO>
                        GOSUB CALL.SUBROUTINE
                    END
                NEXT TAG.SUB.NO
            NEXT TAG.VAL.NO
        END
    NEXT TAG.FIELD.NO
RETURN
*-----------------------------------------------------------------------------
READ.GPM:
*********

    fnGpm  = 'F.JBWW.H.EB.GENERICPARAMETER'
    fGpm   = ''
    EB.DataAccess.Opf(fnGpm, fGpm)
    yGpmId  = 'JBWW.D.SC.SLB.PARAM'
    EB.DataAccess.FRead(fnGpm,yGpmId,yGpmRec,fGpm,yGpmErr)

    IF yGpmRec THEN
        yFldNameArr = yGpmRec<JBWW.GEN.PAR.FIELD.NAME>
        yFldValArr  = yGpmRec<JBWW.GEN.PAR.FIELD.VALUE>

        LOCATE 'TXN.TYPE.202' IN yFldNameArr<1,1> SETTING yTxn THEN
            FT.TXN.TYPE= yFldValArr<1,yTxn>
        END
        LOCATE 'CREDIT.AC.NO.202' IN yFldNameArr<1,1> SETTING yCrAcPos THEN
            CREDIT.ACCOUNT.NO = yFldValArr<1,yCrAcPos>
        END
        LOCATE 'PROFIT.CUST.202' IN yFldNameArr<1,1> SETTING yPcPos THEN
            PROFIT.CUST = yFldValArr<1,yPcPos>
        END
** T24-18247 - S
        Y.RESTRICT.NONSLB = '' ; yRestrictPos = ''
        LOCATE 'RESTRICT.NONSLB' IN yFldNameArr<1,1> SETTING yRestrictPos THEN
            Y.RESTRICT.NONSLB = yFldValArr<1,yRestrictPos>
        END
** T24-18247 - E
    END

RETURN

*************************************************************************
STORE.THE.MESSAGE:

    IN.DEL.KEY = DE.Inward.getRKey()
    R.OFS.DATA := 'DELIVERY.INREF=':IN.DEL.KEY:','

    IN.MSG.TYPE = 'MT':DE.Inward.getRHead(DE.Config.IHeader.HdrMessageType)
    R.OFS.DATA := 'INWARD.PAY.TYPE=':IN.MSG.TYPE:','

    FOR X = 1 TO MSG.FIELD.COUNT-1
        R.OFS.DATA := 'IN.SWIFT.MSG:':X:':="':IN.STORE.MSG<X>:'",'    ;* Store the message
    NEXT X

    R.OFS.DATA := 'INW.SEND.BIC=':DE.Inward.getRHead(DE.Config.IHeader.HdrFromAddress):','

RETURN

*************************************************************************

IDENTIFY.THE.SENDER:

* Check if the sender is a customer

*  SENDERS.BIC.CODE = SUBSTRINGS(R.HEAD(DE.HDR.FROM.ADDRESS),1,11)
    SENDERS.BIC.CODE = DE.Inward.getRHead(DE.Config.IHeader.HdrFromAddress)
*
    COMP.ID = EB.SystemTables.getIdCompany()
    DE.API.SwiftBic(SENDERS.BIC.CODE,COMP.ID,SENDING.CUSTOMER)
    
    IF LEN(SENDERS.BIC.CODE) = 12 THEN
        SENDERS.BIC.CODE = SENDERS.BIC.CODE[1,8]:SENDERS.BIC.CODE[10,3]
    END

    SAVE.SENDING.CUSTOMER = SENDING.CUSTOMER
RETURN

*************************************************************************
STORE.TAG.ERRORS:

* Display all the error messages occured while processing each tag.

    NO.OF.TAG.ERRORS = DCOUNT(MESSAGE.ERROR, @FM)

    FOR CNT = 1 TO NO.OF.TAG.ERRORS

        TAG.ERROR.DATA := 'IN.PROCESS.ERR:':CNT:'="':MESSAGE.ERROR<CNT>:'",'

    NEXT CNT

RETURN
*************************************************************************
STORE.OFS.ERRORS:
* Capture OFS errors and store along with the tag erros
    VM.CNT = ''
* Write the tag errors
    IF TAG.ERROR.DATA THEN
        R.OFS.DATA := TAG.ERROR.DATA
        VM.CNT = NO.OF.TAG.ERRORS
    END
* Write the OFS erros
    ERR.REASON=FIELD(RETURN.INFO,',',2,9999)
    CONVERT "," TO @FM IN ERR.REASON
    CONVERT ":" TO "." IN ERR.REASON

    NO.OF.OFS.ERRORS = DCOUNT(ERR.REASON, @FM)
    FOR CNT = 1 TO NO.OF.OFS.ERRORS
        VM.CNT += 1
* Store only first ?? chars of the error as per the field length, otherwise OFS will reject
        OFS.ERR = ERR.REASON<CNT>[1,65]
        R.OFS.DATA := 'IN.PROCESS.ERR:':VM.CNT:'="':OFS.ERR:'",'
    NEXT CNT

RETURN
*************************************************************************
CALL.OFS.BULK.MANAGER:
    
    R.OFS.DATA = OFS.PREFIX:R.OFS.DATA

    EB.Interface.OfsCallBulkManager(K.OFS.SOURCE, R.OFS.DATA, RETURN.INFO,TXN.COMMITTED)

    CHANGE '<requests>' TO '' IN RETURN.INFO   ;* Remove the '<requests>' string of characters in the RETURN.INFO.
    CHANGE '<request>' TO '' IN RETURN.INFO    ;* Remove the '<request>' string of characters in the RETURN.INFO.

    T24.TRANS.REF = FIELD(RETURN.INFO,'/',1)      ;* Get the inward trans ref
    OFS.REQ.DET.ID = FIELD(RETURN.INFO,'/',2)     ;* Get the ofs request detail id

    R.OFS.DATA = ''

    IF FIELD(RETURN.INFO,'/',3) < 0 THEN

        TXN.REF.GEN=FIELD(RETURN.INFO,'/',1)
        FAIL.CODE=FIELD(RETURN.INFO,'/',3)

        R.OFS.DATA = K.VERSION:"/I,//":TXN.COMPANY:","
        R.OFS.DATA := TXN.REF.GEN:','

        GOSUB STORE.OFS.ERRORS

        EB.Interface.OfsCallBulkManager(K.OFS.SOURCE, R.OFS.DATA,'','')
    END

RETURN

*************************************************************************
CHECK.72.TAG:
*************
    Y.CTR = Y.CTR+1
    LOOP
    WHILE Y.CTR LE MSG.FIELD.COUNT

        Y.TAG = IN.STORE.MSG<Y.CTR>
        FINDSTR ':' IN Y.TAG SETTING FMP THEN RETURN

        FINDSTR 'SLB' IN Y.TAG SETTING SLBFMPOS THEN
            Y.DE.FLAG = '1'
        END
        IF Y.DE.FLAG EQ '1' THEN RETURN
        Y.CTR = Y.CTR+1
    REPEAT

RETURN

*************************************************************************
*                      Special Tailored Subroutines                     *
*************************************************************************

ADD.NON.TAG.FIELDS:

    R.OFS.DATA := 'TRANSACTION.TYPE=':FT.TXN.TYPE:','
*
    GOSUB STORE.THE.MESSAGE   ;* Store the inward message in the appllication
    IF SAVE.SENDING.CUSTOMER THEN
        customerKey = SAVE.SENDING.CUSTOMER
        customerNameAddress = ''
        prefLang = EB.SystemTables.getLngg()
        CALL CustomerService.getNameAddress(customerKey,prefLang,customerNameAddress)
        CUS.NAME = customerNameAddress<NameAddress.shortName>
        IF EB.SystemTables.getEtext() = "" THEN
            CONVERT ',' TO '?' IN CUS.NAME
            R.OFS.DATA := 'TELEX.FROM.CUST=':CUS.NAME:','
        END ELSE
            R.OFS.DATA := 'TELEX.FROM.CUST=':SAVE.SENDING.CUSTOMER:','
        END
    END

    DEBIT.CURRENCY.FOUND = INDEX( R.OFS.DATA, "DEBIT.CURRENCY", 1)
    IF DEBIT.CURRENCY.FOUND THEN
        DEBIT.CURRENCY = SUBSTRINGS( R.OFS.DATA, DEBIT.CURRENCY.FOUND+15, 3)
        CREDIT.CURRENCY = DEBIT.CURRENCY
    END

    Y.CUSTOMER.NO = DE.Inward.getRHead(DE.Config.IHeader.HdrCustomerNo)
    IF Y.CUSTOMER.NO THEN
        CCY = DEBIT.CURRENCY
        CHECK.ACCOUNT.CLASS = "VOSTRO"
        GOSUB DE.I.GET.ACCOUNT.NO
    END

    FIELD.TO.FIND.ALL<-1>= 'IN.ORDERING.BK':'*':'ORDERING.BANK'
    FIELD.TO.FIND.ALL<-1> ='IN.ORDERING.CUS':'*':'ORDERING.CUST'
    GOSUB DEFAULT.FIELDS
	
    R.OFS.DATA := 'CREDIT.ACCT.NO:1:1=':CREDIT.ACCOUNT.NO:','
    R.OFS.DATA := 'CREDIT.CURRENCY:1:1=':CREDIT.CURRENCY:','
    R.OFS.DATA := 'PROFIT.CENTRE.CUST:1:1=':PROFIT.CUST:','

    IF NOT(INDEX(R.OFS.DATA,"IN.ORDERING.BK",1)) THEN

        IF SAVE.SENDING.CUSTOMER = '' THEN SAVE.SENDING.CUSTOMER = 'SW-':SENDERS.BIC.CODE
        R.OFS.DATA := 'IN.ORDERING.BK:1:1=':SAVE.SENDING.CUSTOMER:','
        R.OFS.DATA := 'ORDERING.BANK:1:1=':SAVE.SENDING.CUSTOMER:','
    END

    IN.DEL.KEY = DE.Inward.getRKey()
    R.OFS.DATA := 'DELIVERY.INREF=':IN.DEL.KEY:','
    IN.MSG.TYPE = 'MT':DE.Inward.getRHead(DE.Config.IHeader.HdrMessageType)
    R.OFS.DATA := 'INWARD.PAY.TYPE=':IN.MSG.TYPE:','

RETURN
*************************************************************************
**************************************************************************
DEFAULT.FIELDS:

    LOOP
        REMOVE FIELD.FIND.DEFAULT FROM FIELD.TO.FIND.ALL SETTING FIELD.POS
    WHILE FIELD.FIND.DEFAULT:FIELD.POS
        GOSUB PROCESS.DEFAULT.FIELDS
    REPEAT

RETURN

**************************************************************************
PROCESS.DEFAULT.FIELDS:
***********************************************************************

    FIELD.TO.FIND = QUOTE(FIELD( FIELD.FIND.DEFAULT,'*',1))
    FIELD.TO.DEFAULT = FIELD(FIELD.FIND.DEFAULT,'*',2)
    FINDSTR FIELD.TO.FIND IN DE.I.ALL.FIELD.DATA SETTING FMS,VMS THEN
        IN.DEFAULT.DATA = FIELD( DE.I.ALL.FIELD.DATA<FMS>,CHARX(251),2)
        CONVERT @VM TO @FM IN IN.DEFAULT.DATA
        NO.REP = 1
        LOOP
            REMOVE DATA.TO.DEF FROM IN.DEFAULT.DATA SETTING DEF.POS
        WHILE DATA.TO.DEF:DEF.POS
            DATA.TO.DEF = QUOTE(DATA.TO.DEF)
            R.OFS.DATA :=FIELD.TO.DEFAULT:':':NO.REP:'=':DATA.TO.DEF:','
            NO.REP +=1
        REPEAT

    END
RETURN
***********************************************************************
DE.I.GET.ACCOUNT.NO:
*

    CUSTOMER.NO = Y.CUSTOMER.NO
    OFS.DATA = ''
    TXN.TYPE = ''
    ACCOUNT = ''
    ACCOUNT.CATEGORY = ''
    ACCOUNT.COUNT = ''
    ACCOUNT.CLASS = ''
    ACCOUNT.ERROR = ''
    ACCOUNT.IN = ''
    ACCOUNT.NO = ''
    FT.Delivery.DeIGetAcctNo( CUSTOMER.NO, CCY, TXN.TYPE, ACCOUNT.IN, ACCOUNT, ACCOUNT.CATEGORY, ACCOUNT.COUNT,ACCOUNT.CLASS, ACCOUNT.ERROR)

    LOCATE CHECK.ACCOUNT.CLASS IN ACCOUNT.CLASS<1> SETTING POS THEN
        GOSUB CHECK.ACCT
    END

    IF CHECK.ACCOUNT.CLASS = "VOSTRO" THEN
        IF ACCOUNT.NO THEN
            OFS.DATA = OFS.DATA : "DEBIT.ACCT.NO" :'=' :ACCOUNT.NO
        END ELSE
            CHECK.ACCOUNT.CLASS = "NOSTRO"
            LOCATE CHECK.ACCOUNT.CLASS IN ACCOUNT.CLASS<1> SETTING POS THEN
                GOSUB CHECK.ACCT
            END
            IF ACCOUNT.NO THEN
                OFS.DATA = OFS.DATA : "DEBIT.ACCT.NO" :'=' :ACCOUNT.NO
            END
        END
        IF OFS.DATA THEN
            R.OFS.DATA := OFS.DATA:","
        END
	
        RETURN
	
*****************************************************************************************************
CHECK.ACCT:
*****************************************************************************************************

        IF ACCOUNT.COUNT<POS> GT 1 THEN
            TAG.ERR = 'ERROR - MORE THAN ONE ACCOUNT AVAILABLE'
            ACCOUNT.NO = ''
        END ELSE
            ACCOUNT.NO = ACCOUNT<POS,1>
        END
        RETURN
	
************************************************************************
CALL.SUBROUTINE:
**************************************************************************

        IF NOT(DE.TAG.ID) THEN RETURN

        R.DE.I.SUBROUTINE.TABLE = ''
        SET.ERROR = ''

        R.DE.I.SUBROUTINE.TABLE = DE.Messaging.ISubroutineTable.Read(DE.TAG.ID, TAG.ERR)

        IF TAG.ERR THEN
            SET.ERROR = "TAG ROUTINE FOR ":DE.TAG.ID:" - MISSING"
        END ELSE

            SUBROUTINE.ID = R.DE.I.SUBROUTINE.TABLE<DE.Messaging.ISubroutineTable.SrTbSubroutine>
            OFS.DATA = ''
            COMPILED.OR.NOT = ''
            DE.I.FIELD.DATA = ''

            EB.API.CheckRoutineExist(SUBROUTINE.ID, COMPILED.OR.NOT, R.ERR)

            IF NOT(COMPILED.OR.NOT) THEN
                SET.ERROR = "SUBROUTINE FOR TAG ":DE.TAG.ID:" NOT COMPILED"
            END ELSE
                CALL @SUBROUTINE.ID (SEQUENCED.TAGS<TAG.FIELD.NO>,DE.TAG.SEQ.MSG, OFS.DATA,SENDING.CUSTOMER,CCY,'','',DE.I.FIELD.DATA,SET.ERROR)
                IF OFS.DATA NE '' THEN
                    R.OFS.DATA := OFS.DATA:","
                    DE.I.ALL.FIELD.DATA<-1> = DE.I.FIELD.DATA
                END
            END
        END
        IF SET.ERROR THEN MESSAGE.ERROR<-1> = SET.ERROR
        RETURN

    END
