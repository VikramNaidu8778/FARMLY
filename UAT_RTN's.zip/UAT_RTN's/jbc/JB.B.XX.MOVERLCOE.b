SUBROUTINE JB.B.XX.MOVERLCOE(OE.ID)
*----------------------------------------------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------------------------------------
* This is the run routine of the multi thread job that moves Order Entry application
* RLC records placed for authorization.
*----------------------------------------------------------------------------------------------------------------
* Attached: to
*----------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: OE.ID  record id's of Order Entry application
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*----------------------------------------------------------------------------------------------------------------
* Date           Developer           Reference             Description
* 04-Jun-2025    Prabhu D S          CBPAY-2933            Initial Draft
*----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BATCH
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.DATES
    $INSERT I_JB.B.XX.MOVEOE.COMMON

          R.ORDER.ENTRY = ''
          CALL F.READ(FN.PP.ORDER.ENTRY.NAU, OE.ID, R.ORDER.ENTRY, F.PP.ORDER.ENTRY.NAU, OE.ERR)

          IF R.ORDER.ENTRY<PP.OEYG.LOCAL.REF,L.BLK.CODE> THEN
             Y.OFS.PROCESS = "PROCESS"
             Y.OFS.APP.NAME = "PP.ORDER.ENTRY"
             Y.OFS.SOURCE = "JB.D.XX.RLSOFTBLK"
             Y.OFS.INPUT.FUN = "A"
             NO.OF.AUTH = 2
             GTS.CONTROL = 3
             Y.OFS.VERSION = "PP.ORDER.ENTRY,JB.V.PP.RLCVD.AUTH"
             R.ORDER.ENTRY = ''
             GOSUB PROCESS.OE
          END

    RETURN

PROCESS.OE:

    CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.INPUT.FUN,Y.OFS.PROCESS,Y.OFS.VERSION,GTS.CONTROL,NO.OF.AUTH,OE.ID,R.ORDER.ENTRY,Y.BUILT.OFS)
    CALL OFS.CALL.BULK.MANAGER(Y.OFS.SOURCE,Y.BUILT.OFS,Y.REQ.MSG,Y.RESP)

    Y.OFS.RESPONSE = Y.REQ.MSG
    OFS.ERR.RESPONSE = ""
    TXN.ID   = ""
    SUCCESS.FLG = ""
    Y.RESP.OFS.ERROR = ""
    CALL JB.R.EB.OFSRESPONSEPARSE(Y.OFS.RESPONSE,OFS.ERR.RESPONSE,TXN.ID,SUCCESS.FLG,Y.RESP.OFS.ERROR,'')

    IF SUCCESS.FLG LT 1 THEN
       Y.RESP.OFS.ERROR = Y.REQ.MSG['/',4,1]
       Y.RESP.FOLD.MSG = FOLD(Y.RESP.OFS.ERROR,35)
    END

    IF Y.RESP.OFS.ERROR THEN
       CALL OCOMO(Y.RESP.OFS.ERROR)
    END

    RETURN
END
