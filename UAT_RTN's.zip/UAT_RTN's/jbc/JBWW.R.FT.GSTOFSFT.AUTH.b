*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
* @ValidationCode : MTotMTI0NDQ4Nzg0NjpVVEYtODoxNDgyMzI2MDUxNTMwOjQ2MTA3NjotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 21 Dec 2016 18:44:11
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 461076
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.R.FT.GSTOFSFT.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :

* Date          Developer                               Reference          Description
*---------------------------------------------------------------------------------------
* 22/12/2016    priyadarshni.priyanka@cognizant.com     CR- 162            Added to VERSION
*
* Description : This is new authorization routine, attached to the version
*               FUNDS.TRANSFER,JBWW.V.FT.GSTCALC.OFS.
*               This routine will update the FT reference to GST.REFERENCE, STMT.NO
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.STMT.ENTRY
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.GST.STMT.ENTRY.MB

*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
******
*-----------------------------------------------------------------------------
* !! Initialise the common variable

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU  = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER  = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.STMT.ENTRY = 'F.STMT.ENTRY'
    F.STMT.ENTRY  = ''
    CALL OPF(FN.STMT.ENTRY,F.STMT.ENTRY)

    FN.GST.STMT.ENTRY.MB = 'F.GST.STMT.ENTRY.MB'
    F.GST.STMT.ENTRY.MB = ''
    CALL OPF(FN.GST.STMT.ENTRY.MB,F.GST.STMT.ENTRY.MB)

    APP = 'FUNDS.TRANSFER'
    FLD = 'GST.REFERENCE'
    POS = ''
    CALL MULTI.GET.LOC.REF(APP,FLD,POS)
    CUST.GSTREF.POS = POS<1,1>

    RETURN

PROCESS:
*******
*-----------------------------------------------------------------------------
* !! Main Process begins here

    Y.PARENT.FT      = R.NEW(FT.LOCAL.REF)<1,CUST.GSTREF.POS>
    Y.CHILD.FT       = ID.NEW
    Y.TODAY          = TODAY
    Y.DEBIT.AC       = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CREDIT.AC      = R.NEW(FT.CREDIT.ACCT.NO)
    Y.STMT.NO        = R.NEW(FT.STMT.NOS)

    CHANGE VM TO FM IN Y.STMT.NO
    Y.CNT.VAL = Y.STMT.NO<2>
    TOT.CNT = FIELD(Y.CNT.VAL,"-",2)
    CONS.NO = "000"
    CNT = 1
    LOOP
    WHILE CNT LE TOT.CNT
        STMT.ENTRY.ID = Y.STMT.NO<1>:CONS.NO:CNT
        CALL F.READ(FN.STMT.ENTRY,STMT.ENTRY.ID,R.STMT.ENTRY,F.STMT.ENTRY,ERR.STMT)
        Y.STMT.ENTRY.CUS.ID = R.STMT.ENTRY<AC.STE.CUSTOMER.ID>
        IF Y.STMT.ENTRY.CUS.ID THEN
            Y.TXN.CCY = R.STMT.ENTRY<AC.STE.CURRENCY>
            Y.EXCH.RATE = R.STMT.ENTRY<AC.STE.EXCHANGE.RATE>
            Y.GST.COMP = R.STMT.ENTRY<AC.STE.COMPANY.CODE>
            Y.AMT.LCY  = R.STMT.ENTRY<AC.STE.AMOUNT.LCY>
            Y.AMT.LCY  = ABS(Y.AMT.LCY)
            BREAK
        END ELSE
            CNT ++
        END
    REPEAT

    CALL F.READ(FN.FUNDS.TRANSFER,Y.PARENT.FT,R.FUNDS.RECORD,F.FUNDS.TRANSFER,FUNDS.ERR)
    IF R.FUNDS.RECORD THEN
        R.FUNDS.RECORD<FT.LOCAL.REF,CUST.GSTREF.POS> = Y.CHILD.FT
    END ELSE
        CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.PARENT.FT,R.FUNDS.RECORD,F.FUNDS.TRANSFER.NAU,ERR.FT)
        R.FUNDS.RECORD<FT.LOCAL.REF,CUST.GSTREF.POS> = Y.CHILD.FT
    END
    CALL F.WRITE(FN.FUNDS.TRANSFER,Y.PARENT.FT,R.FUNDS.RECORD)
    Y.L2STMT.ID        = Y.PARENT.FT:".":Y.TODAY:".":"01":".NEW"
    CALL F.READ(FN.GST.STMT.ENTRY.MB,Y.L2STMT.ID,R.STMT.ENTRY.RECORD,F.GST.STMT.ENTRY.MB,STMT.ERR)

    CALL F.READ(FN.ACCOUNT,Y.DEBIT.AC,R.ACC,F.ACCOUNT,ERR.ACC)
    Y.CUS.ID = R.ACC<AC.CUSTOMER>
    IF Y.CUS.ID THEN
        R.STMT.ENTRY.RECORD<GST.STE.CUSTOMER> = Y.CUS.ID
    END ELSE
        CALL F.READ(FN.ACCOUNT,Y.CREDIT.AC,R.ACC,F.ACCOUNT,ERR.ACC)
        Y.CUS.ID = R.ACC<AC.CUSTOMER>
        R.STMT.ENTRY.RECORD<GST.STE.CUSTOMER> = Y.CUS.ID
    END
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,REC.CUS,F.CUSTOMER,ERR.CUS)
    Y.CUS.RESIDENCE    = REC.CUS<EB.CUS.RESIDENCE>


    R.STMT.ENTRY.RECORD<GST.STE.PROFIT.CUST>     = Y.CUS.ID
    R.STMT.ENTRY.RECORD<GST.STE.RESIDENCE>       = Y.CUS.RESIDENCE
    R.STMT.ENTRY.RECORD<GST.STE.STMT.ENTRY.IDS>  = R.NEW(FT.STMT.NOS)
    R.STMT.ENTRY.RECORD<GST.STE.DR.ACCOUNT>      = Y.DEBIT.AC
    R.STMT.ENTRY.RECORD<GST.STE.CR.ACCOUNT>      = Y.CREDIT.AC
    R.STMT.ENTRY.RECORD<GST.STE.BOOK.CODE>       = Y.GST.COMP
    R.STMT.ENTRY.RECORD<GST.STE.GST.AMT.LCY>     = Y.AMT.LCY
    R.STMT.ENTRY.RECORD<GST.STE.EXCHANGE.RATE>    = Y.EXCH.RATE
    R.STMT.ENTRY.RECORD<GST.STE.TXN.CCY>          = Y.TXN.CCY
    CALL F.WRITE(FN.GST.STMT.ENTRY.MB,Y.L2STMT.ID,R.STMT.ENTRY.RECORD)

    RETURN

*-----------------------------------------------------------------------------
    END
