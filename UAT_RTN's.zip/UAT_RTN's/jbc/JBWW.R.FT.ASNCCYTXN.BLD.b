* @ValidationCode : MTotMTA0MDk1MTg3OTpJU08tODg1OS0xOjE1NDc3OTM5Nzc0NjE6YTQ1MzI4Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4xNg==
* @ValidationInfo : Timestamp         : 18 Jan 2019 14:46:17
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.ASNCCYTXN.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 24-12-2018        Sakthivel S           JIRA-P3369                Build routine attached
*                                                                   to add the Asian currency in the filter.
*
* 18-01-2019        Sakthivel S           JIRA-P3369                Logic changed to re-use same logic
*                                                                   for Non-Asian currency enquiry
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
* To Initialise variables and to open necessary files.

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    GEN.PAR.ID = '' ; R.GEN.RECORD = '' ; ERROR.COM = ''
    GEN.FIELD.NAME = '' ;  ASN.CCY.POS = ''
    Y.ASN.CCY.LIST = ''


    RETURN

PROCESS:
* To add the filter for asian currency SAP transactions
    GEN.PAR.ID = "JBWW.D.FT.ASN.CCY"

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GEN.PAR.ID,R.GEN.RECORD,F.JBWW.H.EB.GENERICPARAMETER,ERROR.COM)
    GEN.FIELD.NAME = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.NAME>

    LOCATE "ASIAN.CURRENCY" IN GEN.FIELD.NAME<1,1> SETTING ASN.CCY.POS THEN
    Y.ASN.CCY.LIST = R.GEN.RECORD<JBWW.GEN.PAR.FIELD.VALUE,ASN.CCY.POS>
    CHANGE SM TO ' ' IN Y.ASN.CCY.LIST
    END

    ENQ.DATA<2,-1> = 'DEBIT.CURRENCY'
    BEGIN CASE
        CASE ENQ.DATA<1> EQ "JBWW.E.FT.SAPPAYASNTODAY.EXCEP" OR ENQ.DATA<1> EQ "JBWW.E.FT.SAPPAYASNTODAY.LIST"
            ENQ.DATA<3,-1> = 'EQ'
        CASE ENQ.DATA<1> EQ "JBWW.E.FT.SAPPAYTODAY.UNAUTH"
            ENQ.DATA<3,-1> = 'NE'
    END CASE
    ENQ.DATA<4,-1> = Y.ASN.CCY.LIST

    RETURN

    END
