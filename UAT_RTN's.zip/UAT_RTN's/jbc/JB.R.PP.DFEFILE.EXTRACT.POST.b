SUBROUTINE JB.R.PP.DFEFILE.EXTRACT.POST
*-----------------------------------------------------------------------------
*Attached in : BATCH > SGD/JBWW.B.XX.STATICDATA.EXTRACT(For DFE Mapping > JB.D.PP.POPRD-FIN.MAP)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date            Developer        Reference        Description
*----------------------------------------------------------------------------------
* 20/02/2025     Lakshmi Priya    CBPAY-1725       This Routine is to include Payments Order Product Records in
*                                                      in existing static data extract generated for FT Transaction Codes.
*------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DFE.PARAMETER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DATES
    $INSERT I_F.COMPANY
 
    GOSUB INIT
    GOSUB OPEN.PARAM
    GOSUB PROCESS
    
RETURN
*-----------------------------------------------------------------------------
INIT:
*-----------------------------------------------------------------------------

    Y.PARAMETER.REC.PO = BATCH.DETAILS<3,1,1>
    Y.PARAMETER.REC.FT = BATCH.DETAILS<3,1,2>

    Y.TODAY = TODAY
    
    FN.DFE.PARAMETER = "F.DFE.PARAMETER"
    F.DFE.PARAMETER = ''
    CALL OPF(FN.DFE.PARAMETER , F.DFE.PARAMETER)
    
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)

RETURN
    
*-----------------------------------------------------------------------------
OPEN.PARAM:
*-----------------------------------------------------------------------------
    
    R.DFE.PARAM = ''
    DFE.ERR = ''
    CALL F.READ(FN.DFE.PARAMETER,Y.PARAMETER.REC.FT,R.FT.DFE.PARAM,F.DFE.PARAMETER,DFE.ERR)
    Y.DFE.OUT.DIR      = R.FT.DFE.PARAM<DFE.PARAM.OUTPUT.DIR>
    Y.DFE.OUTPUT.DIR   = EREPLACE(Y.DFE.OUT.DIR,"!MNEMONIC",Y.COMP.ID)
    Y.DFE.FT.FILE.NAME = R.FT.DFE.PARAM<DFE.PARAM.OUT.FILE.NAME>
    Y.DFE.FILE.FT = FIELD(Y.DFE.FT.FILE.NAME,"_",1)
    Y.FT.OUT.FILE.NAME = Y.DFE.FILE.FT:"_":Y.COMP.ID:"_T24_":Y.TODAY:".csv"
            
    CALL F.READ(FN.DFE.PARAMETER,Y.PARAMETER.REC.PO,R.PO.DFE.PARAM,F.DFE.PARAMETER,DFE.ERR)
    Y.DFE.PO.FILE.NAME  = R.PO.DFE.PARAM<DFE.PARAM.OUT.FILE.NAME>
    Y.DFE.FILE.PO = FIELD(Y.DFE.PO.FILE.NAME,"_",1)
    Y.PO.OUT.FILE.NAME = Y.DFE.FILE.PO:"_":Y.COMP.ID:"_T24_":Y.TODAY:".csv"

RETURN


*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------

   
    EXECUTE.CMD1 = "head -n -1 ":Y.DFE.OUTPUT.DIR:Y.FT.OUT.FILE.NAME:">":Y.DFE.OUTPUT.DIR:"temp1.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",EXECUTE.CMD1,CNT.RESULT,RETURN.CODE)

    EXECUTE.CMD2 = "head -n -1 ":Y.DFE.OUTPUT.DIR:Y.PO.OUT.FILE.NAME:">":Y.DFE.OUTPUT.DIR:"temp2.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",EXECUTE.CMD2,CNT.RESULT,RETURN.CODE)

    Y.CREATE.TEMP = "cat ":Y.DFE.OUTPUT.DIR:"temp1.csv > ":Y.DFE.OUTPUT.DIR:"temp5.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",Y.CREATE.TEMP,CNT.RESULT,RETURN.CODE)

    Y.APPEND = "cat ":Y.DFE.OUTPUT.DIR:"temp2.csv >> ":Y.DFE.OUTPUT.DIR:"temp5.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",Y.APPEND,CNT.RESULT,RETURN.CODE)

    CNT.CMD = "cat ":Y.DFE.OUTPUT.DIR:"temp5.csv | wc -l"
    CALL SYSTEM.CALL("EXECUTE","UNIX",CNT.CMD,CNT.RESULT,RETURN.CODE)
    CNT.NUM = CNT.RESULT - 1
  
    CONCAT.CMD1 = "echo '####":CNT.NUM:"' > ":Y.DFE.OUTPUT.DIR:"temp6.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",CONCAT.CMD1,CNT.RESULT,RETURN.CODE)

    CONCAT.CMD2 = "cat ":Y.DFE.OUTPUT.DIR:"temp6.csv >> ":Y.DFE.OUTPUT.DIR:"temp5.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",CONCAT.CMD2,CNT.RESULT,RETURN.CODE)

    EXECUTE.CMD = "mv ":Y.DFE.OUTPUT.DIR:"temp5.csv ":Y.DFE.OUTPUT.DIR:Y.FT.OUT.FILE.NAME
    CALL SYSTEM.CALL("EXECUTE","UNIX",EXECUTE.CMD,CNT.RESULT,RETURN.CODE)

    REM.EXE.CMD = "rm -rf ":Y.DFE.OUTPUT.DIR:Y.PO.OUT.FILE.NAME:" ":Y.DFE.OUTPUT.DIR:"temp6.csv ":Y.DFE.OUTPUT.DIR:"temp1.csv ":Y.DFE.OUTPUT.DIR:"temp2.csv"
    CALL SYSTEM.CALL("EXECUTE","UNIX",REM.EXE.CMD,CNT.RESULT,RETURN.CODE)


RETURN

**-----------------------------------------------------------------------------

END

