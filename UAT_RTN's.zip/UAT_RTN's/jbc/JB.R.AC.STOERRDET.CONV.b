SUBROUTINE JB.R.AC.STOERRDET.CONV
*-----------------------------------------------------------------------------
* Attached as Conversion Routine>JB.E.AC.STOERROR.LIST
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*
*30-Apr-2025     Resmi R            CBPAY-2464       Conversion routine to fetch values for the specified fields
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.PAYMENT.ORDER
    
    GOSUB INIT

       
RETURN

******
INIT:
*****

    FN.PAYMENT.ORDER = "F.PAYMENT.ORDER$NAU"
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER, F.PAYMENT.ORDER)
       
    FN.STANDING.ORDER = "F.STANDING.ORDER"
    F.STANDING.ORDER = ''
    CALL OPF(FN.STANDING.ORDER, F.STANDING.ORDER)

    Y.PO.ID = O.DATA

    GOSUB FETCH.ERROR.DATE
    
    
RETURN
    
********************
FETCH.ERROR.DATE:
********************

    GOSUB READ.PAYMENT.ORDER
    GOSUB READ.STANDING.ORDER
    
    LOCATE Y.PO.ID IN Y.ERR.UL.APPL.ID<1,1> SETTING ID.POS THEN
        Y.STO.ERR.DATE = R.STANDING.ORDER<STO.ERROR.DATE,ID.POS>
        Y.STO.ERR.DETAIL = R.STANDING.ORDER<STO.ERROR.DETAILS,ID.POS>
        
        O.DATA = Y.STO.ERR.DATE:'*':Y.STO.ERR.DETAIL
        
    END ELSE
     
        O.DATA = ''
                
    END
    
   
RETURN


*******************
READ.PAYMENT.ORDER:
*******************

    CALL F.READ(FN.PAYMENT.ORDER,Y.PO.ID,R.PAYMENT.REC,F.PAYMENT.ORDER,PO.ERR)
    Y.STO.REF = R.PAYMENT.REC<PO.ORDERING.REFERENCE>


RETURN

********************
READ.STANDING.ORDER:
********************

    CALL F.READ(FN.STANDING.ORDER,Y.STO.REF,R.STANDING.ORDER,F.STANDING.ORDER,STO.ERR)
    IF R.STANDING.ORDER THEN
       Y.ERR.UL.APPL.ID = R.STANDING.ORDER<STO.ERROR.UL.APPL.ID>
   END
    
RETURN

*****************************************************
END
    
    