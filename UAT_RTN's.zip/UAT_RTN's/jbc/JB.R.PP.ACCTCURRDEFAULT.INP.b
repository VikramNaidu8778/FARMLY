SUBROUTINE JB.R.PP.ACCTCURRDEFAULT.INP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------
* Date            Developer          Reference               Description
* 10/05/2025     Lakshmi Priya       CBPAY-2745        Validation rtn attached for fields Debit Acct No and
*                                                     Credit Acc no to default account currency based on Account
* 18/05/2025     Ragupathy K         CBPAY-2754       As per the requirement existing functionality should be retained.
*                                                       Cross boarder payment not in scope for this version.
* 27/05/2025    Lakshmi Priya        CBPAY-2754       Included logic to default credit account based on credit currency from Nostro Account Table.
*
* 21/05/2025    Lakshmi Priya        CBPAY-2723       Included logic to default credit currency based on credit account for ACPM transactions.
* 30/06/2025    Prabhu D S           CBPAY-2723       OrderingBank to be default for Internal/PL/Nostro accounts involved
*----------------------------------------------------------------------------- 

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.NOSTRO.ACCOUNT


    GOSUB INIT
    GOSUB PROCESS

RETURN

INIT:
****
    
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.NOSTRO.ACCOUNT = 'F.NOSTRO.ACCOUNT'
    F.NOSTRO.ACCOUNT = ''
    CALL OPF(FN.NOSTRO.ACCOUNT,F.NOSTRO.ACCOUNT)

RETURN

PROCESS:
*******


    IF AF EQ FT.DEBIT.ACCT.NO THEN

        Y.ACCT.NO = COMI
        CALL F.READ(FN.ACCOUNT,Y.ACCT.NO,R.ACCT.NO,F.ACCOUNT,ERR.DACC)
        Y.ACCT.CCY = R.ACCT.NO<AC.CURRENCY>
        R.NEW(FT.DEBIT.CURRENCY) = Y.ACCT.CCY
        R.NEW(FT.CREDIT.CURRENCY) = Y.ACCT.CCY
        IF R.NEW(FT.TRANSACTION.TYPE) EQ 'OT60' AND R.NEW(FT.CREDIT.ACCT.NO) EQ '' THEN
             Y.ACCT.CCY = R.NEW(FT.CREDIT.CURRENCY)
             CALL F.READ(FN.NOSTRO.ACCOUNT,Y.ACCT.CCY,R.ACCT.CCY,F.NOSTRO.ACCOUNT,PORS.ERR)
             R.NEW(FT.CREDIT.ACCT.NO) = R.ACCT.CCY<EB.NOS.ACCOUNT>
        END
        IF R.NEW(FT.CREDIT.ACCT.NO)[1,2] EQ 'PL' THEN R.NEW(FT.CREDIT.CURRENCY) = Y.ACCT.CCY
        IF NOT(ISDIGIT(Y.ACCT.NO)) OR NOT(R.ACCT.NO) THEN R.NEW(FT.ORDERING.BANK) = "BJB"
    END 
    IF (AF EQ FT.CREDIT.ACCT.NO) AND (R.NEW(FT.TRANSACTION.TYPE) EQ 'ACPM') THEN
       Y.ACCT.NO = COMI
       CALL F.READ(FN.ACCOUNT,Y.ACCT.NO,R.ACCT.NO,F.ACCOUNT,ERR.DACC)
       Y.ACCT.CCY = R.ACCT.NO<AC.CURRENCY>
       R.NEW(FT.CREDIT.CURRENCY) = Y.ACCT.CCY
       IF R.NEW(FT.DEBIT.ACCT.NO)[1,2] EQ 'PL' THEN R.NEW(FT.DEBIT.CURRENCY) = Y.ACCT.CCY
    END

    DR.AC.NO = R.NEW(FT.DEBIT.ACCT.NO)
    CALL F.READ(FN.ACCOUNT,DR.AC.NO,R.DR.ACCT,F.ACCOUNT,'')
    CR.AC.NO = R.NEW(FT.CREDIT.ACCT.NO)
    CALL F.READ(FN.ACCOUNT,CR.AC.NO,R.CR.ACCT,F.ACCOUNT,'')

    IF (R.DR.ACCT<AC.CATEGORY> GE 5000 AND R.DR.ACCT<AC.CATEGORY> LE 5999) AND (R.CR.ACCT<AC.CATEGORY> GE 5000 AND R.CR.ACCT<AC.CATEGORY> LE 5999) THEN
       R.NEW(FT.ORDERING.BANK) = "BJB"
    END

RETURN

END
