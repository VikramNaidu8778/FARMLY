*-----------------------------------------------------------------------------
SUBROUTINE JB.R.XX.GETTXNENTRIES.NOF(FINAL.ENTRY.LIST)
*-----------------------------------------------------------------------------
* This NOFILE routine attached to the enquiry JB.E.PP.TXNENTRY.LIST to fetch
* the accounting entries of both Other Module Application (FX, ND, MM, SW, FD, DX)
* and its corresponding TPH accounting entries
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date         Developer          Reference              Description
*
* 18-Oct-2024  xxx                CBPAY-1011             Initial Version
* 13-Mar-2025  P Amala            CBPAY-75               Fix to read the history file.
* 09-Apr-2025  Ragupathy K        CBPAY-2426             Included TPH FT numbers
* 31-May-2025  P Amala            CBPAY-3129             Missing spec entry records for OFFDBBL/OFFCRBL in Transaction Entries Enquiry.
* 03-Jun-2025  P Amala            CBPAY-2863             Enquiry should work for other contract module which is not integrated with TPH (Ex: Sec Trade, FT Reference )
* 06-Jun-2025  Prabhu D S         CBPAY-3096             Final Sorting required after combined TPH & other entries.
*-----------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.FD.FIDUCIARY
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.FOREX
    $INSERT I_F.MM.PAYMENT.ENTRY
    $INSERT I_F.ND.DEAL
    $INSERT I_F.DX.TRADE
    $INSERT I_F.SWAP
    $INSERT I_F.COMPANY
    $INSERT I_F.STMT.ENTRY
    $INSERT I_F.RE.CONSOL.SPEC.ENTRY
    $INSERT I_F.CATEG.ENTRY
    $INSERT I_F.STMT.ENTRY.DETAIL
    
    JB.ENTRY.LISTS = ''
    PROCESSED.POS = ''
    ENTRY.ID = ''
    ENTRY.POS = ''
    TEMP.ENTRY.LIST = ''
    STMT.ENTRY.REC = ''
    CATEG.ENTRY.REC = ''
    SPEC.ENTRY.REC = ''
    BOOK.DATES = ''
    VALUE.DATES = ''
    TXN.REFS = ''

    JB.ENTRY.LIST = ''
*   CALL E.MB.TXN.GET.ENTRIES(JB.ENTRY.LIST)
    CALL JBWW.E.XX.TXN.ENTRY.NOF(JB.ENTRY.LIST)
    JB.ENTRY.LISTS = JB.ENTRY.LIST

    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING ID.POS ELSE
        NULL
    END

    TXN.REF = D.RANGE.AND.VALUE<ID.POS>
    IF R.COMPANY(EB.COM.MNEMONIC) EQ TXN.REF[1,3] THEN
* For TPH transactions
        FINAL.ENTRY.LIST = JB.ENTRY.LISTS
        RETURN
    END
    CALL JB.R.XX.GET.TPHTXN(TXN.REF,R.APPLN,PO.LIST)

    GOSUB GET.APPLN.DETS
*For Unknown TXN REF
    IF Y.APPLN THEN
        GOSUB OPEN.FILES
        Y.CURRNO = R.APPLN<Y.FIELD.CURRNO>
    
        GOSUB SAVE.VARS
        JB.ENTRY.LIST = ''
        GOSUB PROCESS
        GOSUB RESTORE.VARS
   
        IF Y.CURRNO GT 1 THEN
            GOSUB LOOP.HISTORY
        END
    
        FINAL.ENTRY.LIST = JB.ENTRY.LISTS
    END ELSE
* Enquiry should work for other contract module which is not integrated with TPH (Example : Sec Trade Reference )
        FINAL.ENTRY.LIST = JB.ENTRY.LISTS
	END
    GOSUB SORT.ENTRIES

RETURN
*
***************
GET.APPLN.DETS:
***************

    BEGIN CASE
        CASE TXN.REF[1,2] EQ 'FD'
            Y.APPLN = 'FD.FIDUCIARY'
            Y.FIELD.NO = FD.PO.REFERENCE
            Y.FIELD.CURRNO = FD.CURR.NO
        CASE TXN.REF[1,2] EQ 'FX'
            Y.APPLN = 'FOREX'
            Y.FIELD.NO = FX.PO.REFERENCE
            Y.FIELD.CURRNO = FX.CURR.NO
        CASE TXN.REF[1,2] EQ 'MM'
            Y.APPLN = 'MM.PAYMENT.ENTRY'
            Y.FIELD.NO = MM.PA.PO.REFERENCE
            Y.FIELD.CURRNO = MM.PA.CURR.NO
            TXN.REF = TXN.REF:'00'
* Getting overwritten - need to add the logic to get the history records
        CASE TXN.REF[1,2] EQ 'SW'
            Y.APPLN = 'SWAP'
            Y.FIELD.NO = SW.PO.REFERENCE
            Y.FIELD.CURRNO = SW.CURR.NO
* Getting overwritten - need to add the logic to get the history records
        CASE TXN.REF[1,2] EQ 'DX'
            Y.APPLN = 'DX.TRADE'
            Y.FIELD.NO = DX.TRA.PAYMENT.ORDER.ID
            Y.FIELD.CURRNO = DX.TRA.CURR.NO
        CASE TXN.REF[1,2] EQ 'ND'
            Y.APPLN = 'ND.DEAL'
            Y.FIELD.NO = ND.DEAL.PO.REFERENCE
            Y.FIELD.CURRNO = ND.DEAL.CURR.NO
    END CASE
*
RETURN
*
***********
OPEN.FILES:
***********
    
    FN.PO = 'F.PAYMENT.ORDER'
    F.PO = ''
    CALL OPF(FN.PO,F.PO)

    FN.PO.HIS = 'F.PAYMENT.ORDER$HIS'
    F.PO.HIS = ''
    CALL OPF(FN.PO.HIS,F.PO.HIS)

    FN.APPLN.HIS = 'F.':Y.APPLN:'$HIS'
    F.APPLN.HIS = ''
    CALL OPF(FN.APPLN.HIS,F.APPLN.HIS)
	
    FN.STMT.ENTRY = 'F.STMT.ENTRY'
    F.STMT.ENTRY = ''
    CALL OPF(FN.STMT.ENTRY,F.STMT.ENTRY)
	
    FN.CATEG.ENTRY = 'F.CATEG.ENTRY'
    F.CATEG.ENTRY = ''
    CALL OPF(FN.CATEG.ENTRY,F.CATEG.ENTRY)
	
    FN.RE.CONSOL.SPEC.ENTRY = 'F.RE.CONSOL.SPEC.ENTRY'
    F.RE.CONSOL.SPEC.ENTRY = ''
    CALL OPF(FN.RE.CONSOL.SPEC.ENTRY,F.RE.CONSOL.SPEC.ENTRY)
	
    FN.STMT.ENTRY.DETAIL = 'F.STMT.ENTRY.DETAIL'
    F.STMT.ENTRY.DETAIL = ''
    CALL OPF(FN.STMT.ENTRY.DETAIL,F.STMT.ENTRY.DETAIL)
    
*
RETURN
*
**********
SAVE.VARS:
**********
    SAVE.D.FIELDS = D.FIELDS
    SAVED.D.RANGE.AND.VALUE = D.RANGE.AND.VALUE
*
RETURN
*
*************
RESTORE.VARS:
*************

    D.FIELDS = SAVE.D.FIELDS
    D.RANGE.AND.VALUE = SAVED.D.RANGE.AND.VALUE
*
RETURN
*
********
PROCESS:
********

    PO.COUNT = DCOUNT(PO.LIST,@FM)

    FOR PO.CNT = 1 TO PO.COUNT
        PO.REF = PO.LIST<PO.CNT>
        LOCATE PO.REF IN PROCESSED.POS<1> SETTING POS ELSE
            PROCESSED.POS<-1> = PO.REF
            R.PO = ''
            E.PO = ''
            CALL F.READ(FN.PO,PO.REF,R.PO,F.PO,E.PO)
            IF NOT(R.PO) THEN
                PO.HIS.ID = PO.REF
                CALL EB.READ.HISTORY.REC(F.PO.HIS,PO.HIS.ID,R.PO,'')
            END
            TPH.REF = R.PO<PO.PAYMENT.SYSTEM.ID>

            LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING ID.POS THEN
                D.RANGE.AND.VALUE<ID.POS> = TPH.REF
            END
                
            JB.ENTRY.LIST = ''
            CALL E.MB.TXN.GET.ENTRIES(JB.ENTRY.LIST)
        
            IF JB.ENTRY.LIST THEN
                IF JB.ENTRY.LISTS THEN
                    JB.ENTRY.LISTS<-1> = JB.ENTRY.LIST
                END ELSE
                    JB.ENTRY.LISTS = JB.ENTRY.LIST
                END
            END
        END
    NEXT PO.CNT
*
RETURN
*
*************
LOOP.HISTORY:
*************

    GOSUB SAVE.VARS
    Y.CNT = Y.CURRNO - 1
    LOOP
    WHILE (Y.CNT GE 1)
        HIS.ID = TXN.REF:';':Y.CNT
        R.APPLN = ''
        ER.APPLN.HIS = ''
        CALL F.READ(FN.APPLN.HIS,HIS.ID,R.APPLN,F.APPLN.HIS,ER.APPLN.HIS)
        JB.ENTRY.LIST = ''
        GOSUB PROCESS
        Y.CNT = Y.CNT - 1
    REPEAT
    GOSUB RESTORE.VARS
*
RETURN
*
*************
SORT.ENTRIES:
*************
* Sorting should be done from final list of entries from other modules and TPH entries
    LOCATE 'SORT.REQ' IN D.FIELDS<1> SETTING BOOK.SORT.POS THEN
	    SORT.BY.BOOK = D.RANGE.AND.VALUE<BOOK.SORT.POS>
    END
    LOCATE 'SORT.REQ.VAL' IN D.FIELDS<1> SETTING VAL.SORT.POS THEN
        SORT.BY.VALUE = D.RANGE.AND.VALUE<VAL.SORT.POS>
    END
    LOCATE 'SORT.REQ.TXN' IN D.FIELDS<1> SETTING TXN.SORT.POS THEN
        SORT.BY.TXN = D.RANGE.AND.VALUE<TXN.SORT.POS>
    END
	
	IF SORT.BY.BOOK OR SORT.BY.VALUE OR SORT.BY.TXN THEN
	   GOSUB GET.ENTRY.DETAILS
	   GOSUB DO.SORTING
	   FINAL.ENTRY.LIST = ENT.LIST
	END

*
RETURN
*
******************
GET.ENTRY.DETAILS:
******************

    TEMP.ENTRY.LIST = FINAL.ENTRY.LIST
    
    LOOP
	 READNEXT ENTRY.ID FROM FINAL.ENTRY.LIST SETTING ENTRY.POS ELSE ENTRY.POS = ''
	 WHILE ENTRY.ID : ENTRY.POS
            CURR.SPEC = ENTRY.ID
	    ENTRY.ID = FIELD(ENTRY.ID,'*',1)
            ENTRY.TYPE = ENTRY.ID[1,1]
	    BEGIN CASE
		   CASE ENTRY.TYPE = 'S'
		         ENTRY.ID = ENTRY.ID[2,LEN(ENTRY.ID)]
			 CALL F.READ(FN.STMT.ENTRY,ENTRY.ID,R.ENTRY.REC,F.STMT.ENTRY,'')
			 IF NOT(R.ENTRY.REC) THEN
			    CALL F.READ(FN.STMT.ENTRY.DETAIL,ENTRY.ID,R.ENTRY.REC,F.STMT.ENTRY.DETAIL,'')
			 END
                         BOOK.DATE = AC.STE.BOOKING.DATE
			 VALUE.DATE = AC.STE.VALUE.DATE
			 TXN.REF = AC.STE.TRANS.REFERENCE
			 DATE.TIME = AC.STE.DATE.TIME
		   
		   CASE ENTRY.TYPE = 'C'
		         ENTRY.ID = ENTRY.ID[2,LEN(ENTRY.ID)]
			 CALL F.READ(FN.CATEG.ENTRY,ENTRY.ID,R.ENTRY.REC,F.CATEG.ENTRY,'')
                         BOOK.DATE = AC.CAT.BOOKING.DATE
			 VALUE.DATE = AC.CAT.VALUE.DATE
			 TXN.REF = AC.CAT.TRANS.REFERENCE	
                         DATE.TIME = AC.CAT.DATE.TIME
		   
		   CASE ENTRY.TYPE = 'R'
		         ENTRY.ID = ENTRY.ID[2,LEN(ENTRY.ID)]
			 CALL F.READ(FN.RE.CONSOL.SPEC.ENTRY,ENTRY.ID,R.ENTRY.REC,F.RE.CONSOL.SPEC.ENTRY,'')
                         BOOK.DATE = RE.CSE.BOOKING.DATE
			 VALUE.DATE = RE.CSE.VALUE.DATE
			 TXN.REF = RE.CSE.TRANS.REFERENCE
                         DATE.TIME = RE.CSE.DATE.TIME
		   
		END CASE
		GOSUB FORM.ARRAY
	REPEAT

*
RETURN
*
***********
FORM.ARRAY:
***********

    BOOK.DATES<-1> = R.ENTRY.REC<BOOK.DATE>
    VALUE.DATES<-1> = R.ENTRY.REC<VALUE.DATE>
    TXN.REFS<-1> = FMT(R.ENTRY.REC<TXN.REF>,"L%60")
    ENTRY.LISTS<-1> = R.ENTRY.REC<DATE.TIME>:"#":CURR.SPEC
*
RETURN
*
***********
DO.SORTING:
***********

    BEGIN CASE
        CASE SORT.BY.BOOK AND SORT.BY.VALUE AND SORT.BY.TXN
            ENTRY.IDS = SPLICE(SPLICE(BOOK.DATES,'#',VALUE.DATES),'#',SPLICE(TXN.REFS,'#',ENTRY.LISTS))
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',5)
			
        CASE SORT.BY.BOOK AND SORT.BY.VALUE
            ENTRY.IDS = SPLICE(SPLICE(BOOK.DATES,'#',VALUE.DATES),'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',4)
			
        CASE SORT.BY.BOOK AND SORT.BY.TXN
            ENTRY.IDS = SPLICE(SPLICE(BOOK.DATES,'#',TXN.REFS),'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',4)
			
        CASE SORT.BY.VALUE AND SORT.BY.TXN
            ENTRY.IDS = SPLICE(SPLICE(VALUE.DATES,'#',TXN.REFS),'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',4)
			
        CASE SORT.BY.TXN
            ENTRY.IDS = SPLICE(TXN.REFS,'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',3)
			
        CASE SORT.BY.VALUE
            ENTRY.IDS = SPLICE(VALUE.DATES,'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',3)
			
        CASE SORT.BY.BOOK
            ENTRY.IDS = SPLICE(BOOK.DATES,'#',ENTRY.LISTS)
            ENTRY.IDS=SORT(ENTRY.IDS)
            ENT.LIST=FIELDS(ENTRY.IDS,'#',3)
			
    END CASE

*
RETURN
*
END
*
