* @ValidationCode : MjoxMjA4NDgyMzMwOkNwMTI1MjoxNzEyODk3NzkxNDk4OjIxMTcwNzg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAyMzEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 12 Apr 2024 10:26:31
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

*--------------------------------------------------------------------------------------------------

SUBROUTINE JB.R.PP.RECEIVERBIC.INP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*----------------------------------------------------------------------------------------------
* 16/04/24    LAKSHMI PRIYA K.S                         CBPAY-98                Defaulting receiver BIC based on the Credit Nostro Account
* 5/12/24     Resmi R                                   CBPAY-847	        Included the logic for defaulting RECEIVER.BIC from PP.PREFERREDCORRESPONDENT>CORR.ID when the PAYMENT.ORDER.PRODUCT is 'OT03'
* 28/03/25    Prabhu D S                                CBPAY-2193              Update ReceiverBIC when Payment Currency changed.
* 07/05/25    Prabhu D S                                CBPAY-2653              Included logic to handle RECEIVER.BIC value for HKCHATS payments
* 29/05/25    Prabhu D S                                CBPAY-3117              Receiver BIC should not be mapped only for HKCHATS payments
* 11/06/25    Prabhu D S                                CBPAY-3238              Defaulting receiver BIC logic included to OTSA
* 28/06/25    Prabhu D S                                CBPAY-2677              Included logic to handle Value date
*-------------------------------------------------------------------------------------------------------------------------------------

    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PI.Contract
    $USING PP.RoutingAndSettlementService
    
    GOSUB INIT
    GOSUB PROCESS

RETURN

INIT:
*****

    SelCmd=''
    SelList=''
    SelCount=''
    REC.ID=''
    R.LN=''
    YN.OWNING.BIC=''
    
    FN.PO='F.PAYMENT.ORDER'; F.PO=''
    EB.DataAccess.Opf(FN.PO, F.PO)
    
    FN.LN='F.PP.LORO.NOSTRO.ACCOUNT'; F.LN=''
    EB.DataAccess.Opf(FN.LN, F.LN)
    
    FN.PREFCORR = 'F.PP.PREFERREDCORRESPONDENT' ; F.PREFCORR = ''
    EB.DataAccess.Opf(FN.PREFCORR, F.PREFCORR)
    

   CreditNostroAccount = '' ; PaymentProduct = '' ; AcctWithBankBic = ''
   PaymentCurrency = ''     ; ReceiverBic = '' ; OrderInitType = ''

   CALL GET.LOC.REF("PAYMENT.ORDER","L.PO.HKPAY.CHNL",PO.HKPAYCHNL.POS)
	
RETURN

PROCESS:
*******

* Receiver BIC should not get defaulted for HKCHATS payments, so do a check and return.
    IF EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoLocalRef)<1,PO.HKPAYCHNL.POS> EQ "HKCHATS" THEN RETURN

    CreditNostroAccount = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoCreditNostroAccount)
    PaymentProduct      = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoPaymentOrderProduct)
    AcctWithBankBic     = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoAcctWithBankBic)
    PaymentCurrency     = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoPaymentCurrency)
    ReceiverBic         = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoReceiverBic)
    OrderInitType       = EB.SystemTables.getRNew(PI.Contract.PaymentOrder.PoOrderInitiationType)
        
                
        BEGIN CASE

            CASE PaymentProduct EQ 'TRSY' AND OrderInitType EQ 'MXCHATS'
                EB.SystemTables.setRNew(PI.Contract.PaymentOrder.PoReceiverBic, '')
            
            CASE CreditNostroAccount NE ''
                GOSUB GET.RCVR.BIC.FRM.LORONOSTRO
            
            CASE CreditNostroAccount EQ '' AND AcctWithBankBic NE '' AND PaymentProduct MATCHES 'OT03':@VM:'OTSA' AND OrderInitType MATCHES 'POA':@VM:'STO'
                GOSUB GET.RCVR.BIC.FRM.PREFCORR
                	 
    	END CASE

  
RETURN

  
GET.RCVR.BIC.FRM.LORONOSTRO:
********************************
* If CreditNostroAccount is provided then populate ReceiverBIC from LoroNostro setup for CreditNostroAccount

    SelCmd = "SELECT ":FN.LN:" WITH AccountNumber EQ ":CreditNostroAccount
    EB.DataAccess.Readlist(SelCmd, SelList, '', SelCount, '')
    LOOP
        REMOVE REC.ID FROM SelList SETTING REC.POS
    WHILE REC.ID : REC.POS
        EB.DataAccess.FRead(FN.LN, REC.ID, R.LN, F.LN, '')
        Y.PP.LORO.ACCTS = R.LN<PP.RoutingAndSettlementService.LoroNostroAccount.LnaAccountnumber>
        LOCATE CreditNostroAccount IN Y.PP.LORO.ACCTS<1,1> SETTING ACCT.POS THEN
            YN.OWNING.BIC = R.LN<PP.RoutingAndSettlementService.LoroNostroAccount.LnaOwningbic,ACCT.POS>
            EB.SystemTables.setRNew(PI.Contract.PaymentOrder.PoReceiverBic, YN.OWNING.BIC)
        END
    REPEAT
 
          
RETURN

GET.RCVR.BIC.FRM.PREFCORR:
**************************
* If CreditNostroAccount not provided then check AcctWithBankBIC provided is already a preferrred correspondent, if not then
* populate ReceiverBIC with preferred correspondent for Payment Currency
	
    SelPref = "SELECT ":FN.PREFCORR:" WITH TransactionCurrency EQ ":PaymentCurrency
    EB.DataAccess.Readlist(SelPref, SelPrfId, '', PrefCount, '')
    EB.DataAccess.FRead(FN.PREFCORR, SelPrfId, R.PREFCORR, F.PREFCORR, '')
    CorrID = R.PREFCORR<PP.RoutingAndSettlementService.Preferredcorrespondent.PctCorrespondentID>

    IF AcctWithBankBic NE CorrID THEN
       EB.SystemTables.setRNew(PI.Contract.PaymentOrder.PoReceiverBic, CorrID) 
    END

RETURN

**************************************
END

