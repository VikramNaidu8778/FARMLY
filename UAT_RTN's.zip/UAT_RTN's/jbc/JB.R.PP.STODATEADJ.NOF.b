SUBROUTINE JB.R.PP.STODATEADJ.NOF(OUT.ARR)

*----------------------------------------------------------------------------------------------------------------------------
*Attached in : Enquiry > JB.E.PP.STO.DATEADJLIST as nofile routine . 
*Attached in : Enquiry attached as dropdown for versions STANDING.ORDER,JB.V.PP.STOACAC.INP , STANDING.ORDER,JBSG.V.AC.STOOT03
*STANDING.ORDER,JBSG.V.AC.STOOT03OT12 , STANDING.ORDER,JBHK.V.AC.STOOT03 , STANDING.ORDER,JBHK.V.AC.STOOT03OT12
*-----------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------
*   Date          Developer          Reference         Description
* 26-03-2025   Lakshmi Priya       CBPAY - 1935   Dropdown Enquiry to list only Preceding and following options 
*                                                  in the field Date Adjustment on STO Input Versions.
*------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON

    LOCATE 'DATE.ADJUSTMENT' IN D.FIELDS<1> SETTING ID.POS THEN
        OUT.ARR = FIELD(D.RANGE.AND.VALUE<ID.POS>,'.',1)
    END ELSE
        OUT.ARR = "PRECEDING":FM:"FOLLOWING"
    END

RETURN
END
