* @ValidationCode : MTotMjY3NjIzOTE3OklTTy04ODU5LTE6MTU0NjU4MDA0NzU1MjphNDUzMjg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 04 Jan 2019 13:34:07
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
SUBROUTINE JBWW.B.FT.SAPPAYMENTPOST(Y.OFS.MSG)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*
* 01-10-2018 - P3369-249 - Sakthivel S
*              Interface Multi threaded routine to POST FT entries which was sent from SAP
*
* 24-10-2018 - P3369-279 - Tony Charles
*              Notification alert logic removed
*
* 24-12-2018        Sakthivel S           P3369-665                For placing Asian currency FT's in INAU as per Tranche 1.2
*
* 04 Sep 2023       P Amala               GBLBB-313                Call new common API to get the status,Transaction ID,Error MESSAGE
*                                                                  Error OFS response and complete OFS response from the OFS response message. 

*-----------------------------------------------------------------------------
* <region = Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.JBWW.H.XX.FINANCELOG
    $INSERT I_JBWW.B.FT.SAPPAYMENTPOST.COMMON
    $INSERT I_GTS.COMMON
    $INSERT I_F.COMPANY
    $INSERT I_BATCH.FILES
* </region>
*-----------------------------------------------------------------------------
* <region name= Main para>

    GOSUB INIT
    GOSUB PROCESS


RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Initialise>
INIT:
* To Initialise the necessary variables
    Y.FILE.NAME = CONTROL.LIST<1,1>
    R.FILE.OFS.MSGS = '' ; FILE.READ.ERR = ''
    Y.TRIM.FILE.NAME2 = TRIM(Y.FILE.NAME,"_","A")
    Y.TRIM.FILE.NAME = FIELD(Y.TRIM.FILE.NAME2,".",1)
RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Process>
PROCESS:
* To process the OFS message from SAP
    Y.OFS.RESP = '' ; REQ.COMM = ''
    Y.SAVE.OFS.SRC = OFS$SOURCE.ID
    OFS$SOURCE.ID = Y.OFS.SRC.ID
    GOSUB CHECK.ASIAN.CURRENCY
    Y.REQ.MSG = Y.OFS.MSG
    CALL OFS.CALL.BULK.MANAGER(Y.OFS.SRC.ID,Y.OFS.MSG,Y.OFS.RESP,REQ.COMM)
* GBLBB-313 START
    Y.OFS.RESPONSE = Y.OFS.RESP
    OFS.ERR.RESPONSE = ""
    Y.FT.ID = ""
    ERROR.FLAG = ""
    Y.ERROR.MSG = ""
    CALL JB.R.EB.OFSRESPONSEPARSE(Y.OFS.RESPONSE,OFS.ERR.RESPONSE, Y.FT.ID, ERROR.FLAG, Y.ERROR.MSG,'')
* GBLBB-313 END
    GOSUB UPDATE.LOG
    OFS$SOURCE.ID = Y.SAVE.OFS.SRC

    GOSUB MOVE.FILES

RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= LOG update>
UPDATE.LOG:
* To update the JBWW.H.XX.FINANCELOG file with the OFS response for each OFS message

* GBLBB-313 START
    R.DC.LOG = ''
*    RESPONSE.HEADER = FIELD(Y.OFS.RESP,',',1)
*    Y.FT.ID = FIELD(Y.OFS.RESP,'/',1)
*    ERROR.FLAG = FIELD(RESPONSE.HEADER, '/',3)
* GBLBB-313 END
    GET.DATE.TIME = TIMEDATE()
    CHANGE ':' TO '' IN GET.DATE.TIME
    GET.DATE.TIME = TODAY : GET.DATE.TIME[1,6]

    IF ERROR.FLAG < 0 THEN
        R.DC.LOG<FIN.ERR.STATUS>   = "ERROR"
    END ELSE
        R.DC.LOG<FIN.ERR.STATUS>   = "PROCESSED"
    END

    Y.SAP.ORIG.REF = '' ; Y.LEN.OFS = '' ; Y.FLD.STRING.POS = ''
    Y.FLD.STRING = '' ; Y.FLD.VALUE1 = '' ;

    Y.LEN.OFS = LEN(Y.REQ.MSG)
    Y.FLD.STRING.POS = INDEX(Y.REQ.MSG,"L.XX.ORIG.REF",1)
    Y.FLD.STRING =  Y.REQ.MSG[Y.FLD.STRING.POS,Y.LEN.OFS]
    Y.FLD.VALUE1 = FIELD(Y.FLD.STRING,",",1)
    Y.SAP.ORIG.REF = FIELD(Y.FLD.VALUE1,"=",2)
    Y.SAP.ORIG.REF = TRIM(Y.SAP.ORIG.REF,'"',"A")

    R.DC.LOG<FIN.ERR.T24.APPL.NAME> = FIELD(Y.REQ.MSG,",",1)
    R.DC.LOG<FIN.ERR.TIME.DATE> = GET.DATE.TIME
    R.DC.LOG<FIN.ERR.REQ.MSG,-1> = Y.REQ.MSG
    R.DC.LOG<FIN.ERR.ERR.MSG,-1> = Y.OFS.RESP
    R.DC.LOG<FIN.ERR.EXTERNAL.REF> = Y.SAP.ORIG.REF
    R.DC.LOG<FIN.ERR.DATE.TIME> = GET.DATE.TIME[3,LEN(GET.DATE.TIME) - 4]
    R.DC.LOG<FIN.ERR.CURR.NO> = 1
    R.DC.LOG<FIN.ERR.INPUTTER> = OPERATOR:'_':OFS$SOURCE.ID
    R.DC.LOG<FIN.ERR.AUTHORISER> = OPERATOR:'_':OFS$SOURCE.ID
    R.DC.LOG<FIN.ERR.DEPT.CODE> = 1

    FLUSH.IT = ''
    IF Y.FT.ID[1,2] NE 'FT' THEN
        Y.UNIQUE.NO = ''
        CALL ALLOCATE.UNIQUE.TIME(Y.UNIQUE.NO)
        Y.FT.ID = TNO:Y.UNIQUE.NO
    END

    Y.FINLOG.ID = 'SAP-':Y.TRIM.FILE.NAME:'-':TODAY:'-':Y.FT.ID
    CALL LOG.WRITE(F.JBWW.H.XX.FINANCELOG, Y.FINLOG.ID, R.DC.LOG, FLUSH.IT)

    IF Y.FT.ID[1,2] EQ 'FT' THEN
        FLUSH.IT = ''
        CALL LOG.WRITE(F.JBWW.T.XX.SAPFINLOG, Y.FT.ID, Y.FINLOG.ID, FLUSH.IT)
    END

RETURN

* </region>
*-----------------------------------------------------------------------------
* <region name= Asian Currency Check>
CHECK.ASIAN.CURRENCY:

    Y.APP.VERS = FIELD(Y.OFS.MSG,"/",1)

    IF Y.APP.VERS[32,4] NE 'OTSA' THEN
        RETURN
    END

    Y.DR.CCY = '' ; Y.LEN.OFS = '' ; Y.FLD.STRING.POS = ''
    Y.FLD.STRING = '' ; Y.FLD.VALUE1 = '' ;
    Y.LEN.OFS = LEN(Y.OFS.MSG)
    Y.FLD.STRING.POS = INDEX(Y.OFS.MSG,"DEBIT.CURRENCY",1)
    Y.FLD.STRING =  Y.OFS.MSG[Y.FLD.STRING.POS,Y.LEN.OFS]
    Y.FLD.VALUE1 = FIELD(Y.FLD.STRING,",",1)
    Y.DR.CCY = FIELD(Y.FLD.VALUE1,"=",2)
    Y.DR.CCY = TRIM(Y.DR.CCY,'"',"A")

    IF Y.DR.CCY MATCHES Y.ASN.CCY.LIST THEN
        Y.OFS.HDR = FIELD(Y.OFS.MSG,",",1,2)
        Y.COMMA.CNT = DCOUNT(Y.OFS.MSG,",")
        Y.OFS.MSG.BODY = FIELD(Y.OFS.MSG,",",3,Y.COMMA.CNT)
        Y.SLASH.CNT = DCOUNT(Y.OFS.HDR,"/")
        Y.ADD.SLASH.CNT = 5-Y.SLASH.CNT
        Y.CUR.SLASH.CNT = 1
        LOOP
        WHILE Y.CUR.SLASH.CNT LE Y.ADD.SLASH.CNT
            Y.OFS.HDR = Y.OFS.HDR:"/"
            Y.CUR.SLASH.CNT = Y.CUR.SLASH.CNT + 1
        REPEAT
        Y.OFS.HDR = Y.OFS.HDR:"1"
        Y.OFS.MSG = Y.OFS.HDR:",":Y.OFS.MSG.BODY
    END

RETURN

* </region>
*-----------------------------------------------------------------------------
* <region name= Archive file>
MOVE.FILES:
* To move the processed files from 'in' folder to 'done' folder

    MOVE.CMD = "SH -c mv ":FN.FILE.PATH:"/":Y.FILE.NAME:" ":FN.ARC.PATH
    EXECUTE MOVE.CMD

RETURN

* </region>
*-----------------------------------------------------------------------------
END
