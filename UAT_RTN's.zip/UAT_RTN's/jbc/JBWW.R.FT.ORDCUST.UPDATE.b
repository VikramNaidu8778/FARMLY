* @ValidationCode : MTo1MTAzMDQ2MjU6SVNPLTg4NTktMToxNTQ1NjU0MTgxNDU0OmE0NTMyODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 24 Dec 2018 20:23:01
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.ORDCUST.UPDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* Date               who                  Reference                 Description
* 24-12-2018        Sakthivel S           JIRA-P3369                Auto new content routine attached 
*                                                                   to update the ORDERING.CUST in SAP FT's record.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:
* To Initialise variables and to open necessary files.
    R.NEW(FT.ORDERING.CUST) = ''
    RETURN

PROCESS:
*To update the ORDERING.CUST in SAP FT's record.
    R.NEW(FT.ORDERING.CUST)<1,-1> = "BANK JULIUS BAER AND CO LTD"
    BEGIN CASE
    CASE ID.COMPANY[1,2] EQ 'SG'
    R.NEW(FT.ORDERING.CUST)<1,-1> = "7 STRAITS VIEW HEX 28-01 MARINA ONE"
    R.NEW(FT.ORDERING.CUST)<1,-1> = "EAST TOWER SINGAPORE 018936"
    CASE ID.COMPANY[1,2] EQ 'HK'
    R.NEW(FT.ORDERING.CUST)<1,-1> = "39/F,ONE INTERNATIONAL FINANCE CTR"
    R.NEW(FT.ORDERING.CUST)<1,-1> = "1 HARBOUR VIEW ST,CENTRAL,HONG KONG"
    END CASE

    RETURN

    END
