* @ValidationCode : MToxOTA3NzE0MTM6SVNPLTg4NTktMToxNjU4NzQzODU1MjUwOmE0MDc3MDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 25 Jul 2022 18:10:55
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a40770
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.XX.ADVRECFTUPD.AUTH
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 10-Apr-2022       Suresh D    T24-17351        Update the FT key in Adv recon concat table.
*-----------------------------------------------------------------------------
    $INSERT I_EQUATE
    $INSERT I_COMMON
    $INSERT I_F.DATES
    $INSERT I_F.VERSION
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.L.XX.ADVRECON.CONCAT
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
    
RETURN
INIT:
*****
    FN.JBWW.L.XX.ADVRECON.CONCAT = 'F.JBWW.L.XX.ADVRECON.CONCAT'
    F.JBWW.L.XX.ADVRECON.CONCAT = ''
    CALL OPF(FN.JBWW.L.XX.ADVRECON.CONCAT,F.JBWW.L.XX.ADVRECON.CONCAT)
    
    FN.JBWW.GEN.PARAM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.GEN.PARAM = ''
    CALL OPF(FN.JBWW.GEN.PARAM,F.JBWW.GEN.PARAM)
    
    ADVRECON.PARAM = 'JBWW.ADVRECON.EXT'
    CALL F.READ(FN.JBWW.GEN.PARAM,ADVRECON.PARAM,R.ADVRECON.PARAM,F.JBWW.GEN.PARAM,ADV.ERR)
    PARAM.FLD.NAMES = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    
    FT.TRANS.VAL = 'FT.TRANS.TYPE'
    LOCATE FT.TRANS.VAL IN PARAM.FLD.NAMES<1,1> SETTING FT.POS THEN
        FT.TRANS.VALS = R.ADVRECON.PARAM<JBWW.GEN.PAR.FIELD.VALUE><1,FT.POS>
    END
    CHANGE ',' TO VM IN FT.TRANS.VALS
    CHANGE SM TO VM IN FT.TRANS.VALS

RETURN
PROCESS:
********
    FUNCTION.VAL  = V$FUNCTION
    STATUS.VAL    = R.NEW(FT.RECORD.STATUS)
    CURR.NO.VAL   = R.NEW(FT.CURR.NO)
    NO.AUTH.VAL   = R.VERSION(EB.VER.NO.OF.AUTH)
    TRANSACTION.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    IF (FUNCTION.VAL EQ 'I' AND NO.AUTH.VAL EQ '0') OR FUNCTION.VAL EQ 'A' THEN    
        LOCATE TRANSACTION.TYPE IN FT.TRANS.VALS<1,1> SETTING FTW.POS THEN
            TXN.REF = ID.NEW
            R.FT = '' ; FTW.ERR = ''
            CALL F.READ(FN.JBWW.L.XX.ADVRECON.CONCAT,TXN.REF,R.JBWW.L.XX.ADVRECON.CONCAT,F.JBWW.L.XX.ADVRECON.CONCAT,FTW.ERR)
            IF NOT(R.JBWW.L.XX.ADVRECON.CONCAT) THEN
                IF RUNNING.UNDER.BATCH EQ '1' THEN
	                PROCESS.DATE = R.DATES(EB.DAT.TODAY)
                END ELSE
                    PROCESS.DATE = TODAY
                END
                R.ADVREC.ARRAY<ADV.RECON.T24.CREATION.DT> = PROCESS.DATE
                CALL F.WRITE(FN.JBWW.L.XX.ADVRECON.CONCAT,TXN.REF,R.ADVREC.ARRAY)
            END
        END
    END

RETURN
END
