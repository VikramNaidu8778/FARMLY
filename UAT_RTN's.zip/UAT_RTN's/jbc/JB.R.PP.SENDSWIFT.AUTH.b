SUBROUTINE JB.R.PP.SENDSWIFT.AUTH
*--------------------------------------------------------------------------------------------------
* This is an Auth routine to update SEND SWIFT Option for Order Entry Payments
*---------------------------------------------------------------------------------------------------
**Modification History :
*----------------------------------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  13-DEC-2024   Prabhu D S         CBPAY- 1437      Attached in MT200 Version (PP.ORDER.ENTRY,JB.V.PP.NOSTRO200.INP) 
*                                                    to update SEND SWIFT Option for Order Entry Payments
*------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.PP.POR.EXTENSION
    $USING PP.PaymentLifecycleHook

    Y.SEND.SWIFT = ''
    Y.FT.NUM = ''
    R.PP.POR.EXTENSION = ''
    
    F.PP.POR.EXTENSION = 'F.PP.POR.EXTENSION'
    FN.PP.POR.EXTENSION = ''
    CALL OPF(F.PP.POR.EXTENSION,FN.PP.POR.EXTENSION)
    LOCATE 'L.PP.SEND.PYMT' IN R.NEW(PP.OEYG.LocalFieldName)<1,1> SETTING Y.POS THEN
    
        Y.SEND.SWIFT = R.NEW(PP.OEYG.LocalFieldValue)<1,Y.POS>
    END
    Y.FT.NUM = R.NEW(PP.OEYG.TransactionReferenceNumber)
    
    IF Y.SEND.SWIFT EQ 'NO' THEN
        R.PP.POR.EXTENSION<PP.PaymentLifecycleHook.PorExtension.ExtHoldMessage> = 'Y'
        CALL F.WRITE(FN.PP.POR.EXTENSION,Y.FT.NUM,R.PP.POR.EXTENSION)
    END
RETURN

END

