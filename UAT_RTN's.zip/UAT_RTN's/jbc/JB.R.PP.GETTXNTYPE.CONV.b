* @ValidationCode : MjotMzQ3NDI5NzQ0OkNwMTI1MjoxNzE1MTQ4NTA1Mjc0OjkxNDgxNTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDIzMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 19 Dec 2024 11:38:25
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202408.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

SUBROUTINE JB.R.PP.GETTXNTYPE.CONV
*-----------------------------------------------------------------------------
* Description :
* Routine is attached in Enquiry JBSG.E.PP.PAYPENPROCESS.LIST/JBHK.E.PP.PAYPENPROCESS.LIST to extract the transaction
* type from POR.SUPPLEMENTARY.INFO.
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date           Developer              Reference           Description
*
* 14-Mar-20025   P Amala                CBPAY-75            Initial Draft
* 10-Jun-20025   P Amala                CBPAY-3002          Fix to display transaction type for ORRT/IRRT/IRRJ/IT/ORRJ/ITCV/ITSL
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
	$USING PP.PaymentSTPFlowService
    $USING EB.SystemTables
	$USING PP.PaymentWorkflowDASService
    $USING PP.PaymentWorkflowGUI
    $USING EB.DataAccess
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $USING PP.PaymentFrameworkService
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $USING PP.StaticDataGUI
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
	  
RETURN
*
*-----------------------------------------------------------------
INIT:
*****

    ftNumber = '' ; Y.TXN.TYPE = '' ; yValdationFlag = ''
    yPaymentDirection = '' ; yTransactionType = '' ; yMessageType = ''
	Y.PI.INF.CODE = '' ; Y.PP.LOC.FLD.NAME = '' ; Y.INW.FLD.POS = ''
	
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    EB.DataAccess.Opf(FN.POR.TRANSACTION, F.POR.TRANSACTION)

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    EB.DataAccess.Opf(FN.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO)

    FN.GENERICPARAM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.GENERICPARAM = ''
    EB.DataAccess.Opf(FN.GENERICPARAM,F.GENERICPARAM)
	
	CALL F.READ(FN.GENERICPARAM,'JB.D.PP.TPH.CONFIG',R.GP,F.GENERICPARAM,'')
    Y.GPM.FIELDNAMES = R.GP<JBWW.GEN.PAR.FIELD.NAME>
    
    CHANGE @SM TO @VM IN Y.GPM.FIELDNAMES
    
    LOCATE 'TIS.MSGTYPE' IN Y.GPM.FIELDNAMES<1,1> SETTING MSGTYP.POS THEN
        TIS.MSGTYPE = R.GP<JBWW.GEN.PAR.FIELD.VALUE,MSGTYP.POS>
    END

    LOCATE 'TIS.TXNCODE' IN Y.GPM.FIELDNAMES<1,1> SETTING CODE.POS THEN
        TIS.TXNCODE = R.GP<JBWW.GEN.PAR.FIELD.VALUE,CODE.POS>
    END
    
    CHANGE @SM TO @VM IN TIS.MSGTYPE
    CHANGE @SM TO @VM IN TIS.TXNCODE
    CHANGE @FM TO @VM IN TIS.MSGTYPE
    CHANGE @FM TO @VM IN TIS.TXNCODE
    CHANGE ',' TO @VM IN TIS.MSGTYPE
    CHANGE ',' TO @VM IN TIS.TXNCODE
	
RETURN
*
*--------------------------------------------------------------------------
PROCESS:
********
 
	ftNumber = O.DATA
    PP.PaymentWorkflowGUI.getSupplementaryInfo('POR.PAYMENTFLOWDETAILS', ftNumber,'LOCK',R.POR.GET.SUPPLEMENTARY.INFO, Error)

    Y.PP.LOC.FLD.NAME = R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldname>
   
    LOCATE 'L.PP.DEF.INW.IT' IN Y.PP.LOC.FLD.NAME<1,1> SETTING Y.INW.FLD.POS THEN
        Y.TXN.TYPE = R.POR.GET.SUPPLEMENTARY.INFO<PP.PaymentWorkflowGUI.PorPaymentflowdetails.Locfieldvalue,Y.INW.FLD.POS>
    END
    
    IF Y.TXN.TYPE EQ '' THEN
	
    EB.DataAccess.FRead(FN.POR.TRANSACTION,ftNumber,R.POR.TRANSACTION,F.POR.TRANSACTION,ERR.POR.TRN)
    yPaymentDirection = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxPaymentdirection>
    yTransactionType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxClearingtransactiontype>
        
    IF (yPaymentDirection EQ 'I') OR (yPaymentDirection EQ 'B') THEN
        yMessageType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxIncomingmessagetype>

    END ELSE
        BEGIN CASE

            CASE yTransactionType EQ 'RT'
                yMessageType = 'pacs.004'
       
            CASE yTransactionType EQ 'RJ'
                yMessageType = 'pacs.002'

        END CASE
    END
          
    yValdationFlag = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxValidationflag>

    Y.PI.INF.CODE = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INFORMATIONCODE>

    LOCATE 'INSSDR' IN Y.PI.INF.CODE<1,1> SETTING Y.PI.INF.POS THEN
        Y.PI.INF.LINE = R.POR.GET.SUPPLEMENTARY.INFO<PORID.PI.INFORMATION.LINE,Y.PI.INF.POS>
        Y.PI.INF.LINE  = FIELD(Y.PI.INF.LINE,"/",3)
        Y.PI.INF.LINE  = Y.PI.INF.LINE [1,3]
    END
	
    Y.PP.MSG.DIR = yMessageType:"_":yPaymentDirection
    
    LOCATE Y.PP.MSG.DIR IN TIS.MSGTYPE<1,1> SETTING Y.POS THEN
        Y.TXN.TYPE =  TIS.TXNCODE<1,Y.POS>
    END
	
    IF yMessageType EQ 'pacs.009' THEN
        BEGIN CASE
            CASE  yValdationFlag EQ 'COV'
                Y.TXN.TYPE = FIELD(Y.TXN.TYPE,"_",1)

            CASE Y.PI.INF.LINE EQ 'SLB'
                Y.TXN.TYPE = FIELD(Y.TXN.TYPE,"_",2)

        END CASE
    END
	END
	
	yMessageType = R.POR.TRANSACTION<PP.PaymentWorkflowDASService.PorTransaction.PpptxIncomingmessagetype>
	IF Y.TXN.TYPE THEN
       O.DATA = Y.TXN.TYPE
	END ELSE
	   O.DATA = yMessageType
	END
	
RETURN
*--------------------------------------------------------------------------
END