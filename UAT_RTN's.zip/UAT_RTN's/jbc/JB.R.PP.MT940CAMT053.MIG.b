SUBROUTINE JB.R.PP.MT940CAMT053.MIG
*-----------------------------------------------------------------------------
* One Time Migration Routine to Modify the DE.PRODUCT Carrier from SWIFT.2(MT940) to
* SWIFTXML.2 for CAMT.053 Conversion.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 10-Mar-2025   Kandan         CBPAY-2124         Initial Draft
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.PRODUCT
    
    GOSUB INIT
    GOSUB PROCESS
    
RETURN
   
*----
INIT:
*----

    FN.DE.PRODUCT = 'F.DE.PRODUCT'
    F.DE.PRODUCT = ''
    CALL OPF(FN.DE.PRODUCT,F.DE.PRODUCT)

RETURN

*-------
PROCESS:
*-------
   
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.REC = '' ; ERR.LIST = '' ;
    SEL.ID =  ID.COMPANY:'.C...940.ALL'
    SEL.CMD = "SELECT ":FN.DE.PRODUCT:" WITH @ID LIKE ": SEL.ID
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.LIST)
  
    LOOP
        REMOVE SEL.ID FROM SEL.LIST SETTING SEL.POS
    WHILE SEL.ID:SEL.POS
        R.DE.PRODUCT = '' ; ERR.DE.PRODUCT = '' ;
        CALL F.READ(FN.DE.PRODUCT,SEL.ID,R.DE.PRODUCT,F.DE.PRODUCT,ERR.DE.PRODUCT)
        IF R.DE.PRODUCT THEN
            R.DE.PRODUCT<DE.PRD.CARR.ADD.NO> = 'SWIFTXML.2'
            GOSUB POST.OFS
        END
    REPEAT
    
RETURN
*--------
POST.OFS:
*--------
    Y.OFS.APP.NAME = "DE.PRODUCT"
    Y.OFS.PROCESS = "PROCESS"
    Y.OFS.FUNCTION = "I"
    Y.OFS.VERSION = "DE.PRODUCT,RECON.DEPRODUCT.BJB"
    Y.OFS.SOURCE = 'JBWW.DA.VAL.OFS.POST'
    Y.OFS.GTS = '1'
    Y.OFS.NO.OF.AUTH = '0'
  
    CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.FUNCTION,Y.OFS.PROCESS,Y.OFS.VERSION,Y.OFS.GTS,Y.OFS.NO.OF.AUTH,SEL.ID,R.DE.PRODUCT,getOfsRecord)
    CALL OFS.POST.MESSAGE(getOfsRecord,Y.RET.OFS.MSG,Y.OFS.SOURCE,'')
   
RETURN
*-----------------------------------------------------------------------------------------------------------
END
