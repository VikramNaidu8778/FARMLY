* @ValidationCode : MToyMTY5NzY3MDM6SVNPLTg4NTktMToxNTQ3NjE5ODM2MjUyOmE0NTMyODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 16 Jan 2019 14:23:56
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a45328
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.CCYHOLIDAY.CHK
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 24-12-2018        Sakthivel S           JIRA-P3369                Input routine attached
*                                                                   to check whether value date is on currency holiday
*
* 16-01-2019        Sakthivel S           JIRA-P3369                To fix the Working day error issue
*                                                                   
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN


INIT:
* To Initialise variables and to open necessary files.
    Y.DR.VAL.DT = '' ; Y.CCY.REGION = '' ; Y.CHK.DATE = ''
    Y.CR.VAL.DT = '' ;

    RETURN

PROCESS:
* To check whether value date is on currency holiday

    Y.DR.VAL.DT = R.NEW(FT.DEBIT.VALUE.DATE)

    Y.CCY.REGION = R.NEW(FT.DEBIT.CURRENCY)[1,2]

    Y.CHK.DATE = Y.DR.VAL.DT
    Y.RET = ''
    IF Y.CHK.DATE THEN
       CALL WORKING.DAY('',Y.CHK.DATE,'','','',Y.CCY.REGION,'','',Y.RET,'')
    END

    IF Y.RET NE "0" THEN
        AF = FT.DEBIT.VALUE.DATE
        ETEXT = "SC-DATE.HOLIDAY"
        CALL STORE.END.ERROR
    END


    Y.CR.VAL.DT = R.NEW(FT.CREDIT.VALUE.DATE)
    Y.CHK.DATE = Y.CR.VAL.DT
    Y.RET = ''
    IF Y.CHK.DATE THEN
       CALL WORKING.DAY('',Y.CHK.DATE,'','','',Y.CCY.REGION,'','',Y.RET,'')
    END

    IF Y.RET NE "0" THEN
        AF = FT.CREDIT.VALUE.DATE
        ETEXT = "SC-DATE.HOLIDAY"
        CALL STORE.END.ERROR
    END

    RETURN
    END
