*-----------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.ORDINITTYPE.INPUT
*-----------------------------------------------------------------------------------------------------
* This is the input routine attached to the version PAYMENT.ORDER,JB.V.PP.NOSTRO202.INP
*-------------------------------------------------------------------------------------------------------------------------------------------------------
* 03-Jul-2025     u40786            CBPAY-3403     Initial Version
*                                                  Copy of the routine JB.R.PP.ORDINITIATION.TYPE.b
*
*--------------------------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB INIT
    GOSUB READ.GPM
    GOSUB PROCESS
*
RETURN
*
INIT:
*****

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    Y.ORD.INIT.TYPE = '' ; Y.PAYMENT.CURRENCY = '' ; Y.ORDER.TYPE = ''
    R.GENERICPARAMETER = '' ; Y.GPM.FIELD.NAMES = '' ; Y.GPM.FIELD.VALUES = ''

   CALL GET.LOC.REF('PAYMENT.ORDER','L.PO.HKPAY.CHNL',Y.POS)

    Y.PAY.CCY = R.NEW(PO.PAYMENT.CURRENCY)
    Y.ORDER.TYPE = R.NEW(PO.ORDER.TYPE)
   Y.ORDERING.REF = R.NEW(PO.ORDERING.REFERENCE)
*
RETURN
*
READ.GPM:
*********

   Y.GPM.FIELD.NAMES = "HKCHATS_CCY_":UPCASE(Y.ORDER.TYPE):"_MXCHATS"
   CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.GPM.FIELD.NAMES,Y.GPM.FIELD.VALUES)
           
   Y.GPM.CCY = FIELD(Y.GPM.FIELD.VALUES,"_",2)
   CHANGE ',' TO @VM IN Y.GPM.CCY
* 
RETURN
*
PROCESS:
********

    IF Y.PAY.CCY MATCHES Y.GPM.CCY THEN
            BEGIN CASE
                CASE R.NEW(PO.LOCAL.REF)<1,Y.POS> EQ 'HKCHATS' AND Y.ORDERING.REF EQ ''
                    R.NEW(PO.ORDER.INITIATION.TYPE) = 'MXCHATS'
                    Y.ORD.INIT.TYPE = 'MXCHATS'
                    GOSUB DEFAULT.CATEG.PURP.CODE
                CASE R.NEW(PO.LOCAL.REF)<1,Y.POS> EQ 'SWIFTMX' AND Y.ORDERING.REF EQ ''
                     R.NEW(PO.ORDER.INITIATION.TYPE) = 'POA'
                     R.NEW(PO.PAYMENT.CATEGORYPURP.PRTY) = ''
                CASE R.NEW(PO.LOCAL.REF)<1,Y.POS> EQ 'HKCHATS' AND Y.ORDERING.REF NE ''
                    GOSUB DEFAULT.CATEG.PURP.CODE                
       END CASE
    END ELSE
         R.NEW(PO.PAYMENT.CATEGORYPURP.PRTY) = ''
   END
*
RETURN
*
DEFAULT.CATEG.PURP.CODE:
************************

      Y.HKCHATS.PRTY = FIELD(Y.GPM.FIELD.VALUES,"_",1)

      Y.HKCHATS.CCY = FIELD(Y.GPM.FIELD.VALUES,"_",2)

      CHANGE "," TO @VM IN Y.HKCHATS.CCY

    IF Y.PAY.CCY MATCHES Y.HKCHATS.CCY THEN
       R.NEW(PO.PAYMENT.CATEGORYPURP.PRTY) = Y.HKCHATS.PRTY
    END

RETURN
*
END
*