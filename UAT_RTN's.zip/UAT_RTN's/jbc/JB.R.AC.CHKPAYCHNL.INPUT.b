SUBROUTINE JB.R.AC.CHKPAYCHNL.INPUT
*----------------------------------------------------------------------------------------------------------------------------------
*This is the Input routine attached to Versions STO to raise error based on payment currency and payment channel 
*and Payment Channel.
*
*-----------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-----------------------------------------------------------------------------------------------------------------------------------
*06/08/2024   LAKSHMI PRIYA KS               CBPAY-439           Based on the PAYMENT.CURRENCY and PAYMENT.CHANNEL ,
*                                                                         Error is Raised.
*
*------------------------------------------------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE 
    $INSERT I_F.STANDING.ORDER

    Y.PAY.CCY = R.NEW(STO.CURRENCY)
 
    CALL GET.LOC.REF('STANDING.ORDER','L.PO.HKPAY.CHNL',Y.POS)

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","ORD.INIT.TYPE.CURRENCY",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE

    IF NOT(Y.PAY.CCY MATCHES Y.GPM.VALUE) AND NOT(R.NEW(STO.LOCAL.REF)<1,Y.POS> EQ 'SWIFTMX') THEN 
       AF = (STO.LOCAL.REF)
       AV = Y.POS
       ETEXT = 'EB-JB.D.PP.CHKORDINIT.TYPE':@FM:Y.PAY.CCY
       CALL STORE.END.ERROR
    END
    
RETURN
 
END

