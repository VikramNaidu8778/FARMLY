* @ValidationCode : MTotMTk5MTM1Nzk4MjpJU08tODg1OS0xOjE1MTAyMjMzOTUwMjA6MzExODQ5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC43
* @ValidationInfo : Timestamp         : 09 Nov 2017 15:59:55
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 311849
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.DE.103.MAP(MAT DE.O.HANDOFF,ERR.MSG)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date          Developer                           Reference          Description
*-----------------------------------------------------------------------------
* 23/11/2017    Lakshmanan-2.V-2@cognizant.com      JIRA - 44224       Initial Version
* 04/12/2020    Senthil K                           P3636-5615         Updates for P3636-5615: CNYCNH - Retrofit
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER

    GOSUB OPN.FILES
    GOSUB INIT
    GOSUB PROCESS

RETURN

*---------
OPN.FILES:
*---------

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

RETURN

*----
INIT:
*----
    Y.AC.ID = R.NEW(FT.CREDIT.ACCT.NO)
    R.ACC.DET = ''

RETURN

*-------
PROCESS:
*-------
    DE.O.HANDOFF(9)<11> = ""
    CALL F.READ(FN.ACCOUNT,Y.AC.ID,R.ACC.DET,F.ACCOUNT,ACC.ERR)
    IF R.ACC.DET<AC.CUSTOMER> THEN
        DE.O.HANDOFF(2)<42> =  R.ACC.DET<AC.CUSTOMER>
    END

* CALL SGMB.CHG.SWF.CCY.OUT(MAT DE.O.HANDOFF,ERR.MSG) ;*P3636-5615
     
RETURN

END
*---------------------------------------------------------------------------------------------------------------------------------------------------------
