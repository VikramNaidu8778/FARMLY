* @ValidationCode : Mjo3Nzk5MTQ2MDk6Q3AxMjUyOjE2MDgwOTk3MzU5NDU6dTQ4NTcxOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTkwOC42Oi0xOi0x
* @ValidationInfo : Timestamp         : 16 Dec 2020 14:22:15
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : u48571
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201908.6
SUBROUTINE JBWW.R.FT.210.MAPPING.RTN(MAT HANDOFF.REC,ERR.MSG)

*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is the MAPPING routine, attached to DE.MAPPING>210.FT.1 ROUTINE field to map TAG 56 in 210 message.
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: HANDOFF.REC
* OUT: MAT HANDOFF.REC, ERR.MSG
*
* Revision History:
*------------------
* Date                Developer            Reference        Description
* 28/09/2017		  Balaji               JB2A-43056		To map TAG 56 in 210 message and Calling Core API (CNH to CNY conversion)
* 04/12/2020          Senthil K            P3636-5615       Updates for P3636-5615: CNYCNH - Retrofit
*-------------------------------------------------------------------------

	$INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
	
* CALL SGMB.CHG.SWF.CCY.OUT(MAT HANDOFF.REC,ERR.MSG);*P3636-5615
    GOSUB OPEN.FILES
	GOSUB PROCESS

*==================
OPEN.FILES:
*================
	
	FN.ACCOUNT = "F.ACCOUNT"
	F.ACCOUNT = ""
	CALL OPF(FN.ACCOUNT,F.ACCOUNT)

RETURN

*===========
PROCESS:
*=========
	Y.INTERMED.BANK = R.NEW(FT.INTERMED.BANK)
	IF Y.INTERMED.BANK EQ "" THEN
		Y.CR.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
		R.ACCOUNT = "" ; ACCOUNT.ERR = ""
		CALL F.READ(FN.ACCOUNT,Y.CR.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
		IF R.ACCOUNT NE "" THEN
			Y.INTERMED.BANK = R.ACCOUNT<AC.CUSTOMER>
		END
	END
    HANDOFF.REC(9)<1> = Y.INTERMED.BANK
RETURN
	
END