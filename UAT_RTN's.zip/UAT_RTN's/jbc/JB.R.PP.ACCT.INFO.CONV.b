SUBROUTINE JB.R.PP.ACCT.INFO.CONV
*--------------------------------------------------------------------------------------
* This is a conversion routine to get Alternate Account (BJB.ACCT) for portfolio number
*
*--------------------------------------------------------------------------------------
* Modification History
*
* Date         JIRA Ref      Developer        Description
* 31-01-2025  CBPAY-1410     Prabhu D S       Initial draft
*--------------------------------------------------------------------------------------
 $INSERT I_COMMON
 $INSERT I_EQUATE
 $INSERT I_ENQUIRY.COMMON
 $INSERT I_F.SEC.ACC.MASTER
 $INSERT I_F.ACCOUNT


 GOSUB INIT
 GOSUB GET.ALT.ACCT

RETURN
*****
INIT:
*****

 Y.PORT.ID = ''
 R.SEC.ACC.MAS.ACCT.NAME = ''
 Y.SAM.ID = ''
 R.SEC.ACC.MASTER = ''

 FN.SEC.ACC.MAS.ACCT.NAME = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
 F.SEC.ACC.MAS.ACCT.NAME = ''
 CALL OPF(FN.SEC.ACC.MAS.ACCT.NAME,F.SEC.ACC.MAS.ACCT.NAME)

 FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
 F.SEC.ACC.MASTER = ''
 CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

 FN.ACCOUNT = 'F.ACCOUNT'
 F.ACCOUNT = ''
 CALL OPF(FN.ACCOUNT,F.ACCOUNT)

 Y.PORT.ID = O.DATA

RETURN
*************
GET.ALT.ACCT:
*************

 O.DATA = ''

 CALL F.READ(FN.SEC.ACC.MAS.ACCT.NAME,Y.PORT.ID,R.SEC.ACC.MAS.ACCT.NAME,F.SEC.ACC.MAS.ACCT.NAME,'')
 IF R.SEC.ACC.MAS.ACCT.NAME THEN
    Y.SAM.ID = FIELD(R.SEC.ACC.MAS.ACCT.NAME,'*',2)
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,'')
    IF R.SEC.ACC.MASTER THEN
       Y.AC.NO = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NOS,1>
       CALL F.READ(FN.ACCOUNT,Y.AC.NO,R.ACCOUNT.REC,F.ACCOUNT,'')
       IF R.ACCOUNT.REC THEN
          LOCATE "BJB.ACCT" IN R.ACCOUNT.REC<AC.ALT.ACCT.TYPE,1> SETTING Y.POS THEN
              O.DATA = R.ACCOUNT.REC<AC.ALT.ACCT.ID,Y.POS>
          END
       END
    END
 END

RETURN
END

