* @ValidationCode : MTo0NzQ3NTY3NDY6SVNPLTg4NTktMToxNDk4MjA5MTY3NDA3OjU1OTgyODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNQ==
* @ValidationInfo : Timestamp         : 23 Jun 2017 14:42:47
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 559828
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.5
*-----------------------------------------------------------------------------
* <Rating>-114</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JBWW.R.FT.REV.NOF(FINAL.ARRAY)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is no-file enquiry routine attached to enquiry JBWW.E.FT.REVERSE
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY(Result Array)
* Dependencies:
*---------------
* NA
* Revision History:
*------------------
* 05/11/2020            Pradeep             P3636-5690              Variable not initialised
*-----------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB OPEN.FILES


RETURN

*-----------------------------------------------------------------------------------------------
OPEN.FILES:
************



    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.FUNDS.TRANSFER.HIS = ''
    CALL OPF(FN.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER.HIS)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)


    APP.NAME  = "FUNDS.TRANSFER"
    FLD.NAME  = "L.FT.FREQ.PMT":VM:"L.XX.CID.DATA"
    FLD.POS   = ''
    CALL MULTI.GET.LOC.REF(APP.NAME,FLD.NAME,FLD.POS)
    Y.FREQ.PMT = FLD.POS<1,1>
    Y.CID.DATA = FLD.POS<1,2>
    FT.LIVE.LIST = '' ; * P3636-5690 S/E
    GOSUB LOCATE.DET

    GOSUB GET.SEL.LIST.LIVE
    GOSUB GET.SEL.LIST.HIS
    GOSUB GET.SEL.LIST
RETURN

*-----------------------------------------------------------------------------------------------
LOCATE.DET:
************
    LOCATE 'TRANSACTION.REF' IN D.FIELDS<1> SETTING POS1 THEN
        Y.FT.ID = D.RANGE.AND.VALUE<POS1>
        Y.ID.OPER = D.LOGICAL.OPERANDS<POS1>
        IF Y.ID.OPER EQ '1' THEN
            Y.OPER.ID = 'EQ'
        END
    

        IF Y.ID.OPER EQ '5' THEN
            Y.OPER.ID = 'NE'
        END

        IF Y.ID.OPER EQ '6' THEN
            Y.OPER.ID = 'LIKE'
        END

    END


    LOCATE 'CREDIT.ACCOUNT.NO' IN D.FIELDS<1> SETTING POS2 THEN
        Y.CREDIT.ACCT.NO = D.RANGE.AND.VALUE<POS2>
        Y.CREDIT.ACCT.OPER = D.LOGICAL.OPERANDS<POS2>
        IF Y.CREDIT.ACCT.OPER EQ '1' THEN
            Y.OPERAND.CR.ACC = 'EQ'
        END
   

        IF Y.CREDIT.ACCT.OPER EQ '5' THEN
            Y.OPERAND.CR.ACC = 'NE'
        END

        IF Y.CREDIT.ACCT.OPER EQ '6' THEN
            Y.OPERAND.CR.ACC = 'LIKE'
        END


    END

    LOCATE 'CREDIT.CURRENCY' IN D.FIELDS<1> SETTING POS3 THEN
        Y.CREDIT.CURRENCY = D.RANGE.AND.VALUE<POS3>
        Y.CREDIT.CURRENCY.OPER = D.LOGICAL.OPERANDS<POS3>
        IF Y.CREDIT.CURRENCY.OPER EQ '1' THEN
            Y.OPERAND.CR.CUR = 'EQ'
        END
    
        IF Y.CREDIT.CURRENCY.OPER EQ '5' THEN
            Y.OPERAND.CR.CUR = 'NE'
        END

        IF Y.CREDIT.CURRENCY.OPER EQ '6' THEN
            Y.OPERAND.CR.CUR = 'LIKE'
        END

    END


    LOCATE 'DEBIT.ACCT.NO' IN D.FIELDS<1> SETTING POS4 THEN
        Y.DEBIT.ACCT.NO = D.RANGE.AND.VALUE<POS4>

        Y.DEBIT.ACCT.OPR = D.LOGICAL.OPERANDS<POS4>
        IF Y.DEBIT.ACCT.OPR EQ '1' THEN
            Y.OPERAND.DEB.ACC = 'EQ'
        END
    
        IF Y.DEBIT.ACCT.OPR EQ '5' THEN
            Y.OPERAND.DEB.ACC = 'NE'
        END

        IF Y.DEBIT.ACCT.OPR EQ '6' THEN
            Y.OPERAND.DEB.ACC = 'LIKE'
        END

    END


    LOCATE 'DEBIT.CURRENCY' IN D.FIELDS<1> SETTING POS5 THEN
        Y.DEBIT.CURRENCY = D.RANGE.AND.VALUE<POS5>
        Y.DEBIT.CUR.OPR = D.LOGICAL.OPERANDS<POS5>
        IF Y.DEBIT.CUR.OPR  EQ '1' THEN
            Y.OPERAND.DEB.CUR = 'EQ'
        END
   
        IF Y.DEBIT.CUR.OPR  EQ '5' THEN
            Y.OPERAND.DEB.CUR = 'NE'
        END

        IF Y.DEBIT.CUR.OPR  EQ '6' THEN
            Y.OPERAND.DEB.CUR = 'LIKE'
        END

    END

    LOCATE 'DEBIT.CUSTOMER' IN D.FIELDS<1> SETTING POS6 THEN
        Y.DEBIT.CUSTOMER = D.RANGE.AND.VALUE<POS6>
        Y.DEBIT.CUSTOMER.OPR = D.LOGICAL.OPERANDS<POS6>
        IF Y.DEBIT.CUSTOMER.OPR  EQ '1' THEN
            Y.OPERAND.DEB.CUS = 'EQ'
        END
    
        IF Y.DEBIT.CUSTOMER.OPR  EQ '5' THEN
            Y.OPERAND.DEB.CUS = 'NE'
        END


        IF Y.DEBIT.CUSTOMER.OPR  EQ '6' THEN
            Y.OPERAND.DEB.CUS = 'LIKE'
        END

    END



RETURN



*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------------------------
GET.SEL.LIST.HIS:
**************
*******
    SEL.CMD1 = "SELECT ":FN.FUNDS.TRANSFER.HIS:" WITH TRANSACTION.TYPE EQ ACAC OR TRANSACTION.TYPE EQ ACPM OR TRANSACTION.TYPE EQ ODDL OR TRANSACTION.TYPE EQ ODDF OR TRANSACTION.TYPE EQ OTDA OR TRANSACTION.TYPE EQ OT03 OR TRANSACTION.TYPE EQ OT12 OR TRANSACTION.TYPE EQ OT60 OR TRANSACTION.TYPE EQ ACCL OR TRANSACTION.TYPE EQ ACAC OR TRANSACTION.TYPE EQ ITPM"

    IF Y.FT.ID THEN
        IF Y.OPER.ID NE 'LIKE' THEN
            SEL.CMD1 := " AND @ID ":Y.OPER.ID:' ':Y.FT.ID
        END ELSE
            SEL.CMD1 := " AND @ID ":Y.OPER.ID:' ':'...':Y.FT.ID:'...'
        END
    END
    IF Y.CREDIT.ACCT.NO THEN
        IF Y.OPERAND.CR.ACC NE 'LIKE' THEN
            SEL.CMD1 := " AND CREDIT.ACC.NO ":Y.OPERAND.CR.ACC:' ':Y.CREDIT.ACCT.NO
        END ELSE
            SEL.CMD1 := " AND CREDIT.ACC.NO ":Y.OPERAND.CR.ACC:' ':'...':Y.CREDIT.ACCT.NO:'...'
        END
    END
    IF Y.CREDIT.CURRENCY THEN
        IF Y.OPERAND.CR.CUR NE	'LIKE' THEN

            SEL.CMD1 := " AND CREDIT.CURRENCY ":Y.OPERAND.CR.CUR:' ':Y.CREDIT.CURRENCY
        END ELSE
             
            SEL.CMD1 := " AND CREDIT.CURRENCY ":Y.OPERAND.CR.CUR:' ':'...':Y.CREDIT.CURRENCY:'...'
        END

    END
    IF Y.DEBIT.ACCT.NO THEN
        IF Y.OPERAND.DEB.ACC NE	'LIKE' THEN
            SEL.CMD1 := " AND DEBIT.ACCT.NO ":Y.OPERAND.DEB.ACC:' ':Y.DEBIT.ACCT.NO
        END ELSE
            SEL.CMD1 := " AND DEBIT.ACCT.NO ":Y.OPERAND.DEB.ACC:' ':'...':Y.DEBIT.ACCT.NO:'...'
        END
    END
    IF Y.DEBIT.CURRENCY THEN
        IF Y.OPERAND.DEB.CUR NE	'LIKE' THEN
            SEL.CMD1 := " AND DEBIT.CURRENCY ":Y.OPERAND.DEB.CUR:' ':Y.DEBIT.CURRENCY
        END ELSE
            SEL.CMD1 := " AND DEBIT.CURRENCY ":Y.OPERAND.DEB.CUR:' ':'...':Y.DEBIT.CURRENCY:'...'
        END
    END
    IF Y.DEBIT.CUSTOMER THEN
        IF Y.OPERAND.DEB.CUS NE	'LIKE' THEN
            SEL.CMD1 := " AND DEBIT.CUSTOMER ":Y.OPERAND.DEB.CUS:' ':Y.DEBIT.CUSTOMER
        END ELSE
            SEL.CMD1 := " AND DEBIT.CUSTOMER ":Y.OPERAND.DEB.CUS:' ':'...':Y.DEBIT.CUSTOMER:'...'
        END
    END

    CALL EB.READLIST(SEL.CMD1,SEL.LIST1,'',NO.OF.RECS1,SEL.ERR)

	

	LOOP
        REMOVE FT.HIST.ID FROM SEL.LIST1 SETTING HIST.POS
	WHILE FT.HIST.ID:HIST.POS
		FT.ID = FIELD(FT.HIST.ID,';',1)
		FT.HIST.REC = ''
		CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS, FT.ID, FT.HIST.REC, '')
		FT.HIST.ID = FT.ID
		FT.ID = FIELD(FT.ID,';',1)
		IF FT.HIST.REC<FT.RECORD.STATUS> NE 'REVE' THEN
			LOCATE FT.ID IN FT.LIVE.LIST SETTING Y.POS ELSE
				LOCATE FT.ID IN FINAL.HIST.LIST SETTING FINAL.HIST.POS ELSE
					FINAL.HIST.LIST<-1> = FT.ID
			    END
		    END
		END
		
	REPEAT
RETURN

*-----------------------------------------------------------------------------
GET.SEL.LIST.LIVE:
**********************************************************
    SEL.CMD2 = "SELECT ":FN.FUNDS.TRANSFER:" WITH TRANSACTION.TYPE EQ ACAC OR TRANSACTION.TYPE EQ ACPM OR TRANSACTION.TYPE EQ ODDL OR TRANSACTION.TYPE EQ ODDF OR TRANSACTION.TYPE EQ OTDA OR TRANSACTION.TYPE EQ OT03 OR TRANSACTION.TYPE EQ OT12 OR TRANSACTION.TYPE EQ OT60 OR TRANSACTION.TYPE EQ ACCL OR TRANSACTION.TYPE EQ ACAC OR TRANSACTION.TYPE EQ ITPM"



        
    IF Y.FT.ID THEN
        IF Y.OPER.ID NE 'LIKE' THEN
            SEL.CMD2 := " AND @ID ":Y.OPER.ID:' ':Y.FT.ID
        END ELSE
            SEL.CMD2 := " AND @ID ":Y.OPER.ID:' ':'...':Y.FT.ID:'...'
        END
    END
    IF Y.CREDIT.ACCT.NO THEN
        IF Y.OPERAND.CR.ACC NE 'LIKE' THEN
            SEL.CMD2 := " AND CREDIT.ACC.NO ":Y.OPERAND.CR.ACC:' ':Y.CREDIT.ACCT.NO
        END ELSE
            SEL.CMD2 := " AND CREDIT.ACC.NO ":Y.OPERAND.CR.ACC:' ':'...':Y.CREDIT.ACCT.NO:'...'
        END
    END
    IF Y.CREDIT.CURRENCY THEN
        IF Y.OPERAND.CR.CUR NE 'LIKE' THEN

            SEL.CMD2 := " AND CREDIT.CURRENCY ":Y.OPERAND.CR.CUR:' ':Y.CREDIT.CURRENCY
        END ELSE
             
            SEL.CMD2 := " AND CREDIT.CURRENCY ":Y.OPERAND.CR.CUR:' ':'...':Y.CREDIT.CURRENCY:'...'
        END

    END
    IF Y.DEBIT.ACCT.NO THEN
        IF Y.OPERAND.DEB.ACC NE	'LIKE' THEN
            SEL.CMD2 := " AND DEBIT.ACCT.NO ":Y.OPERAND.DEB.ACC:' ':Y.DEBIT.ACCT.NO
        END ELSE
            SEL.CMD2 := " AND DEBIT.ACCT.NO ":Y.OPERAND.DEB.ACC:' ':'...':Y.DEBIT.ACCT.NO:'...'
        END
    END
    IF Y.DEBIT.CURRENCY THEN
        IF Y.OPERAND.DEB.CUR NE	'LIKE' THEN
            SEL.CMD2 := " AND DEBIT.CURRENCY ":Y.OPERAND.DEB.CUR:' ':Y.DEBIT.CURRENCY
        END ELSE
            SEL.CMD2 := " AND DEBIT.CURRENCY ":Y.OPERAND.DEB.CUR:' ':'...':Y.DEBIT.CURRENCY:'...'
        END
    END
    IF Y.DEBIT.CUSTOMER THEN
        IF Y.OPERAND.DEB.CUS NE	'LIKE' THEN
            SEL.CMD2 := " AND DEBIT.CUSTOMER ":Y.OPERAND.DEB.CUS:' ':Y.DEBIT.CUSTOMER
        END ELSE
            SEL.CMD2 := " AND DEBIT.CUSTOMER ":Y.OPERAND.DEB.CUS:' ':'...':Y.DEBIT.CUSTOMER:'...'
        END
    END

    CALL EB.READLIST(SEL.CMD2,SEL.LIST2,'',NO.OF.RECS2,SEL.ERR)

RETURN
*-------------------------------------------------------------------------
GET.SEL.LIST:
***********************************************************************************


    IF FINAL.HIST.LIST NE '' AND SEL.LIST2 NE '' THEN
        SEL.CONSOL.LIST = FINAL.HIST.LIST:FM:SEL.LIST2

    END

    IF FINAL.HIST.LIST EQ '' THEN
        SEL.CONSOL.LIST = SEL.LIST2
    END

    IF SEL.LIST2 EQ '' THEN
        SEL.CONSOL.LIST = FINAL.HIST.LIST

    END

    IF SEL.CONSOL.LIST THEN
        LOOP
            REMOVE Y.FT.ID FROM SEL.CONSOL.LIST SETTING FT.ID.POS
        WHILE Y.FT.ID : FT.ID.POS
				
            GOSUB GET.DETAILS
        REPEAT
    END
RETURN
GET.DETAILS:
*************

    CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FT.REC,F.FUNDS.TRANSFER,FT.ERR)

    IF R.FT.REC THEN
        Y.TRANSACTION.ID = Y.FT.ID
        Y.TRANSACTION.TYPE = R.FT.REC<FT.TRANSACTION.TYPE>
        Y.DEBIT.ACCT.NO = R.FT.REC<FT.DEBIT.ACCT.NO>
        Y.ALT.ID = Y.DEBIT.ACCT.NO
        GOSUB ALT.ACC.ID
        Y.DEBIT.ALT.NO = Y.AC.ALT.ID
        Y.DEBIT.CURRENCY = R.FT.REC<FT.DEBIT.CURRENCY>
        Y.DEBIT.AMOUNT = R.FT.REC<FT.DEBIT.AMOUNT>
        Y.CREDIT.ACCOUNT.NO = R.FT.REC<FT.CREDIT.ACCT.NO>
        Y.CREDIT.CURRENCY = R.FT.REC<FT.CREDIT.CURRENCY>
        Y.CREDIT.AMOUNT = R.FT.REC<FT.CREDIT.AMOUNT>
        Y.FREQ.PMT1 = R.FT.REC<FT.LOCAL.REF,Y.FREQ.PMT>
        Y.CID.DATA1 = R.FT.REC<FT.LOCAL.REF,Y.CID.DATA>
        GOSUB EDGEURL.CONV
        Y.CID.DATA1 = Y.FINAL.URL
        Y.RECORD.STATUS = R.FT.REC<FT.RECORD.STATUS>
        Y.INPUTTER = R.FT.REC<FT.INPUTTER>
        Y.INPUT = FIELD(Y.INPUTTER,'_',2,1)
        Y.ALT.ID = Y.CREDIT.ACCOUNT.NO
        GOSUB ALT.ACC.ID
        Y.CREDIT.ACCOUNT.NO = Y.AC.ALT.ID
        Y.INWARD.PAY.TYPE = R.FT.REC<FT.INWARD.PAY.TYPE>
              

        CHANGE '-' TO '.' IN Y.INWARD.PAY.TYPE
        Y.DEBIT.CUSTOMER = R.FT.REC<FT.DEBIT.CUSTOMER>
    END ELSE
        CALL F.READ(FN.FUNDS.TRANSFER.HIS,Y.FT.ID,R.FT.REC1,F.FUNDS.TRANSFER.HIS,FT.ERR)

        IF R.FT.REC1 THEN

            Y.TRANSACTION.ID = Y.FT.ID
            Y.TRANSACTION.TYPE = R.FT.REC1<FT.TRANSACTION.TYPE>
            Y.DEBIT.ACCT.NO = R.FT.REC1<FT.DEBIT.ACCT.NO>
            Y.ALT.ID = Y.DEBIT.ACCT.NO
            GOSUB ALT.ACC.ID
            Y.DEBIT.ALT.NO = Y.AC.ALT.ID
            Y.DEBIT.CURRENCY = R.FT.REC1<FT.DEBIT.CURRENCY>
            Y.DEBIT.AMOUNT = R.FT.REC1<FT.DEBIT.AMOUNT>
            Y.CREDIT.ACCOUNT.NO = R.FT.REC1<FT.CREDIT.ACCT.NO>
            Y.CREDIT.CURRENCY = R.FT.REC1<FT.CREDIT.CURRENCY>
            Y.CREDIT.AMOUNT = R.FT.REC1<FT.CREDIT.AMOUNT>
            Y.FREQ.PMT1 = R.FT.REC1<FT.LOCAL.REF,Y.FREQ.PMT>
            Y.CID.DATA1 = R.FT.REC1<FT.LOCAL.REF,Y.CID.DATA>
            GOSUB EDGEURL.CONV
            Y.CID.DATA1 = Y.FINAL.URL
            Y.RECORD.STATUS = R.FT.REC1<FT.RECORD.STATUS>
            Y.INPUTTER = R.FT.REC1<FT.INPUTTER>
            Y.INPUT = FIELD(Y.INPUTTER,'_',2,1)
            Y.ALT.ID = Y.CREDIT.ACCOUNT.NO
            GOSUB ALT.ACC.ID
            Y.CREDIT.ACCOUNT.NO = Y.AC.ALT.ID
            Y.INWARD.PAY.TYPE = R.FT.REC1<FT.INWARD.PAY.TYPE>

            CHANGE '-' TO '.' IN Y.INWARD.PAY.TYPE
            Y.DEBIT.CUSTOMER = R.FT.REC1<FT.DEBIT.CUSTOMER>
        END
    END
    FINAL.ARRAY<-1> = Y.TRANSACTION.ID:'*':Y.TRANSACTION.TYPE:'*':Y.DEBIT.ACCT.NO:'*':Y.DEBIT.ALT.NO:'*':Y.DEBIT.CURRENCY:'*':Y.DEBIT.AMOUNT:'*':Y.CREDIT.ACCOUNT.NO:'*':Y.CREDIT.CURRENCY:'*':Y.CREDIT.AMOUNT:'*':Y.FREQ.PMT1:'*':Y.CID.DATA1:'*':Y.RECORD.STATUS:'*':Y.INPUT:'*':Y.CREDIT.ACCOUNT.NO:'*':Y.INWARD.PAY.TYPE:'*':Y.DEBIT.CUSTOMER

RETURN
****************************************************************************************
ALT.ACC.ID:
***************************************************************************************
    Y.FT.ACCT = Y.ALT.ID
    Y.STO.ACCT = FIELD(Y.FT.ACCT,'.',1)

    IF Y.STO.ACCT THEN
        Y.ACCT.ID = Y.STO.ACCT
    END ELSE
        Y.ACCT.ID = Y.FT.ACCT
    END


    R.ACC.REC = ''
    ACCT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACC.REC,F.ACCOUNT,ACCT.ERR)

    ALT.ACCT.TYPE = R.ACC.REC<AC.ALT.ACCT.TYPE>
    ALT.ACCT.IDS = R.ACC.REC<AC.ALT.ACCT.ID>

    LOCATE "BJB.ACCT" IN ALT.ACCT.TYPE<1,1> SETTING ALTACCT.TYPE.POS THEN
        Y.AC.ALT.ID = ALT.ACCT.IDS<1,ALTACCT.TYPE.POS>
    END ELSE

        Y.AC.ALT.ID = ''
    END




RETURN

*----------------------------------------------------------------------------------------------
EDGEURL.CONV:
*******************************

    Y.FT.ID.DATA = Y.FT.ID
    ENQR.NAME = ENQ.SELECTION<1>
    Y.COMP = ID.COMPANY

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    GOSUB EDGEURL.LINK
RETURN
*************************************************
EDGEURL.LINK:
*****************************
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,'PAYMENT.EDGE.URL',R.GEN.PAR,F.JBWW.H.EB.GENERICPARAMETER,PAR.ERR)
    Y.GENPAR.NAME = R.GEN.PAR<JBWW.GEN.PAR.FIELD.NAME>
    Y.GENPAR.VALUE = R.GEN.PAR<JBWW.GEN.PAR.FIELD.VALUE>

    ENQ.POS = ''
    LOCATE ENQR.NAME IN Y.GENPAR.NAME<1,1> SETTING ENQ.POS THEN
        Y.KEY = Y.GENPAR.VALUE<1,ENQ.POS>
    END

    IP.POS = ''
    LOCATE "IP.PORT" IN Y.GENPAR.NAME<1,1> SETTING IP.POS THEN
        Y.IP = Y.GENPAR.VALUE<1,IP.POS>
    END

    SERVICE.POS = ''
    LOCATE "SERVICE.LINK" IN Y.GENPAR.NAME<1,1> SETTING SERVICE.POS THEN
        Y.SERVICE = Y.GENPAR.VALUE<1,SERVICE.POS>
    END

    Y.FLAG = 'Flag=':Y.KEY:'&'
    Y.MENU = 'MnuTyp=':Y.FT.ID:'&'
    Y.CO.CODE = 'CoCode=':Y.COMP

    Y.FINAL.URL = Y.IP:Y.SERVICE:Y.FLAG:Y.MENU:Y.CO.CODE


RETURN
END
