*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.NONCIDVD.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
**
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer                              Reference               
*--------------------------------------------------------------------------------------------
*11-12-2024     Resmi.R                                CBPAY-1426              
*--------------------------------------------------------------------------------------------
* Description : Routine is used to filter the non CID transaction excluding VALDTE.AMND.TXN.CODES configured in generic parameter "JB.D.PP.TPH.CONFIG".
* Attached to : ENQUIRY>JB.E.PP.DATECHECK.NONCID
* Attached as : BUILD.ROUTINE
**---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.JBWW.H.XX.CCYCUTOFF.RULE
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.PAYMENT.ORDER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS


RETURN

INIT:
*****
* !! Initialise and open the necessary files ;

    Y.SOFTBLOCK.ARRAY = ''
    REC.GEN.FT.DATA = ''
    REC.CCY.RULE = ''
    REC.FT.DATA = ''
    REC.PAYMENT.ORDER = ''
    ERR.PO = ''

    FN.JBWW.H.XX.CCYCUTOFF.RULE = 'F.JBWW.H.XX.CCYCUTOFF.RULE'
    F.JBWW.H.XX.CCYCUTOFF.RULE = ''
    CALL OPF(FN.JBWW.H.XX.CCYCUTOFF.RULE,F.JBWW.H.XX.CCYCUTOFF.RULE)

    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    F.JBWW.H.XX.SOFTBLOCK = ''
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)


    Y.APPL = 'PAYMENT.ORDER'
    Y.FLD =  'L.FT.VALDT.CHKD'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.FLD,Y.FLD.POS)
    Y.VALDT.CHKD.POS = Y.FLD.POS<1,1>


RETURN

*-----------------------------------------------------------------------------

PROCESS:
*******
*!! Read and fetch necessary field values.

    Y.CCYCUTOFF.RULE.ID = 'SYSTEM'
 
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","VALDTE.AMND.TXN.CODES",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE
    
    CALL F.READ(FN.JBWW.H.XX.CCYCUTOFF.RULE,Y.CCYCUTOFF.RULE.ID,REC.CCY.RULE,F.JBWW.H.XX.CCYCUTOFF.RULE,ERR.CUTOFF)

    IF REC.CCY.RULE THEN
        Y.CUTOFF.CCY = REC.CCY.RULE<JHXCR.CURRENCY>
        CCY.CUT.OFF.VAL = REC.CCY.RULE<JHXCR.CUT.OFF.RULE>
    END

    SEL.CMD = "SELECT ":FN.JBWW.H.XX.SOFTBLOCK:" WITH OVERALL.STATUS NE 'REJECT' AND APPLICATION EQ 'PAYMENT.ORDER' AND CREDIT.READY EQ 'YES' "

    LOCATE "@ID" IN ENQ.DATA<2,1> SETTING Y.POS THEN
        Y.TRANS.ID = ENQ.DATA<4,Y.POS>
        IF Y.TRANS.ID THEN
            SEL.CMD := " AND @ID EQ ":Y.TRANS.ID
        END
    END

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)

    IF SEL.LIST THEN
        LOOP
            REMOVE Y.SOFTBLOCK.ID FROM SEL.LIST SETTING Y.POS
        WHILE Y.SOFTBLOCK.ID:Y.POS
            GOSUB MAIN.PROCESS

        REPEAT
        GOSUB FORM.FINAL.DATA
    END
    
RETURN
*-----------------------------------------------------------------------------

MAIN.PROCESS:
************
* !! check the transaction type of selected records;

    Y.TODAY = TODAY
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK,Y.SOFTBLOCK.ID,REC.FT.DATA,F.JBWW.H.XX.SOFTBLOCK,ERR.FT)
	
    Y.VALUE.DATE = REC.FT.DATA<JHXS.VALUE.DATE>
    Y.CURR = REC.FT.DATA<JHXS.CURRENCY>


	CALL F.READ(FN.PAYMENT.ORDER.NAU,Y.SOFTBLOCK.ID,REC.PO,F.PAYMENT.ORDER.NAU,ERR.PO)
	Y.PAYMENT.ORDER.PRODUCT = REC.PO<PO.PAYMENT.ORDER.PRODUCT>


    LOCATE Y.PAYMENT.ORDER.PRODUCT IN Y.GPM.VALUE<1,1> SETTING Y.TRANS.POS ELSE ;* For Non CID transaction
        GOSUB CHECK.PO.REC.STATUS
    END

RETURN

*-----------------------------------------------------------------------------

CHECK.PO.REC.STATUS:
*******************
* GOSUB introduced as a part of RL- 160  requirement

    Y.PO.STATUS = REC.PO<PO.RECORD.STATUS>
    Y.VALDT.CHKD = ''
    Y.VALDT.CHKD = REC.PO<PO.LOCAL.REF,Y.VALDT.CHKD.POS>
    IF (Y.PO.STATUS EQ 'INA2' AND Y.VALDT.CHKD EQ "") OR (Y.PO.STATUS EQ 'INAU' AND Y.VALDT.CHKD EQ "MAKER") THEN

        GOSUB CHECK.DATA
    END
    
RETURN

*-----------------------------------------------------------------------------

CHECK.DATA:
**********
* !! check the currency of selected records

    LOCATE Y.CURR IN Y.CUTOFF.CCY<1,1> SETTING Y.CUR.POS THEN
        CCY.RULE.VAL = CCY.CUT.OFF.VAL<1,Y.CUR.POS>

        IF CCY.RULE.VAL EQ '0' THEN
            CUT.OFF.DATE = Y.VALUE.DATE
        END ELSE
            VAL.DATE = CCY.RULE.VAL
            VAL.DATE = '-':VAL.DATE:'W'
            CUT.OFF.DATE = Y.VALUE.DATE
            CALL CDT("",CUT.OFF.DATE,VAL.DATE)
        END
        IF CUT.OFF.DATE LT Y.TODAY THEN
            Y.SOFTBLOCK.ARRAY<-1> = Y.SOFTBLOCK.ID

        END
    END ELSE
        Y.SOFTBLOCK.ARRAY<-1> = Y.SOFTBLOCK.ID
    END

RETURN
*-----------------------------------------------------------------------------

FORM.FINAL.DATA:
****************
* !! Form final data array to be displayed in enquiry.

    CHANGE FM TO ' ' IN Y.SOFTBLOCK.ARRAY
    ENQ.DATA<2,1> = '@ID'
    ENQ.DATA<3,1> = 'EQ'
    ENQ.DATA<4,1> =  Y.SOFTBLOCK.ARRAY
    
RETURN

*-----------------------------------------------------------------------------
END
