* @ValidationCode : MToxNzI2MjQ2MDU2OklTTy04ODU5LTE6MTU0Mjk2NTE0MjA4Mzo1MzQ0NjI6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjQ=
* @ValidationInfo : Timestamp         : 23 Nov 2018 14:55:42
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 534462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------
* <Rating>-114</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.NAULIST.NOF(OUT.ARRAY)
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is no-file enquiry routine attached to enquiry JBWW.E.FT.NAU.LIST
*-------------------------------------------------------------------------
* Attached: NA
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: OUT.ARRAY(Result Array)
* Dependencies:
*---------------
* NA
* Revision History:
*------------------
*   Date               who                          Reference                                Desc
* 19-Dec-2016          Neeraj Kumar                   CR-199                                 Initial Version
* 23-Jan-2017          Priyadarshni Priyanka          JB2A-26146                             Defect Fix
* 14-Mar-2017          Guru Hanji                     JB2A-28788                             Defect Fix
* 17-Apr-2017          Ramesh Kummara                 JB2A-30871                             Defect Fix
* 21-Sep-2017          Timothy Yap                    JB2A-42979                             Pending Fund Transfer Enquiry Account Officer Issue
* 16-Oct-2017          Jeeva Kumari                   JB2A-42979                             Fix to cater for multiple User ids provided in Selection Criteria
* 23-Oct-2018          Rajagopalan R                  DAY15-4245 & DAY15-4482                Updating code to restrict TRANSACTION TYPE for CASH and SECURITY User roles.
* 22-Nov-2018          Kalyani L K                    DAY15-4878                             Updating code to restrict TRANSACTION TYPE for CASH and SECURITY User roles
* 06-Dec-2018          Lakshmanan V                   DAY15-4878                             Transaction type for sec and cash corrected in the selection command
* 23-May-2025          Lakshmi Priya KS               CBPAY-1930                             Included logic to display the Payments order and order entry 
*                                                                                              which are in unauthorized status.
* 07-Jun-2025          Resmi R                        CBPAY-3204 & CBPAY-3195                Fixed the logic for CCY field not getting populated in incoming payments & Value Date missing in Outgoing payments                                                                                          
*-----------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.USERACL
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_F.JBWW.H.EB.USERTEAM
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.USER.ROLES
    $INSERT I_F.USER
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.PAYMENT.ORDER.PRODUCT


    GOSUB OPEN.FILES
    GOSUB LOCATE.DET

    OUT.ARRAY = Y.LIST

    RETURN

*-----------------------------------------------------------------------------------------------
OPEN.FILES:
************

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.FUNDS.TRANSFER.NAU = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER.NAU = ''
    CALL OPF(FN.FUNDS.TRANSFER.NAU,F.FUNDS.TRANSFER.NAU)

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)
    
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    FN.PP.ORDER.ENTRY.NAU = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY.NAU = ''
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,F.PP.ORDER.ENTRY.NAU)
    
    FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    FN.FT.TXN.TYPE.CONDITION = 'F.FT.TXN.TYPE.CONDITION'
    F.FT.TXN.TYPE.CONDITION = ''
    CALL OPF(FN.FT.TXN.TYPE.CONDITION,F.FT.TXN.TYPE.CONDITION)

    FN.PAYMENT.ORDER.PRODUCT = 'F.PAYMENT.ORDER.PRODUCT'
    F.PAYMENT.ORDER.PRODUCT = ''
    CALL OPF(FN.PAYMENT.ORDER.PRODUCT,F.PAYMENT.ORDER.PRODUCT)

    FN.JBWW.H.EB.USERACL = 'F.JBWW.H.EB.USERACL'
    F.JBWW.H.EB.USERACL = ''
    CALL OPF(FN.JBWW.H.EB.USERACL,F.JBWW.H.EB.USERACL)

    FN.JBWW.H.EB.USERTEAM ='F.JBWW.H.EB.USERTEAM'
    F.JBWW.H.EB.USERTEAM =''
    CALL OPF(FN.JBWW.H.EB.USERTEAM,F.JBWW.H.EB.USERTEAM)

    FN.SEC.ACC.MASTER.ACCOUNT.NAME ='F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ACCOUNT.NAME =''
    CALL OPF(FN.SEC.ACC.MASTER.ACCOUNT.NAME,F.SEC.ACC.MASTER.ACCOUNT.NAME)

    FN.ALTERNATE.ACCOUNT ='F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT =''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)
    
    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)
        
    LOC.REF.APPLICATION = "CUSTOMER":FM:"SEC.ACC.MASTER"
    LOC.REF.FIELDS= 'L.ST.OFFCR.TYPE':VM:'L.ST.OFFICER.ID':FM:'L.XX.TEAM.ID'
    LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.REF.APPLICATION,LOC.REF.FIELDS,LOC.REF.POS)
    L.ST.OFFICER.TYPE.POS = LOC.REF.POS<1,1>
    L.ST.OFFICER.ID.POS = LOC.REF.POS<1,2>
    L.XX.TEAM.ID.POS = LOC.REF.POS<2,1>
    Y.GO.FLAG = ''

    RETURN

*-----------------------------------------------------------------------------------------------
LOCATE.DET:
************
    LOCATE 'USER.ID' IN D.FIELDS<1> SETTING USR.POS THEN
    Y.USER.ID = D.RANGE.AND.VALUE<USR.POS>
    CHANGE ' ' TO VM IN Y.USER.ID
    CHANGE SM TO VM IN Y.USER.ID
    END 

    LOCATE 'ACCOUNT.OFFICER' IN D.FIELDS<1> SETTING ACCOUNT.OFFICER.POS THEN
    Y.ACCOUNT.OFFICER = D.RANGE.AND.VALUE<ACCOUNT.OFFICER.POS>
    CHANGE ' ' TO VM IN Y.ACCOUNT.OFFICER
    CHANGE SM TO VM IN Y.ACCOUNT.OFFICER
    END

***CONVERSION FROM EXTERNAL REF TO T24 FOR VALUE IN SELECTION PORTFOLIO.NO

    LOCATE 'PORTFOLIO.NO' IN D.FIELDS<1> SETTING PORT.POS THEN
    SEL.PORT.ID = D.RANGE.AND.VALUE<PORT.POS>
    CHANGE ' ' TO VM IN SEL.PORT.ID
    CHANGE SM TO VM IN SEL.PORT.ID
    GOSUB SEL.PORTID.CHK
    END

***CONVERSION FROM EXTERNAL REF TO T24 FOR VALUE IN SELECTION ACCOUNT.NO

    LOCATE 'ACCOUNT.NO' IN D.FIELDS<1> SETTING ACCOUNT.NO.POS THEN
    SEL.AACNT.NO = D.RANGE.AND.VALUE<ACCOUNT.NO.POS>
    CHANGE ' ' TO VM IN SEL.AACNT.NO
    CHANGE SM TO VM IN SEL.AACNT.NO
    GOSUB SEL.ACCTID.CHK
    END

    LOCATE 'ROLE' IN D.FIELDS<1> SETTING ROLE.POS THEN
    Y.ROLE = D.RANGE.AND.VALUE<ROLE.POS>
    CHANGE ' ' TO VM IN Y.ROLE
    CHANGE SM TO VM IN Y.ROLE
    END

    GOSUB GET.USRACL.DETAILS
    GOSUB GET.SEL.LIST
    GOSUB GET.SEL.LIST.PO
    GOSUB GET.SEL.LIST.OE

    RETURN

*-----------------------------------------------------------------------------
SEL.PORTID.CHK:
***************

    NOSELPORTID=DCOUNT(SEL.PORT.ID,VM)
    Y.PORTID.CNT=1
    LOOP
    WHILE Y.PORTID.CNT LE NOSELPORTID
        SEL.PORT.ID1=SEL.PORT.ID<1,Y.PORTID.CNT>

        R.SEC.ACC.MASTER.ACCOUNT.NAME = ''
        ERR.SEC.ACC.NAME = ''
        CALL F.READ(FN.SEC.ACC.MASTER.ACCOUNT.NAME,SEL.PORT.ID1,R.SEC.ACC.MASTER.ACCOUNT.NAME,F.SEC.ACC.MASTER.ACCOUNT.NAME,ERR.SEC.ACC.NAME)
        IF R.SEC.ACC.MASTER.ACCOUNT.NAME THEN
            SEC.PORT.ID.VAL = FIELD(R.SEC.ACC.MASTER.ACCOUNT.NAME,'*',2,1)
            CHANGE VM TO FM IN SEC.PORT.ID.VAL
            Y.PORTFOLIO.NO <1,-1> = SEC.PORT.ID.VAL
        END
        Y.PORTID.CNT += 1
    REPEAT

    RETURN

*-----------------------------------------------------------------------------
SEL.ACCTID.CHK:
***************

    NOSELACCTNO=DCOUNT(SEL.AACNT.NO,VM)
    Y.ACCNTNO.CNT=1
    LOOP
    WHILE Y.ACCNTNO.CNT LE NOSELACCTNO
        SEL.AACNT.NO1=SEL.AACNT.NO<1,Y.ACCNTNO.CNT>

        R.ALTERNATE.ACCOUNT = ''
        ERR.ALTERNATE.ACCOUNT = ''
        CALL F.READ(FN.ALTERNATE.ACCOUNT,SEL.AACNT.NO1,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ERR.ALTERNATE.ACCOUNT)
        IF R.ALTERNATE.ACCOUNT THEN
            SEC.ACCNT.ID.VAL = R.ALTERNATE.ACCOUNT<AAC.GLOBUS.ACCT.NUMBER>
            CALL F.READ(FN.ACCOUNT,SEC.ACCNT.ID.VAL,R.AC.REC,F.ACCOUNT,SEL.ACC.ERR)
            IF R.AC.REC THEN
                SEL.ALT.ACCNT.TYPE=R.AC.REC<AC.ALT.ACCT.TYPE>
                LOCATE 'BJB.ACCT' IN SEL.ALT.ACCNT.TYPE<1,1> SETTING ACC.TYP.POS THEN
                Y.ACCOUNT.NO<1,-1> = SEC.ACCNT.ID.VAL
            END
        END
    END
    Y.ACCNTNO.CNT += 1
    REPEAT

    RETURN
*-----------------------------------------------------------------------------
GET.USRACL.DETAILS:
*******************
*JB2A-30871 - Start

    IF Y.USER.ID NE '' THEN
***JB2A-42979 S/ 16-Oct-2017
        Y.MULTIPLE.USER.ID = Y.USER.ID
        Y.USER.ID.CNT = DCOUNT(Y.MULTIPLE.USER.ID,VM)
        Y.USR.CNT = 1
        LOOP
        WHILE Y.USR.CNT LE Y.USER.ID.CNT
            Y.USER.ID =   Y.MULTIPLE.USER.ID<1,Y.USR.CNT>
***JB2A-42979 /E 16-Oct-2017
            Y.ID.TEAM = FIELD(Y.USER.ID,'.',1):"-":ID.COMPANY
            REC.USRACL = ''; ERR.USRACL = ''
            CALL F.READ(FN.JBWW.H.EB.USERACL,Y.ID.TEAM,REC.USRACL,F.JBWW.H.EB.USERACL,ERR.USRACL)
            IF REC.USRACL THEN
                Y.PORTFOLIO.ALW = REC.USRACL<USR.ACL.PORTFOLIO.ALLOW>
                PORT.ALLOW<1,-1> = Y.PORTFOLIO.ALW
            END
            IF Y.USR.CNT = 1 THEN ;****JB2A-42979 S/E 16-Oct-2017
                CALL F.READ(FN.JBWW.H.EB.USERTEAM,Y.ID.TEAM,REC.USRTEAM,F.JBWW.H.EB.USERTEAM,ERR.USRTEAM)
                IF REC.USRTEAM THEN
                    Y.TEAM.ID= REC.USRTEAM<USR.TEAM.TEAM.ID>
                END
******JB2A-42979 S/ 16-Oct-2017
            END
            Y.USR.CNT+ =1
        REPEAT
***JB2A-42979 /E 16-Oct-2017
    END ELSE
* (S) - DAY15-4878    
        GOSUB GET.USER.ROLES
        GOSUB GET.GEN.PARAM.DETAILS
        GOSUB CASH.USER.ROLE.CHK
* (E) - DAY15-4878        
    END
*JB2A-30871 - END
    RETURN
*-----------------------------------------------------------------------------------------------
* (S) - DAY15-4878
***************
GET.USER.ROLES:
***************
* In this para of the program, the user role is fetched
**        
    Y.LOGIN.USER = OPERATOR
    CALL F.READ(FN.USER,Y.LOGIN.USER,R.LOGIN.USER,F.USER,LOG.USR.ERR)
    Y.USERROLES.LIST = R.LOGIN.USER<EB.USE.USER.ROLES>
    CHANGE SM TO FM IN Y.USERROLES.LIST
         
    RETURN
*-----------------------------------------------------------------------------------------------------------------    
**********************
GET.GEN.PARAM.DETAILS:
**********************
* In this para of the program, the GPM details are fetched
**  
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.CASHSEC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,USERROLE.ERR)
    USERROLES.FN = R.CASHSEC.ROLE<JBWW.GEN.PAR.FIELD.NAME>
    USERROLES.FV = R.CASHSEC.ROLE<JBWW.GEN.PAR.FIELD.VALUE>
          
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.AC.CASHROLE.TXNTYPES",R.CASHROLE.TXN,F.JBWW.H.EB.GENERICPARAMETER,CASHROLE.ERR)
    Y.CASHROLES.FN = R.CASHROLE.TXN<JBWW.GEN.PAR.FIELD.NAME>
    Y.CASHROLES.TXNTYPES.FV = R.CASHROLE.TXN<JBWW.GEN.PAR.FIELD.VALUE>

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.SC.SECROLE.TXNTYPES",R.SECROLE.TXN,F.JBWW.H.EB.GENERICPARAMETER,SECROLE.ERR)
    Y.SECROLES.FN = R.SECROLE.TXN<JBWW.GEN.PAR.FIELD.NAME>
    Y.SECROLES.TXNTYPES.FV = R.SECROLE.TXN<JBWW.GEN.PAR.FIELD.VALUE>
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------    
*******************
CASH.USER.ROLE.CHK:
*******************
* In this para of the program, the User role is checked against cash users
** 
    USER.COUNT = DCOUNT(Y.USERROLES.LIST,FM)
    USER.CNT = 1
 
    TXNTYPES = ''
    LOCATE 'CASH.USER.ROLES' IN USERROLES.FN<1,1> SETTING USERROLE.POS THEN
        LOOP
*           REMOVE Y.USER.ROLES FROM Y.USERROLES.LIST SETTING ROLE.POS
*        WHILE Y.USER.ROLES : ROLE.POS
        WHILE USER.CNT LE USER.COUNT
           Y.USER.ROLES = Y.USERROLES.LIST<USER.CNT>   
           LOCATE Y.USER.ROLES IN USERROLES.FV<1,USERROLE.POS,1> SETTING FV.USERROLE.POS THEN
              LOCATE 'CASH' IN Y.CASHROLES.FN<1,1> SETTING CASHROLE.POS THEN
                 TXNTYPES = Y.CASHROLES.TXNTYPES.FV<1,CASHROLE.POS>
*                 CHANGE SM TO ' ' IN TXNTYPES
              END 
           END
           USER.CNT += 1
        REPEAT
    END
    
    IF TXNTYPES EQ '' THEN
        GOSUB SEC.USER.ROLE.CHK
    END
    
    RETURN
*-----------------------------------------------------------------------------------------------------------------        
******************
SEC.USER.ROLE.CHK:
******************
* In this para of the program, the user role is checked against security users
**
    USER.COUNT = DCOUNT(Y.USERROLES.LIST,FM)
    USER.CNT = 1

    LOCATE 'SEC.USER.ROLES' IN USERROLES.FN<1,1> SETTING USERROLE.POS THEN
       LOOP
*          REMOVE Y.USER.ROLES FROM Y.USERROLES.LIST SETTING ROLE.POS
*       WHILE Y.USER.ROLES : ROLE.POS
       WHILE USER.CNT LE USER.COUNT
         Y.USER.ROLES = Y.USERROLES.LIST<USER.CNT>   
         LOCATE Y.USER.ROLES IN USERROLES.FV<1,USERROLE.POS,1> SETTING FV.USERROLE.POS THEN
             LOCATE 'SEC' IN Y.SECROLES.FN<1,1> SETTING SECROLE.POS THEN
                TXNTYPES = Y.SECROLES.TXNTYPES.FV<1,SECROLE.POS>
*                CHANGE SM TO ' ' IN TXNTYPES
             END
         END
       USER.CNT += 1
       REPEAT
    END         
   
    RETURN 
* (E) - DAY15-4878
*-----------------------------------------------------------------------------------------------------------------
**************    
GET.SEL.LIST:
**************

*    SEL.CMD = "SELECT ":FN.FUNDS.TRANSFER.NAU
* JB2A-26146 Start
    SEL.CMD = "SELECT ":FN.FUNDS.TRANSFER.NAU:" WITH RECORD.STATUS EQ 'INAU' OR RECORD.STATUS EQ 'INA2' "
* (S) - DAY15-4878

     CONVERT SM TO FM IN TXNTYPES
     CONVERT VM TO FM IN TXNTYPES
     TXNTYPES.CNT = DCOUNT(TXNTYPES,FM)

     I = 1
     LOOP
     WHILE I LE TXNTYPES.CNT
        IF TXNTYPES<I> NE '' THEN
              SEL.CMD := " AND TRANSACTION.TYPE NE '":TXNTYPES<I>:"' "
        END
        I += 1
     REPEAT
* (E) - DAY15-4878
* JB2A-26146 End
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE Y.FT.ID FROM SEL.LIST SETTING FT.ID.POS
        WHILE Y.FT.ID : FT.ID.POS
            GOSUB GET.DETAILS
            GOSUB PUT.LOGIC
        REPEAT
    END

    RETURN
*-----------------------------------------------------------------------------
***************
GET.SEL.LIST.PO:
***************

    SEL.CMD = "SELECT ":FN.PAYMENT.ORDER.NAU:" WITH RECORD.STATUS EQ 'INAU' OR RECORD.STATUS EQ 'INA2' "
    
    CONVERT SM TO FM IN TXNTYPES
    CONVERT VM TO FM IN TXNTYPES
    TXNTYPES.CNT = DCOUNT(TXNTYPES,FM)

    I = 1
    LOOP
    WHILE I LE TXNTYPES.CNT
        IF TXNTYPES<I> NE '' THEN
            SEL.CMD := " AND PAYMENT.ORDER.PRODUCT NE '":TXNTYPES<I>:"' "
        END
        I += 1
    REPEAT

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
     
    IF SEL.LIST THEN
        LOOP
            REMOVE Y.FT.ID FROM SEL.LIST SETTING PO.ID.POS
        WHILE Y.FT.ID : PO.ID.POS
            GOSUB GET.DETAILS.PO
            GOSUB PUT.LOGIC
        REPEAT
    END

RETURN

*-----------------------------------------------------------------------------
***************
GET.SEL.LIST.OE:
***************
   
    SEL.CMD = "SELECT ":FN.PP.ORDER.ENTRY.NAU:" WITH RECORD.STATUS EQ 'INAU' OR RECORD.STATUS EQ 'INA2' "

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE Y.FT.ID FROM SEL.LIST SETTING OE.ID.POS
        WHILE Y.FT.ID : OE.ID.POS
            GOSUB GET.DETAILS.OE
            GOSUB PUT.LOGIC
        REPEAT
    END

RETURN

*-----------------------------------------------------------------------------
GET.DETAILS:
*************
***JB2A-42979 S/
    DB.TEAM.ID = ''
    Y.DB.PORT.NAME = ''
    CR.TEAM.ID = ''
    Y.CR.PORT.NAME=''
***JB2A-42979 /E
    CALL F.READ(FN.FUNDS.TRANSFER.NAU,Y.FT.ID,R.FT.REC,F.FUNDS.TRANSFER.NAU,FT.ERR)

    IF R.FT.REC THEN

        Y.DEBIT.AC.NO = R.FT.REC<FT.DEBIT.ACCT.NO>
        Y.DEBIT.CUS = R.FT.REC<FT.DEBIT.CUSTOMER>
        GOSUB GET.DEBIT.ACC.DETAILS
        IF Y.DEBIT.CUS THEN
            GOSUB GET.DEBIT.CUS.DETAILS
        END

        Y.CREDIT.AC.NO = R.FT.REC<FT.CREDIT.ACCT.NO>
        Y.CREDIT.CUS = R.FT.REC<FT.CREDIT.CUSTOMER>
        GOSUB GET.CREDIT.ACC.DETAILS
        IF Y.CREDIT.CUS THEN
            GOSUB GET.CREDIT.CUS.DETAILS
        END


        Y.TXN.TYPE = R.FT.REC<FT.TRANSACTION.TYPE>
        GOSUB GET.FT.TXN.TYPE.DETAILS

        Y.RCRD.STATUS=R.FT.REC<FT.RECORD.STATUS>
        Y.FT.CR.CCY=R.FT.REC<FT.CREDIT.CURRENCY>
        Y.FT.DB.CCY=R.FT.REC<FT.DEBIT.CURRENCY>
        Y.DATE=R.FT.REC<FT.DATE.TIME>
        Y.FT.BOOKING.DATE = OCONV(ICONV(Y.DATE[1,6],"D2/"),'D4Y'):Y.DATE[3,4]

        Y.FT.CREDIT.DATE=R.FT.REC<FT.CREDIT.VALUE.DATE>
        Y.FT.DEBIT.DATE=R.FT.REC<FT.DEBIT.VALUE.DATE>
        Y.FT.PROC.DATE=R.FT.REC<FT.PROCESSING.DATE>
        * JB2A-26146 Start
        GOSUB FETCH.AMT
        * JB2A-26146 End
        Y.LCL.DB.AMT=R.FT.REC<FT.LOC.AMT.DEBITED>
        Y.LCL.CR.AMT=R.FT.REC<FT.LOC.AMT.CREDITED>
        Y.FT.AMT.DBT1=R.FT.REC<FT.AMOUNT.DEBITED>
        Y.FT.AMT.DBT=Y.FT.AMT.DBT1[4,-1]
        Y.FT.AMT.CRT1=R.FT.REC<FT.AMOUNT.CREDITED>
        Y.FT.AMT.CRT=Y.FT.AMT.CRT1[4,-1]
        Y.FT.ORD.CUS=R.FT.REC<FT.ORDERING.CUST>
        Y.FT.ORD.BNK=R.FT.REC<FT.ORDERING.BANK>
        Y.FT.TRS.RATE=R.FT.REC<FT.TREASURY.RATE>
        Y.FT.CCODE=R.FT.REC<FT.CO.CODE>
        Y.GO.FLAG = '1'
    END

    RETURN

*-----------------------------------------------------------------------------
**************
GET.DETAILS.PO:
**************

    DB.TEAM.ID = ''
    Y.DB.PORT.NAME = ''
    CR.TEAM.ID = ''
    Y.CR.PORT.NAME=''
    Y.DEBIT.AC.NO='';Y.DEBIT.CUS='';Y.CREDIT.AC.NO='';Y.CREDIT.CUS='';Y.TXN.TYPE=''
    Y.RCRD.STATUS='';Y.FT.CR.CCY='';Y.FT.DB.CCY='';Y.DATE='';Y.FT.BOOKING.DATE='';Y.FT.CREDIT.DATE=''
    Y.FT.DEBIT.DATE='';Y.FT.PROC.DATE='';Y.LCL.DB.AMT='';Y.LCL.CR.AMT='';Y.FT.AMT.DBT1=''
    Y.FT.AMT.CRT1='';Y.FT.ORD.CUS='';Y.FT.ORD.BNK='';Y.FT.TRS.RATE='';Y.FT.CCODE=''

    CALL F.READ(FN.PAYMENT.ORDER.NAU,Y.FT.ID,R.PO.REC,F.PAYMENT.ORDER.NAU,PO.ERR)

    IF R.PO.REC THEN

        Y.DEBIT.AC.NO = R.PO.REC<PO.DEBIT.ACCOUNT>
        Y.DEBIT.CUS = R.PO.REC<PO.ORDERING.CUSTOMER>
        GOSUB GET.DEBIT.ACC.DETAILS
        IF Y.DEBIT.CUS THEN
            GOSUB GET.DEBIT.CUS.DETAILS
        END

        Y.CREDIT.AC.NO = R.PO.REC<PO.CREDIT.ACCOUNT>
        GOSUB GET.CREDIT.CUSTOMER
        GOSUB GET.CREDIT.ACC.DETAILS
        IF Y.CREDIT.CUS THEN
            GOSUB GET.CREDIT.CUS.DETAILS
        END


        Y.TXN.TYPE = R.PO.REC<PO.PAYMENT.ORDER.PRODUCT>
        GOSUB GET.PAY.ORDER.PROD.DETAILS

        Y.RCRD.STATUS=R.PO.REC<PO.RECORD.STATUS>
        Y.FT.CR.CCY=R.PO.REC<PO.CREDIT.CURRENCY>
        Y.FT.DB.CCY=R.PO.REC<PO.DEBIT.CCY>
        Y.DATE=R.PO.REC<PO.DATE.TIME>
        Y.FT.BOOKING.DATE = OCONV(ICONV(Y.DATE[1,6],"D2/"),'D4Y'):Y.DATE[3,4]

        Y.FT.CREDIT.DATE=R.PO.REC<PO.CREDIT.VALUE.DATE>
        Y.FT.DEBIT.DATE=R.PO.REC<PO.DEBIT.VALUE.DATE>
	IF Y.FT.DEBIT.DATE EQ '' THEN
	   IF Y.FT.CREDIT.DATE NE '' THEN
	     Y.FT.DEBIT.DATE = Y.FT.CREDIT.DATE
	   END ELSE
	      Y.FT.DEBIT.DATE = R.PO.REC<PO.REQUIRED.CREDIT.VALUE.DATE>
	   END
	END

        Y.FT.PROC.DATE=R.PO.REC<PO.PAYMENT.EXECUTION.DATE>

        GOSUB FETCH.AMT.PO

        Y.LCL.DB.AMT=R.PO.REC<PO.TOTAL.DEBIT.AMOUNT>
        Y.LCL.CR.AMT=R.PO.REC<PO.CREDIT.AMOUNT>
        Y.FT.AMT.DBT=R.PO.REC<PO.DEBIT.AMOUNT>
        Y.FT.AMT.CRT=R.PO.REC<PO.CREDIT.AMOUNT>
        Y.FT.ORD.CUS=R.PO.REC<PO.ORDERING.CUSTOMER>
        Y.FT.ORD.BNK=R.PO.REC<PO.ORDERING.CUSTOMER.BIC>
        Y.FT.TRS.RATE=R.PO.REC<PO.ORDERING.PAYMENT.TREASURY.RATE>
        Y.FT.CCODE=R.PO.REC<PO.CO.CODE>
        Y.GO.FLAG = '1'
    END

RETURN
*-----------------------------------------------------------------------------
**************
GET.DETAILS.OE:
**************

    DB.TEAM.ID = ''
    Y.DB.PORT.NAME = ''
    CR.TEAM.ID = ''
    Y.CR.PORT.NAME=''
    Y.DEBIT.AC.NO='';Y.DEBIT.CUS='';Y.CREDIT.AC.NO='';Y.CREDIT.CUS='';Y.TXN.TYPE=''
    Y.RCRD.STATUS='';Y.FT.CR.CCY='';Y.FT.DB.CCY='';Y.DATE='';Y.FT.BOOKING.DATE='';Y.FT.CREDIT.DATE=''
    Y.FT.DEBIT.DATE='';Y.FT.PROC.DATE='';Y.LCL.DB.AMT='';Y.LCL.CR.AMT='';Y.FT.AMT.DBT1=''
    Y.FT.AMT.CRT1='';Y.FT.ORD.CUS='';Y.FT.ORD.BNK='';Y.FT.TRS.RATE='';Y.FT.CCODE=''

    CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.FT.ID,R.OE.REC,F.PP.ORDER.ENTRY.NAU,OE.ERR)

    IF R.OE.REC THEN

        Y.DEBIT.AC.NO = R.OE.REC<PP.OEYG.DebitAccountNumber>
        Y.DEBIT.CUS = R.OE.REC<PP.OEYG.OrderingCustomerId>
        GOSUB GET.DEBIT.ACC.DETAILS
        IF Y.DEBIT.CUS THEN
            GOSUB GET.DEBIT.CUS.DETAILS
        END

        Y.CREDIT.AC.NO = R.OE.REC<PP.OEYG.CreditAccountNumber>
        GOSUB GET.CREDIT.CUSTOMER
        GOSUB GET.CREDIT.ACC.DETAILS
        IF Y.CREDIT.CUS THEN
            GOSUB GET.CREDIT.CUS.DETAILS
        END

        Y.OE.LOCFIELD.NAME = R.OE.REC<PP.OEYG.LocalFieldName>

        LOCATE "L.PP.DEF.INW.IT" IN Y.OE.LOCFIELD.NAME<1,1> SETTING Y.OE.POS THEN
           Y.TXN.TYPE =  R.OE.REC<PP.OEYG.LocalFieldValue,Y.OE.POS>
        END

        GOSUB GET.PAY.ORDER.PROD.DETAILS

        Y.RCRD.STATUS=R.OE.REC<PP.OEYG.RECORD.STATUS>
        Y.FT.CR.CCY=R.OE.REC<PP.OEYG.CreditAccountCurrency>

	IF Y.FT.CR.CCY EQ '' THEN
	   IF Y.CREDIT.AC.NO NE '' THEN
	    Y.FT.CR.CCY = R.CREDIT.ACC.REC<AC.CURRENCY>	   
	   END

	END

        Y.FT.DB.CCY=R.OE.REC<PP.OEYG.DebitAccountCurrency>
        Y.DATE=R.OE.REC<PP.OEYG.DATE.TIME>
        Y.FT.BOOKING.DATE = OCONV(ICONV(Y.DATE[1,6],"D2/"),'D4Y'):Y.DATE[3,4]

        Y.FT.CREDIT.DATE=R.OE.REC<PP.OEYG.CreditValueDate>
        Y.FT.DEBIT.DATE=R.OE.REC<PP.OEYG.DebitValueDate>
        Y.FT.PROC.DATE=R.OE.REC<PP.OEYG.ProcessingDate>

        GOSUB FETCH.AMT.OE

        Y.LCL.DB.AMT=R.OE.REC<PP.OEYG.DebitAmount>
        Y.LCL.CR.AMT=R.OE.REC<PP.OEYG.CreditAmount>
        Y.FT.AMT.DBT=R.OE.REC<PP.OEYG.DebitAmount>
        Y.FT.AMT.CRT=R.OE.REC<PP.OEYG.CreditAmount>
        Y.FT.ORD.CUS=R.OE.REC<PP.OEYG.OrderingCustomerId>
        Y.FT.ORD.BNK=R.OE.REC<PP.OEYG.SenderInstitutionBIC>
        Y.FT.TRS.RATE=R.OE.REC<PP.OEYG.DebitTreasuryRate>
        Y.FT.CCODE=R.OE.REC<PP.OEYG.CO.CODE>
        Y.GO.FLAG = '1'
    END

RETURN
*-----------------------------------------------------------------------------
FETCH.AMT:
*********
* JB2A-26146 Start
    IF Y.FT.CR.CCY EQ Y.FT.DB.CCY THEN
        Y.FT.DB.AMT=R.FT.REC<FT.DEBIT.AMOUNT>
        IF Y.FT.DB.AMT NE '' THEN
            Y.FT.CR.AMT = Y.FT.DB.AMT
        END ELSE
            Y.FT.CR.AMT=R.FT.REC<FT.CREDIT.AMOUNT>
            Y.FT.DB.AMT = Y.FT.CR.AMT
        END
    END ELSE
        Y.FT.DB.AMT= R.FT.REC<FT.DEBIT.AMOUNT>
        IF Y.FT.DB.AMT NE '' THEN
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.DB.CCY
            BUY.CCY = Y.FT.CR.CCY
            SELL.AMT = Y.FT.DB.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.CR.AMT = BUY.AMT
        END ELSE
            Y.FT.CR.AMT=R.FT.REC<FT.CREDIT.AMOUNT>
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.CR.CCY
            BUY.CCY = Y.FT.DB.CCY
            SELL.AMT = Y.FT.CR.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.DB.AMT = BUY.AMT
        END
    END

    RETURN
* JB2A-26146 End
*-----------------------------------------------------------------------------
************
FETCH.AMT.PO:
************

    IF Y.FT.CR.CCY EQ Y.FT.DB.CCY THEN
        Y.FT.DB.AMT=R.PO.REC<PO.DEBIT.AMOUNT>
        IF Y.FT.DB.AMT NE '' THEN
            Y.FT.CR.AMT = Y.FT.DB.AMT
        END ELSE
            Y.FT.CR.AMT=R.PO.REC<PO.PAYMENT.AMOUNT>
            Y.FT.DB.AMT = Y.FT.CR.AMT
        END
    END ELSE
        Y.FT.DB.AMT= R.PO.REC<PO.DEBIT.AMOUNT>
        IF Y.FT.DB.AMT NE '' THEN
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.DB.CCY
            BUY.CCY = Y.FT.CR.CCY
            SELL.AMT = Y.FT.DB.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.CR.AMT = BUY.AMT
        END ELSE
            Y.FT.CR.AMT=R.PO.REC<PO.PAYMENT.AMOUNT>
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.CR.CCY
            BUY.CCY = Y.FT.DB.CCY
            SELL.AMT = Y.FT.CR.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.DB.AMT = BUY.AMT
        END
    END

RETURN
*-----------------------------------------------------------------------------
************
FETCH.AMT.OE:
*************

    IF Y.FT.CR.CCY EQ Y.FT.DB.CCY THEN
        Y.FT.DB.AMT=R.OE.REC<PP.OEYG.DebitAmount>
        IF Y.FT.DB.AMT NE '' THEN
            Y.FT.CR.AMT = Y.FT.DB.AMT
        END ELSE
            Y.FT.CR.AMT=R.OE.REC<PP.OEYG.TransactionAmount>
            Y.FT.DB.AMT = Y.FT.CR.AMT
        END
    END ELSE
        Y.FT.DB.AMT= R.OE.REC<PP.OEYG.DebitAmount>
        IF Y.FT.DB.AMT NE '' THEN
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.DB.CCY
            BUY.CCY = Y.FT.CR.CCY
            SELL.AMT = Y.FT.DB.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.CR.AMT = BUY.AMT
        END ELSE
            Y.FT.CR.AMT=R.OE.REC<PP.OEYG.TransactionAmount>
            BASE.CCY = ''
            EXCHANGE.RATE = ''
            DIFFERENCE = ''
            LCY.AMT = ''
            RET.CODE = ''
            CCY.MKT = '1'
            BUY.AMT = ''
            SELL.CCY = Y.FT.CR.CCY
            BUY.CCY = Y.FT.DB.CCY
            SELL.AMT = Y.FT.CR.AMT
            CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RET.CODE)
            Y.FT.DB.AMT = BUY.AMT
        END
    END

RETURN
*-----------------------------------------------------------------------------
**********************
GET.DEBIT.CUS.DETAILS:
***********************
    DB.OFFCR.TYPE=''
    DB.OFFCR.ID=''
    DB.CUS.MNEMONIC=''
    CALL F.READ(FN.CUSTOMER,Y.DEBIT.CUS,R.DEBIT.CUS.REC,F.CUSTOMER,CUS.DB.ERR)
    IF R.DEBIT.CUS.REC THEN
        DB.OFFCR.TYPE=R.DEBIT.CUS.REC<EB.CUS.LOCAL.REF,L.ST.OFFICER.TYPE.POS>
        DB.OFFCR.ID=R.DEBIT.CUS.REC<EB.CUS.LOCAL.REF,L.ST.OFFICER.ID.POS>
        DB.CUS.MNEMONIC=R.DEBIT.CUS.REC<EB.CUS.MNEMONIC>
        DB.RM.ID = R.DEBIT.CUS.REC<EB.CUS.ACCOUNT.OFFICER>
    END
    RETURN
*-----------------------------------------------------------------------------
GET.DEBIT.ACC.DETAILS:
***********************
    Y.DB.PORTFOLIO.ID =''
    Y.DB.ALT.ACCNT.TYPE =''
    Y.DB.ALT.ACCNT.ID1 =''
    Y.DB.ALT.ACCNT.ID =''
    CALL F.READ(FN.ACCOUNT,Y.DEBIT.AC.NO,R.DEBIT.ACC.REC,F.ACCOUNT,ACC.DB.ERR)
    IF R.DEBIT.ACC.REC THEN
        Y.DB.PORTFOLIO.ID = R.DEBIT.ACC.REC<AC.PORTFOLIO.NO>
        Y.DB.ALT.ACCNT.TYPE = R.DEBIT.ACC.REC<AC.ALT.ACCT.TYPE>
        Y.DB.ALT.ACCNT.ID1 = R.DEBIT.ACC.REC<AC.ALT.ACCT.ID>
        Y.DEBIT.CUS = R.DEBIT.ACC.REC<AC.CUSTOMER>

        LOCATE 'BJB.ACCT' IN Y.DB.ALT.ACCNT.TYPE<1,1> SETTING ALT.ACC.TYP.POS THEN
        Y.DB.ALT.ACCNT.ID = Y.DB.ALT.ACCNT.ID1<1,ALT.ACC.TYP.POS>
    END
    IF Y.DB.PORTFOLIO.ID THEN
        GOSUB GET.DEBIT.SEC.ACC.DETAILS
    END
    END
    RETURN
*-----------------------------------------------------------------------------
GET.DEBIT.SEC.ACC.DETAILS:
***************************
    NOFDBPORTID=DCOUNT(Y.DB.PORTFOLIO.ID,VM)
    Y.DB.CNT=1
    DB.TEAM.ID = ''
    LOOP
    WHILE Y.DB.CNT LE NOFDBPORTID
        Y.DBPORT.ID=Y.DB.PORTFOLIO.ID<1,Y.DB.CNT>

        CALL F.READ(FN.SEC.ACC.MASTER,Y.DBPORT.ID,R.DB.SEC.ACC.REC,F.SEC.ACC.MASTER,SEC.DB.ERR)
        IF R.DB.SEC.ACC.REC THEN
            DB.TEAM.ID1=R.DB.SEC.ACC.REC<SC.SAM.LOCAL.REF,L.XX.TEAM.ID.POS>
            DB.TEAM.ID<1,-1> = DB.TEAM.ID1
            Y.DB.PORT.NAME = R.DB.SEC.ACC.REC<SC.SAM.ACCOUNT.NAME>      ;* Jira 28788 S/E
        END
        Y.DB.CNT += 1
    REPEAT
    RETURN
*-----------------------------------------------------------------------------
GET.CREDIT.CUS.DETAILS:
************************
    CR.OFFCR.TYPE=''
    CR.OFFCR.ID=''
    CR.CUS.MNEMONIC=''

    CALL F.READ(FN.CUSTOMER,Y.CREDIT.CUS,R.CREDIT.CUS.REC,F.CUSTOMER,CUS.CR.ERR)
    IF R.CREDIT.CUS.REC THEN
        CR.OFFCR.TYPE=R.CREDIT.CUS.REC<EB.CUS.LOCAL.REF,L.ST.OFFICER.TYPE.POS>
        CR.OFFCR.ID=R.CREDIT.CUS.REC<EB.CUS.LOCAL.REF,L.ST.OFFICER.ID.POS>
        CR.CUS.MNEMONIC=R.CREDIT.CUS.REC<EB.CUS.MNEMONIC>
        CR.RM.ID = R.CREDIT.CUS.REC<EB.CUS.ACCOUNT.OFFICER>
    END

    RETURN
*-----------------------------------------------------------------------------
GET.CREDIT.ACC.DETAILS:
************************
    Y.CR.PORTFOLIO.ID =''
    Y.CR.ALT.ACCNT.TYPE =''
    Y.CR.ALT.ACCNT.ID1 =''
    Y.CR.ALT.ACCNT.ID = ''

    CALL F.READ(FN.ACCOUNT,Y.CREDIT.AC.NO,R.CREDIT.ACC.REC,F.ACCOUNT,ACC.CR.ERR)
    IF R.CREDIT.ACC.REC THEN
        Y.CR.PORTFOLIO.ID = R.CREDIT.ACC.REC<AC.PORTFOLIO.NO>
        Y.CR.ALT.ACCNT.TYPE = R.CREDIT.ACC.REC<AC.ALT.ACCT.TYPE>
        Y.CR.ALT.ACCNT.ID1 = R.CREDIT.ACC.REC<AC.ALT.ACCT.ID>
        Y.CREDIT.CUS = R.CREDIT.ACC.REC<AC.CUSTOMER>

        LOCATE 'BJB.ACCT' IN Y.CR.ALT.ACCNT.TYPE<1,1> SETTING CRALT.ACC.TYP.POS THEN
        Y.CR.ALT.ACCNT.ID = Y.CR.ALT.ACCNT.ID1<1,CRALT.ACC.TYP.POS>
    END
    IF Y.CR.PORTFOLIO.ID THEN
        GOSUB GET.CREDIT.SEC.ACC.DETAILS
    END
    END
    RETURN
*-----------------------------------------------------------------------------
GET.CREDIT.SEC.ACC.DETAILS:
****************************
    NOFCRPORTID=DCOUNT(Y.CR.PORTFOLIO.ID,VM)
    Y.CR.CNT=1
    CR.TEAM.ID = ''
    LOOP
    WHILE Y.CR.CNT LE NOFCRPORTID
        Y.CRPORT.ID=Y.CR.PORTFOLIO.ID<1,Y.CR.CNT>

        CALL F.READ(FN.SEC.ACC.MASTER,Y.CRPORT.ID,R.CR.SEC.ACC.REC,F.SEC.ACC.MASTER,SEC.CR.ERR)
        IF R.CR.SEC.ACC.REC THEN
            CR.TEAM.ID1=R.CR.SEC.ACC.REC<SC.SAM.LOCAL.REF,L.XX.TEAM.ID.POS>
            CR.TEAM.ID<1,-1> = CR.TEAM.ID1
            Y.CR.PORT.NAME = R.CR.SEC.ACC.REC<SC.SAM.ACCOUNT.NAME>          ;* Jira 28788 S/E
        END
        Y.CR.CNT += 1
    REPEAT
    RETURN
*-----------------------------------------------------------------------------------
GET.CREDIT.CUSTOMER:
********************
  CALL F.READ(FN.ACCOUNT,Y.CREDIT.AC.NO,R.CREDIT.AC.NO,F.ACCOUNT,ACC.ERR)
  
  IF R.CREDIT.AC.NO THEN
    Y.CREDIT.CUS = R.CREDIT.AC.NO<AC.CUSTOMER>
  END 
  
RETURN

*-----------------------------------------------------------------------------
GET.FT.TXN.TYPE.DETAILS:
*************************
    CALL F.READ(FN.FT.TXN.TYPE.CONDITION,Y.TXN.TYPE,R.FT.TXN.REC,F.FT.TXN.TYPE.CONDITION,FT.TXN.ERR)

    IF R.FT.TXN.REC THEN
        Y.DESC = R.FT.TXN.REC<FT6.DESCRIPTION>
    END
    RETURN
*-----------------------------------------------------------------------------
GET.PAY.ORDER.PROD.DETAILS:
*************************
    CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,Y.TXN.TYPE,R.TXN.REC,F.PAYMENT.ORDER.PRODUCT,TXN.ERR)

    IF R.TXN.REC THEN
        Y.DESC = R.TXN.REC<POP.DESCRIPTION>
    END 

RETURN
*-----------------------------------------------------------------------------------------------
PUT.LOGIC:
***********

    Y.AC = Y.DEBIT.AC.NO:FM:Y.CREDIT.AC.NO
    Y.CNT1 = 1
    Y.DCNT = 2
    LOOP
    WHILE Y.CNT1 LE Y.DCNT
        Y.AC.ID = Y.AC<Y.CNT1>
        GOSUB PERFORM.CHK
        Y.CNT1 += 1
    REPEAT
    RETURN
*-----------------------------------------------------------------------------------------------
PERFORM.CHK:
************
    USER.FLAG = 'TRUE'
    ACCOUNTOFFICER.FLAG = 'TRUE'
    PORTFOLIO.FLAG = 'TRUE'
    ACCOUNT.FLAG = 'TRUE'
    ROLE.FLAG = 'TRUE'
    IF Y.CNT1 EQ 1 THEN
        GOSUB DB.TEAM.CHK            ;* Jira 28788 s/e
    END
    IF Y.CNT1 EQ 2 THEN
        GOSUB CR.TEAM.CHK            ;* Jira 28788 s/e
    END
    RETURN
*-----------------------------------------------------------------------------------------------
DB.TEAM.CHK:                                    ;* Jira 28788 s/
*----------
    IF Y.TEAM.ID THEN
        DB.TEAM.ID.CNT=DCOUNT(DB.TEAM.ID,VM)
        Y.CNT.DB=1
        LOOP
        WHILE Y.CNT.DB LE DB.TEAM.ID.CNT
            DBTEAMID = DB.TEAM.ID<1,Y.CNT.DB>
            *            DBTEAMID = DBTEAMID[2,9]
            IF DBTEAMID MATCHES Y.TEAM.ID THEN
                GOSUB DB.ARR.CHK
            END ELSE
                GOSUB DB.USR.CHK
            END
            Y.CNT.DB += 1
        REPEAT
    END ELSE
        GOSUB DB.USR.CHK
    END
    RETURN
*-----------------------------------------------------------------------------
DB.USR.CHK:
*----------
    IF Y.USER.ID THEN
        IF Y.DB.PORT.NAME MATCHES PORT.ALLOW THEN
            USER.FLAG = 'TRUE'
        END ELSE
            USER.FLAG = 'FALSE'
        END
    END
    GOSUB DB.ARR.CHK
    RETURN                                              ;* Jira 28788 /e
*-----------------------------------------------------------------------------
DB.ARR.CHK:
***********
    IF Y.ACCOUNT.OFFICER NE '' THEN
        IF DB.OFFCR.ID MATCHES Y.ACCOUNT.OFFICER THEN
        END ELSE
            ACCOUNTOFFICER.FLAG = 'FALSE'
        END
    END
    IF Y.PORTFOLIO.NO NE '' THEN
        IF Y.DB.PORTFOLIO.ID MATCHES Y.PORTFOLIO.NO THEN
        END ELSE
            PORTFOLIO.FLAG = 'FALSE'
        END
    END
    IF Y.ACCOUNT.NO NE '' THEN
        IF Y.DEBIT.AC.NO MATCHES Y.ACCOUNT.NO THEN
        END ELSE
            ACCOUNT.FLAG = 'FALSE'
        END
    END
    IF Y.ROLE NE '' THEN
        IF DB.OFFCR.TYPE MATCHES Y.ROLE THEN
        END ELSE
            ROLE.FLAG = 'FALSE'
        END
    END
    IF USER.FLAG EQ 'TRUE' AND ACCOUNTOFFICER.FLAG EQ 'TRUE' AND PORTFOLIO.FLAG EQ 'TRUE' AND ACCOUNT.FLAG EQ 'TRUE' AND ROLE.FLAG EQ 'TRUE' THEN
        Y.LIST<-1> = DB.RM.ID:"*":Y.DB.ALT.ACCNT.ID:"*":Y.DESC:"*":Y.RCRD.STATUS:"*":Y.FT.ID:"*":Y.FT.DB.CCY:"*":Y.FT.BOOKING.DATE:"*":Y.FT.DEBIT.DATE:"*":Y.FT.PROC.DATE:"*":Y.FT.DB.AMT:"*":Y.LCL.DB.AMT:"*":Y.FT.AMT.DBT:"*":Y.FT.ORD.CUS:"*":Y.FT.ORD.BNK:"*":Y.FT.TRS.RATE:"*":DB.TEAM.ID:"*":DB.CUS.MNEMONIC:"*":Y.FT.CCODE:"*":'D':"*":SEL.PORT.ID
    END
    RETURN
*-----------------------------------------------------------------------------------------------
CR.TEAM.CHK:                                            ;* Jira 28788 s/
*----------
    IF Y.TEAM.ID THEN
        CR.TEAM.ID.CNT=DCOUNT(CR.TEAM.ID,VM)
        Y.CNT.CR=1
        LOOP
        WHILE Y.CNT.CR LE CR.TEAM.ID.CNT
            CRTEAMID = CR.TEAM.ID<1,Y.CNT.CR>
            *            CRTEAMID = CRTEAMID[2,9]
            IF CRTEAMID MATCHES Y.TEAM.ID THEN
                GOSUB CR.ARR.CHK
            END ELSE
                GOSUB CR.USR.CHK
            END
            Y.CNT.CR += 1
        REPEAT
    END ELSE
        GOSUB CR.USR.CHK
    END
    RETURN
*-----------------------------------------------------------------------------
CR.USR.CHK:
*----------
    IF Y.USER.ID THEN
        IF Y.CR.PORT.NAME MATCHES PORT.ALLOW THEN
            USER.FLAG = 'TRUE'
        END ELSE
            USER.FLAG = 'FALSE'
        END
    END
    GOSUB CR.ARR.CHK
    RETURN                                               ;* Jira 28788 /e
*-----------------------------------------------------------------------------------------------
CR.ARR.CHK:
***********
    IF Y.ACCOUNT.OFFICER NE '' THEN
        IF CR.OFFCR.ID MATCHES Y.ACCOUNT.OFFICER THEN
        END ELSE
            ACCOUNTOFFICER.FLAG = 'FALSE'
        END
    END
    IF Y.PORTFOLIO.NO NE '' THEN
        IF Y.CR.PORTFOLIO.ID MATCHES Y.PORTFOLIO.NO THEN
        END ELSE
            PORTFOLIO.FLAG = 'FALSE'
        END
    END
    IF Y.ACCOUNT.NO NE '' THEN
        IF Y.CREDIT.AC.NO MATCHES Y.ACCOUNT.NO THEN
        END ELSE
            ACCOUNT.FLAG = 'FALSE'
        END
    END
    IF Y.ROLE NE '' THEN
        IF CR.OFFCR.TYPE MATCHES Y.ROLE THEN
        END ELSE
            ROLE.FLAG = 'FALSE'
        END
    END
    IF USER.FLAG EQ 'TRUE' AND ACCOUNTOFFICER.FLAG EQ 'TRUE' AND PORTFOLIO.FLAG EQ 'TRUE' AND ACCOUNT.FLAG EQ 'TRUE' AND ROLE.FLAG EQ 'TRUE' THEN
        Y.LIST<-1> = CR.RM.ID:"*":Y.CR.ALT.ACCNT.ID:"*":Y.DESC:"*":Y.RCRD.STATUS:"*":Y.FT.ID:"*":Y.FT.CR.CCY:"*":Y.FT.BOOKING.DATE:"*":Y.FT.CREDIT.DATE:"*":Y.FT.PROC.DATE:"*":Y.FT.CR.AMT:"*":Y.LCL.CR.AMT:"*":Y.FT.AMT.CRT:"*":Y.FT.ORD.CUS:"*":Y.FT.ORD.BNK:"*":Y.FT.TRS.RATE:"*":CR.TEAM.ID:"*":CR.CUS.MNEMONIC:"*":Y.FT.CCODE:"*":'C':"*":SEL.PORT.ID
    END
    RETURN
*-----------------------------------------------------------------------------------------------
END

