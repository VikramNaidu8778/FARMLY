* @ValidationCode : MTo4NTUyMzMzMDA6SVNPLTg4NTktMToxNTEwMTIwMTI2Nzk2OjUzNDQ2MjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNA==
* @ValidationInfo : Timestamp         : 28 Aug 2018 14:23:46
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 534462
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-----------------------------------------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.ACCTCOMP.CHECK
*-----------------------------------------------------------------------------------------------------------------
* This is an Input routine attached to VERSION.CONTROL of FUNDS.TRANSFER application to check if the DEBIT.ACCT.NO 
* and CREDIT.ACCT.NO belong to the same company if not an error will appear 
*-----------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date               Developer                          Reference          Description
* ---------------------------------------------------------------------------------------
* 03/09/2018        Kalyani.L.K                         DAY15-1593        Initial Version
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
*-----------------------------------------------------------------------------------------------------------------    
**********
MAIN.PARA:
**********
* This is the para of the program, from where the execution of the code starts
**
    GOSUB PROCESS.PARA

    RETURN
*-----------------------------------------------------------------------------------------------------------------
*************
PROCESS.PARA:
*************
* In this para of the program, the main processing starts
**
    DEBIT.COMP  = R.NEW(FT.DEBIT.COMP.CODE)
	CREDIT.COMP = R.NEW(FT.CREDIT.COMP.CODE)
	
	IF (ID.COMPANY NE DEBIT.COMP) OR (ID.COMPANY NE CREDIT.COMP) THEN
	  AF = 0
	  ETEXT = "FT-ACCTCOMP.CHECK"
	  CALL STORE.END.ERROR
	END
	
    RETURN
*-----------------------------------------------------------------------------------------
END       ;*End of program