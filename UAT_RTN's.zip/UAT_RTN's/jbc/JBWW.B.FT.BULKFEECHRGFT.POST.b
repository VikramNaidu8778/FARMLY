*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
* @ValidationCode : MTotMTI4MDM1Njk3NDpVVEYtODoxNDcwOTA4Njk0NTAyOjIzMzE3OTotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.B.FT.BULKFEECHRGFT.POST
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer                     Reference            Description
*-----------------------------------------------------------------------------
* 
* ----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_T24.UPLOAD.PROCESS.COMMON
    $INSERT I_F.EB.FILE.UPLOAD.PARAM
    $INSERT I_F.EB.FILE.UPLOAD.TYPE
    $INSERT I_F.EB.FILE.UPLOAD
    $INSERT I_JBWW.B.FT.BULKFEECHRGUPLOAD.COMMON

*-----------------------------------------------------------------------------
    GOSUB INIT
	GOSUB PROCESS
	
    RETURN
*-----------------------------------------------------------------------------
INIT:
******

    RETURN
*-----------------------------------------------------------------------------

PROCESS:
********

    Y.SOURCE.PATH = Y.DIR : "/" : UPLOAD.DIR:"/":Y.CSV.NAME
	
	X = OCONV(DATE(),'D4-')
    TIME.STAMP = TIMEDATE()
    DATE.TIME = X[9,2]:X[1,2]:X[4,2]:TIME.STAMP[1,2]:TIME.STAMP[4,2]
	
	Y.DEST.FILE.NAME = FIELD(Y.CSV.NAME,'.csv',1):'.':DATE.TIME:'.pro'
	Y.DESTINATION.PATH = Y.DIR:"/":ARCHIVE.DIR:"/":Y.DEST.FILE.NAME

    IF OS.NAME EQ "WINNT" OR OS.NAME EQ "WIN95" THEN
        CHANGE "/" TO "\" IN Y.SOURCE.PATH
		CHANGE "/" TO "\" IN Y.DESTINATION.PATH
    END ELSE
        CHANGE "\" TO "/" IN Y.SOURCE.PATH
		CHANGE "\" TO "/" IN Y.DESTINATION.PATH
    END
		
	MOVE.CMD ="SH -c 'mv ":Y.SOURCE.PATH:" ":Y.DESTINATION.PATH:"'"
	
	EXECUTE MOVE.CMD
	
    RETURN
*-----------------------------------------------------------------------------

    END
