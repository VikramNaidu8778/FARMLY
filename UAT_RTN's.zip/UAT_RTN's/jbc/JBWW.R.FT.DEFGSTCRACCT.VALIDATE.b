* @ValidationCode : MTotNjI3MzcxOTAyOklTTy04ODU5LTE6MTQ4NDIxMzI5NDcyNzo0ODAzMjY6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjA=
* @ValidationInfo : Timestamp         : 12 Jan 2017 14:58:14
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 480326
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.FT.DEFGSTCRACCT.VALIDATE
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* * Modification History :
*-----------------------------------------------------------------------------
*This is a new validation routine attached to DEBIT.ACCT.NO field of the version
*FUNDS.TRANSFER,JBWW.V.SC.SFADVFEES.INP. This routine will default the appropriate
*credit account based on the currency and accounting company of the debit account.
*-----------------------------------------------------------------------------
* Date          Developer                   Reference           Description
*-----------------------------------------------------------------------------
*6/1/2017     Batturu.Sivanandini         CR_145                 ROUTINE
* 26/07/2022         D Suresh    	      P.3948                 ACU DBU Decommission
*-----------------------------------------------------------------------------
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.COMPANY
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB OPENFILES
    GOSUB PROCESS
    RETURN

INIT:
****
    R.GENERIC.PARAM = ''
    ERR.GPM=''
    GENERIC.PARAM.ID=''
    Y.GEN.PARM.FIELD.NAME=''
    Y.GEN.PARM.FIELD.VALUE=''
    LOC.POS=''
    Y.CR.AC.SUFFIX=''
    Y.DR.AC=''
    ERR.ACC=''
    R.ACCOUNT=''
    Y.DR.CCY=''
    Y.ACCT.COMP=''
    R.ACCT.COMP=''
    ERR.COMPANY=''
    Y.CR.ACCT=''
    Y.SUB.DIV=''
    RETURN

OPENFILES:
*********
    FN.JBWW.H.EB.GENERICPARAMETER='F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER=''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    FN.ACCOUNT='F.ACCOUNT'
    F.ACCOUNT=''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.COMPANY='F.COMPANY'
    F.COMPANY=''
    CALL OPF(FN.COMPANY,F.COMPANY)
    RETURN

PROCESS:
*******
    IF COMI THEN
        GOSUB GET.STATIC.DETAILS
        GOSUB DETERMINE.CREDIT.ACCOUNT
        IF Y.CR.ACCT THEN
            R.NEW(FT.DEBIT.CURRENCY)=Y.DR.CCY
            R.NEW(FT.CREDIT.ACCT.NO)=Y.CR.ACCT
            R.NEW(FT.CREDIT.CURRENCY)=Y.DR.CCY
        END
    END
    RETURN
GET.STATIC.DETAILS:
*******************
    GENERIC.PARAM.ID='PHYSICAL.ASSET.DETAILS'
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,GENERIC.PARAM.ID,R.GENERIC.PARAM,F.JBWW.H.EB.GENERICPARAMETER,ERR.GPM)
    IF R.GENERIC.PARAM THEN
        Y.GEN.PARM.FIELD.NAME=R.GENERIC.PARAM<JBWW.GEN.PAR.FIELD.NAME>
        Y.GEN.PARM.FIELD.VALUE=R.GENERIC.PARAM<JBWW.GEN.PAR.FIELD.VALUE>
        LOCATE 'CR.ACCT.SUFFIX' IN Y.GEN.PARM.FIELD.NAME<1,1> SETTING LOC.POS THEN
        Y.CR.AC.SUFFIX=Y.GEN.PARM.FIELD.VALUE<1,LOC.POS,1>
    END ELSE
        ETEXT='Suffix for Credit Account not Parameterized'
        CALL STORE.END.ERROR
    END
    END ELSE

    ETEXT='Generic Parameter not setup for Physical Assets'
    CALL STORE.END.ERROR
    END

    RETURN
DETERMINE.CREDIT.ACCOUNT:
*************************
    Y.DR.AC=COMI
    CALL F.READ(FN.ACCOUNT,Y.DR.AC,R.ACCOUNT,F.ACCOUNT,ERR.ACC)
    Y.DR.CCY=R.ACCOUNT<AC.CURRENCY>
    Y.ACCT.COMP=R.ACCOUNT<AC.ACCOUNTING.COMPANY>
	
* ACUDCU Decommission change/S
	ACUDCU.MIG.DAT = ''
	CALL JBWW.R.XX.ACUDCU.MIGDATECHK(ACUDCU.MIG.DAT)		
	IF TODAY GT ACUDCU.MIG.DAT THEN
		Y.ACCT.COMP = ID.COMPANY
	END
* ACUDCU Decommission change/E

    IF Y.ACCT.COMP[1,2] EQ 'SG' THEN
        CALL F.READ(FN.COMPANY,Y.ACCT.COMP,R.ACCT.COMP,F.COMPANY,ERR.COMPANY)
        Y.SUB.DIV=R.ACCT.COMP<EB.COM.SUB.DIVISION.CODE>
        Y.CR.ACCT= Y.DR.CCY:Y.CR.AC.SUFFIX:Y.SUB.DIV
    END

    RETURN
    END
