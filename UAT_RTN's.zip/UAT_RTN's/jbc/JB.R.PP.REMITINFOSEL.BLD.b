SUBROUTINE JB.R.PP.REMITINFOSEL.BLD(ENQ.DATA)
*--------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*--------------------------------------------------------------------------------------------
* 16-APR-2025   Resmi                        CBPAY-2076             To display records based on the Transaction code 
*
* 16-JUN-2025   Prabhu D S                   CBPAY-3373             To display only current company records
*
* 23-06-2025    Prabhu D S                   CBPAY-3464             Selection Criteria based on Transaction Code 
*                                                                   not working properly
* Description : Routine to List all transactions from POR.SUPPLEMENTARY.INFO based on the Transaction Code
* Attached to : ENQUIRY>JB.E.PP.REMITINFO.REGREPORT
* Attached as : BUILD.ROUTINE
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.COMPANY

    GOSUB INIT
    GOSUB PROCESS


RETURN
*****
INIT:
*****

    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
     
    LOCATE "IncomingMessageType" IN ENQ.DATA<2,1> SETTING CODE.POS THEN
        Y.OPERAND = ENQ.DATA<3,CODE.POS>
        Y.CODE.VAL = ENQ.DATA<4,CODE.POS>
    END
    
    LOCATE "CreditValueDate" IN ENQ.DATA<2,1> SETTING DATE.POS THEN
        Y.DATE.VAL = ENQ.DATA<4,DATE.POS>
    END
    
    LOCATE "ProcessingDate" IN ENQ.DATA<2,1> SETTING PROCDT.POS THEN
        Y.PROCDT.VAL = ENQ.DATA<4,PROCDT.POS>
    END
    
    IF (Y.DATE.VAL EQ '') AND (Y.PROCDT.VAL EQ '') THEN
        ENQ.ERROR = "Either Value Date or Processing Date is mandatory"
    END

    COMP.MNE = R.COMPANY(EB.COM.MNEMONIC)
    ENQ.NAME = ENQ.DATA<1>

    PORS.COMP = ""
    BEGIN CASE
    
    CASE ENQ.NAME EQ "JBSG.E.PP.REMITINFO.REGREPORT" AND COMP.MNE EQ "SGD"
      PORS.COMP = "SGD"
    

    CASE ENQ.NAME EQ "JBHK.E.PP.REMITINFO.REGREPORT" AND COMP.MNE EQ "HKD"
      PORS.COMP = "HKD"
      
    END CASE      
    
RETURN

********
PROCESS:
********

     IF NOT(PORS.COMP) THEN
	ENQ.ERROR = "No records found to display"
     END
     
    IF ENQ.ERROR THEN RETURN

    IF Y.CODE.VAL THEN
 
        SEL.CMD = "SELECT ":FN.POR.SUPPL.INFO:" WITH @ID LIKE ":PORS.COMP:"... AND WITH LOC.FIELD.VALUE ":Y.OPERAND:" ":Y.CODE.VAL
        CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
        IF SEL.LIST THEN
           
            CHANGE FM TO ' ' IN SEL.LIST
            
            ENQ.DATA<2,-1> = '@ID'
            ENQ.DATA<3,-1> = 'EQ'
            ENQ.DATA<4,-1> =  SEL.LIST

           DEL ENQ.DATA<2,CODE.POS>
           DEL ENQ.DATA<3,CODE.POS>
           DEL ENQ.DATA<4,CODE.POS>
                       
        END
        
    END
    
    ENQ.DATA<2,-1> = 'CompanyID'
    ENQ.DATA<3,-1> = 'EQ'
    ENQ.DATA<4,-1> = PORS.COMP

        
RETURN

***********************************************************************************
END
