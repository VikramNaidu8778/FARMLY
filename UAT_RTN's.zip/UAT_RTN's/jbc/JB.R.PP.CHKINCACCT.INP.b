SUBROUTINE JB.R.PP.CHKINCACCT.INP
* Description :
* Routine attached as Input routine in VERSION.CONTROL>PP.ORDER.ENTRY
*---------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------
* Date              Developer            Reference          Description
*
* 01-Apr-2025        Resmi            CBPAY-2277         Routine to raise error when the Credit Account is Income Account
* 06-Jun-2025       u40616            CBPAY-2912         Check the lenght of ReturnDescription & ReturnDescription2
*                                                        if the lenght is more than 105 then throw an error
*--------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_EQUATE
    $INSERT I_COMMON
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING SC.ScoPortfolioMaintenance
    $USING AC.AccountOpening
    $INSERT I_F.PP.ORDER.ENTRY

    GOSUB INIT
    GOSUB CHECK.RET.DESC
    IF (yPymtTrsfTyp = "C") AND (yPymtDir = "I") THEN
        GOSUB PROCESS
    END
    
RETURN
*****
INIT:
*****
    FN.ACC = 'F.ACCOUNT' ; F.ACC = '' ; R.ACC = ''
    EB.DataAccess.Opf(FN.ACC, F.ACC)

    FN.ALT.ACC = 'F.ALTERNATE.ACCOUNT' ; F.ALT.ACC = '' ; R.ALT.ACC = '' ; ALT.ERR = ''
    EB.DataAccess.Opf(FN.ALT.ACC, F.ALT.ACC)

    FN.SAMN = 'F.SEC.ACC.MASTER.ACCOUNT.NAME' ; F.SAMN = '' ; R.SAMN = ''
    EB.DataAccess.Opf(FN.SAMN, F.SAMN)

    FN.SAM = 'F.SEC.ACC.MASTER'  ;  F.SAM = '' ; R.SAM = ''
    EB.DataAccess.Opf(FN.SAM, F.SAM)
        
    yPymtTrsfTyp = R.NEW(PP.OEYG.TransferType)
    yPymtDir = R.NEW(PP.OEYG.Direction)

RETURN
*****************
CHECK.RET.DESC:
*****************
    Y.RET.DESC1 = '' ; Y.RET.DESC2 = ''
    Y.RET.DESC1 = R.NEW(PP.OEYG.ReturnDescription)
    Y.RET.DESC2 = R.NEW(PP.OEYG.ReturnDescription2)
    IF LEN(Y.RET.DESC1) GT '105' THEN
        AF = PP.OEYG.ReturnDescription
        ETEXT = "PI-JB.D.XX.FLDLEN.EXCEEDS.MAX":FM:"105"
        CALL STORE.END.ERROR
    END
    
    IF LEN(Y.RET.DESC2) GT '105' THEN
        AF = PP.OEYG.ReturnDescription2
        ETEXT = "PI-JB.D.XX.FLDLEN.EXCEEDS.MAX":FM:"105"
        CALL STORE.END.ERROR
    END

RETURN
*****************
PROCESS:
*****************
  
    Y.CURR.NO = Y.CURR.NO + 1
    yCrAccountNo = R.NEW(PP.OEYG.CreditAccountNumber)

    IF yCrAccountNo THEN
        EB.DataAccess.FRead(FN.ACC, yCrAccountNo, R.ACC, F.ACC, Err)
        LOCATE "BJB.ACCT" IN R.ACC<AC.AccountOpening.Account.AltAcctType,1> SETTING yAltAccPos THEN
            yCrAccount= R.ACC<AC.AccountOpening.Account.AltAcctId,yAltAccPos>
            yAltAccValue=FIELD(yCrAccount,'-',1):'-':FIELD(yCrAccount,'-',2)
        END
    
        EB.DataAccess.FRead(FN.SAMN, yAltAccValue, R.SAMN, F.SAMN, Err)
        IF R.SAMN  THEN
            SamId = FIELD(R.SAMN,'*',2)
        END

        EB.DataAccess.FRead(FN.SAM, SamId, R.SAM, F.SAM, Err)
        Err=''
   
        IF R.SAM THEN
            LOCATE yCrAccountNo IN R.SAM<SC.ScoPortfolioMaintenance.SecAccMaster.ScSamIncAccountNo,1> SETTING INC.POS THEN
                TEXT = 'PP-CPD90001'
                CALL STORE.OVERRIDE(Y.CURR.NO)
            END
        END
        
    END
RETURN
*******************************************************************************************************************
END
