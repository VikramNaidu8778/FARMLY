SUBROUTINE JB.R.PP.STOVERSION.DEFAULT
*-----------------------------------------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------
**29-11-2024   lakshmi Priya      CBPAY-1402         This Routine is used to default STO PO Version
* 19-03-2025   Resmi R            CBPAY-1402         Updated the STO record variable that is passed inside the OFS.BUILD.RECORD api 
* 20-06-2025   Prabhu D S         CBPAY-2677         Default DEBIT.VALUE.DATE.GAP field to raise value dated payments
*-----------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER
 
    GOSUB INIT
    GOSUB PROCESS


    
INIT:
****

    FN.STANDING.ORDER = 'F.STANDING.ORDER'
    F.STANDING.ORDER = ''
    CALL OPF(FN.STANDING.ORDER, F.STANDING.ORDER)
    
    SEL.CMD = ''
    
RETURN
PROCESS:
*******
    SEL.CMD = "SELECT ":FN.STANDING.ORDER:" WITH FT.VERSION NE ''"
    CALL EB.READLIST(SEL.CMD, ID.LIST, '', Y.COUNT, ERR)
    LOOP
        REMOVE TXN.ID FROM ID.LIST SETTING POS
    WHILE TXN.ID : POS
        CALL F.READ(FN.STANDING.ORDER, TXN.ID, R.STO.REC, F.STANDING.ORDER, ERR)
        GOSUB CHK.FT.ROUTINE
        Y.PAY.METHOD = R.STO.REC<STO.PAY.METHOD>
        Y.DAYS.PRIOR = R.STO.REC<STO.DAYS.PRIOR>
        Y.DATE.ADJ = R.STO.REC<STO.DATE.ADJUSTMENT>
        IF Y.DAYS.PRIOR AND Y.DATE.ADJ EQ "PRECEDING" THEN
            R.STO.REC<STO.DEBIT.VALUE.GAP> = "+":Y.DAYS.PRIOR
        END
        IF Y.PAY.METHOD EQ 'ACAC' THEN
            R.OFS.STO.REC<STO.PO.PRD.NAME> = 'ACAC'
            R.OFS.STO.REC<STO.SUPPRESS.FT> = 'PAYMENT'
            R.OFS.STO.REC<STO.PO.VERSION> = 'PAYMENT.ORDER,JB.V.PP.STOACAC.INP'
        END ELSE
            GOSUB STO.REC.DEFAULT
        END
        GOSUB PROCESS.OFS
    REPEAT
   
RETURN

PROCESS.OFS:
************

   Y.OFS.APP.NAME = "STANDING.ORDER"
   Y.OFS.PROCESS = "PROCESS"
   Y.OFS.FUNCTION = "I"
   Y.OFS.VERSION = "STANDING.ORDER,JB.V.AC.OFS"
   Y.OFS.SOURCE = 'JBWW.DA.VAL.OFS.POST'

   CALL OFS.BUILD.RECORD(Y.OFS.APP.NAME,Y.OFS.FUNCTION,Y.OFS.PROCESS,Y.OFS.VERSION,'','',TXN.ID,R.OFS.STO.REC,Y.OFS.REQUEST)
   CALL OFS.POST.MESSAGE(Y.OFS.REQUEST,Y.RET.OFS.MSG,Y.OFS.SOURCE,'')

RETURN
CHK.FT.ROUTINE:
***************

    R.OFS.STO.REC<STO.FT.VERSION> = 'NULL'
    R.OFS.STO.REC<STO.FT.LOC.REF.DATA> = 'NULL'
    R.OFS.STO.REC<STO.PO.VERSION> = ''
    R.OFS.STO.REC<STO.FT.ROUTINE> = '@JB.R.AC.MAPSTOCLCHG.RTN'

RETURN

STO.REC.DEFAULT:
****************

    IF ID.COMPANY EQ 'SG0020001' THEN
        BEGIN CASE
            CASE (Y.PAY.METHOD EQ 'OT03')
                R.OFS.STO.REC<STO.PO.PRD.NAME> = 'OT03'
                R.OFS.STO.REC<STO.SUPPRESS.FT> = 'PAYMENT'
                R.OFS.STO.REC<STO.PO.VERSION> = 'PAYMENT.ORDER,JBSG.V.AC.NOSTRO103.INP'
            CASE (Y.PAY.METHOD EQ 'OT12')
                R.OFS.STO.REC<STO.PO.PRD.NAME> = 'OT12'
                R.OFS.STO.REC<STO.SUPPRESS.FT> = 'PAYMENT'
                R.OFS.STO.REC<STO.PO.VERSION> = 'PAYMENT.ORDER,JBSG.V.AC.NOST103COV.INP'
        END CASE
    END ELSE
        IF ID.COMPANY EQ 'HK0030001' THEN
        
            BEGIN CASE
                CASE (Y.PAY.METHOD EQ 'OT03')
                    R.OFS.STO.REC<STO.PO.PRD.NAME> = 'OT03'
                    R.OFS.STO.REC<STO.SUPPRESS.FT> = 'PAYMENT'
                    R.OFS.STO.REC<STO.PO.VERSION> = 'PAYMENT.ORDER,JBHK.V.AC.NOSTRO103.INP'
                CASE (Y.PAY.METHOD EQ 'OT12')
                    R.OFS.STO.REC<STO.PO.PRD.NAME> = 'OT12'
                    R.OFS.STO.REC<STO.SUPPRESS.FT> = 'PAYMENT'
                    R.OFS.STO.REC<STO.PO.VERSION> = 'PAYMENT.ORDER,JBHK.V.AC.NOST103COV.INP'
            END CASE
        END
        
    END
RETURN
