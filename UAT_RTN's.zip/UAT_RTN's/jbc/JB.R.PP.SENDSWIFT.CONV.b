SUBROUTINE JB.R.PP.SENDSWIFT.CONV
*-----------------------------------------------------------------------------
*Attached in : Attached as conversion routine in Enquiry .
*JBSG.E.PP.PAYPENPROCESS.LIST ,JBHK.E.PP.PAYPENPROCESS.LIST  .
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer       Reference           Description
*-----------------------------------------------------------------------------
*
* 21-OCT-2024  Vikram Pavuluru  CBPAY-495         Convertion routine to get
*                                                SEND SWIFT Staus of the Payment.
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    
    GOSUB INIT
    GOSUB PROCESS
RETURN
    
INIT:
*****
    FN.POR.SUPPLEMENTARY.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPLEMENTARY.INFO = ""
    CALL OPF(FN.POR.SUPPLEMENTARY.INFO, F.POR.SUPPLEMENTARY.INFO)
RETURN

PROCESS:
********

    Y.FT.ID = O.DATA

    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO, Y.FT.ID, R.POR.SUPPLEMENTARY.INFO, F.POR.SUPPLEMENTARY.INFO, ACC.ERR)
    Y.PP.LOC.FLD.NAME = R.POR.SUPPLEMENTARY.INFO<PORID.LOC.FIELD.NAME>
    LOCATE 'L.PP.SEND.PYMT' IN Y.PP.LOC.FLD.NAME<1,1> SETTING Y.SND.FLD.POS THEN
        O.DATA = R.POR.SUPPLEMENTARY.INFO<PORID.LOC.FIELD.VALUE,Y.SND.FLD.POS>
    END ELSE
        O.DATA = ''
RETURN
END

