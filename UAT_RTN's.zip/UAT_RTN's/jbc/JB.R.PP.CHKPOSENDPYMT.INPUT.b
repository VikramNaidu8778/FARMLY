SUBROUTINE JB.R.PP.CHKPOSENDPYMT.INPUT
*******************************************************************************************
* This is an input routine to check Send Payment option and raise
* an override if set as NO for outgoing payments.
* Attached in: VERSION.CONTROL for PAYMENT.ORDER & PP.ORDER.ENTRY
*
*******************************************************************************************
* Modification History
*
* Date          Developer      JIRA Ref         Description
* 24.01.2025    Prabhu D S     CBPAY-1286       Initial draft
*
*******************************************************************************************
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.PAYMENT.ORDER
$INSERT I_F.PP.ORDER.ENTRY

Y.SEND.PYMT = ''
Y.OVE.CNT = 0
Y.PO.FLD.POS = ''
Y.OE.FLD.POS = ''

APPL = "PAYMENT.ORDER":FM:"PP.ORDER.ENTRY"
Y.LOC.FLD.NAMES = 'L.PP.SEND.PYMT':FM:'L.PP.SEND.PYMT'

CALL MULTI.GET.LOC.REF(APPL,Y.LOC.FLD.NAMES,Y.LOC.FLD.POS)
Y.PO.FLD.POS = Y.LOC.FLD.POS<1,1>
Y.OE.FLD.POS = Y.LOC.FLD.POS<2,1>

BEGIN CASE

CASE APPLICATION EQ 'PAYMENT.ORDER'
Y.SEND.PYMT = R.NEW(PO.LOCAL.REF)<1,Y.PO.FLD.POS>
IF Y.SEND.PYMT EQ 'NO' THEN
   Y.OVE.CNT = DCOUNT(R.NEW(PO.OVERRIDE),VM)
END

CASE APPLICATION EQ 'PP.ORDER.ENTRY'
Y.SEND.PYMT = R.NEW(PP.OEYG.LOCAL.REF)<1,Y.OE.FLD.POS>
IF Y.SEND.PYMT EQ 'NO' THEN
   Y.OVE.CNT = DCOUNT(R.NEW(PP.OEYG.OVERRIDE),VM)
END

END CASE

IF Y.SEND.PYMT EQ 'NO' THEN
   Y.OVE.CNT += 1
   TEXT = 'JB.D.PP.SEND.PAYMENT'
   CALL STORE.OVERRIDE(Y.OVE.CNT)
END

RETURN
END
