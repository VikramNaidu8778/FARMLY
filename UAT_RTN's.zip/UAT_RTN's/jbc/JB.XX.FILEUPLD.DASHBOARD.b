* @ValidationCode : MjotNjY0MDQ4OTE4OkNwMTI1MjoxNzA5ODcwNjI4NTY1OmphZ2FuLnJhdmFuYW46LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAyMzEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 08 Mar 2024 12:03:48
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : jagan.ravanan
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
SUBROUTINE JB.XX.FILEUPLD.DASHBOARD
*-----------------------------------------------------------------------------
* This is the template routine for Exception Dashboard being used for TIS File Uploads
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date            Reference             Developer           Description
*
* 08-Aug-2024     CBPAY-xxx             xxx                 Initial Version
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_Table

    Table.name = 'JB.XX.FILEUPLD.DASHBOARD'
    Table.title = 'JB.XX.FILEUPLD.DASHBOARD'
    Table.stereotype = 'H'
    Table.product = 'EB'
    Table.subProduct = ''
    Table.classification = 'INT'
    Table.systemClearFile = 'Y'
    Table.relatedFiles = ''
    Table.isPostClosingFile = ''
    Table.equatePrefix = 'JB.XX'
    Table.idPrefix = ''
    Table.blockedFunctions = ''
    Table.trigger = ''
*
RETURN
*
END
*