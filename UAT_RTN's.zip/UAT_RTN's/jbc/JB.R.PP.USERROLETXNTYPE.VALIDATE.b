*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.USERROLETXNTYPE.VALIDATE
*-----------------------------------------------------------------------------
** Description:
*-------------------------------------------------------------------------
* This is field validation routine attached to TRANSACTION.TYPE field in PAYMENT.ORDER,JB.V.PP.REFUNDS.INP, PAYMENT.ORDER,JBWW.V.FT.FEECHRG.INP &
* PAYMENT.ORDER,JB.V.PP.INTERNAL.INP versions to restrict user to manually input different TRANSACTION.TYPES not accessible for his role.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer        Reference           Description
*-----------------------------------------------------------------------------
*30/05/2024    Hariharan T         CBPAY-52         This routine is for validating the defined PAYMENT.ORDER.PRODUCT from GPM and throw error for other products.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.EB.ERROR
    $INSERT I_F.USER
    $INSERT I_F.PAYMENT.ORDER.PRODUCT
*-----------------------------------------------------------------------------
    GOSUB INIT
    GOSUB GET.GEN.PARAM.DETAILS
    GOSUB GET.USER.ROLES
    GOSUB CASHROLE.CHECK

RETURN
*-----------------------------------------------------------------------------
INIT:
*****
  
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
    
    FN.PAYMENT.ORDER.PRODUCT = 'F.PAYMENT.ORDER.PRODUCT'
    F.PAYMENT.ORDER.PRODUCT = ''
    CALL OPF(FN.PAYMENT.ORDER.PRODUCT,F.PAYMENT.ORDER.PRODUCT)
		
	FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
	
    FN.EB.USER.ROLES = 'F.EB.USER.ROLES'
    F.EB.USER.ROLES = ''
    CALL OPF(FN.EB.USER.ROLES,F.EB.USER.ROLES)

    F.EB.ERROR = ''
    FN.EB.ERROR = 'F.EB.ERROR'
    CALL OPF(FN.EB.ERROR,F.EB.ERROR)


    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER, F.USER)

    Y.TXN.TYPE = COMI

    JBWW.GEN.PAR.FN = '' ; JBWW.GEN.PAR.FV = ''
    FT.TXN.CNT = '' ; FT.TXN.ID = ''
    FT.TXN.DESC = '' ; FV.CNT = ''
    FT.TXN.CNT = '' ; GP.ERR.MSG = ''
    R.FT.TXN = '' ; R.GEN.REC.ROLE = ''
    FT.ERR = '' ; VER.POS = ''
    VER.NAME = '' ;
    Y.CASH.TXNTYPES.FN = ""
    Y.SEC.TXNTYPES.FN = ""

RETURN
*-----------------------------------------------------------------------------
GET.GEN.PARAM.DETAILS:
**********************
    
    VER.NAME = APPLICATION:PGM.VERSION
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.E.XX.CASHSEC.USERROLES",R.GEN.REC.ROLE,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.CASHSEC.ROLES.FN = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.NAME> 

    LOCATE "CASH.USER.ROLES" IN Y.CASHSEC.ROLES.FN<1,1> SETTING CASHSEC.ROLE.POS THEN
        Y.CASH.USER.ROLES = R.GEN.REC.ROLE<JBWW.GEN.PAR.FIELD.VALUE,CASHSEC.ROLE.POS>

        CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",VER.NAME,Y.CASH.TXNTYPES.FV)
        CHANGE SM TO VM IN Y.CASH.TXNTYPES.FV
        CHANGE ',' TO VM IN Y.CASH.TXNTYPES.FV
    END

RETURN

READ.EB.ERROR:
**************
    R.EB.REC = ''
    Y.MSG.VAL = ''
    CALL F.READ(FN.EB.ERROR,"EB-JBWW.D.FT.TXNTYPE.CHK",R.EB.REC,F.EB.ERROR,'')
    Y.MSG.VAL = R.EB.REC<EB.ERR.ERROR.MSG>
RETURN

GET.USER.ROLES:
***************
    Y.INPUSER.ROLES.LIST = R.USER<EB.USE.USER.ROLES>
    IF Y.INPUSER.ROLES.LIST EQ '' THEN
        RETURN
    END
    CHANGE SM TO FM IN Y.INPUSER.ROLES.LIST
    Y.INPUSER.ROLES.CASH = Y.INPUSER.ROLES.LIST
RETURN

CASHROLE.CHECK:
***************


    LOOP

        Y.USER.ROLES1 = ''
        ROLE.POS1 = ''

        REMOVE Y.USER.ROLES1 FROM Y.INPUSER.ROLES.LIST SETTING ROLE.POS1
    WHILE Y.USER.ROLES1:ROLE.POS1
        FV.CASH.ROLE.POS1 = ''
        LOCATE Y.USER.ROLES1 IN Y.CASH.USER.ROLES<1,1,1> SETTING FV.CASH.ROLE.POS1 THEN
            CASHTXNTYPE.POS1 = ''
            LOCATE Y.TXN.TYPE IN Y.CASH.TXNTYPES.FV<1,1> SETTING CASHTXNTYPE.POS1 THEN
                CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,Y.TXN.TYPE,R.PO.ORD.PRD.CASH,F.PAYMENT.ORDER.PRODUCT,CASHFT.ERR)
                CASH.PO.ORD.PRD.DESC = R.PO.ORD.PRD.CASH<POP.DESCRIPTION>
                LIST.ARRY<-1> = Y.TXN.TYPE:"*":CASH.PO.ORD.PRD.DESC
            END ELSE
                GOSUB READ.EB.ERROR
                ETEXT = Y.MSG.VAL
                CALL STORE.END.ERROR
                RETURN
            END
        END
    REPEAT
RETURN
END
