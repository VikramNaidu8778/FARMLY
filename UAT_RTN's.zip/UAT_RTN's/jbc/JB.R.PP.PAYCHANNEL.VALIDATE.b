SUBROUTINE JB.R.PP.PAYCHANNEL.VALIDATE
*----------------------------------------------------------------------------------------------------------------------------------------------
*This is the validation routine attached to the field PAYMENT.CURRENCY in OTO3,OT22,OT12 versions.
*Attached: to version PAYMENT.ORDER,JBHK.V.PP.NOSTRO103.INP,PAYMENT.ORDER,JBHK.V.PP.NOSTRO202.INP,PAYMENT.ORDER,JBHK.V.PP.NOST103COV.INP
*----------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-----------------------------------------------------------------------------------------------------------------------------------------------
*05/08/2024  LAKSHMI PRIYA K S               CBPAY-439     Based on the PAYMENT.CURRENCY, Payment Channel is Defaulted
*04/03/2025  LAKSHMI PRIYA K S               CBPAY 2037    Removed the condition Message not equal *to val , so that payment channel is defaulted everytime payment currency is amended .
*19/03/2025  P Amala                         CBPAY-2225    Fix to not overwrite the field Payment channel when user select the value.
*------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.STANDING.ORDER

    IF ID.COMPANY EQ 'HK0030001' THEN
        APPL.NAME = 'PAYMENT.ORDER':@FM:'STANDING.ORDER'
        APPL.FIELDS = 'L.PO.HKPAY.CHNL':@FM:'L.PO.HKPAY.CHNL'
        CALL MULTI.GET.LOC.REF(APPL.NAME,APPL.FIELDS,Y.POS)

        CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","HKCHATS.CURRENCY",Y.GPM.VALUE)
        CHANGE ',' TO VM IN Y.GPM.VALUE
        CHANGE FM TO VM IN Y.GPM.VALUE


        BEGIN CASE
        
            CASE APPLICATION EQ "PAYMENT.ORDER"
                APPL.LOC.FIELD = PO.LOCAL.REF
                Y.LOC.POS = Y.POS<1>
        
            CASE APPLICATION EQ "STANDING.ORDER"
                APPL.LOC.FIELD = STO.LOCAL.REF
                Y.LOC.POS = Y.POS<2>
        
        END CASE
    
        IF R.NEW(APPL.LOC.FIELD)<1,Y.LOC.POS> NE '' THEN RETURN
	
        Y.PAY.CCY = COMI

        IF Y.PAY.CCY MATCHES Y.GPM.VALUE THEN
            R.NEW(APPL.LOC.FIELD)<1,Y.LOC.POS> = 'HKCHATS'
        END ELSE
            R.NEW(APPL.LOC.FIELD)<1,Y.LOC.POS> = 'SWIFTMX'
        END
	END

RETURN

END



