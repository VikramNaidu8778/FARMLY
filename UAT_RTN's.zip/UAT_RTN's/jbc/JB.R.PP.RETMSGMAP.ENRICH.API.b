*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.RETMSGMAP.ENRICH.API(ioPaymentObject, ioAuditTrailLog)
*-----------------------------------------------------------------------------
* This routine attached as EnrichAPI in the below records,
* PP.MSGMAPPINGPARAMETER>SWIFTMX.pacs.004
* PP.MSGMAPPINGPARAMETER>CHATSMX.pacs.004
*
* This is to do the following activities
* 3) For Incoming messages, Inter Bank Settlement to be honored for DVD & CVD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 30-Jun-2025 u40786             CBPAY-3145        Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    
    CALL PPSWMX.ENRICH.RET.PYMT.API(ioPaymentObject, ioAuditTrailLog)
    
    CALL JB.R.PP.MSGMAP.ENRICH.API(ioPaymentObject, ioAuditTrailLog)
*
RETURN
*
END
*