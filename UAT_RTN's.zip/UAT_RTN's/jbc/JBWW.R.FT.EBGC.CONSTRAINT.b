* @ValidationCode : MToxMzQwMDg4ODQ6SVNPLTg4NTktMToxNTE0NDYxOTA3NTg1OjU1MDM1MDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguNw==
* @ValidationInfo : Timestamp         : 28 Dec 2017 17:21:47
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 550350
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.7
    SUBROUTINE JBWW.R.FT.EBGC.CONSTRAINT
*-----------------------------------------------------------------------------
* Developed by : Ashik Chandrashekar
*  Attached to  : EBGC.CONSTRAINTS>FUNDS.TRANSFER,PAYMENT.ORDER,PP.ORDER.ENTRY,EB.QUERIES.ANSWERS
*  Descrption   :Capture the Portfolio specified in the SC.INC.ACCOUNT which will hold the Customer/portfolio Blocks
*                
*-----------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*------------------------------------------------------------------------------------------------------------------------------------------------------
* 02/07/2024      Amala P                      CBPAY-534                       Capture of TCA and EB.GC.CONSTRAINTS soft Blocks and updating application local fields
*                                                                              and updating TCA hard BlocKs to JBWW.H.XX.SOFTBLOCK table
* 
*------------------------------------------------------------------------------------------------------------------------------------------------------  
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
	$INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PP.ORDER.ENTRY
	$INSERT I_F.EB.QUERIES.ANSWERS
    $INSERT I_F.POR.TRANSACTION
	
    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------


INIT:
**********

    APPL = 'SEC.ACC.MASTER'
    LREF.FLD = 'L.XX.TAG.BLK.ID'
    CALL MULTI.GET.LOC.REF(APPL,LREF.FLD,Y.POS)

    Y.BLK.IDS.POS = Y.POS<1,1>

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.SC.INC.ACCOUNT = ''
    FN.SC.INC.ACCOUNT = 'F.SC.INC.ACCOUNT'
    CALL OPF(FN.SC.INC.ACCOUNT,F.SC.INC.ACCOUNT)

    F.POR.TRANSACTION = ''
    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
	
    RETURN


PROCESS:
***********

    Y.ACT.NO = ''
*    Y.ACT.NO = R.NEW(FT.DEBIT.ACCT.NO)
    IF ID.NEW[1,4] = 'FMQA' THEN
	   GOSUB PROCESS.FMQA
	END ELSE
    Y.ACT.NO = COMI
    	END
	GOSUB SC.INC.ACCOUNT.CONSTRAINT
*    Y.ACT.NO = ''
*    Y.ACT.NO = R.NEW(FT.CREDIT.ACCT.NO)
*    GOSUB SC.INC.ACCOUNT.CONSTRAINT
    RETURN

PROCESS.FMQA:
*************

   Y.PORTRN.ID = R.NEW(EB.QA.ORIG.FT.NUMBER)
	
    CALL F.READ(FN.POR.TRANSACTION,Y.PORTRN.ID,R.PORREC,F.POR.TRANSACTION,'')
* Credit account number considered for cancellation of incoming pacs.008.	
	Y.ACT.NO = R.PORREC<PPPTX.CreditMainAccount>
	    
RETURN

SC.INC.ACCOUNT.CONSTRAINT:
*************************
    Y.SAM.ID = ''
    R.AC = ''
    R.INC = ''
    R.SAM = ''
    CALL F.READ(FN.ACCOUNT,Y.ACT.NO,R.AC,F.ACCOUNT,'')
    Y.SAM.ID = R.AC<AC.PORTFOLIO.NO,1>
    IF Y.SAM.ID NE '' THEN RETURN

    IF Y.SAM.ID EQ '' THEN
        CALL F.READ(FN.SC.INC.ACCOUNT,Y.ACT.NO,R.INC,F.SC.INC.ACCOUNT,'')
        Y.SAM.ID = R.INC<1>
    END
    IF Y.SAM.ID EQ '' THEN RETURN
    R.SAM = ''
    Y.BULK.ID.CNT = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,'')
    IF R.SAM NE '' THEN

        Y.BULK.ID = R.SAM<SC.SAM.LOCAL.REF,Y.BLK.IDS.POS>
        CONVERT SM TO VM IN Y.BULK.ID
        CONVERT VM TO FM IN Y.BULK.ID
        Y.BULK.ID.CNT = DCOUNT(Y.BULK.ID,FM)
        I = 0
        AF = 0
        LOOP
            I = I + 1
        WHILE I LE Y.BULK.ID.CNT
            COMI = Y.BULK.ID<I>
        REPEAT

    END

    RETURN
    END
