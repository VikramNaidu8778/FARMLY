SUBROUTINE JB.R.PP.PPTRHTRADES.PSAHOOK(iStatusAction)
*------------------------------------------------------------------------------------------------------
* This routine is to Create record in Tables JBWW.L.XX.TRH.TRADES & JBWW.H.XX.TRH.TRADES with ID as FT
* no generated, when PO is authorized and Payment status reached '999'. Existing entry in these table to
* be updated to Status "Closed".
* Attached in PP.STATUS.ACTION of 999.* (Payment Completion)
*------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer           Reference              Description
*------------------------------------------------------------------------------------------------------
*08-JUL-2024    Hariharan T         CBPAY-549            Initial Version
*26-MAR-2025    Prabhu              CBPAY-2100           Transactions which has status 'Closed' are sent to the TCA
*06-May-2025    Resmi R             CBPAY-2742           Included logic to update Status & Reverse fields in the Trades tables when the StatusCode is '993'
*13-May-2025    Resmi R             CBPAY-2826           Included logic to handle pacs.004 status update in trades table.
*                                                        Hanlded pacs.004 for cancellation request scenario.
*15-May-2025    Resmi R             CBPAY-2857           Included logic to handle pacs.002 status update in trades table.
*17-May-2025    Prabhu D S          CBPAY-2659           Reversal of Incoming pacs.008 handled. i.e. Status at 993
*23-May-2025    Prabhu D S          CBPAY-3055           Rejected Payments pacs.002 handled, scenario for negative acknowledgement
*03-jUN-2025    Resmi R             CBPAY-3044           Fixed the logic to update FT reference in Ref Nbr field of JBWW.L.XX.TRH.TRADES & JBWW.H.XX.TRH.TRADES when the payment status is 993
*11-Jun-2025   LakshmiPriyaKS       CBPAY-3267           Updated logic to remove Record Status 'INAU' when record is authorised .
*02-Jul-2025   Resmi R              CBPAY-3395           Updated the logic to call the core Api ExportToTRIP after each F.WRITE statement.
*04-Jul-2025   Prabhu D S           CBPAY-3656           Handled logic when PO / FT number does not have Indicator (i.e. 1/2/D/C)
*------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $USING PP.TRIPService
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowService
    $USING PP.PaymentWorkflowDASService
    $USING PP.PaymentSTPFlowService
    $INSERT I_F.JBWW.L.XX.TRH.TRADES
    $INSERT I_F.JBWW.H.XX.TRH.TRADES
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.POSTING.AND.CONFIRMATION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.PAYMENT.ORDER.PRODUCT
    $INSERT I_TPH.TRHTRADES.COMMON
    $INSERT I_F.POR.AUDIT.TRAIL
  
  
    GOSUB Initialise
    GOSUB Process
    
    
RETURN
*-----------------------------------------------------------------------------
*** <region name= INIT>
Initialise:
*** <desc>Initialize variables </desc>

    StatusCode = ''
    PaymentRecord = ''
    iPaymentRecord = ''
    FTNo = ''
    PaymentDirection = ''
    TRHTRADESId = ''
    OutgoingMsgType = ''
    TxnRefIncom = ''
    PorTransactionRec = ''
    PorSupplementaryInfoRec = ''
    PorPostingandConfirmationRec = ''
    DebitMainAccount = ''
    TxnCcy = ''
    ProcessingDate = ''
    TxnAmt = ''
    DrCrIndicator = ''
    DebitValueDate = ''
    CreditValueDate = ''
    TradeRecordArrayRec = ''
    AccountRec = ''
    CustomerRec = ''
    SecAccMasterRec = ''
    CustID = ''
    AccountName = ''
    PortfolioName = ''
    IfEventRec = ''
    TransactionType = ''
    Narrative = ''
    PorAuditTrailRec = ''
   
    CALL JB.R.PP.TRHTRADES.OPENFILES

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = MAIN.PROCESS>
Process:
*** <desc> Actual process </desc>

    StatusCode = iStatusAction<PP.TRIPService.StatusAction.statusCode>
    PaymentRecord = iStatusAction<PP.TRIPService.StatusAction.paymentRecord> ;*To get the PAYMENT.ORDER record data
    iPaymentRecord = RAISE(PaymentRecord)
    
    FTNo = iPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ftNumber>
    
    GOSUB ReadPorTables

    BEGIN CASE

        CASE PaymentDirection = 'B'
	
            IF IncomingMsgType EQ 'pacs.002' THEN
                TRHTRADESId = FTNo
                AcctNo = CreditMainAccount
                GOSUB ReadTrhTrades
* Incase Original Payment receives negative acknowledgement from clearing / SWIFT then pacs.002 will be processed in NSTP mode.
* So we are creating an entry to send UCCE at this level.
* Payment flow: Outgoing pacs.008 --> Negative Acknowledgement --> Outgoing pacs.002
                IF NOT(JbwwLTrhTradesRec) THEN
                    GOSUB ReadAccountandCustomer
                    GOSUB CreateTrhTrades
                END
            END ELSE
                TRHTRADESId = PaymentOrderID
* For book payments Debit / Credit can be PL / Internal, so PaymentOrderID will not have Indicator
                GOSUB ReadTrhTrades
                IF JbwwLErr THEN
                  TrhIndicator = '-D'
                  TRHTRADESId = PaymentOrderID:TrhIndicator
                  GOSUB ReadTrhTrades
                  TrhIndicator = '-C'
                  TRHTRADESId = PaymentOrderID:TrhIndicator
                  GOSUB ReadTrhTrades
                END
            END
	 
                
        CASE PaymentDirection = 'O'
            IF OutgoingMsgType EQ 'pacs.004' THEN
                TRHTRADESId = FTNo
                AcctNo = DebitMainAccount
                GOSUB ReadTrhTrades
* Inase we receive cancellation request to return original payment, then pacs.004 will be processed in NSTP mode.
* So we are  creating an entry to send UCCE at this level.
* Payment Flow: Incoming pacs.008 --> Incoming camt.056 --> Outgoing pacs.004
                IF NOT(JbwwLTrhTradesRec) AND IncomingMsgType EQ 'camt.056' THEN
                    GOSUB ReadAccountandCustomer
                    GOSUB CreateTrhTrades
                END
            END ELSE
                TrhIndicator = '-1'
                TRHTRADESId = PaymentOrderID:TrhIndicator
                GOSUB ReadTrhTrades
                TrhIndicator = '-2'
                TRHTRADESId = PaymentOrderID:TrhIndicator
                GOSUB ReadTrhTrades
            END
            
        CASE PaymentDirection = 'I'
            BEGIN CASE
                CASE StatusCode EQ 999
                    TRHTRADESId = FTNo
                    AcctNo = CreditMainAccount
                    GOSUB ReadAccountandCustomer
                    GOSUB ReadTrhTrades

                CASE StatusCode EQ 993
                    TRHTRADESId = FTNo
                    GOSUB ReadTrhTrades

                CASE OTHERWISE
                    TRHTradesId = ReturnPaymentID
                    AcctNo = DebitMainAccount
                    GOSUB ReadAccountandCustomer
                    GOSUB CreateTrhTrades

            END CASE
            
    END CASE

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = ReadPorTables>
ReadPorTables:
*** <desc> Get Details from POR Transaction & POR Supplementary Info </desc>

    CALL F.READ(FN.POR.TRANSACTION,FTNo,PorTransactionRec,FV.POR.TRANSACTION,PorTxnErr)
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,FTNo,PorSupplementaryInfoRec,FV.POR.SUPPLEMENTARY.INFO,PorSupplErr)
    CALL F.READ(FN.POR.POSTING.AND.CONFIRMATION,FTNo,PorPostingandConfirmationRec,FV.POR.POSTING.AND.CONFIRMATION,PorPostErr)
    CALL F.READ(FN.POR.AUDIT.TRAIL,FTNo,PorAuditTrailRec,FV.POR.AUDIT.TRAIL,PorAuditErr)


    PaymentOrderID = PorTransactionRec<PPPTX.SendersReferenceIncoming>
    PaymentDirection = PorTransactionRec<PPPTX.PaymentDirection>
    OutgoingMsgType = PorTransactionRec<PPPTX.OutgoingMessageType>
    TxnRefIncom = PorTransactionRec<PPPTX.TransactionReferenceIncoming>
    DebitMainAccount = PorTransactionRec<PPPTX.DebitMainAccount>
    CreditMainAccount = PorTransactionRec<PPPTX.CreditMainAccount>
    TxnCcy = PorTransactionRec<PPPTX.TransactionCurrencyCode>
    ProcessingDate = PorTransactionRec<PPPTX.ProcessingDate>
    TxnAmt = PorTransactionRec<PPPTX.TransactionAmount>
    DrCrIndicator = PorPostingandConfirmationRec<PORPD.POSTING.LINE.DBT.CDT.IND>
    IncomingMsgType = PorTransactionRec<PPPTX.IncomingMessageType>
       
    LOCATE 'D' IN DrCrIndicator<1,1> SETTING DR.IND.POS THEN
        DebitValueDate = PorPostingandConfirmationRec<PORPD.VALUE.DATE,DR.IND.POS>
    END

    LOCATE 'C' IN DrCrIndicator<1,1> SETTING CR.IND.POS THEN
        CreditValueDate = PorPostingandConfirmationRec<PORPD.VALUE.DATE,CR.IND.POS>
    END
    
    ReturnPaymentID = PorSupplementaryInfoRec<PORID.RETURN.PAYMENT.REFERENCE>
    LOCATE 'L.PP.DEF.INW.IT' IN PorSupplementaryInfoRec<PORID.LOC.FIELD.NAME,1> SETTING LocPos THEN
        TransactionType = PorSupplementaryInfoRec<PORID.LOC.FIELD.VALUE,LocPos>
    END
    
    CALL F.READ(FN.PAYMENT.ORDER.PRODUCT,TransactionType,PaymentOrderPrdRec,FV.PAYMENT.ORDER.PRODUCT,PoPrdErr)
    IF PaymentOrderPrdRec THEN
        Narrative = PaymentOrderPrdRec<POP.DESCRIPTION>
    END
       
        
RETURN
*** </region>
*-----------------------------------------------------------------------
CreateTrhTrades:

    TradeRecordArrayRec<JB.TRHTRD.is.Batch>      = 'False'
    TradeRecordArrayRec<JB.TRHTRD.src.System>    = 'T24-FT'
    TradeRecordArrayRec<JB.TRHTRD.client.Nbr>    = CustomerRec<EB.CUS.MNEMONIC>
    GOSUB ReadPortfolioName
    TradeRecordArrayRec<JB.TRHTRD.portfolio.Nbr> = AccountName
    TradeRecordArrayRec<JB.TRHTRD.inst.Identifier> = ''
    TradeRecordArrayRec<JB.TRHTRD.underlying> = ''
    TradeRecordArrayRec<JB.TRHTRD.sub.Asset.Type> = ''
    TradeRecordArrayRec<JB.TRHTRD.txn.Ccy> = TxnCcy
    TradeRecordArrayRec<JB.TRHTRD.sell.Txn.Amt> = ''
    TradeRecordArrayRec<JB.TRHTRD.sell.Txn.Ccy> = ''
    TradeRecordArrayRec<JB.TRHTRD.ref.Nbr> = FTNo
    TradeRecordArrayRec<JB.TRHTRD.value.Date> = CreditValueDate
    TradeRecordArrayRec<JB.TRHTRD.quantity> = ''
    TradeRecordArrayRec<JB.TRHTRD.strike.Price> = ''
    TradeRecordArrayRec<JB.TRHTRD.spot.Price> = ''
    TradeRecordArrayRec<JB.TRHTRD.delta> = ''
    TradeRecordArrayRec<JB.TRHTRD.run.Notional> = ''
    TradeRecordArrayRec<JB.TRHTRD.notional.Amt> = ''
    TradeRecordArrayRec<JB.TRHTRD.short.Notional.Amt> = ''
    TradeRecordArrayRec<JB.TRHTRD.contract.Size> = ''
    TradeRecordArrayRec<JB.TRHTRD.delta.Structure> = ''
    TradeRecordArrayRec<JB.TRHTRD.number.Of.Settl.Dates> = ''
    TradeRecordArrayRec<JB.TRHTRD.multiplier> = ''
    TradeRecordArrayRec<JB.TRHTRD.nbr.Of.Options> = ''
    TradeRecordArrayRec<JB.TRHTRD.trans.Desc> = Narrative
    TradeRecordArrayRec<JB.TRHTRD.price> = ''
    TradeRecordArrayRec<JB.TRHTRD.tenor> = ''
    TradeRecordArrayRec<JB.TRHTRD.contract.Event> = ''
    TradeRecordArrayRec<JB.TRHTRD.option.Desc> = ''
    TradeRecordArrayRec<JB.TRHTRD.dlv.Ccy> = ''
    TradeRecordArrayRec<JB.TRHTRD.link.Reference> = ''
    TradeRecordArrayRec<JB.TRHTRD.processing.Date> = ProcessingDate
    TradeRecordArrayRec<JB.TRHTRD.buy.Ccy> = ''
    TradeRecordArrayRec<JB.TRHTRD.base.Ccy> = ''
    TradeRecordArrayRec<JB.TRHTRD.rec.Status> = ''
    TradeRecordArrayRec<JB.TRHTRD.trx.Type> = 'PAYOUT'
    TradeRecordArrayRec<JB.TRHTRD.trx.Amt> = TxnAmt
    IF IncomingMsgType EQ 'camt.056' THEN
        TradeRecordArrayRec<JB.TRHTRD.status>  = 'Inception'
    END ELSE
        TradeRecordArrayRec<JB.TRHTRD.status>  = 'Amendment'
    END
    TradeRecordArrayRec<JB.TRHTRD.contract.Event> = ''
    TradeRecordArrayRec<JB.TRHTRD.reverse>     = 'FALSE'
    BEGIN CASE
        CASE StatusCode EQ 999
            TradeRecordArrayRec<JB.TRHTRD.curr.Number> = '1'
            
        CASE StatusCode EQ 982
            TradeRecordArrayRec<JB.TRHTRD.rec.Status> = "INAU"
            TradeRecordArrayRec<JB.TRHTRD.curr.Number> = ''
    
        CASE StatusCode EQ 988
            TradeRecordArrayRec<JB.TRHTRD.status>  = 'Closed'

    END CASE
    TrxDateTimeVal = ''
    CALL JBWW.R.XX.TRH.TRXDATETIME.UPD(TrxDateTimeVal)
    TradeRecordArrayRec<JB.TRHTRD.trx.Datetime> = TrxDateTimeVal
    CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,FTNo,TradeRecordArrayRec)
    CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,FTNo,TradeRecordArrayRec)
    TphFTNo = FTNo
    IfEventRec = TradeRecordArrayRec
    GOSUB SendToIF
  
RETURN

*** </region>
*-----------------------------------------------------------------------
ReadAccountandCustomer:
    
    CALL F.READ(FN.ACCOUNT,AcctNo,AccountRec,FV.ACCOUNT,AcErr)
    CustID = AccountRec<AC.CUSTOMER>
    CALL F.READ(FN.CUSTOMER, CustID, CustomerRec, FV.CUSTOMER, CustErr)

RETURN
*** </region>
*-----------------------------------------------------------------------
ReadPortfolioName:
    
    CALL JB.R.PP.GETSAMACC.RTN(AcctNo,PortfolioNumberVal)
    GOSUB GetPortfolioDetails
    AccountName = PortfolioName
    
RETURN
*** </region>
*-----------------------------------------------------------------------
GetPortfolioDetails:
********************

    SecAccMasterRec = '' ; SecAccMasterErr = '' ; PortfolioName = ''
    CALL F.READ(FN.SEC.ACC.MASTER, PortfolioNumberVal, SecAccMasterRec, FV.SEC.ACC.MASTER, SecAccMasterErr)
    IF NOT(SecAccMasterErr) THEN
        PortfolioName = SecAccMasterRec<SC.SAM.ACCOUNT.NAME>
    END

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = ReadTrhTrades>
ReadTrhTrades:
*** <desc> Update Concat Tables </desc>

    IF StatusCode EQ '999' AND '677' MATCHES PorAuditTrailRec<PORAT.STATUS.CODE> THEN RETURN
    
   
    JbwwLTrhTradesRec = ''
    JbwwHTrhTradesRec = ''
    IfEventRec = ''
    CALL F.READ(FN.JBWW.L.XX.TRH.TRADES,TRHTRADESId,JbwwLTrhTradesRec,FV.JBWW.L.XX.TRH.TRADES,JbwwLErr)
    CALL F.READ(FN.JBWW.H.XX.TRH.TRADES,TRHTRADESId,JbwwHTrhTradesRec,FV.JBWW.H.XX.TRH.TRADES,JbwwHErr)
    
    
    IF JbwwLTrhTradesRec THEN
        TphFTNo = EREPLACE(TRHTRADESId,PaymentOrderID,FTNo)
                
        BEGIN CASE
            CASE FIELD(TphFTNo,'-',2) MATCHES 'D':@VM:'1':@VM:'2'
                JbwwLTrhTradesRec<JB.TRHTRD.value.Date> = DebitValueDate

            CASE FIELD(TphFTNo,'-',2) EQ 'C'
                JbwwLTrhTradesRec<JB.TRHTRD.value.Date> = CreditValueDate
             
            CASE OTHERWISE
                IF StatusCode EQ 982 THEN
                    JbwwLTrhTradesRec<JB.TRHTRD.reverse>     = 'True'
                    JbwwLTrhTradesRec<JB.TRHTRD.status>      = 'Closed'
                END ELSE
                    JbwwLTrhTradesRec<JB.TRHTRD.value.Date> = CreditValueDate
                    JbwwLTrhTradesRec<JB.TRHTRD.status> = 'Amendment'
                    JbwwLTrhTradesRec<JB.TRHTRD.rec.Status> = ''
                    JbwwLTrhTradesRec<JB.TRHTRD.curr.Number> = '1'
                END
           
        END CASE

        JbwwLTrhTradesRec<JB.TRHTRD.processing.Date>  = ProcessingDate


        TphFTNo = FTNo:TrhIndicator
        TempJbwwLTrhTradesRec = JbwwLTrhTradesRec


        IF StatusCode EQ '993' THEN
            TempJbwwLTrhTradesRec<JB.TRHTRD.rec.Status> = ''
            TempJbwwLTrhTradesRec<JB.TRHTRD.reverse>     = 'True'
            TempJbwwLTrhTradesRec<JB.TRHTRD.status>      = 'Closed'
            TempJbwwLTrhTradesRec<JB.TRHTRD.ref.Nbr>     = TphFTNo
            
        END ELSE
            TempJbwwLTrhTradesRec<JB.TRHTRD.status> = "Amendment"
            TempJbwwLTrhTradesRec<JB.TRHTRD.rec.Status> = ''
        	TempJbwwLTrhTradesRec<JB.TRHTRD.ref.Nbr> = TphFTNo

        END

        CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,TphFTNo,TempJbwwLTrhTradesRec)
        GOSUB ExportToTRIP ;* Core Api is called to complete the Process after each write into the Trades table so that every entry is recorded.
                
        IfEventRec = TempJbwwLTrhTradesRec
        GOSUB SendToIF
        IF PaymentDirection NE 'I' AND OutgoingMsgType NE 'pacs.004' AND IncomingMsgType NE 'pacs.002' THEN
            JbwwLTrhTradesRec<JB.TRHTRD.status> = 'Closed'
            JbwwLTrhTradesRec<JB.TRHTRD.rec.Status> = ''
            CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,TRHTRADESId,JbwwLTrhTradesRec)
            GOSUB ExportToTRIP        ;* Core Api is called to complete the Process after each write into the Trades table so that every entry is recorded.
            TphFTNo = TRHTRADESId
            IfEventRec = JbwwLTrhTradesRec
            GOSUB SendToIF
        END
    END

    IF JbwwHTrhTradesRec THEN
        TphFTNo = EREPLACE(TRHTRADESId,PaymentOrderID,FTNo)
        BEGIN CASE
            CASE FIELD(TphFTNo,'-',2) MATCHES 'D':@VM:'1':@VM:'2'
                JbwwHTrhTradesRec<JB.TRHTRD.value.Date> = DebitValueDate

            CASE FIELD(TphFTNo,'-',2) EQ 'C'
                JbwwHTrhTradesRec<JB.TRHTRD.value.Date> = CreditValueDate

            CASE OTHERWISE
                IF StatusCode EQ 982 THEN
                    JbwwHTrhTradesRec<JB.TRHTRD.reverse>     = 'True'
                    JbwwHTrhTradesRec<JB.TRHTRD.status>      = 'Closed'
                END ELSE
                    JbwwHTrhTradesRec<JB.TRHTRD.value.Date> = CreditValueDate
                    JbwwHTrhTradesRec<JB.TRHTRD.status> = 'Amendment'
                    JbwwHTrhTradesRec<JB.TRHTRD.rec.Status> = ''
                    JbwwHTrhTradesRec<JB.TRHTRD.curr.Number> = '1'
                END
        END CASE

        JbwwHTrhTradesRec<JB.TRHTRD.processing.Date> = ProcessingDate
        
                      
        TphFTNo = FTNo:TrhIndicator
        TempJbwwHTrhTradesRec = JbwwHTrhTradesRec

        IF StatusCode EQ '993' THEN
            TempJbwwHTrhTradesRec<JB.TRHTRD.rec.Status> = ''
            TempJbwwHTrhTradesRec<JB.TRHTRD.reverse>     = 'True'
            TempJbwwHTrhTradesRec<JB.TRHTRD.status>      = 'Closed'
            TempJbwwHTrhTradesRec<JB.TRHTRD.ref.Nbr>     = TphFTNo
            
        END ELSE
            TempJbwwHTrhTradesRec<JB.TRHTRD.status> = "Amendment"
            TempJbwwHTrhTradesRec<JB.TRHTRD.rec.Status> = ''
        	TempJbwwHTrhTradesRec<JB.TRHTRD.ref.Nbr> = TphFTNo
        END

        CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,TphFTNo,TempJbwwHTrhTradesRec)
        GOSUB ExportToTRIP                ;* Core Api is called to complete the Process after each write into the Trades table so that every entry is recorded.
                
        IF PaymentDirection NE 'I' AND OutgoingMsgType NE 'pacs.004' AND IncomingMsgType NE 'pacs.002' THEN
            JbwwHTrhTradesRec<JB.TRHTRD.status> = 'Closed'
            JbwwHTrhTradesRec<JB.TRHTRD.rec.Status> = ''
            CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,TRHTRADESId,JbwwHTrhTradesRec)
            GOSUB ExportToTRIP            ;* Core Api is called to complete the Process after each write into the Trades table so that every entry is recorded.
        END
    END
    
RETURN

*** </region>
*-----------------------------------------------------------------------
SendToIF:
    
    CALL OCOMO("TRH Record updated":IfEventRec:" ":TphFTNo)
    FlowCatalogID = 'TRH-JbwwLXxTrhTrades'
    FlowName = 'JBWW.L.XX.TRH.TRADES'
    ApplicationName = 'JBWW.L.XX.TRH.TRADES'
    CALL JBWW.R.IF.TRHTRADES.CAPTURE(FlowName , FlowCatalogID , ApplicationName , TphFTNo)
    
RETURN
*********************************************************************************************
ExportToTRIP:

*** <desc>To call the core API exportToTRIP in order to complete the Payment Order Process </desc>
    PP.TRIPService.exportToTRIP(iStatusAction) ;* To call the core API exportToTRIP in order to complete the Payment Order Process
RETURN
*************************
END
