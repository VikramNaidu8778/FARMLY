* @ValidationCode : MToxNDg1NjgwOklTTy04ODU5LTE6MTUzOTA1MjI0NjcxNzphMzg5NjA6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjEx
* @ValidationInfo : Timestamp         : 09 Oct 2018 10:30:46
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.11
SUBROUTINE JBWW.B.XX.RETROPAYCLEANUP(PAYMENT.ID)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
* 
* 09-10-2018 - T24-13868
*              Re-compilation of load, select and process routine of multi threaded
*              job JBWW.B.XX.RETROPAYCLEANUP
*
*-----------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_JBWW.B.XX.RETROPAYCLEANUP.COMMON
    $INSERT I_F.JBWW.H.FT.RETROPAY
    $INSERT I_F.FUNDS.TRANSFER
* </region>
*-----------------------------------------------------------------------------
* <region name= Main process>

    RETROPAY.ID = PAYMENT.ID
    
    RETROPAY.ER = ''
    R.RETROPAY = ''
    CALL F.READ (FN.JBWW.H.FT.RETROPAY, RETROPAY.ID, R.RETROPAY, F.JBWW.H.FT.RETROPAY, RETROPAY.ER)
    
    IF R.RETROPAY<RTR.PAY.BEN.NAME> EQ '' THEN
        RETURN
    END
    
    RETRY = ''
    RETROPAY.ER = ''
    CALL F.READU (FN.JBWW.H.FT.RETROPAY, RETROPAY.ID, R.RETROPAY, F.JBWW.H.FT.RETROPAY, RETROPAY.ER, RETRY)
    R.RETROPAY<RTR.PAY.BEN.NAME> = 'CID Withheld'
    CALL F.WRITE (FN.JBWW.H.FT.RETROPAY, RETROPAY.ID, R.RETROPAY)
    
    IF R.RETROPAY<RTR.PAY.PAYMENT.TYPE> = '02' THEN  ;* Internal payment, need not check FT and Swift messages.
        RETURN 
    END
    
    FT.ID = R.RETROPAY<RTR.PAY.T24.TXN.REF.ID,1>

    R.FT = ''
    EB.FT = ''   
    CALL F.READ (FN.FUNDS.TRANSFER.NAU, FT.ID, R.FT, F.FUNDS.TRANSFER.NAU, ER.FT)
    IF R.FT THEN
        RETRY = ''
        CALL F.READU (FN.FUNDS.TRANSFER.NAU, FT.ID, R.FT, F.FUNDS.TRANSFER.NAU, ER.FT, RETRY)
        GOSUB MOCK.CID.FT
        CALL F.WRITE (FN.FUNDS.TRANSFER.NAU, FT.ID, R.FT)
    END
    
    R.FT = ''
    ER.FT = ''
    DELIVERY.REF = ''
    CALL F.READ (FN.FUNDS.TRANSFER, FT.ID, R.FT, F.FUNDS.TRANSFER, ER.FT)
    IF R.FT THEN
        RETRY = ''
        CALL F.READU (FN.FUNDS.TRANSFER, FT.ID, R.FT, F.FUNDS.TRANSFER, ER.FT, RETRY)
        GOSUB MOCK.CID.FT
        CALL F.WRITE (FN.FUNDS.TRANSFER, FT.ID, R.FT)
        DELIVERY.REF = R.FT<FT.DELIVERY.OUTREF, 1>
    END
    
    FT.IN.HISTORY = 0    
    HIS.ID = FT.ID
    R.FT = ''
    ER.FT = ''
    CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS, HIS.ID, R.FT, ER.FT)
    IF R.FT THEN
        RETRY = ''
        CALL F.READU (FN.FUNDS.TRANSFER.HIS, HIS.ID, R.FT, F.FUNDS.TRANSFER.HIS, ER.FT, RETRY)
        GOSUB MOCK.CID.FT
        CALL F.WRITE (FN.FUNDS.TRANSFER.HIS, HIS.ID, R.FT)
        IF NOT(DELIVERY.REF) THEN
            DELIVERY.REF = R.FT<FT.DELIVERY.OUTREF, 1>
        END
    END

    IF NOT(DELIVERY.REF) THEN
        RETURN
    END
    
    DELIVERY.REF.ID = FIELD(DELIVERY.REF,'-',1):'.1'
    
    R.SWIFT = ''
    ER.SWIFT = ''
    CALL F.READ (FN.DE.O.MSG.SWIFT, DELIVERY.REF.ID, R.SWIFT, F.DE.O.MSG.SWIFT, ER.SWIFT)
    
    IF NOT(R.SWIFT) THEN
        RETURN
    END
    
    TMP.SWIFT = R.SWIFT
    GOSUB MOCK.SWIFT.MSG
    
    CALL F.WRITE(FN.DE.O.MSG.SWIFT, DELIVERY.REF.ID, MOCKED.SWIFT)
    CALL F.WRITE(FN.DE.O.HISTORY, DELIVERY.REF.ID, MOCKED.SWIFT)
    
    HANDOFF.ID = FIELD(DELIVERY.REF.ID,'.',1)
    R.HANDOFF = ''
    HANDOFF.ER = ''
    CALL F.READ (FN.DE.O.HANDOFF, HANDOFF.ID, R.HANDOFF, F.DE.O.HANDOFF, HANDOFF.ER)
    IF R.HANDOFF THEN
        GOSUB MOCK.DE.O.HANDOFF
        CALL F.WRITE (FN.DE.O.HANDOFF, HANDOFF.ID, R.HANDOFF)
    END
     
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Mock CID data in DE.O.HANDOFF>
MOCK.DE.O.HANDOFF:

    VM.COUNT = DCOUNT(R.HANDOFF<27>, VM)
    IF VM.COUNT > 1 THEN
        IDX = 1
        LOOP
            IDX += 1   ;* Delete multi value from 2nd position
        WHILE IDX LE VM.COUNT
            DEL R.HANDOFF<27, IDX>
        REPEAT 
    END
    
    R.HANDOFF<27> = 'CID Withheld'  ;* 1st multi value always updated as CID Withheld

    VM.COUNT = DCOUNT(R.HANDOFF<245>, VM)
    IF VM.COUNT > 1 THEN
        IDX = 1
        LOOP
            IDX += 1   ;* Delete multi value from 2nd position
        WHILE IDX LE VM.COUNT
            DEL R.HANDOFF<245, IDX>
        REPEAT 
    END
    R.HANDOFF<245> = 'CID Withheld'  ;* 1st multi value always updated as CID Withheld
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Mock CID data in Funds Transfer>
MOCK.CID.FT:

    BEN.LEN = 0
    
    VM.COUNT = DCOUNT(R.FT<FT.BEN.CUSTOMER>, VM)
    IF VM.COUNT > 1 THEN
        IDX = 1
        LOOP
            IDX += 1   ;* Delete multi value from 2nd position
        WHILE IDX LE VM.COUNT
            BEN.LEN += LEN(R.FT<FT.BEN.CUSTOMER, IDX>)
            DEL R.FT<FT.BEN.CUSTOMER, IDX>
        REPEAT 
    END
    
    BEN.LEN += LEN(R.FT<FT.BEN.CUSTOMER, 1>)
    R.FT<FT.BEN.CUSTOMER,1> = 'CID Withheld'  ;* 1st multi value always updated CID Withheld

    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Mock CID data in Outward swift message>
MOCK.SWIFT.MSG:
    
    SWIFT.PART1 = FIELD(TMP.SWIFT,':59:',1)  ;* Store tags 1 to 58 
    SWIFT.PART2 = FIELD(TMP.SWIFT,':59:',2)  ;* Store tags 59 and above
    SWIFT.PART2 = ':59:':SWIFT.PART2  ;* restore tag 59 indicator

    SWIFT.PART2.CID = FIELD(SWIFT.PART2,':71A:',1)  ;* Store tag 59 alone
    SWIFT.PART2.NOCID = FIELD(SWIFT.PART2,':71A:',2)  ;* Store tag 71 and above
    SWIFT.PART2.NOCID = ':71A:':SWIFT.PART2.NOCID ;* restore tag 71 indicator

    CR = CHARX(13)
    CHANGE CR TO FM IN SWIFT.PART2.CID   ;* convert tag dimiler to FM

    MOCKED.SWIFT = SWIFT.PART1 ;* tags 1 to 58
    
    MOCKED.SWIFT = MOCKED.SWIFT:SWIFT.PART2.CID<1>  ;* concatenate tag 59 - beneficiary account with tag delimiter
    
    MOCKED.SWIFT = MOCKED.SWIFT:CHARX(10):CHARX(13):'CID Withheld'  ;* concatenate tag 59 with mocked CID along with tag delimiter
    
    MOCKED.SWIFT = MOCKED.SWIFT:CHARX(10):CHARX(13):SWIFT.PART2.NOCID  ;* concatenate tag 79 and above along with tag delimiter 
    
    MOCKED.SWIFT = MOCKED.SWIFT:CHARX(10):CHARX(13)  ;* add tag delimiter
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
END
