*---------------------------------------------------------------
     SUBROUTINE JBWW.R.FT.NOSAMTROUND.INP
*---------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA-
* OUT: NA-
*
* Dependencies:
*---------------
* CALLS:-NA-
* CALLED BY:-NA-
*
* Revision History:
*------------------
* Date               who                  Reference                 Description
* 13-09-2016         Mahesh J(CTS)        FXIRX30-45               Initial Version
*---------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE            
	$INSERT I_F.CURRENCY
	$INSERT I_F.JBWW.H.FT.NOSTROINTEREST
 
	
	
	GOSUB INIT
	GOSUB OPEN.FILE
	GOSUB PROCESS
	
	RETURN
	
*---------------------------------------------------------------	
	INIT:
*---------------------------------------------------------------
   NOSFT.CURRENCY = '' ; NOSFT.AMT = ''
		
	RETURN
	
*---------------------------------------------------------------
	OPEN.FILE:
*---------------------------------------------------------------

	FN.CURRENCY = 'F.CURRENCY'
	F.CURRENCY = ''
	CALL OPF(FN.CURRENCY,F.CURRENCY)
	
		
	RETURN

*---------------------------------------------------------------
  PROCESS:
*---------------------------------------------------------------


   NOSFT.CURRENCY = R.NEW(JB.NOSINT.L.FT.CURRENCY)
   NOSFT.AMT = R.NEW(JB.NOSINT.L.FT.AMOUNT)
   
   CNT.NOSAMT = DCOUNT(NOSFT.AMT,VM)
   CHANGE VM TO FM IN NOSFT.CURRENCY
   CHANGE VM TO FM IN NOSFT.AMT
   
   CNT = 1
   LOOP
   WHILE CNT LE CNT.NOSAMT
   Y.CCY = NOSFT.CURRENCY<CNT>
   Y.AMT = NOSFT.AMT<CNT>
   GOSUB READ.CCY   
   CALL EB.ROUND.AMOUNT(Y.CCY,Y.AMT,Y.DECI,"")
   R.NEW(JB.NOSINT.L.FT.AMOUNT)<1,CNT> = Y.AMT
   
   CNT ++
   REPEAT
      
   
  RETURN
 
 READ.CCY:
 **********
 R.NOSCCY = '' ; ERR.CCY = ''
    CALL F.READ(FN.CURRENCY,Y.CCY,R.NOSCCY,F.CURRENCY,ERR.CCY)
    IF R.NOSCCY THEN
	Y.DECI = R.NOSCCY<EB.CUR.NO.OF.DECIMALS>	
	END
 
 
 RETURN
  

END
