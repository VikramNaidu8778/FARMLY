SUBROUTINE JB.R.PP.CALCCVD.API(TXN.CCY,PED,RCVD,I.CHANNEL.NAME,CVD)
*-----------------------------------------------------------------------------
* This is the call routine to calculate the CVD based on the Payment Currency & RCVD passed
* by considering the settlement shift defined in PP.CHANNEL.CUTOFF
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date        Developer          Reference         Description
*
* 01-Mar-2025 u40786             CBPAY-1617        Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $USING PP.RoutingAndSettlementService

    GOSUB GET.CHANNEL.CUTOFF.DETS
    GOSUB CALC.CVD
*
RETURN
*
*********
CALC.CVD:
*********

    Y.REGION = TXN.CCY[1,2]:'00'
    Y.DATE.2 = RCVD
    Y.DATE.1 = TODAY
    DIFF.DAYS = 'W'
    CALL CDD(Y.REGION,Y.DATE.1,Y.DATE.2,DIFF.DAYS)

    IF DIFF.DAYS GT 2 THEN
* If RCVD is greater than 2 days, set CVD as RCVD
        CVD = RCVD ; * Ignore SS
    END ELSE
* If RCVD is less than or equal to 2 days, consider the Setttlement Shift defined in PP.CHANNEL.CUTOFF to calculate CVD
        Y.REGION = TXN.CCY[1,2]:'00'
        Y.DATE = PED
        Y.DAYS = SS:'W'
        CALL CDT(Y.REGION,Y.DATE,Y.DAYS)
        CVD = Y.DATE
                
        IF CVD LT RCVD THEN
* If calculated CVD is less than RCVD, reset the CVD to RCVD
            CVD = RCVD
        END
    END
*
RETURN
*
************************
GET.CHANNEL.CUTOFF.DETS:
************************

    O.CHANNEL.DETS = ''
    O.CHANNEL.FXSHIFT.DETS = ''
    O.CHANNEL.RESP = ''
        
    CALL PP.FIND.CHANNEL.CUTOFF(I.CHANNEL.NAME,O.CHANNEL.DETS,O.CHANNEL.FXSHIFT.DETS,O.CHANNEL.RESP)
    
    SS = ''
    IF O.CHANNEL.RESP EQ '' THEN
        SS = O.CHANNEL.DETS<PP.RoutingAndSettlementService.ChannelCutoffDetails.settlementShift>
    END
*
RETURN
*
END
*