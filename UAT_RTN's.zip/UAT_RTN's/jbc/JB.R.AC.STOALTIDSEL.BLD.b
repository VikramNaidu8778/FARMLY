SUBROUTINE JB.R.AC.STOALTIDSEL.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------------------
* This is an Build routine to display the STO records when Alternate Acct ID is given in STO reference field in Selection criteria.
*-----------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*  18-JUL-2024   Hariharan T         CBPAY-456        Initial Draft
*  19-JUN-2025   P Amala             CBPAY-3416       Fix to check and list Unauth payment Order transaction as well.
*-----------------------------------------------------------------------------------------
    
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.PAYMENT.ORDER
*------------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

RETURN

*****
INIT:
*****
   
    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT)
   
    Y.STO.LIST = '' ; STO.POS = '' ; AC.POS = ''
    ALT.ID = '' ; Y.AC.IDS = '' ; Y.STO.LIST = ''

RETURN

********
PROCESS:
********

    BEGIN CASE

            CASE ENQ.DATA<1> MATCHES 'JB.E.AC.STOERROR.LIST'
            FN.PAYMENT.ORDER = "F.PAYMENT.ORDER$NAU"
            F.PAYMENT.ORDER = ""
            CALL OPF(FN.PAYMENT.ORDER, F.PAYMENT.ORDER)
            GOSUB PROCESS.PO
                         
        CASE ENQ.DATA<1> MATCHES 'JB.E.AC.STO.EXECLIST':@VM:'JB.E.AC.STOINACTIVE.LIST':@VM:'JB.E.AC.STOEXEC.LIST'
            FN.STANDING.ORDER = "F.STANDING.ORDER"
            F.STANDING.ORDER = ""
            CALL OPF(FN.STANDING.ORDER, F.STANDING.ORDER)
            GOSUB PROCESS.STO

        CASE ENQ.DATA<1> MATCHES 'JB.E.AC.STO.NAU':@VM:'JB.E.AC.STOAMEND.NAU'
            FN.STANDING.ORDER = "F.STANDING.ORDER$NAU"
            F.STANDING.ORDER = ""
            CALL OPF(FN.STANDING.ORDER, F.STANDING.ORDER)
            GOSUB PROCESS.STO

    END CASE

RETURN

************
PROCESS.PO:
************

    LOCATE 'ORDERING.REFERENCE' IN ENQ.DATA<2,1> SETTING STO.POS THEN
        ALT.ID = ENQ.DATA<4,STO.POS>
    
        CALL F.READ(FN.ALTERNATE.ACCOUNT, ALT.ID, R.ALT.REC, F.ALTERNATE.ACCOUNT, ALT.ERR)
        Y.AC.IDS = R.ALT.REC<AAC.GLOBUS.ACCT.NUMBER>

        LOOP
            REMOVE AC.ID FROM Y.AC.IDS SETTING AC.POS
        WHILE AC.ID:AC.POS
            SEL.LIST = ""
            SEL.CMD = "SELECT ":FN.PAYMENT.ORDER:" WITH ORDERING.REFERENCE LIKE '":AC.ID:"...'"
            CALL EB.READLIST(SEL.CMD,SEL.LIST,"",NO.REC,Y.RET)
            IF SEL.LIST THEN
                Y.STO.LIST<-1> = SEL.LIST
            END
        REPEAT
    
        CHANGE FM TO ' ' IN Y.STO.LIST
        
        ENQ.DATA<2,STO.POS> = '@ID'
        ENQ.DATA<3,STO.POS> = 'EQ'
        ENQ.DATA<4,STO.POS> = Y.STO.LIST
    END

RETURN

************
PROCESS.STO:
************

    LOCATE '@ID' IN ENQ.DATA<2,1> SETTING STO.POS THEN
        ALT.ID = ENQ.DATA<4,STO.POS>
    
        CALL F.READ(FN.ALTERNATE.ACCOUNT, ALT.ID, R.ALT.REC, F.ALTERNATE.ACCOUNT, ALT.ERR)
        Y.AC.IDS = R.ALT.REC<AAC.GLOBUS.ACCT.NUMBER>

        LOOP
            REMOVE AC.ID FROM Y.AC.IDS SETTING AC.POS
        WHILE AC.ID:AC.POS
            SEL.LIST = ""
            SEL.CMD = "SELECT ":FN.STANDING.ORDER:" WITH @ID LIKE '":AC.ID:"...'"
            CALL EB.READLIST(SEL.CMD,SEL.LIST,"",NO.REC,Y.RET)
            IF SEL.LIST THEN
                Y.STO.LIST<-1> = SEL.LIST
            END
        REPEAT
    
        CHANGE FM TO ' ' IN Y.STO.LIST
        
        ENQ.DATA<2,STO.POS> = '@ID'
        ENQ.DATA<3,STO.POS> = 'EQ'
        ENQ.DATA<4,STO.POS> = Y.STO.LIST
    END

RETURN

*******************
END