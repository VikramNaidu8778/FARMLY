SUBROUTINE JB.R.PP.REJPAYUSRGRP.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*Attached in : ENQUIRY>JB.E.PP.REJECTEDPAYMENTS.VIEW
*Attached as : Build Routine
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date             Developer       Reference        Description
*------------------------------------------------------------------------------
* 30-06-2025     Lakshmi Priya     CBPAY-3549     The Build Routine is to display transactions
*                                                  which are in status 998 respective to company.
*-----------------------------------------------------------------------------

   
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON

    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS


RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
   
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)
RETURN


*****************
GET.PARAM.VALUES:
*****************

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
 
    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END
    
    
RETURN


PROCESS:
********

    GOSUB CHECK.TXN.COMPANY
    IF ENQ.ERROR THEN RETURN
     Y.SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ '":Y.COMP.ID:"' AND ":"StatusCode EQ '998'"
    IF ENQ.DATA<2,1> THEN
       GOSUB FORM.SEL.CMD
       Y.SEL.CMD := Y.SEL.OPER
    END
    CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST.1,'',Y.SEL.CNT,'')

    IF Y.SEL.LIST.1 THEN
        LOOP
            REMOVE Y.REC.ID FROM Y.SEL.LIST.1 SETTING Y.ROLE.POS
        WHILE Y.REC.ID:Y.ROLE.POS
             GOSUB CHECK.USER.GROUP	
             IF FLAG THEN
                Y.SEL.LIST<-1> = Y.REC.ID
             END
        REPEAT
     END
     
    Y.TEMP.CNT = DCOUNT(Y.SEL.LIST,FM)
    CONVERT FM TO ' ' IN Y.SEL.LIST

    ENQ.DATA<2,1> = '@ID'
    ENQ.DATA<3,1> = 'EQ'
    ENQ.DATA<4,1> = Y.SEL.LIST
    ENQ$SKIP.FLAG = 1


RETURN

CHECK.USER.GROUP:
*****************

     FLAG = 0
     CALL F.READ(FN.POR.SUPPL.INFO,Y.REC.ID,R.SUPP.REC,F.POR.SUPPL.INFO,'')
     Y.LOC.FIELD.NAME = R.SUPP.REC<PORID.LOC.FIELD.NAME>
     LOCATE 'L.PO.USR.GRP' IN Y.LOC.FIELD.NAME<1,1> SETTING Y.POS THEN
          Y.LOC.FIELD.VALUE = R.SUPP.REC<PORID.LOC.FIELD.VALUE,Y.POS>
          IF Y.LOC.FIELD.VALUE EQ Y.USR.GRP THEN
             FLAG = 1
          END
     END

RETURN

FORM.SEL.CMD:
*************
   Y.CNT = DCOUNT(ENQ.DATA<2>,VM)
   FOR I = 1 TO Y.CNT
   
    Y.SEL.OPERAND = ENQ.DATA<3,I>
    BEGIN CASE
         CASE Y.SEL.OPERAND EQ "BW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "EW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "CT"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" LIKE ...":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNBW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UNLIKE ":ENQ.DATA<4,I>:"..."
         CASE Y.SEL.OPERAND EQ "DNEW"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" UNLIKE ...":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND MATCHES "EQ":VM:"NE":VM:"GT":VM:"GE":VM:"LT":VM:"LE"
              Y.SEL.OPER := " AND ":ENQ.DATA<2,I>:" ":Y.SEL.OPERAND:" ":ENQ.DATA<4,I>
         CASE Y.SEL.OPERAND EQ "RG"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" GE ":Y.TEMP.DATA<1,1>:" AND ":ENQ.DATA<2,I>:" LE ":Y.TEMP.DATA<1,2>:")"
         CASE Y.SEL.OPERAND EQ "NR"
              Y.TEMP.DATA = ENQ.DATA<4,I>
              CONVERT " " TO VM IN Y.TEMP.DATA
              Y.SEL.OPER := " AND (":ENQ.DATA<2,I>:" LT ":Y.TEMP.DATA<1,1>:" OR ":ENQ.DATA<2,I>:" GT ":Y.TEMP.DATA<1,2>:")"

    END CASE
   NEXT I
    

RETURN

CHECK.TXN.COMPANY:
******************

    LOCATE "CompanyID" IN ENQ.DATA<2> SETTING Y.POS THEN
        IF ENQ.DATA<4,Y.POS> NE Y.COMP.ID THEN
           ENQ.ERROR = "No records found to display"
        END
    END

RETURN
        
END
