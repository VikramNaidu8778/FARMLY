* @ValidationCode : MTotOTcwMTgwNjY6SVNPLTg4NTktMToxNTM2OTIxNTU3ODU5OmEzODg0NjotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMTY=
* @ValidationInfo : Timestamp         : 14 Sep 2018 18:39:17
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38846
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.INC.ACCT.PORT.CHK
*-------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------
* This is input routine to block FT-ACIA type based on account/portfolio check
*-------------------------------------------------------------------------
* Attached: As input routine to ACIA, ACME, ACMI & ACFX FT Versions
*-------------------------------------------------------------------------
* Input/Output:
*--------------
* IN:NA
* OUT:NA
*
* Dependencies:
*---------------
*
* RevisionHistory:
*------------------
* Date          Developer   Reference   Description
*
* 23/08/2018    DIANA.K     DAY15-3134  This is input routine to block FT-ACIA type based on account/portfolio check
*
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.FUNDS.TRANSFER

    IF R.NEW(FT.TRANSACTION.TYPE) MATCHES 'ACIA':VM:'ACME':VM:'ACMI':VM:'ACFX' THEN
        Y.PROCESS.FLAG = 1
    END ELSE
        IF PGM.VERSION EQ ",JBWW.V.FT.INW.INP" THEN
            Y.PROCESS.FLAG = 1
        END
    END

    IF Y.PROCESS.FLAG THEN
        GOSUB OPEN.FILES
        GOSUB PROCESS
    END

    RETURN

*==========
OPEN.FILES:
*==========
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.SEC.ACC.MASTER.ALT = 'F.SEC.ACC.MASTER.ACCOUNT.NAME'
    F.SEC.ACC.MASTER.ALT = ''
    CALL OPF(FN.SEC.ACC.MASTER.ALT,F.SEC.ACC.MASTER.ALT)

    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
    RETURN

*=======
PROCESS:
*=======
    Y.INC.FLAG = ''
    Y.DR.INC.FLAG = ''
    Y.CR.INC.FLAG = ''
    Y.DR.ACNO = R.NEW(FT.DEBIT.ACCT.NO)
    Y.CR.ACNO = R.NEW(FT.CREDIT.ACCT.NO)

    BEGIN CASE
        CASE R.NEW(FT.TRANSACTION.TYPE) EQ 'ACIA'
          
        IF Y.DR.ACNO[1,2] NE "PL" THEN
	    	Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
			GOSUB PROCESS.FETCH.ACCNT
	    END
	    
	    IF Y.CR.ACNO[1,2] NE "PL" AND NOT(Y.INC.FLAG) THEN
			Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
			GOSUB PROCESS.FETCH.ACCNT
	    END

		IF NOT(Y.PORT.FLAG) THEN
			GOSUB CHECK.SAM.PORT.ACCNT
		END
		

        CASE Y.DR.ACNO[1,2] NE "PL" AND R.NEW(FT.TRANSACTION.TYPE) MATCHES 'ACME':VM:'ACMI':VM:'ACFX'
            Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
            GOSUB PROCESS.FETCH.ACCNT

            IF Y.CR.ACNO[1,2] EQ "PL" THEN
                Y.PORT.FLAG = 1
            END ELSE
            	IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
			GOSUB CHECK.SAM.PORT.ACCNT
                END               
            END
			
			IF NOT(Y.INC.FLAG) OR NOT(Y.PORT.FLAG) THEN
				Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
				GOSUB PROCESS.FETCH.ACCNT
			END

        CASE Y.CR.ACNO[1,2] NE "PL" AND R.NEW(FT.TRANSACTION.TYPE) MATCHES 'ACME':VM:'ACMI':VM:'ACFX'

            Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
            GOSUB PROCESS.FETCH.ACCNT
			
            IF Y.DR.ACNO[1,2] EQ "PL" THEN
                Y.PORT.FLAG = 1
            END ELSE 
				IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
					GOSUB CHECK.SAM.PORT.ACCNT
				END
			END
			
				
			IF NOT(Y.INC.FLAG) OR NOT(Y.PORT.FLAG) THEN
				Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
				GOSUB PROCESS.FETCH.ACCNT
			END
			
        CASE PGM.VERSION EQ ",JBWW.V.FT.INW.INP"
* In case an FT is initiated in which either a Dr/Cr account(or both)is an income account
* And FTTC is any other than ACIA,ACME,ACFX or ACMI then the FT input should be blocked.

            Y.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
            GOSUB PROCESS.FETCH.ACCNT

            IF NOT(Y.INC.FLAG) THEN
                Y.ACCOUNT = R.NEW(FT.CREDIT.ACCT.NO)
                GOSUB PROCESS.FETCH.ACCNT
            END

            IF Y.INC.FLAG THEN
                Y.INC.FLAG = ''
            END ELSE
                RETURN
            END

    END CASE

    IF Y.INC.FLAG AND NOT(Y.PORT.FLAG) THEN
        AF = Y.FIELD
        ETEXT = "EB-ACCOUNT.TRANS.ONLY.INC.SAMEPORT"
        CALL STORE.END.ERROR
    END


    RETURN

*===================
PROCESS.FETCH.ACCNT:
*===================

    R.ACCOUNT = ''; ACCOUNT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
    IF R.ACCOUNT NE"" THEN
        Y.ALT.ACCT.IDS = R.ACCOUNT<AC.ALT.ACCT.ID>
        IF R.ACCOUNT<AC.CATEGORY> GE 5000 AND R.ACCOUNT<AC.CATEGORY> LE 5999 THEN
			Y.PORT.FLAG = 1
            RETURN
        END
        ALT.POS = ''
        LOCATE "BJB.ACCT" IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING ALT.POS THEN
            Y.SAM.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,ALT.POS>
            Y.SAM.ALT.ID = FIELD(Y.SAM.ALT.ID,'-',1):'-':FIELD(Y.SAM.ALT.ID,'-',2)
            GOSUB CHECK.ACCOUNT.SAM
        END ELSE
			Y.PORT.FLAG = 1
        END
    END

    RETURN
    
*=================
CHECK.ACCOUNT.SAM:
*=================

    R.SAM.ALT.REC = ''; SAM.ALT.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER.ALT,Y.SAM.ALT.ID,R.SAM.ALT.REC,F.SEC.ACC.MASTER.ALT,SAM.ALT.ERR)
    IF R.SAM.ALT.REC NE'' THEN
        Y.SAM.ID = FIELD(R.SAM.ALT.REC,'*',2)
        R.SAM = ''; SAM.ERR = ''
        CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,F.SAM,SAM.ERR)
        IF R.SAM THEN
            GOSUB CHECK.SAM.INC.ACCNT
        END
    END ELSE
        Y.PORT.FLAG = 1
    END

    RETURN

*==================
CHECK.SAM.INC.ACCNT:
*==================

*To check at least one of the account(DR/CRacct)is an income account
    INC.POS = ''
    LOCATE Y.DR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
		Y.DR.INC.FLAG = 1
		Y.FIELD = FT.DEBIT.ACCT.NO
    END

    INC.POS = ''
    LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.INC.ACCOUNT.NO,1> SETTING INC.POS THEN
        Y.CR.INC.FLAG = 1
		Y.FIELD = FT.CREDIT.ACCT.NO
    END

    IF Y.DR.INC.FLAG AND Y.CR.INC.FLAG THEN
        Y.PORT.FLAG = 1
    END

    IF Y.DR.INC.FLAG OR Y.CR.INC.FLAG THEN
        Y.INC.FLAG = 1
    END

    RETURN

*===================
CHECK.SAM.PORT.ACCNT:
*===================

*To check whether CR account belongs to the same portfolio
    IF NOT(Y.CR.INC.FLAG) THEN
        PORT.POS = ''
        LOCATE Y.CR.ACNO IN R.SAM<SC.SAM.ACCOUNT.NOS,1> SETTING PORT.POS THEN
            Y.PORT.FLAG = 1
        END
    END

*To check whether DR account belongs to the same portfolio
    IF NOT(Y.DR.INC.FLAG) THEN
        PORT.POS = ''
        LOCATE Y.DR.ACNO IN R.SAM<SC.SAM.ACCOUNT.NOS,1>SETTING PORT.POS THEN
            Y.PORT.FLAG = 1
        END
    END

    RETURN

    END