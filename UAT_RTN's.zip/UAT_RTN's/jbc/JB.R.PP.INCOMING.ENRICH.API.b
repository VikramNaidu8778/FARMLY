SUBROUTINE JB.R.PP.INCOMING.ENRICH.API(ioPaymentObject,ioAuditTrailLogFields)
*----------------------------------------------------------------------------------------------------------------------------
*This is routine attached in Message Mapping Parameter Table to default Transaction code .
*Attached:SWIFTMX.pacs.004 , SWIFTMX.pacs.002 , SWIFTMX.pacs.009 ,PayOrder.TRSY,PayOrder.ORRT,PayOrder.OTSA,PayOrder.ACSA
*-----------------------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------
* Date          Developer                    Reference               Description
*-----------------------------------------------------------------------------------------------------------------------------
*28/08/2024    Lakshmi Priya                 CBPAY-774           Based on Payment Order Product ,Transaction code is defaulted
*
*------------------------------------------------------------------------------------------------------------------------------

    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.MessageMappingService
    $USING PP.PaymentFrameworkService
    $USING PI.Contract

    GOSUB PROCESS



PROCESS:
********

    Y.INCOMING.MSG = ioPaymentObject<PP.MessageMappingService.PaymentObject.transaction,1,PP.MessageMappingService.Transaction.incomingMessageType>
    Y.INSTRUCT.INFO = ioPaymentObject<PP.MessageMappingService.PaymentObject.information,1,PP.MessageMappingService.Information.informationLine>
    Y.SLB.VAL = FIELD(Y.INSTRUCT.INFO ,"/",3)
    Y.SLB.VAL = Y.SLB.VAL[1,3]
    ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldName> = "L.PP.DEF.INW.IT"
    BEGIN CASE
       CASE Y.INCOMING.MSG EQ 'pacs.002'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "IRRJ"
       CASE Y.INCOMING.MSG EQ 'pacs.004'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "IRRT"
       CASE Y.INCOMING.MSG EQ 'pacs.009cov'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "ITCV"
       CASE (Y.INCOMING.MSG EQ 'pacs.009') AND (Y.SLB.VAL EQ 'SLB')
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "ITSL"
       CASE Y.INCOMING.MSG EQ 'OTSA'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "OTSA"
       CASE Y.INCOMING.MSG EQ 'ACSA'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "ACSA"
       CASE Y.INCOMING.MSG EQ 'TRSY'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "TRSY"
       CASE Y.INCOMING.MSG EQ 'ORRT'
          ioPaymentObject<PP.MessageMappingService.PaymentObject.paymentFlowDetails,1,PP.PaymentFrameworkService.PORPmtFlowDetailsList.localFieldValue> = "ORRT"
               
    END CASE
    
RETURN

END

