*------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PARTYDETAILS.INP
*-----------------------------------------------------------------------------------------------------------------------------------------------
* This routine is attached in below Outgoing Payment versions as Input Routine to extract values and update in Ordering customer Name and Address
* related fields.
* Attached To : PAYMENT.ORDER,JBHK.V.PP.NOSTRO103.INP & PAYMENT.ORDER,JBSG.V.PP.NOSTRO103.INP
*               PAYMENT.ORDER,JBSG.V.PP.NOST103COV.INP & PAYMENT.ORDER,JBHK.V.PP.NOST103COV.INP
*-----------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*-----------------------------------------------------------------------------------------------------------------------------------------------
* 01/07/2024     Amala P                       CBPAY-27 & 80                   Capture the details from the local table and update in Ordering
*                                                                              customer related fields in Payment Order.
* 13/10/2024     Amala P                       CBPAY-1068                      Retrive the account number if user enter alternate account Id.
*
* 08/01/2025     Lakshmi Priya                 CBPAY - 1603                    Changed Trim request to start from position '1' instead OF '0'
*
* 22/01/2025     Lakshmi Priya                 CBPAY-1220                    This case is applicable for Counterparties / Nostro Accounts
*                                                                             Out of box TPH functionality will default the Ordering Customer
*                                                                                  details except the Ordering Customer Residence.
*                                                                             Hence L3 logic incorporated to default the Ordering Customer Residence .
* 04/03/2025     Vikram Pavuluru               CBPAY-2016                    Included the logic to restrict null at end of the Address Details.
*
* 10/04/2025     Prabhu D S                    CBPAY-2450                    Impose Debtor Details for Nostro Account to avoid sending actual Nostro
*                                                                            Customer details in outgoing payments. Julius Baer entity details should
*                                                                            go as Ordering Party (i.e. Dbtr Tag)
* 07/05/2025    Lakshmi Priya                  CBPAY-2751                    Impose Debtor Details is enabled for all the payments ,when the record is not 
*                                                                            available in Party Details Table .
*
*23/06/2025    Lakshmi Priya                   CBPAY-3382/2234               Included logic to default remaining part to updated in "Instruction for Next Agent"
*                                                                            If the name exceeds the maximum character (i.e) 140 as defined 
*                                                                             in CBPR+ guidelines
*------------------------------------------------------------------------------------------------------------------------------------------------


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.JB.XX.PARTY.DETAILS
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_F.ALTERNATE.ACCOUNT
*-------------------------------------------------------------------------
 IF V$FUNCTION EQ 'I' THEN
    GOSUB INIT
    GOSUB PROCESS
 END

RETURN
*-----------------------------------------------------------------------------

INIT:
*****

    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.CUSTOMER = ''
    FN.CUSTOMER = 'F.CUSTOMER'
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    F.JB.XX.PARTY.DETAILS = ''
    FN.JB.XX.PARTY.DETAILS = 'F.JB.XX.PARTY.DETAILS'
    CALL OPF(FN.JB.XX.PARTY.DETAILS,F.JB.XX.PARTY.DETAILS)
    
    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT)

    FN.GPM = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.GPM = ''
    CALL OPF(FN.GPM,F.GPM)

    Y.FIELD.NAME = 'STRUCTURED.ADDRESS'
    Y.FIELD.VALUE = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.CRM.PARTYDETAILS",Y.FIELD.NAME,Y.FIELD.VALUE)
    Y.SWITCH.ADDR = Y.FIELD.VALUE<1>
    CHANGE VM TO FM IN Y.SWITCH.ADDR
    
    Y.SAM.ID = '' ; R.SAM = '' ; Y.ACT.NO = ''
    R.AC = '' ; R.JB.PARTYDET = '' ; Y.PARTYID.CNT = ''
    R.NEW(PO.ORDERING.CUST.NAME) = '' ; R.NEW(PO.ORDERING.STREET.NAME) = ''
    R.NEW(PO.ORDERING.BUILDING.NUMBER) = '' ; R.NEW(PO.ORDERING.BUILDING.NAME) = ''
    R.NEW(PO.ORDERING.POST.CODE) = '' ; R.NEW(PO.ORDERING.CUSTOMER.TOWN.NAME) = ''
    R.NEW(PO.ORDERING.COUNTRY.RESIDENCE) = '' ; R.NEW(PO.ORDERING.POST.SWIFT.ADDR) = ''
    R.NEW(PO.ORDERING.RESIDENCE.CTRY) = ''

    Y.APP = 'PAYMENT.ORDER'
    Y.LOCFIELD = 'L.FT.VALDT.CHKD':VM:'L.PP.ORIG.REF':VM:'L.PP.SEND.PYMT':VM:'L.PO.B2B.INFO'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.VLDT.CHKD.POS =  Y.LOCPOS<1,1>
    Y.ORIG.POS = Y.LOCPOS<1,2>
    Y.SND.PYMT.POS = Y.LOCPOS<1,3>
    Y.B2B.INFO.POS = Y.LOCPOS<1,4>


RETURN

PROCESS:
********

    R.AC = '' ; Y.ACT.NO = '' ; R.ALT.REC = ''
    Y.ACT.NO = COMI
    CALL F.READ(FN.ACCOUNT,Y.ACT.NO,R.AC,F.ACCOUNT,'')
    IF NOT(R.AC) THEN

        CALL F.READ(FN.ALTERNATE.ACCOUNT, Y.ACT.NO, R.ALT.REC, F.ALTERNATE.ACCOUNT, ALT.ERR)
        IF R.ALT.REC THEN
            Y.ACT.NO = R.ALT.REC<AAC.GLOBUS.ACCT.NUMBER>
            CALL F.READ(FN.ACCOUNT,Y.ACT.NO,R.AC,F.ACCOUNT,'')
        END
    END
    Y.CUST.ID = R.AC<AC.CUSTOMER>
    GOSUB READ.CUSTOMER
    Y.SAM.ID = R.AC<AC.PORTFOLIO.NO,1>
    Y.CATEG = R.AC<AC.CATEGORY>
    IF Y.SAM.ID NE '' THEN
        GOSUB READ.SAM
    END
    CALL F.READ(FN.JB.XX.PARTY.DETAILS,Y.PARTY.ID,R.JB.PARTYDET,F.JB.XX.PARTY.DETAILS,'')
    
    IF R.JB.PARTYDET NE '' THEN
        BEGIN CASE
            CASE Y.SECTOR EQ '1003'
                GOSUB EXT.INDIVIDUAL.CLIENT
            CASE OTHERWISE
                GOSUB EXT.CORP.CLIENT
        END CASE
   END ELSE
        R.NEW(PO.ORDERING.COUNTRY.RESIDENCE) = Y.CUS.RESIDENCE
        R.NEW(PO.IMPOSE.DEBTOR.DETAILS) = 'YES'
   END
    
RETURN

READ.CUSTOMER:
**************

    R.CUST.REC = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.ID,R.CUST.REC,F.CUSTOMER,'')
    IF R.CUST.REC THEN
        Y.SECTOR = R.CUST.REC<EB.CUS.SECTOR>
        Y.CUS.RESIDENCE = R.CUST.REC<EB.CUS.RESIDENCE>
    END
RETURN

READ.SAM:
*********

    R.SAM.REC = '' ; Y.PARTY.ID = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
    IF R.SAM.REC THEN
        Y.PARTY.ID = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
    END
RETURN

EXT.INDIVIDUAL.CLIENT:
**********************

    Y.SOLE.PROPRIET = R.JB.PARTYDET<PART.DET.PORT.SUB.TYPE>
    Y.JC.IDENT = R.JB.PARTYDET<PART.DET.J.C.IDENTIFIER>
    BEGIN CASE
        CASE Y.SOLE.PROPRIET EQ "Sole Proprietorship"
            R.NEW(PO.ORDERING.CUST.NAME) = R.JB.PARTYDET<PART.DET.PORT.NAME>
            GOSUB FETCH.ADDR.DET
         
        CASE Y.JC.IDENT EQ "Joint" OR Y.JC.IDENT EQ "Collective" OR Y.JC.IDENT EQ ''
            Y.PARTY.ID = R.JB.PARTYDET<PART.DET.PARTY.ID>
            Y.PARTYID.CNT = DCOUNT(Y.PARTY.ID,VM)

            GOSUB FETCH.PARTYNAME
            GOSUB FETCH.ADDR.DET

    END CASE

RETURN

EXT.CORP.CLIENT:
****************

    Y.PORT.RELTYPE = R.JB.PARTYDET<PART.DET.PORT.REL.TYPE>
    BEGIN CASE
        CASE Y.PORT.RELTYPE EQ "Trust"

            R.NEW(PO.ORDERING.CUST.NAME) = R.JB.PARTYDET<PART.DET.PORT.NAME>
            GOSUB FETCH.ADDR.DET

        CASE OTHERWISE

            R.NEW(PO.ORDERING.CUST.NAME) = R.JB.PARTYDET<PART.DET.LEGAL.ORG.NAME>
            GOSUB FETCH.ADDR.DET
    END CASE
RETURN

FETCH.PARTYNAME:
****************

    Y.ORD.CUSTNAME = '' ; Y.FIRST.ORDCUST = ''
    II = 0
    LOOP
        II = II + 1
    WHILE II LE Y.PARTYID.CNT


        IF R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II> NE '' AND Y.FIRST.ORDCUST EQ '' THEN
            Y.ORD.CUSTNAME = R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II>
            Y.FIRST.ORDCUST = '1'
        END ELSE
            IF R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II> NE '' AND Y.FIRST.ORDCUST EQ '1' THEN
                Y.ORD.CUSTNAME := ' ':R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II>
            END
        END
        IF R.JB.PARTYDET<PART.DET.PART.M.NAME><1,II> NE '' THEN
            Y.ORD.CUSTNAME := ' ':R.JB.PARTYDET<PART.DET.PART.M.NAME><1,II>
        END
        IF R.JB.PARTYDET<PART.DET.PART.L.NAME><1,II> NE '' THEN
            Y.ORD.CUSTNAME := ' ':R.JB.PARTYDET<PART.DET.PART.L.NAME><1,II>
        END

    REPEAT
    R.NEW(PO.ORDERING.CUST.NAME) = Y.ORD.CUSTNAME

RETURN

FETCH.ADDR.DET:
***************
   
    R.NEW(PO.IMPOSE.DEBTOR.DETAILS) = 'YES'
    IF Y.SWITCH.ADDR EQ 'NO' THEN
        GOSUB POPULATE.CUSTOMER.NAME
        GOSUB POPULATE.UNSTRUCT.ADDR
    END ELSE
        R.NEW(PO.ORDERING.STREET.NAME) = R.JB.PARTYDET<PART.DET.PART.STREET.NAME>
        R.NEW(PO.ORDERING.BUILDING.NUMBER) = R.JB.PARTYDET<PART.DET.PART.BUILD.NUMBER>
        R.NEW(PO.ORDERING.BUILDING.NAME) = R.JB.PARTYDET<PART.DET.PART.BUILD.NAME>
        R.NEW(PO.ORDERING.POST.CODE) = R.JB.PARTYDET<PART.DET.PART.POST.CODE>
        R.NEW(PO.ORDERING.CUSTOMER.TOWN.NAME) = R.JB.PARTYDET<PART.DET.PART.TOWN.NAME>
        R.NEW(PO.ORDERING.COUNTRY.RESIDENCE) = R.JB.PARTYDET<PART.DET.PART.ADDRESS.COUNTRY>
    END

RETURN

POPULATE.UNSTRUCT.ADDR:
***********************
*CBPAY-2016
    Y.UNSTRUCT.ADDR = ''
    Y.UNSTRUCT.ADDR1 = ''
    Y.UNSTRUCT.ADDR2 = ''
    Y.UNSTRUCT.ADDR3 = ''
    
    IF R.JB.PARTYDET<PART.DET.PART.ADDRESS> NE '' THEN
        Y.UNSTRUCT.ADDR1 = R.JB.PARTYDET<PART.DET.PART.ADDRESS>
    END
	IF R.JB.PARTYDET<PART.DET.PART.POST.CODE> NE '' THEN
        Y.UNSTRUCT.ADDR2 = ' ':R.JB.PARTYDET<PART.DET.PART.POST.CODE>
    END
	IF R.JB.PARTYDET<PART.DET.PART.CITY> NE '' THEN
        Y.UNSTRUCT.ADDR3 = ' ':R.JB.PARTYDET<PART.DET.PART.CITY>
    END

	Y.UNSTRUCT.ADDR = Y.UNSTRUCT.ADDR1:Y.UNSTRUCT.ADDR2:Y.UNSTRUCT.ADDR3
*CBPAY-2016
    YINDEX = '1'
    YCNT = '1'
    LOOP
    WHILE Y.UNSTRUCT.ADDR[YINDEX,35] NE '' AND YCNT LE '3'
        IF Y.UNSTRUCT.ADDR[YINDEX,35] NE '' THEN
            R.NEW(PO.ORDERING.POST.SWIFT.ADDR)<1,-1> = TRIM(Y.UNSTRUCT.ADDR[YINDEX,35]," ","D")
            YINDEX += 35
            YCNT += 1	
        END

    REPEAT
    
 IF MESSAGE NE 'VAL' THEN 
    
    IF LEN(Y.UNSTRUCT.ADDR) GT '105' THEN
        YINIT = '106' ; YLEN = '22'; CNT = '1'

           LOOP
           WHILE Y.UNSTRUCT.ADDR[YINIT,YLEN] NE ''
               IF (Y.UNSTRUCT.ADDR[YINIT,YLEN] NE '') AND (CNT EQ '1') THEN
                   R.NEW(PO.LOCAL.REF)<1,Y.B2B.INFO.POS,-1> = "DbtrAdr cont:": TRIM(Y.UNSTRUCT.ADDR[YINIT,YLEN]," ","D")
                   YINIT += YLEN
                   CNT += CNT
               END ELSE
                  IF (Y.UNSTRUCT.ADDR[YINIT,YLEN] NE '') AND (CNT NE '1') THEN
                     YLEN = YLEN + 13
                     R.NEW(PO.LOCAL.REF)<1,Y.B2B.INFO.POS,-1> = TRIM(Y.UNSTRUCT.ADDR[YINIT,YLEN]," ","D")
                     YINIT += YLEN
                  END
               END 
           REPEAT
      END
 END

    R.NEW(PO.ORDERING.RESIDENCE.CTRY) = R.JB.PARTYDET<PART.DET.PART.COUNTRY>

RETURN

POPULATE.CUSTOMER.NAME:
*----------------------------

    Y.ORD.CUST.NAME = R.NEW(PO.ORDERING.CUST.NAME)
   
    IF LEN(Y.ORD.CUST.NAME) GT '140' THEN
        R.NEW(PO.ORDERING.CUST.NAME) = TRIM(Y.ORD.CUST.NAME[1,140]," ","D")
    END

    YINIT.1 = '141' ; YLEN.1 = '23'; CNT = '1'
IF MESSAGE NE 'VAL' THEN 

    LOOP
    WHILE Y.ORD.CUST.NAME[YINIT.1,YLEN.1] NE ''
        IF (Y.ORD.CUST.NAME[YINIT.1,YLEN.1] NE '') AND (CNT EQ '1') THEN
            R.NEW(PO.LOCAL.REF)<1,Y.B2B.INFO.POS,-1> = "DbtrNm cont:": TRIM(Y.ORD.CUST.NAME[YINIT.1,YLEN.1]," ","D")
            YINIT.1 += YLEN.1
            CNT += CNT
        END ELSE
        IF (Y.ORD.CUST.NAME[YINIT.1,YLEN.1] NE '') AND (CNT NE '1') THEN
            YLEN.1 = YLEN.1 + 12
            R.NEW(PO.LOCAL.REF)<1,Y.B2B.INFO.POS,-1> = TRIM(Y.ORD.CUST.NAME[YINIT.1,YLEN.1]," ","D")
            YINIT.1 += YLEN.1 
        END
        END
    REPEAT
END

RETURN

*-------------------------------------------------------------------------------------------------

END

