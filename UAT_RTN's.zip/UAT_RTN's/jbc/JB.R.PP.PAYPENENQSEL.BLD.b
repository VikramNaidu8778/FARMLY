* @ValidationCode : MTotMTc1MzkzOTM1MjpJU08tODg1OS0xOjE1NTg0MTQ3MjUxOTk6YTM4MjkxOi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4w
* @ValidationInfo : Timestamp         : 30 Oct 2024 12:58:45
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PAYPENENQSEL.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------
*  Date          Developer          Reference         Description
*
*  30-10-2024    Resmi              CBPAY-535        Build routine that displays the transactions based on company ID
*-----------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.COMPANY
*------------------------------------------------------------------------------
    FN.COMPANY = 'F.COMPANY'
    F.COMPANY = ''
    CALL OPF(FN.COMPANY, F.COMPANY)

    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)

    Y.ENQNAME = ENQ.DATA<1>
    Y.ENQFIELDNAME = ENQ.DATA<2>

    CO.POS = DCOUNT(Y.ENQFIELDNAME,@VM)+1
    ENQ.DATA<2,CO.POS> = 'CompanyID'
    ENQ.DATA<3,CO.POS> = 'EQ'
    ENQ.DATA<4,CO.POS> = Y.COMP.ID
 
RETURN
 
**********************
END