SUBROUTINE JB.R.FT.CHKTXNTYPE.INPUT
*-----------------------------------------------------------------------------------------------------------------------
*-----------------------------------------------------------------------------------------------------------------------
* Description:
*-----------------------------------------------------------------------------------------------------------------------
* This Routine is attached in VERSION.CONTROL of FUNDS.TRANSFER, to throw error if Transaction Type
* used is not Allowed .
*-----------------------------------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: N/A
* OUT: N/A
* Revision History:
*----------------------------------------------------------------------------------------------------------------------
* Date               who               Reference          Description

*23-JUL-2024        Lakshmi Priya      CBPAY-304         This routine is to set to throw error if Transaction Type 
*                                                                       used is not Allowed .
*-----------------------------------------------------------------------------------------------------------------------


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
 
    GOSUB INIT
    GOSUB PROCESS
        
RETURN
    
INIT:
*****

    Y.TXNTYPE = ''

    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","FT.RESTRICT.TYPES",Y.GPM.VALUE)
    CHANGE ',' TO VM IN Y.GPM.VALUE
    CHANGE FM TO VM IN Y.GPM.VALUE
    
RETURN

PROCESS:
********

          Y.TXNTYPE = R.NEW(FT.TRANSACTION.TYPE)
          IF Y.TXNTYPE MATCHES Y.GPM.VALUE THEN
             AF = FT.TRANSACTION.TYPE
             ETEXT = 'EB-JB.D.PP.POPRD.CHKTXNTYPE'
            CALL STORE.END.ERROR
          END

RETURN
END




