* @ValidationCode : MjotMzQ3NDI5NzQ0OkNwMTI1MjoxNzE1MTQ4NTA1Mjc0OjkxNDgxNTotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDIzMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 19 Dec 2024 11:38:25
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202408.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.

SUBROUTINE JB.R.PP.GETUSERID.CONV
*-----------------------------------------------------------------------------
* Description :
* Routine is attached in Enquiry JBSG.E.PP.PAYPENPROCESS.LIST to extract the transaction
* type from POR.SUPPLEMENTARY.INFO.
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date           Developer              Reference           Description
*
* 14-Mar-20025   P Amala                CBPAY-75            Initial Draft
*
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_ENQUIRY.COMMON
	$USING PP.PaymentSTPFlowService
    $USING EB.SystemTables
	$USING PP.PaymentWorkflowDASService
    $USING PP.PaymentWorkflowGUI
    $USING EB.DataAccess
	$INSERT I_F.USER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
	  
RETURN
*
*-----------------------------------------------------------------
INIT:
*****

    yUserId = '' ; Y.USR.ID = '' ; R.USR = ''
	
	F.USER = ''
    FN.USER = 'F.USER'
    CALL OPF(FN.USER,F.USER)
	
RETURN
*
*--------------------------------------------------------------------------
PROCESS:
********
  
	yUserId= O.DATA

    Y.USR.ID = yUserId['_',2,1]
    IF Y.USR.ID EQ '' THEN
       Y.USR.ID = yUserId
    END
	CALL F.READ(FN.USER,Y.USR.ID,R.USR,F.USER,'')
	IF R.USR THEN
        Y.USR.ID =  R.USR<EB.USE.DEPARTMENT.CODE>
	END
    O.DATA = Y.USR.ID
RETURN
*--------------------------------------------------------------------------
END