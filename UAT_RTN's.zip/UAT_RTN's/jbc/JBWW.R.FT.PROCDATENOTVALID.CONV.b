*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PROCDATENOTVALID.CONV
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 13/08/2018	Parameshwari		DAY15-2867			Pass the function to the respective version in the enquiry.
*												
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
	$INSERT I_ENQUIRY.COMMON
*-------------------------------------------------------------------------

	GOSUB INIT
	GOSUB PROCESS

    RETURN

*--------------------------------------------------------------------------
INIT:
****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER$NAU'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********

	Y.FT.ID = O.DATA

	CALL F.READ(FN.FUNDS.TRANSFER,Y.FT.ID,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,FUNDS.TRANSFER.ERR)
	
	Y.PROC.DATE = R.FUNDS.TRANSFER<FT.PROCESSING.DATE>
	Y.FT.STATUS = R.FUNDS.TRANSFER<FT.STATUS>

	IF Y.FT.STATUS EQ 'IFWD' AND Y.PROC.DATE LT TODAY THEN
		O.DATA = 'I'
	END ELSE
		O.DATA = 'A'
	END
	
    RETURN

*--------------------------------------------------------------------------

END