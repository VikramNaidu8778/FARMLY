SUBROUTINE JB.XX.FILEUPLD.DASHBOARD.FIELDS
*-----------------------------------------------------------------------------
* This is the field definition routine for Exception Dashboard being used
* for TIS File Uploads
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date            Reference             Developer           Description
*
* 08-Aug-2024     CBPAY-xxx             xxx                 Initial Version
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
    
    ID.F = '@ID'
    ID.N = '35'
    ID.T = 'A'
    
    CALL Table.addFieldDefinition('T24.UPLD.DATE','11','D','')
    CALL Table.addFieldDefinition('SYS.UPLD.DATE','11','D','')
    CALL Table.addFieldDefinition('SYS.UPLD.ST.TIME','10','ANY','')
    CALL Table.addFieldDefinition('SYS.UPLD.END.TIME','10','ANY','')
*    CALL Table.addFieldDefinition('FILE.UPLD.STATUS','10','A','')
    CALL Table.addOptionsField('FILE.UPLD.STATUS','SUCCESS_FAILURE','','')
    CALL Table.addFieldDefinition('SUCCESS.CNT','10','','')
    CALL Table.addFieldDefinition('FAILED.CNT','10','','')
    CALL Table.addFieldDefinition('TOTAL.CNT','10','','')
    CALL Table.addFieldDefinition('FILE.NAME','65','ANY','')
    CALL Table.addFieldDefinition('UPLD.CNT','10','','')
    CALL Table.addFieldDefinition('XX<FAILED.TXN','65','ANY','')
    CALL Table.addFieldDefinition('XX>XX.ERROR.MSG','200','ANY','')
    
    fieldName = 'RESERVED.10'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.9'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.8'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.7'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.6'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.5'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.4'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.3'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.2'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.1'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'XX.OVERRIDE'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    CALL Table.setAuditPosition
*
RETURN
*
END
*
