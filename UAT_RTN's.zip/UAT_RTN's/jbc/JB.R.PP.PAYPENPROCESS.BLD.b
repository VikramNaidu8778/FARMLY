SUBROUTINE JB.R.PP.PAYPENPROCESS.BLD(ENQ.DATA)
*--------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------
* Date          Developer                              Reference               Description
*--------------------------------------------------------------------------------------------
* 17-APR-2025   Vikram Pavuluru                        CBPAY-2449             To Display records Based on transaction types across between roles.
*
* 28-APR-2025   Vikram Pavuluru                        CBPAY-2669             Added condition to display transasctions which are of PaymentDirection EQ 'O'
*                                                                             CTRBTRIndicator EQ 'B' and IncomingMessageType EQ 'TRSY'
* Description : Routine to List all the payments based on User roles & Txn Types.
* Attached to : ENQUIRY>JB.E.PP.USERPAYPENPROCESS.LIST
* Attached as : BUILD.ROUTINE
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.USER
    $INSERT I_F.COMPANY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $INSERT I_ENQUIRY.COMMON
    
    GOSUB INIT
    GOSUB GET.PARAM.VALUES
    GOSUB PROCESS


RETURN
*****
INIT:
*****
* In this para of the program, the files are initialised **
    FN.POR.SUPPL.INFO = "F.POR.SUPPLEMENTARY.INFO"
    F.POR.SUPPL.INO = ""
    CALL OPF(FN.POR.SUPPL.INFO,F.POR.SUPPL.INFO)
    
    FN.POR.TRANSACTION = "F.POR.TRANSACTION"
    F.POR.TRANSACTION = ""
    CALL OPF(FN.POR.TRANSACTION,F.POR.TRANSACTION)
   
    Y.COMP.ID = R.COMPANY(EB.COM.MNEMONIC)
    
RETURN
*****************
GET.PARAM.VALUES:
*****************
*Configured the user roles in the GPM>JB.D.PP.TPH.CONFIG>SECOPS.TXNTYPES,SECTRF.TXNTYPES,FXMM.TXNTYPES,CA.TXNTYPES and SECOPS roles in SECOPS.ROLES.

    Y.GPM.FLD.NAMES = "CASH.USER.ROLES":@FM:"SEC.USER.ROLES"
    CALL JBWW.R.EB.GETGENPARM.VAL("JBWW.E.XX.CASHSEC.USERROLES",Y.GPM.FLD.NAMES,Y.GPM.FLD.VALUES)
    
   
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","SECOPS.TXNTYPES",Y.GPM.FLD.VALUES2)
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","SECTRF.TXNTYPES",Y.GPM.FLD.VALUES3)
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","FXMM.TXNTYPES",Y.GPM.FLD.VALUES4)
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","CA.TXNTYPES",Y.GPM.FLD.VALUES5)
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG","SECOPS.ROLES",Y.GPM.FLD.VALUES6)
    
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES2
    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES2
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES3
    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES3
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES4
    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES4
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES5
    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES5
    CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES6
    CHANGE ',' TO @VM IN Y.GPM.FLD.VALUES6
    
    SECOPS.TXNTYPES = Y.GPM.FLD.VALUES2<1>
    SECTRF.TXNTYPES = Y.GPM.FLD.VALUES3<1>
    FXMM.TXNTYPES = Y.GPM.FLD.VALUES4<1>
    CA.TXNTYPES = Y.GPM.FLD.VALUES5<1>
    SECOPS.ROLES = Y.GPM.FLD.VALUES6<1>
    
    FIND USER.ROLE IN Y.GPM.FLD.VALUES SETTING Y.FM.POS,Y.VM.POS,Y.SM.POS THEN
        Y.USR.GRP = Y.GPM.FLD.NAMES<Y.FM.POS>
    END

    BEGIN CASE
        CASE USER.ROLE MATCHES SECOPS.ROLES
            Y.GPM.TXNTYPE = SECOPS.TXNTYPES
        CASE USER.ROLE MATCHES 'SECURITY.PROCESSING.TRF.A' :@VM: 'SECURITY.PROCESSING.TRF.R'
            Y.GPM.TXNTYPE = SECTRF.TXNTYPES
        CASE USER.ROLE MATCHES 'OPS.CASH.ALL.A' :@VM: 'OPS.CASH.ALL.R'
            Y.GPM.TXNTYPE = FXMM.TXNTYPES
        CASE USER.ROLE MATCHES 'CA.A' :@VM: 'CA.R'
            Y.GPM.TXNTYPE = CA.TXNTYPES
    END CASE
    
RETURN
********
PROCESS:
********

    SEL.CMD = "SELECT ":FN.POR.TRANSACTION:" WITH CompanyID EQ ":Y.COMP.ID
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST EQ '' THEN
        ENQ.ERROR = "No records found to display"
    END ELSE
        LOOP
            REMOVE SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.ID : SEL.POS
            Y.FT.NO = SEL.ID
            CALL F.READ(FN.POR.SUPPL.INFO,Y.FT.NO,R.POR.SUPPL.INFO.REC,FV.POR.SUPPL.INO,PORS.ERR)
            CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION.REC,FV.POR.TRANSACTION,PORT.ERR)
            Y.PMTDIR = R.POR.TRANSACTION.REC<PPPTX.PaymentDirection>
            Y.TRFTYPE = R.POR.TRANSACTION.REC<PPPTX.CTRBTRIndicator>
            Y.MSG.TYPE = R.POR.TRANSACTION.REC<PPPTX.IncomingMessageType>
            IF R.POR.TRANSACTION.REC THEN
                LOCATE Y.MSG.TYPE IN Y.GPM.TXNTYPE<1,1> SETTING MSG.POS THEN
                    LOCATE "L.PO.USR.GRP" IN R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.NAME,1> SETTING BP.POS THEN
                        Y.PP.USR.GRP = R.POR.SUPPL.INFO.REC<PORID.LOC.FIELD.VALUE,BP.POS>
                        IF Y.PP.USR.GRP EQ Y.USR.GRP THEN
                            Y.FNL.SEL.LIST<-1> =  SEL.ID
                        END
                    END ELSE
                        IF Y.PMTDIR EQ 'I' AND Y.TRFTYPE EQ 'B' THEN
                            Y.FNL.SEL.LIST<-1> =  SEL.ID
                        END ELSE
                            IF Y.MSG.TYPE MATCHES Y.GPM.TXNTYPE THEN
                                Y.FNL.SEL.LIST<-1> =  SEL.ID
                            END
                        END
                    END
                END
            END
        REPEAT
        CHANGE @FM TO ' ' IN Y.FNL.SEL.LIST
        ENQ.DATA<2,-1> = '@ID'
        ENQ.DATA<3,-1> = 'EQ'
        ENQ.DATA<4,-1> =  Y.FNL.SEL.LIST
    END
RETURN
**********************************************************************************************
END
