SUBROUTINE JBWW.R.FT.DIARREV.AUTH
* -----------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date           Developer             Reference      Description
*------------------------------------------------------------------------------------------------------
* 31/07/2018     Anitha C              CR             Initial Version
*------------------------------------------------------------------------------------------------------
* Description : 
* -----------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.DIARY
    $INSERT I_F.SC.RESTRICTED.CURRENCY

    GOSUB INIT
    GOSUB PROCESS

    RETURN

INIT:

    FN.SC.RESTRICTED.CURRENCY = 'F.SC.RESTRICTED.CURRENCY'
    F.SC.RESTRICTED.CURRENCY = ''
    CALL OPF(FN.SC.RESTRICTED.CURRENCY,F.SC.RESTRICTED.CURRENCY)
    R.SC.RESTRICTED.CURRENCY = ''
    
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    FN.HIS = 'F.FUNDS.TRANSFER$HIS'
    F.HIS = ''
   CALL OPF(FN.HIS,F.HIS)                                                                                                                 
    LOC.APP = 'DIARY'
    LOC.FLD = 'L.SC.DYFT.REF'
    Y.POS = ''

    CALL MULTI.GET.LOC.REF(LOC.APP,LOC.FLD,Y.POS)
    R.FUNDS.TRANSFER = ''
    DIA.CURRENCY.VAL = '' ; V.POS = ''
    RETURN


PROCESS:
    
    DIA.CURRENCY.VAL = R.NEW(SC.DIA.CURRENCY)
    CALL F.READ(FN.SC.RESTRICTED.CURRENCY,ID.COMPANY,R.SC.RESTRICTED.CURRENCY,F.SC.RESTRICTED.CURRENCY,ERR.SC.RESTRICTED.CURRENCY)
    IF R.SC.RESTRICTED.CURRENCY NE '' THEN
    RESTRICT.FLD.VAL = R.SC.RESTRICTED.CURRENCY<SC.RES.RESTRICTED.CCY>
    RESTRICT.FLD.CNT = DCOUNT(RESTRICT.FLD.VAL,@VM)
    LOCATE DIA.CURRENCY.VAL IN RESTRICT.FLD.VAL<1,1> SETTING V.POS THEN
    RECORD.STATUS.VAL = R.NEW(SC.DIA.RECORD.STATUS)
    IF RECORD.STATUS.VAL EQ 'RNAU' THEN
    GOSUB REV.FT
    END
    END
    RETURN

REV.FT:    
    DIA.FT.REF = R.NEW(SC.DIA.LOCAL.REF)<1,Y.POS>
    DIA.FT.CNT = DCOUNT(DIA.FT.REF,@VM)
    DIA.FT.REF = DIA.FT.REF<1,DIA.FT.CNT>
    CALL F.READ(FN.FUNDS.TRANSFER,DIA.FT.REF,R.FUNDS.TRANSFER,F.FUNDS.TRANSFER,ERR.FT)
    *IF R.FUNDS.TRANSFER NE '' THEN
DIA.FT.HIS.REF = DIA.FT.REF
IF NOT(R.FUNDS.TRANSFER) THEN
CALL EB.READ.HISTORY.REC(F.HIS,DIA.FT.HIS.REF,R.FUNDS.TRANSFER,ERRHIS.FT)
END
    MY.OFS.MSG = ""
    TOL.FT.OFS.SOURCE = "JBWW.D.FT.NOSAC.OFS"
    MY.OFS.MSG = 'FUNDS.TRANSFER,JBWW.V.FT.NOSAC.INP'
    MY.OFS.MSG := "/R/PROCESS,//":ID.COMPANY:"/////,":DIA.FT.HIS.REF  
    END
    CALL OFS.POST.MESSAGE ( MY.OFS.MSG, MY.MSG.ID, TOL.FT.OFS.SOURCE, "" )

    RETURN

END