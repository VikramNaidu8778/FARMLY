* @ValidationCode : MTotMTQxNzY3NDMxNTpVVEYtODoxNDk2ODEwMzg5MDcyOjIzMzE2MzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 07 Jun 2017 10:09:49
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
    SUBROUTINE JBWW.R.FT.SOFTBLOCK.AFTUNAU
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
*
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                           Reference               Description
*-------------------------------------------------------------------------------------------
* 18/11/2016    Dheeraj.Nallabelli@cognizant.com    BJB L3_CR-135           Initial Version
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.JBWW.H.XX.SOFTBLOCK
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN


INIT:

    Y.APP = ''
    Y.ID = ID.NEW
    Y.LOCFIELD = ''
    Y.LOCFIELD.POS = ''
    Y.LOCPOS = ''
    Y.LFT.VLDT.CHKD = ''
    R.SOFTBLOCK = ''
    R.SOFTBLOCK.ERR = ''
    Y.CREDITSFTBLKFLAG = ''
    Y.CC.POS = ''
    Y.OVERALL.STATUS = ''
    Y.APP.FIELD.NAME = ''
    Y.APP.VER.NAME = ''
    Y.OFS.SOURCE = ''

    FN.JBWW.H.XX.SOFTBLOCK = 'F.JBWW.H.XX.SOFTBLOCK'
    F.JBWW.H.XX.SOFTBLOCK = ''
    CALL OPF(FN.JBWW.H.XX.SOFTBLOCK,F.JBWW.H.XX.SOFTBLOCK)
    CALL F.READ(FN.JBWW.H.XX.SOFTBLOCK, Y.ID, R.SOFTBLOCK, F.JBWW.H.XX.SOFTBLOCK, R.SOFTBLOCK.ERR)

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    RETURN
***********************************************************************
PROCESS:

    Y.APP = APPLICATION
    Y.LOCFIELD = 'L.FT.VALDT.CHKD'
    CALL MULTI.GET.LOC.REF(Y.APP,Y.LOCFIELD,Y.LOCPOS)
    Y.LOCFIELD.POS =  Y.LOCPOS<1,1>
    Y.LFT.VLDT.CHKD = R.NEW(FT.LOCAL.REF)<1,Y.LOCFIELD.POS>


    Y.PARAM.ID = 'RLC.SOFTBLOCK.AUTH.VER'
    R.RLC.PARAM = ''
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER, Y.PARAM.ID, R.RLC.PARAM, F.JBWW.H.EB.GENERICPARAMETER, R.GEN.ERR)
    Y.APP.FIELD.NAME = R.RLC.PARAM<JBWW.GEN.PAR.FIELD.NAME>
    CONVERT VM TO FM IN Y.APP.FIELD.NAME
    Y.APP.POS = ''
    FIND Y.APP IN Y.APP.FIELD.NAME SETTING Y.APP.POS ELSE Y.APP.POS = ''
    Y.APP.VER.NAME = R.RLC.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.APP.POS,1>
    Y.OFS.SRC = 'OFS.SOURCE'
    Y.OFS.SRC.POS = ''
    FIND Y.OFS.SRC IN Y.APP.FIELD.NAME SETTING Y.OFS.SRC.POS ELSE Y.OFS.SRC.POS = ''
    Y.OFS.SOURCE = R.RLC.PARAM<JBWW.GEN.PAR.FIELD.VALUE,Y.OFS.SRC.POS,1>


    GOSUB CREDITSOFTBLKCHECK

    IF Y.LFT.VLDT.CHKD EQ "CHECKER" AND Y.CREDITSFTBLKFLAG EQ "1" THEN
        R.SOFTBLOCK<JHXS.CREDIT.READY> = Y.LFT.VLDT.CHKD
        CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK, Y.ID, R.SOFTBLOCK)
    END

    IF Y.CREDITSFTBLKFLAG EQ '' AND Y.LFT.VLDT.CHKD EQ 'CHECKER'  THEN
        R.SOFTBLOCK<JHXS.OVERALL.STATUS> = 'APPROVE'
        CALL F.WRITE(FN.JBWW.H.XX.SOFTBLOCK, Y.ID, R.SOFTBLOCK)
        GOSUB POSTOFSMSG
    END

    RETURN
***********************************************************************
CREDITSOFTBLKCHECK:

    IF NOT(R.SOFTBLOCK.ERR) THEN
        Y.CC.BLK.DEPT = 'CC'
        Y.BLOCK.DEPT = R.SOFTBLOCK<JHXS.BLOCK.DEPT>
        CONVERT VM TO FM IN Y.BLOCK.DEPT
        FIND Y.CC.BLK.DEPT IN Y.BLOCK.DEPT SETTING Y.CC.POS ELSE Y.CC.POS = ''
        IF Y.CC.POS THEN
            Y.CREDITSFTBLKFLAG = '1'
        END
    END

    RETURN
***********************************************************************
POSTOFSMSG:

    OFS.APP.NAME  = 'FUNDS.TRANSFER'
    OFS.INPUT.FUN = 'A'
    OFS.PROCESS   = 'PROCESS'
    OFS.VERSION   = Y.APP.VER.NAME
    OFS.GTS.MODE  = ''
    OFS.NO.AUTH   = '0'
    R.REC         = ''
    TRANSACTION.ID = ID.NEW

    CALL OFS.BUILD.RECORD(OFS.APP.NAME,OFS.INPUT.FUN,OFS.PROCESS,OFS.VERSION,OFS.GTS.MODE,OFS.NO.AUTH,TRANSACTION.ID,R.REC,OFS.RESPONSE)
    OFS.MSG.ID = ''
    OPTION = ''
    OFS.SRC = Y.OFS.SOURCE
    CALL OFS.POST.MESSAGE(OFS.RESPONSE,OFS.MSG.ID,OFS.SRC,OPTION)

    RETURN
***********************************************************************
    END
