*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PROCESSINGDATE.INPUT
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 08/07/2016    Jothi                 FIN_GSD034           Initial Version
* 21/FEB/2017   Mahesh J            JB2A-27467            Fatel error in CDD. 
* 13/03/2017    Dinesh				JB2A-27467			  Debit value date Fetch correction applied 	
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.FUNDS.TRANSFER
*-------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS

    RETURN

*--------------------------------------------------------------------------
INIT:
****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********
*      
**JB2A-27467  (S)
	Y.DR.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)

    IF Y.DR.VALUE.DATE THEN
**JB2A-27467  (E)
    Y.TODAY = TODAY
    CALL CDT('',Y.TODAY,'+2W')
    TWO.W.DAYS.ADDED = Y.TODAY

        IF Y.DR.VALUE.DATE NE "" THEN
         Y.DR.VALUE.DATE.MINUS = Y.DR.VALUE.DATE
         CALL CDT('',Y.DR.VALUE.DATE.MINUS,'-2W')
        END

    TWO.W.DAYS.SUBTRACT = Y.DR.VALUE.DATE.MINUS


    IF Y.DR.VALUE.DATE GT TWO.W.DAYS.ADDED THEN
        Y.PROCESSING.DATE = TWO.W.DAYS.SUBTRACT
    END ELSE
        Y.PROCESSING.DATE = TODAY
    END

    R.NEW(FT.PROCESSING.DATE) = Y.PROCESSING.DATE
	END ; **JB2A-27467  (S/E)
    RETURN

*--------------------------------------------------------------------------

END