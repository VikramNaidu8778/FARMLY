* @ValidationCode : MTotODIxMjc0MzQwOklTTy04ODU5LTE6MTU0MDM3ODIxMTg5NDphMzk5MjI6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxNjA4LjE2
* @ValidationInfo : Timestamp         : 24 Oct 2018 18:50:11
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a39922
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.16
    SUBROUTINE JBWW.R.FT.COMMCHARDFLT.INPUT
*------------------------------------------------------------------------------------------------------------------
*   Desc : This routine is to Default the local fields  L.XX.PM.ALLOC,L.XX.PM.METTYPE,L.XX.PM.METID,L.XX.PM.METQTY
*    in FT from CURRENCY.
*------------------------------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                  Reference               Description
*-------------------------------------------------------------------------------------------
* 09/10/2017	Rajagopalan R              JB2A-43485              Defaulting values for different fields based on Ben Our Charges field.
*09/11/2017     Sushmitha B                JB2A-43485              Defaulting values for Draft110 fields based on Ben Our Charges field.
*16/11/2017     Lavanya Kumar              JB2A-44895              Defaulting the values for OT60 based on Ben Our Charges field.
*30/01/2018     Balaji              	   JB2A-47695              Corr bank charge should not be populated for charge code BEN & SHA.
*09/03/2018     Karthik                    JB2A-49645              Defaulting CHARGE.CODE as "WAIVE" when debit account is  PL.
*27/04/2018     Lakshmanan                 JB2A-51690              Debit account category check added
*03/09/2018     Smitha                     DAY15-3798              Outward Remmitances: 103 and 103+202Cov: Charge Code of BEN/SHA should be supported
*03/10/2018     Smitha                     Day15-4782              To create Outward Remittance- MT604 (OT60) from edgeConnect for OUR-WAIVE-WAIVE combinations for PL account
*16/10/2018		Kalyani					   DAY15-4941 			   To stop defaulting WAIVE for CHARGE.CODE & COMMISSION.CODE when charge code is BEN
*17/10/2018     Charan Prasad KS           DAY15-4871              To default CHARGES.ACCT.NO currency in CHARGE.AMT for BEN.OUR.CHARGES SHA.
*22/10/2018     Charan Prasad KS           DAY15-4871              Commented IF condition, not to check the CHARGE.AMT field value
*23/10/2018     Charan Prasad KS           DAY15-4941              COMMISSION.CODE and CHARGE.CODE should default to CREDIT LESS CHARGES for client account
*15/03/2024		u1e851					   CBGBB-325			   R23.10 upgrade-Changed the update CHARGE.FOR and COMMISSION.FOR as SENDER
*26/06/2024 Prabhu D S CBPAY-84 COMMISSION.CODE and CHARGE.CODE should defaulted to DEBIT PLUS CHARGES for Precious Metals
*--------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------

*****
INIT:
*****

    Y.BEN.OUR.CHARGES = COMI
    Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

	RETURN ;*CBGBB-325
********
PROCESS:
********
*S - JB2A-47695

*JB2A-49645 S

    Y.DEBIT.ACCT.NO = '' ; Y.DEBIT.ACCT.NO.PL = ''
    Y.DEBIT.ACCT.NO = R.NEW(FT.DEBIT.ACCT.NO)

    R.ACC.REC = ''
    CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCT.NO,R.ACC.REC,F.ACCOUNT,ACC.ERR)
    IF R.ACC.REC THEN
        Y.AC.CATEGORY = R.ACC.REC<AC.CATEGORY>
    END

    Y.DEBIT.ACCT.NO.PL = ISDIGIT(Y.DEBIT.ACCT.NO)
*   IF Y.TXN.TYPE EQ "OT03" OR Y.TXN.TYPE EQ "OT12" AND Y.DEBIT.ACCT.NO.PL EQ "0" THEN
    IF (Y.TXN.TYPE EQ "OT03") OR (Y.TXN.TYPE EQ "OT12") OR (Y.TXN.TYPE EQ 'OT60' ) THEN
        *AND (Y.AC.CATEGORY GT 1999)) THEN
        IF (Y.AC.CATEGORY GT 1999) OR Y.DEBIT.ACCT.NO.PL EQ "0"   THEN
            BEGIN CASE
                CASE Y.BEN.OUR.CHARGES EQ 'BEN'
                    * (S) - DAY15-4941
                    COMM.CODE = R.NEW(FT.COMMISSION.CODE)
                    CHRG.CODE = R.NEW(FT.CHARGE.CODE)
                    IF COMM.CODE EQ '' THEN
                        R.NEW(FT.COMMISSION.AMT) = ""
                        R.NEW(FT.COMMISSION.CODE) = "WAIVE"
                        R.NEW(FT.COMMISSION.TYPE) = ""
                    END
                    IF CHRG.CODE EQ '' THEN
                        R.NEW(FT.CHARGE.CODE) = "WAIVE"
                        R.NEW(FT.CHARGE.AMT) = ""
                        R.NEW(FT.CHARGE.TYPE) = ""
                    END
                    * (E) - DAY15-4941

                CASE Y.BEN.OUR.CHARGES EQ 'OUR'
                    R.NEW(FT.COMMISSION.AMT) = ""
                    R.NEW(FT.COMMISSION.CODE) = "WAIVE"
                    R.NEW(FT.CHARGE.CODE) = "WAIVE"
                    R.NEW(FT.CHARGE.AMT) = ""
                    R.NEW(FT.CHARGE.TYPE) = ""
                    * (S) - DAY15-4941
                    R.NEW(FT.COMMISSION.TYPE) = ""
                    * (E) - DAY15-4941

                CASE Y.BEN.OUR.CHARGES EQ 'SHA'
                    R.NEW(FT.COMMISSION.AMT) = ""
                    R.NEW(FT.CHARGE.CODE) = "WAIVE"
                    R.NEW(FT.COMMISSION.CODE) = "WAIVE"
                    R.NEW(FT.CHARGE.AMT) = ""
                    R.NEW(FT.CHARGE.TYPE) = ""
                    * (S) - DAY15-4941
                    R.NEW(FT.COMMISSION.TYPE) = ""
                    * (E) - DAY15-4941

            END CASE
        END
    END
*JB2A-49645 E

    IF Y.TXN.TYPE EQ "OT03" OR Y.TXN.TYPE EQ "OT12" OR Y.TXN.TYPE EQ 'OT60' THEN
        IF Y.BEN.OUR.CHARGES EQ "OUR" THEN
            R.NEW(FT.CHARGE.FOR) = "SENDER" 
        END
        *commented to default the CHARGE.AMT with CHARGE.ACCT currency - 22/10/2018
        *IF R.NEW(FT.CHARGE.AMT) EQ '' THEN
        IF Y.BEN.OUR.CHARGES EQ 'SHA' AND Y.AC.CATEGORY LT '1999' AND R.NEW(FT.CHARGE.CODE) NE 'WAIVE' THEN
            R.NEW(FT.CHARGE.TYPE) = 'CORRBKCHG'
            *(S) - day15- 4871
            Y.CHARGE.ACCT = R.NEW(FT.CHARGES.ACCT.NO)
            IF Y.CHARGE.ACCT THEN
                CALL F.READ(FN.ACCOUNT,Y.CHARGE.ACCT,R.ACC.REC,F.ACCOUNT,ACC.ERR)
                Y.CHARGE.CCY = R.ACC.REC<AC.CURRENCY>
                R.NEW(FT.CHARGE.AMT) = Y.CHARGE.CCY:"0.00"
            END ELSE
                R.NEW(FT.CHARGE.AMT) = R.NEW(FT.DEBIT.CURRENCY):"0.00"
            END
            *(E) - day15- 4871
        END

        IF Y.BEN.OUR.CHARGES EQ 'BEN' AND R.NEW(FT.CHARGE.CODE) NE 'WAIVE' THEN
            R.NEW(FT.CHARGE.TYPE) = 'CORRBKCHG'
            R.NEW(FT.CHARGE.AMT) = R.NEW(FT.CREDIT.CURRENCY):"0.00"
        END
        *END
    END

*E - JB2A-47695

;*(S)*JIRA day15-4941-for TXN.TYPE OT60 and BEN.OUR.CHARGES is BEN, COMMISSION.CODE and CHARGE.CODE should default to CREDIT LESS CHARGES for client account and allow users to overwrite - 23/10/2018
    Y.COMM.CODE = R.NEW(FT.COMMISSION.CODE)
*    IF Y.TXN.TYPE EQ "OT60" AND Y.BEN.OUR.CHARGES EQ "BEN" THEN
    IF (Y.TXN.TYPE EQ "OT60") AND (Y.AC.CATEGORY LT 1999 OR Y.DEBIT.ACCT.NO.PL NE "0") THEN
        IF Y.COMM.CODE EQ '' THEN
            BEGIN CASE
                CASE Y.BEN.OUR.CHARGES EQ "BEN"
                    R.NEW(FT.COMMISSION.CODE) = "CREDIT LESS CHARGES"
                    R.NEW(FT.CHARGE.CODE) = "CREDIT LESS CHARGES"
                
                CASE Y.BEN.OUR.CHARGES MATCHES "OUR":@VM:"SHA"
                    R.NEW(FT.COMMISSION.CODE) = "DEBIT PLUS CHARGES"
                    R.NEW(FT.CHARGE.CODE) = "DEBIT PLUS CHARGES"
            END CASE
        END
    END

 ;*(E)
    IF Y.TXN.TYPE EQ "OT60" AND (Y.BEN.OUR.CHARGES EQ "OUR" OR Y.BEN.OUR.CHARGES EQ "BEN" OR Y.BEN.OUR.CHARGES EQ "SHA")THEN
        R.NEW(FT.COMMISSION.FOR) = "SENDER" 
        R.NEW(FT.CHARGE.FOR) = "SENDER" 
    END

    IF Y.TXN.TYPE EQ "OTDA" AND (Y.BEN.OUR.CHARGES EQ "OUR" OR Y.BEN.OUR.CHARGES EQ "BEN" OR Y.BEN.OUR.CHARGES EQ "SHA")THEN
        R.NEW(FT.CHARGE.FOR) = "SENDER" 
    END

    IF Y.TXN.TYPE EQ "ODDF" AND Y.BEN.OUR.CHARGES EQ "" THEN
        R.NEW(FT.COMMISSION.FOR) = "SENDER" 
    END
* (S) - DAY15-4941
    IF R.NEW(FT.CHARGE.CODE) EQ "WAIVE" THEN
        R.NEW(FT.CHARGE.AMT) = ''
        R.NEW(FT.CHARGE.TYPE) = ''
    END
*
    IF R.NEW(FT.COMMISSION.CODE) EQ "WAIVE" THEN
        R.NEW(FT.COMMISSION.AMT) = ''
        R.NEW(FT.COMMISSION.TYPE) = ''
    END
* (E) - DAY15-4941
    RETURN

    END
