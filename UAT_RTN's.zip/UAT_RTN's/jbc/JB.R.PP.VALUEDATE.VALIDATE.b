* @ValidationCode : MjoxNjIzNjY3NDEyOkNwMTI1MjoxNzEzMTcyMjMzNjY1OjIxMTcwNzg6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAyMzEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 20 May 2024 16:40:33
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 2117078
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
SUBROUTINE JB.R.PP.VALUEDATE.VALIDATE
*---------------------------------------------------------------------------------------------
* Description:
*---------------------------------------------------------------------------------------------
* This is the validation routine attached to the field CREDIT.VALUE.DATE in PO Draft versions.
* It is used to default the ORDERING.CUSTOMER.ACCOUNT field with DEBIT.ACCOUNT Number.
* This Logic is retroffited from the Routine JBWW.R.FT.VALUEDATE.VALIDATE.b in FT Versions.
*---------------------------------------------------------------------------------------------
* Attached: to version PAYMENT.ORDER,JB.V.PP.NOST103COV.INP
*---------------------------------------------------------------------------------------------
* Input/Output:
*--------------
* IN: NA
* OUT: NA
*
* Dependencies:
*---------------
* NA
* Revision History:
*-------------------------------------------------------------------------------------------
* Date               who               Reference          Description

* 20-05-2024        Vikram Pavuluru     CBPAY-33        To Default the Debit Value Date
*-------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    GOSUB INITIALISE
    GOSUB PROCESS
RETURN
******************************************************************
INITIALISE:
***********
    Y.DRVAL.DATE = ''
    Y.DRVAL.DATE = R.NEW(PO.DEBIT.VALUE.DATE)

    FN.JBWW.H.EB.GENERICPARAMETER = "F.JBWW.H.EB.GENERICPARAMETER"
    F.JBWW.H.EB.GENERICPARAMETER = ""
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

RETURN
******************************************************************
PROCESS:
***********
    IF Y.DRVAL.DATE THEN
        COMI = Y.DRVAL.DATE
    END
    
    R.JBWW.H.EB.GENERICPARAMETER = "" ; JBWW.H.EB.GENERICPARAMETER.ERR = ""
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.FT.SWIFT.VERSION",R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,JBWW.H.EB.GENERICPARAMETER.ERR)
    IF R.JBWW.H.EB.GENERICPARAMETER NE "" THEN
        Y.FIELD.NAME.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
        Y.FIELD.VALUE.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE>
        LOCATE "TAG50.VERSION.LIST" IN Y.FIELD.NAME.LIST<1,1> SETTING TAG50.VERS.POS THEN
            Y.TAG50.VERSION.LIST = Y.FIELD.VALUE.LIST<1,TAG50.VERS.POS>
            CHANGE SM TO VM IN Y.TAG50.VERSION.LIST
        END
                
        Y.CURRENT.VERSION = APPLICATION:PGM.VERSION
        LOCATE Y.CURRENT.VERSION IN Y.TAG50.VERSION.LIST<1,1> SETTING CURR.VERS.POS THEN
            R.NEW(PO.ORDERING.CUSTOMER.ACCOUNT) = R.NEW(PO.DEBIT.ACCOUNT)
        END
    END

RETURN
********************************************************************
END