* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 914815
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*------------------------------------------------------------------------- 

SUBROUTINE JB.R.PP.ERRORMSG.CONV
*---------------
** Description:
*----------------------------------------------------------------------------------
* This is Conversion  routine attached to enquiry JB.E.PP.EAMSSDTRANSFERFAILED.NAU which was previously a functionality in Funds.Transfer
*----------------------------------------------------------------------------------

*-----------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*02/04/2024	Murali krishnan H			CBPAY-9		To fetch Error message from JB.XX.FILEUPLD.DASHBOARD for EAM SSD fileupload in
*									Payment order 
*--------------------------------------------------------------------------------------------------------------------------------------------------------



$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_ENQUIRY.COMMON
$INSERT I_F.JB.XX.FILEUPLD.DASHBOARD
$INSERT I_F.PAYMENT.ORDER



GOSUB INIT
GOSUB PROCESS

 
RETURN
 
INIT:

FN.JB.XX.FILEUPLD.DASHBOARD='F.JB.XX.FILEUPLD.DASHBOARD'
F.JB.XX.FILEUPLD.DASHBOARD=''
CALL OPF(FN.JB.XX.FILEUPLD.DASHBOARD,F.JB.XX.FILEUPLD.DASHBOARD)
ERR.JB.XX=''
R.JB.XX.FILEUPLD.DASHBOARD=''
Y.ID=''

 
RETURN
 
PROCESS:

 Y.L.FT.FILEUPD.ID = O.DATA
CALL F.READ(FN.JB.XX.FILEUPLD.DASHBOARD,Y.L.FT.FILEUPD.ID,R.JB.XX.FILEUPLD.DASHBOARD,F.JB.XX.FILEUPLD.DASHBOARD,ERR.JB.XX)
Y.FAILED.TXNS.ARRAY=R.JB.XX.FILEUPLD.DASHBOARD<JB.XX.FAILED.TXN>
Y.POS=''
Y.ID=@ID
LOCATE Y.ID IN Y.FAILED.TXNS.ARRAY<1,1> SETTING Y.POS THEN
	O.DATA = R.JB.XX.FILEUPLD.DASHBOARD<JB.XX.ERROR.MSG,Y.POS>

	   Q.DATA = O.DATA
    CHANGE SM TO "*" IN Q.DATA
O.DATA = Q.DATA

END ELSE
O.DATA=''
END

RETURN
END
