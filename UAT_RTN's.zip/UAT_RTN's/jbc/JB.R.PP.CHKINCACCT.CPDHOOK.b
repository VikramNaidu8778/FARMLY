$PACKAGE PP.RoutingAndSettlementService
SUBROUTINE JB.R.PP.CHKINCACCT.CPDHOOK(iTransactionDetails,iCreditPartyDetails,HookResponse)
* Description :
* Routine attached in PP.COMPONENT.HOOK.API>CreditPartyDetermination
* API routine to * API routine to raise a Warning if Account is not found for Payment Currency received in incoming pacs.008.
* with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date              Developer            Reference          Description
*
*08/07/2024         Lakshmi Priya K S    CBPAY-548          Raise a Warning if Account is not found for Payment Currency received in incoming pacs.008.
*----------------------------------------------------------------------------------------------------------------------------------------------------------
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.CreditPartyDeterminationService
    $USING SC.ScoPortfolioMaintenance
    $USING AC.AccountOpening
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $USING PP.StaticDataGUI
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentLifecycleHook

    iPaymentID=iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>

    PP.PaymentWorkflowDASService.getPaymentRecord(iPaymentID, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)
    GOSUB INIT
    IF ((oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ctrBtrIndicator>="C") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.paymentDirection>="I") AND (oPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.repairFlag>='')) THEN
        GOSUB GET.ACCT.DETAILS
        GOSUB PROCESS
        RETURN
    END
RETURN

*****
INIT:
*****
    FN.ACC = 'F.ACCOUNT' ; F.ACC = '' ; R.ACC = ''
    EB.DataAccess.Opf(FN.ACC, F.ACC)

    FN.ALT.ACC = 'F.ALTERNATE.ACCOUNT' ; F.ALT.ACC = '' ; R.ALT.ACC = '' ; ALT.ERR = ''
    EB.DataAccess.Opf(FN.ALT.ACC, F.ALT.ACC)

    FN.SAMN = 'F.SEC.ACC.MASTER.ACCOUNT.NAME' ; F.SAMN = '' ; R.SAMN = ''
    EB.DataAccess.Opf(FN.SAMN, F.SAMN)

    FN.SAM = 'F.SEC.ACC.MASTER'  ;  F.SAM = '' ; R.SAM = ''
    EB.DataAccess.Opf(FN.SAM, F.SAM)

    FN.ERRCODE='F.PP.ERRORCODE' ; F.ERRCODE='' ; R.ERRCODE=''
    EB.DataAccess.Opf(FN.ERRCODE, F.ERRCODE)

    FN.POR.TRANSACTION = 'F.POR.TRANSACTION'
    F.POR.TRANSACTION = ''
    EB.DataAccess.Opf(FN.POR.TRANSACTION, F.POR.TRANSACTION)

    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    EB.DataAccess.Opf(FN.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO)
    yCompanyID = iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.companyID>

RETURN

*****************
GET.ACCT.DETAILS:
*****************
    yCrAccountNo = iCreditPartyDetails<PP.CreditPartyDeterminationService.DetermineCreditPartyInput.crMainAccNumber>
    
    IF NUM(yCrAccountNo) THEN
        EB.DataAccess.FRead(FN.ACC, yCrAccountNo, R.ACC, F.ACC, Err)
        LOCATE "BJB.ACCT" IN R.ACC<AC.AccountOpening.Account.AltAcctType,1> SETTING yAltAccPos THEN
            yCrAccount= R.ACC<AC.AccountOpening.Account.AltAcctId,yAltAccPos>
        END
    END
    
    FINDSTR "-" IN yCrAccount SETTING yPos THEN
        yAltAccValue=FIELD(yCrAccount,'-',1):'-':FIELD(yCrAccount,'-',2)
        yPaymentCcy = FIELD(yCrAccount , '-' ,3)
        yPaymentCcy = yPaymentCcy[1,3]
    END ELSE
        EB.DataAccess.FRead(FN.ACC, yCrAccount, R.ACC, F.ACC, Err)
    END
RETURN
********
PROCESS:
********
    
    LOCATE "BJB.ACCT" IN R.ACC<AC.AccountOpening.Account.AltAcctType,1> SETTING yAltAccPos THEN
        yAltAccVal= R.ACC<AC.AccountOpening.Account.AltAcctId,yAltAccPos>
        yAltAccValue=FIELD(yAltAccVal,'-',1):'-':FIELD(yAltAccVal,'-',2)
    END
       
    EB.DataAccess.FRead(FN.SAMN, yAltAccValue, R.SAMN, F.SAMN, Err)
    IF R.SAMN  THEN
        SamId = FIELD(R.SAMN,'*',2)
    END

    EB.DataAccess.FRead(FN.SAM, SamId, R.SAM, F.SAM, Err)
    Err=''
    
    IF R.SAM THEN
        LOCATE yCrAccountNo IN R.SAM<SC.ScoPortfolioMaintenance.SecAccMaster.ScSamIncAccountNo,1> SETTING INC.POS THEN
            iErrorTableKey<PP.PaymentFrameworkService.ErrorTableKey.errorCode> = 'CPD90001'
            PP.PaymentFrameworkService.getErrorDetails(iErrorTableKey, oErrorDetails, oGetErrTypeError)
            IF oErrorDetails THEN
                HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode> = "CPD90001"
                HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType> = "ERR"
                HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText> = oErrorDetails<PP.PaymentFrameworkService.ErrorDetails.errorText>
            END
        END
    END
RETURN
***************************************************************************************************************************************************
END
