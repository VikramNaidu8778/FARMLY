SUBROUTINE JB.R.PP.OETRHTRADES.PSAHOOK(iStatusAction)
*------------------------------------------------------------------------------------------------------
* This routine is to Create record in Tables JBWW.L.XX.TRH.TRADES & JBWW.H.XX.TRH.TRADES with ID as FT
* no generated, when we recieve pacs.008 and when payment is in Repair queue due to Non STP setup.
* Attached in PP.STATUS.ACTION of 235.* (Payment Repair Queue)
*------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------
* Date          Developer           Reference    Description
*------------------------------------------------------------------------------------------------------
*16-JUL-2024    Prabhu D S          CBPAY-550    Initial Version
*------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.VERSION
    $INSERT I_F.ACCOUNT
    $INSERT I_TPH.TRHTRADES.COMMON
    $INSERT I_F.POR.TRANSACTION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO
    $INSERT I_F.FT.TXN.TYPE.CONDITION
    $INSERT I_F.JBWW.L.XX.TRH.TRADES
    $INSERT I_F.JBWW.H.XX.TRH.TRADES
    $USING PP.TRIPService
    $USING PP.PaymentWorkflowDASService
    
    GOSUB INIT
    GOSUB MAIN.PROCESS
    GOSUB EXPORT.TO.TRIP.API
    
RETURN
*-----------------------------------------------------------------------------
*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>
    
    R.TRADE.RECORD.ARRAY = '' ; R.POR.TRANSACTION = '' ; R.POR.SUPPL.INFO = ''
    NARRATIVE = '' ; Y.TXN.TYPE = '' ; CR.FLAG = '0' ; CR.INCLUDE.ACCT = '0'

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = MAIN.PROCESS>
MAIN.PROCESS:
*
* Get necessary values from incoming argument to fetch details from POR.TRANSACTION
* and POR.SUPPLEMENTARY.INFO tables. Process further only for Incoming payments and
* in Repair Queue only because of Non STP setup.

    PaymentRecord = iStatusAction<PP.TRIPService.StatusAction.paymentRecord> ;*To get the PAYMENT.ORDER record data
    iPaymentRecord = RAISE(PaymentRecord)
     
    Y.FT.NO = iPaymentRecord<PP.PaymentWorkflowDASService.PaymentRecord.ftNumber>
    
    CALL JB.R.PP.TRHTRADES.OPENFILES
    
    GOSUB GET.INFO.FROM.POR.TABLES
    
    IF Y.PMT.DIR EQ 'I' AND NOT(Y.REPAIR.FLAG) AND CR.FLAG EQ '1' AND CR.INCLUDE.ACCT EQ '1' THEN
        GOSUB ASSIGN.TRHTRADES.TABLE
        GOSUB UPDATE.TRHTRADES.TABLES
    END

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = GET.INFO.FROM.POR.TABLES>
GET.INFO.FROM.POR.TABLES:
* Get values from POR.TRANSACTION & POR.SUPPLEMENTARY.INFO

    CALL F.READ(FN.POR.TRANSACTION,Y.FT.NO,R.POR.TRANSACTION,FV.POR.TRANSACTION,ERR.POR.TRN)
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO,Y.FT.NO,R.POR.SUPPL.INFO,FV.POR.SUPPLEMENTARY.INFO,ERR.POR.INFO)
    
    IF R.POR.TRANSACTION THEN
        Y.PMT.DIR = R.POR.TRANSACTION<PPPTX.PaymentDirection>
        Y.REPAIR.FLAG = R.POR.TRANSACTION<PPPTX.RepairFlag>
        Y.CR.ACCOUNT = R.POR.TRANSACTION<PPPTX.CreditMainAccount>
        GOSUB CR.CHECK.CUSTOMER
        Y.TXN.AMT = R.POR.TRANSACTION<PPPTX.TransactionAmount>
        Y.TXN.CCY = R.POR.TRANSACTION<PPPTX.TransactionCurrencyCode>
        CR.VALUE.DATE = R.POR.TRANSACTION<PPPTX.CreditValueDate>
        PROCESSING.DATE = R.POR.TRANSACTION<PPPTX.ProcessingDate>
    END
    
    IF R.POR.SUPPL.INFO THEN
        Y.LOC.FLD.NAME = R.POR.SUPPL.INFO<PORID.LOC.FIELD.NAME>
        Y.LOC.FLD.VALUE = R.POR.SUPPL.INFO<PORID.LOC.FIELD.VALUE>

        LOCATE 'L.PP.DEF.INW.IT' IN Y.LOC.FLD.NAME<1,1> SETTING LOC.POS THEN
            Y.TXN.TYPE = Y.LOC.FLD.VALUE<1,LOC.POS>
            CALL F.READ(FN.FT.TXN.TYPE.CONDITION, Y.TXN.TYPE, R.FT.TXN.TYPE.CONDITION, FV.FT.TXN.TYPE.CONDITION, FT.TXN.ERR)
            NARRATIVE = R.FT.TXN.TYPE.CONDITION<FT6.DESCRIPTION>
        END
    END

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = CR.CHECK.CUSTOMER>
CR.CHECK.CUSTOMER:
* To Check Credit Customer falls under configured values
    GOSUB CHECK.CLIENT.CUST

    CR.FLAG = ''
    LOCATE Y.SECTOR IN INCLUDE.SECTOR.VALS<1,1> SETTING SECT.POS THEN
        CR.FLAG = '1'
    END
    CR.INCLUDE.ACCT = ''
    LOCATE CATEGORY.VAL IN INCLUDE.CATEGORY.VALS<1,1> SETTING CATEGORY.POS THEN
        CR.INCLUDE.ACCT = '1'
    END

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = CHECK.CLIENT.CUST>
CHECK.CLIENT.CUST:
* To get Category & Sector for Credit Account

    R.ACCOUNT = '' ; ACCT.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.CR.ACCOUNT,R.ACCOUNT,FV.ACCOUNT,ACCT.ERR)
    CUSTOMER.ID = R.ACCOUNT<AC.CUSTOMER>
    PORTFOLIO.ID = R.ACCOUNT<AC.PORTFOLIO.NO>
    CATEGORY.VAL = R.ACCOUNT<AC.CATEGORY>
    R.CUSTOMER = '' ; CUSTOMER.ERR = ''
    CALL F.READ(FN.CUSTOMER,CUSTOMER.ID,R.CUSTOMER,FV.CUSTOMER,CUSTOMER.ERR)
    Y.SECTOR = R.CUSTOMER<EB.CUS.SECTOR>

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = ASSIGN.TRHTRADES.TABLE>
ASSIGN.TRHTRADES.TABLE:
*** <desc> Actual process </desc>
    
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.is.Batch>      = 'False'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.src.System>    = 'T24-FT'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.client.Nbr>    = R.CUSTOMER<EB.CUS.MNEMONIC>
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.portfolio.Nbr> = CR.ACCOUNT.NAME
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Type> = 'PAYIN'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.inst.Identifier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.underlying> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sub.Asset.Type> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Amt> = Y.TXN.AMT
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.txn.Ccy> = Y.TXN.CCY
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.sell.Txn.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.ref.Nbr> = Y.FT.NO
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.value.Date> = CR.VALUE.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.quantity> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.strike.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.spot.Price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.run.Notional> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.short.Notional.Amt> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Size> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.delta.Structure> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.number.Of.Settl.Dates> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.multiplier> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.nbr.Of.Options> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trans.Desc> = NARRATIVE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.price> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.tenor> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.option.Desc> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.dlv.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.link.Reference> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.processing.Date> = PROCESSING.DATE
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.buy.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.base.Ccy> = ''
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.rec.Status>     = 'INAU'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.status> = 'Unauth'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.reverse>     = 'False'
    TRX.DATE.TIME.VAL = ''
    CALL JBWW.R.XX.TRH.TRXDATETIME.UPD(TRX.DATE.TIME.VAL)
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.trx.Datetime> = TRX.DATE.TIME.VAL
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.curr.Number> = '1'
    R.TRADE.RECORD.ARRAY<JB.TRHTRD.contract.Event> = ''    
    
RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = GET.PORTFOLIO.DETAILS>
GET.PORTFOLIO.DETAILS:
* Get Customer name from Portfolio
    
    SEC.ACC.MASTER.ERR = '' ; SEC.ACC.MASTER.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,PORTFOLIO.ID, R.SEC.ACC.MASTER, FV.SEC.ACC.MASTER,SEC.ACC.MASTER.ERR)
    CR.ACCOUNT.NAME = ''

    IF NOT(SEC.ACC.MASTER.ERR) THEN
        CR.ACCOUNT.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
    END ELSE
* If Portfolio id is not available in Account>Portfolio.No field then get the portfolio name from alt.acct.id field.
        CALL JB.R.PP.GETSAMACC.RTN(Y.CR.ACCOUNT,PORTFOLIO.NUMBER.VAL)
    
        R.SEC.ACC.MASTER = '' ; SEC.ACC.MASTER.ERR = '' ; PORTFOLIO.NAME = ''
        CALL F.READ(FN.SEC.ACC.MASTER, PORTFOLIO.NUMBER.VAL, R.SEC.ACC.MASTER, FV.SEC.ACC.MASTER, SEC.ACC.MASTER.ERR)
        IF NOT(SEC.ACC.MASTER.ERR) THEN
            PORTFOLIO.NAME = R.SEC.ACC.MASTER<SC.SAM.ACCOUNT.NAME>
            INC.ACCOUNT.NO.VAL = R.SEC.ACC.MASTER<SC.SAM.INC.ACCOUNT.NO>
        END
        CR.ACCOUNT.NAME = PORTFOLIO.NAME
    END

RETURN
*** </region>
*-----------------------------------------------------------------------
*** <region name = UPDATE.TRHTRADES.TABLES>
UPDATE.TRHTRADES.TABLES:
* TO Update H & L type TRH TABLES for given FT Number
    
    CALL F.WRITE(FN.JBWW.L.XX.TRH.TRADES,Y.FT.NO,R.TRADE.RECORD.ARRAY)
    CALL F.WRITE(FN.JBWW.H.XX.TRH.TRADES,Y.FT.NO,R.TRADE.RECORD.ARRAY)  
    
    CALL OCOMO("TRH Record updated":R.TRADE.RECORD.ARRAY:" ":Y.FT.NO)
    FLOW.CATALOG.ID = 'TRH-JbwwLXxTrhTrades'
    FLOWNAME = 'JBWW.L.XX.TRH.TRADES'
    APPLICATIONNAME = 'JBWW.L.XX.TRH.TRADES'
    CALL JBWW.R.IF.TRHTRADES.CAPTURE(FLOWNAME , FLOW.CATALOG.ID , APPLICATIONNAME ,  Y.FT.NO)
        
RETURN
***</region>
*-----------------------------------------------------------------------------
*** <region name= EXPORT.TO.TRIP.API>
EXPORT.TO.TRIP.API:
*** <desc>To call the core API exportToTRIP in order to complete the Payment Order Process </desc>
    PP.TRIPService.exportToTRIP(iStatusAction) ;* To call the core API exportToTRIP in order to complete the Payment Order Process
RETURN
*** </region>
*-----------------------------------------------------------------------------

END
