*--------------------------------------------------------------------------------------------------
	SUBROUTINE JBWW.R.FT.BENEFICIARY.DEFAULT
*--------------------------------------------------------------------------------------------------
* Description: This Auto New Content routine attached to FUNDS.TRANSFER,JBWW.V.SC.EAMTRF.INP to default Beneficiary Customer
*---------------------------------------------------------------------------------------------------
* Modification History :
*
*---------------------------------------------------------------------------------------------------
* Date       	   Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
* 10-JUL-2018	   Rajagopalan R       JB2A-DAY15-2976	    		Defaulting Beneficiary Customer field
*--------------------------------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.HOLIDAY
	$INSERT I_F.REGION
	$INSERT I_F.CURRENCY
	$INSERT I_F.FUNDS.TRANSFER

	GOSUB INIT
	GOSUB PROCESS
		
	RETURN
	
INIT:
*****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
	RETURN

PROCESS:
********
	BEN.POS1 = 1
	
	R.NEW(FT.BEN.CUSTOMER)<1,BEN.POS1> = "BANK JULIUS BAER AND CO LTD ZURICH"
		
	BEN.POS2 = 2 
	R.NEW(FT.BEN.CUSTOMER)<1,BEN.POS2> = "EAM TAX SSD"
	
	RETURN
END
