*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE JBWW.R.IT210.SUP(TEMP.HEADER,TMP.OPERAND,TMP.CONDITION,OUT.VAR)
*-----------------------------------------------------------------------------
*Desc : This routine is to supress the swift message for MT103
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Developer         Reference               Description
*-------------------------------------------------------------------------------------------
* 08/11/2017    Parameshwari      JB2A_44607		      Initial Version
*-------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.HEADER
    $INSERT I_F.FUNDS.TRANSFER
	
	GOSUB PROCESS
	RETURN

*-------------------------------------------------------------------------------------------
PROCESS:
*-------

	IF R.NEW(FT.TRANSACTION.TYPE) EQ 'IT' OR R.NEW(FT.TRANSACTION.TYPE) EQ 'ITPM' THEN
		TMP.OPERAND = 'EQUAL'
        TMP.CONDITION = '1'
		OUT.VAR = '1'
	END
	
	RETURN
*-------------------------------------------------------------------------------------------
	END