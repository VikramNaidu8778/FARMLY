* @ValidationCode : MToyODI4NDM2NTc6SVNPLTg4NTktMToxNDc1NjUxNTkwNzA0OmEzODk2MDotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE2MDguMA==
* @ValidationInfo : Timestamp         : 05 Oct 2016 15:13:10
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : a38960
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
SUBROUTINE JBWW.R.FT.RETROPAYUPDSTATUS.INP
*-----------------------------------------------------------------------------
* Attached as Input routine to the version JBWW.H.FT.RETROPAYMENT,JBWW.V.FT.PAYUPDSTS.INP. 
* This version is used in Enquiry JBWW.E.FT.RETROPAYMENT.FIN
*  
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date          who             Reference        Descrition of Change
* 
* 05-08-2016    Tony Charles    CALCULO          Validation routine for version JBWW.H.FT.RETROPAYMENT,JBWW.V.FT.PAYUPDSTS.INP. 
*-----------------------------------------------------------------------------
* <region name= Inserts>
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.JBWW.H.FT.RETROPAY
$INSERT I_F.JBWW.H.EB.GENERICPARAMETER
$INSERT I_F.ACCOUNT
$INSERT I_F.ALTERNATE.ACCOUNT
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>

    GOSUB INITIALISE
    GOSUB VALIDATE
    
    RETURN 
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>
INITIALISE:
    
    FN.JBWW.H.GENERIC.PARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.GENERIC.PARAMETER = ''
    CALL OPF(FN.JBWW.H.GENERIC.PARAMETER, F.JBWW.H.GENERIC.PARAMETER)
    
    R.PARAM.RECORD = ''
    PARAM.ER = ''
    PARAM.ID = 'JBWW.D.XX.RETROCESSION'
    CALL EB.READ.PARAMETER(FN.JBWW.H.GENERIC.PARAMETER, '', '', R.PARAM.RECORD, PARAM.ID, F.JBWW.H.GENERIC.PARAMETER, PARAM.ER)
    
    THRESHOLD.AMOUNT = 0
    
    LOCATE 'THRESHOLD.AMT' IN R.PARAM.RECORD<JBWW.GEN.PAR.FIELD.NAME,1> SETTING AMT.POS THEN
        THRESHOLD.AMOUNT = R.PARAM.RECORD<JBWW.GEN.PAR.FIELD.VALUE ,AMT.POS,1>
    END
        
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>
VALIDATE:

    PROCESS.STATUS = R.NEW(RTR.PAY.PROCESSING.STATUS)
    
    RETRO.AMOUNT = R.NEW(RTR.PAY.AMOUNT)
    
    RETRO.CCY = R.NEW(RTR.PAY.CCY)
    
    OLD.PROCESS.STATUS = R.OLD(RTR.PAY.PROCESSING.STATUS)
    NEW.PROCESS.STATUS = R.NEW(RTR.PAY.PROCESSING.STATUS)
    
    IF OLD.PROCESS.STATUS AND OLD.PROCESS.STATUS NE NEW.PROCESS.STATUS THEN
        AF = RTR.PAY.PROCESSING.STATUS
        ETEXT = 'FT-JBWW.D.FT.STATUSCANNOTCHG.CHECK'  ;* Error msg STATUS Cannnot change once updated
        CALL STORE.END.ERROR
    END
    
    IF R.NEW(RTR.PAY.BEN.NAME) EQ '' AND R.NEW(RTR.PAY.PAYMENT.TYPE) EQ '01' THEN  ;* For External paymment, BEN.NAME is mandatory as this will be updated in BENEFICIARY.CUSTOMER field in Payment
        AF = RTR.PAY.BEN.NAME
        ETEXT = 'FT-JBWW.D.FT.BENNAME.MANDATORY'  ;* Error msg 'Mandatory for External Payment'
        CALL STORE.END.ERROR
    END
    
    BEGIN CASE 
    CASE PROCESS.STATUS = 'CONFIRM'
        GOSUB VALIDATE.CONFIRM
    CASE PROCESS.STATUS = 'AMEND'
        GOSUB VALIDATE.AMEND
    CASE PROCESS.STATUS = 'CANCEL'
        GOSUB VALIDATE.CANCEL 
    END CASE
    

    
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>
VALIDATE.CONFIRM:

    DEBIT.ACCT = R.NEW(RTR.PAY.PARTNER.ACCOUNT)
    DB.ACCT.REC = ''
    IF INDEX(DEBIT.ACCT,'-',1) THEN  ;* Alternate Account is specified then get the Actual account
        F.ALTERNATE.ACCOUNT = ''
        CALL F.READ('F.ALTERNATE.ACCOUNT', DEBIT.ACCT, R.ALT.ACCT, F.ALTERNATE.ACCOUNT, ALT.ERR)
        IF R.ALT.ACCT<AAC.GLOBUS.ACCT.NUMBER> THEN 
            DEBIT.ACCT = R.ALT.ACCT<AAC.GLOBUS.ACCT.NUMBER>
        END
    END
    CALL F.READ ('F.ACCOUNT', DEBIT.ACCT, DB.ACCT.REC, F.ACCOUNT, DB.ER)
    DB.CCY = DB.ACCT.REC<AC.CURRENCY>
    
* If the Payment Amount is above the Threshold, then BO REMARKS is mandatory
* If Payment currency is not CHF(cross currency payment), then PROCESSING.STATUS cannot be set to CONFIRM
    IF RETRO.AMOUNT GT THRESHOLD.AMOUNT AND R.NEW(RTR.PAY.CCY) NE 'CHF' THEN
        ADD.BO.REMARKS = R.NEW(RTR.PAY.ADD.BO.REMARKS)
        IF ADD.BO.REMARKS EQ '' THEN
            AF = RTR.PAY.ADD.BO.REMARKS
            ETEXT = 'FT-JBWW.D.FT.RETRONOINPUTFIELD.CHECK'  ;* Error msg NOINPUT field for CONFIRM status
            CALL STORE.END.ERROR 
        END
        
        CR.CCY = R.NEW(RTR.PAY.CCY)
        IF CR.CCY NE LCCY OR DB.CCY NE LCCY THEN ;* Check cross currency payment
            AF = RTR.PAY.PROCESSING.STATUS
            ETEXT = 'FT-JBWW.D.FT.CROSSCCYPAYINEXCESS.CHK'  ;* Error msg 'Invalid Status. Cross currency payment in-excess of CHF100000'
            CALL STORE.END.ERROR    
        END
    END

* If the PROCESSING.STATUS is CONFIRM, then BO.REMARKS should be null
    IF R.NEW(RTR.PAY.ADD.BO.REMARKS) NE '' THEN
        AF = RTR.PAY.PROCESSING.STATUS
        ETEXT = 'FT-JBWW.D.FT.RETROPROCESSSTATUS.CHECK'  ;* Error msg Status should be AMEND if BO Remarks specified
        CALL STORE.END.ERROR 
    END
        
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>
VALIDATE.AMEND:

* If PROCESSING.STATUS is AMEND, then ADD.BO.REMARKS is mandatory
    ADD.BO.REMARKS = R.NEW(RTR.PAY.ADD.BO.REMARKS)
    IF ADD.BO.REMARKS = '' THEN
        AF = RTR.PAY.ADD.BO.REMARKS
        ETEXT = 'FT-JBWW.D.FT.RETROAMENDMANDATORYRATE.CHK'  ;* Error msg Input FX Rate Mandatory for AMEND status
        CALL STORE.END.ERROR    
    END
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
* <region name= Inserts>
VALIDATE.CANCEL:

* If PROCESSING.STATUS is CANCEL, then ADD.BO.REMARKS is mandatory 
    ADD.BO.REMARKS = R.NEW(RTR.PAY.ADD.BO.REMARKS)
    IF ADD.BO.REMARKS = '' THEN
        AF = RTR.PAY.ADD.BO.REMARKS
        ETEXT = 'FT-JBWW.D.FT.RETROCANCELMANDATORY.CHK'  ;* Error msg Input Mandatory for CANCEL status
        CALL STORE.END.ERROR    
    END

* If PROCESSING.STATUS is set to CANCEL by the user, then update the TECH.STATUS also as CANCEL
    TECH.STATUS = R.NEW(RTR.PAY.TECH.STATUS)
    IF TECH.STATUS = 'VALIDATED' THEN
        R.NEW(RTR.PAY.TECH.STATUS) = 'CANCEL'
    END
    
    RETURN
* </region>
*-----------------------------------------------------------------------------
END
