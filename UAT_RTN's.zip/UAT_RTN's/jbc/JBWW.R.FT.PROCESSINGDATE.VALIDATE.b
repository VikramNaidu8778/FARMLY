* @ValidationCode : MTotMTI0NzA5NzUxMzpJU08tODg1OS0xOjE0ODgyODA0MTI5NzY6NjE4NTM5Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC40
* @ValidationInfo : Timestamp         : 28 Feb 2017 16:43:32
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 618539
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.4
*-------------------------------------------------------------------------
* <Rating>-40</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PROCESSINGDATE.VALIDATE
*-------------------------------------------------------------------------
*
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date          Developer             Reference               Description
*-------------------------------------------------------------------------
* 08/07/2016     Jothi		          FIN_GSD034           Initial Version
*
* 28/02/2017     Vidya A         JB2A-27882/27769/27467    The existing Input routine "JBWW.R.FT.PROCESSINGDATE.INPUT" 
*                                                          is changed as validation routine.
* 17/03/2017	 Dinesh			 JB2A-27467                COMI value checked for NULL to avoid fatal outs
* 12/10/2017     Rajesh Kopparapu     CR-338               Funds Transfer - Processing Date Default 
*-------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.FUNDS.TRANSFER
*-------------------------------------------------------------------------
    IF MESSAGE EQ 'VAL' THEN
       GOSUB INIT
       GOSUB PROCESS
    END	

    RETURN
*--------------------------------------------------------------------------
INIT:
*****
    Y.CR.ACCT = ''  ; Y.DB.CCY = ''
	Y.CR.CCY = ''   ; Y.REGION = ''
    Y.CR.VAL.DATE = '' ; Y.DATE1 = ''
    Y.DAY.TYPE = ''  ; 
	
    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)

    RETURN
*--------------------------------------------------------------------------
PROCESS:
********
*    Y.DR.VALUE.DATE = COMI
*	IF Y.DR.VALUE.DATE THEN 
*		Y.TODAY = TODAY
*		CALL CDT('',Y.TODAY,'+2W')
*		TWO.W.DAYS.ADDED = Y.TODAY
*
*		Y.DR.VALUE.DATE.MINUS = Y.DR.VALUE.DATE
*		CALL CDT('',Y.DR.VALUE.DATE.MINUS,'-2W')
*		TWO.W.DAYS.SUBTRACT = Y.DR.VALUE.DATE.MINUS
*
*		IF Y.DR.VALUE.DATE GT TWO.W.DAYS.ADDED THEN
*			Y.PROCESSING.DATE = TWO.W.DAYS.SUBTRACT
*		END ELSE
*			Y.PROCESSING.DATE = TODAY
*		END
*
*		R.NEW(FT.PROCESSING.DATE) = Y.PROCESSING.DATE
*	END
    
	
    Y.CR.ACCT = R.NEW(FT.CREDIT.ACCT.NO)
    Y.DB.CCY  = R.NEW(FT.DEBIT.CURRENCY)
	Y.CR.CCY  = R.NEW(FT.CREDIT.CURRENCY)
	
	IF Y.CR.ACCT[1,2] EQ 'PL' AND Y.CR.ACCT[3,7] MATCHES '0N' THEN
        Y.REGION = Y.DB.CCY[1,2] : '00'
    END ELSE
        Y.REGION = Y.CR.CCY[1,2] : '00'
    END
	
	Y.CR.VAL.DT = R.NEW(FT.DEBIT.VALUE.DATE)
	IF Y.CR.VAL.DT NE '' THEN
	   CALL CDT(Y.REGION,Y.CR.VAL.DT,'-2W')
		Y.DATE1 = Y.CR.VAL.DT
		CALL AWD('',Y.DATE1,Y.DAY.TYPE)
	   IF Y.DAY.TYPE NE 'W' THEN
	     CALL CDT('',Y.DATE1,'-1W')
       END
    END
	IF Y.DATE1 GT TODAY THEN
        R.NEW(FT.PROCESSING.DATE) = Y.DATE1
    END ELSE
       R.NEW(FT.PROCESSING.DATE) = TODAY
    END
 
    RETURN
*--------------------------------------------------------------------------
    END
