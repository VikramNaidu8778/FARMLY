* @ValidationCode : MTotMjA4NjA2ODY2OTpJU08tODg1OS0xOjE0OTU0NTY5NDU3MDY6NDgwMzI2Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTYwOC4w
* @ValidationInfo : Timestamp         : 22 May 2017 18:12:25
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 480326
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201608.0
    SUBROUTINE JBWW.R.FT.ALLHIST.BLD(ENQ.DATA)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* Date               Name                         Reference                                   Description
* 22-05-2017        Batturu Sivanandini        Non_Functional_Requirements_Enquiry_Changes_4  selection of FUNDS.TRANSFER history records
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* This a build routine attached to enquiry JBWW.E.FT.FTALLHIST.VIEW
* to filter the records  based on selection criteria.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ENQUIRY

*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB GET.ORACLE.FILE
    IF PROCESS.GOAHEAD THEN
        GOSUB PROCESS
    END

    RETURN

INIT:
*****

    PROCESS.GOAHEAD = 1
    Y.ENQ.FILE = R.ENQ<ENQ.FILE.NAME>

    RETURN

GET.ORACLE.FILE:
****************

    Y.T24.FILE = Y.ENQ.FILE
    IF Y.T24.FILE THEN
        Y.ORACLE.FILE = '' ; Y.ERR = ''
        CALL JBWW.R.XX.GETORACLE.FILENAME(Y.T24.FILE,Y.ORACLE.FILE,Y.ERR)
        IF Y.ORACLE.FILE THEN
            Y.ORA.FT.HIS = Y.ORACLE.FILE
        END ELSE
            PROCESS.GOAHEAD = 0
            ENQ.ERROR = Y.ERR
        END
    END

    RETURN

PROCESS:
********
    GOSUB FORM.SQL.QUERY
    GOSUB EXECUTE.SQL.QUERY

    RETURN

FORM.SQL.QUERY:
***************

    ! Form an SQL query as below.
    ! SELECT RECID FROM V_FSGD_FUNDS_TRANSFER#HIS

    Y.SQL.QUERY = '' ; Y.JOIN = ''
    Y.SQL.QUERY = "SELECT RECID FROM V_":Y.ORA.FT.HIS

    Y.ENQ.DATA = ENQ.DATA
    IF Y.ENQ.FILE AND Y.ENQ.DATA<2> AND Y.SQL.QUERY THEN
        CALL JBWW.R.XX.APPENDSQLFILTER.QUERY(Y.ENQ.FILE,Y.ENQ.DATA,Y.JOIN,Y.SQL.QUERY)
    END

    RETURN

EXECUTE.SQL.QUERY:
******************

    Y.SQL.RESULT = '' ; Y.DELIM = CHAR(251)
    Y.SQL.RESULT = EXECSQLQUERY(1,Y.SQL.QUERY)

    IF Y.SQL.RESULT THEN
        CONVERT Y.DELIM TO ' ' IN Y.SQL.RESULT
        Y.ENQ.NAME = ENQ.DATA<1>
        ENQ.DATA = ''
        ENQ.DATA<1> = Y.ENQ.NAME
        ENQ.DATA<2,1> = "@ID"
        ENQ.DATA<3,1> = "EQ"
        ENQ.DATA<4,1> = Y.SQL.RESULT
    END ELSE
        ENQ.ERROR = "NO RECORDS FOUND"
    END

    RETURN
    END

