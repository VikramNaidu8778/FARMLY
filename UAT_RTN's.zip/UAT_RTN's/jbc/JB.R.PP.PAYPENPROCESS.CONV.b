SUBROUTINE JB.R.PP.PAYPENPROCESS.CONV
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer           Reference           Description
* 14/05/2025        Ayush Kumar         CBPAY-1827          This new conversion routine for the enquiry JB.E.PP.PENPACS008.AUTH
*                                                           and JB.E.PP.INCPACS008.REPAIR to show all error and warning messages
*                                                           except the error code defined under generic parameter JB.D.PP.ERRCODE.EXCEPTION
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.POR.AUDIT.TRAIL
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    GOSUB INITIALISE
    GOSUB PROCESS

RETURN

*----------
INITIALISE:
*----------
    
    FN.POR.AUDIT.TRAIL = 'F.POR.AUDIT.TRAIL'
    F.POR.AUDIT.TRAIL = ''
    CALL OPF(FN.POR.AUDIT.TRAIL,F.POR.AUDIT.TRAIL)
    
    FN.PP.ORDER.ENTRY.NAU = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY.NAU = ''
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,F.PP.ORDER.ENTRY.NAU)

    FN.JBWW.H.EB.GENERICPARAMETER = "F.JBWW.H.EB.GENERICPARAMETER"
    F.JBWW.H.EB.GENERICPARAMETER = ""
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)
    
    Y.GPM.ID = "JB.D.PP.ERRCODE.EXCEPTION"
    R.GPM.REC = ""
    Y.GPM.ERR = ""
    Y.FIELD.NAME = ""
    Y.FIELD.VALUE = ""
    Y.ERR.CODE.POS = ""
    Y.ERROR.CODE = ""
    Y.ERROR.CODE.POS = ""
    Y.PP.ID = ID
    R.PP.REC = ""
    Y.PP.ERR = ""
    Y.POR.AUDIT.TRAIL.ID = ""
    R.POR.AUDIT.TRAIL.REC = ''
    Y.POR.AUDIT.TRAIL.ERR = ''
    Y.ERR.CODE.LIST = ''
    Y.ADDL.INFO.LIST = ''
    Y.ERR.CODE = ''
    Y.ADDL.INFO = ''
    Y.ERR.CODE.CNT = ''
    Y.CNT = '1'
    
RETURN

*-------
PROCESS:
*-------
    
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.GPM.ID,R.GPM.REC,F.JBWW.H.EB.GENERICPARAMETER,Y.GPM.ERR)
    IF R.GPM.REC THEN
        Y.FIELD.NAME = R.GPM.REC<JBWW.GEN.PAR.FIELD.NAME>
        Y.FIELD.VALUE = R.GPM.REC<JBWW.GEN.PAR.FIELD.VALUE>
        LOCATE "ERROR.CODE" IN Y.FIELD.NAME<1,1> SETTING Y.ERR.CODE.POS THEN
            Y.ERROR.CODE = Y.FIELD.VALUE<1,Y.ERR.CODE.POS>
        END
    END
    
    CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.PP.ID,R.PP.REC,F.PP.ORDER.ENTRY.NAU,Y.PP.ERR)
    IF R.PP.REC THEN
        Y.POR.AUDIT.TRAIL.ID = R.PP.REC<PP.OEYG.TransactionReferenceNumber>
        CALL F.READ(FN.POR.AUDIT.TRAIL,Y.POR.AUDIT.TRAIL.ID,R.POR.AUDIT.TRAIL.REC,F.POR.AUDIT.TRAIL,Y.POR.AUDIT.TRAIL.ERR)
        IF R.POR.AUDIT.TRAIL.REC THEN
            Y.ERR.CODE.LIST = R.POR.AUDIT.TRAIL.REC<PORAT.ERROR.CODE>
            Y.ADDL.INFO.LIST = R.POR.AUDIT.TRAIL.REC<PORAT.ADDITIONAL.INFORMATION>
            Y.ERR.CODE.CNT = DCOUNT(Y.ERR.CODE.LIST,@VM)
            IF Y.ERR.CODE.CNT THEN
                GOSUB READ.ERROR.CODE
                CONVERT @FM TO @VM IN Y.O.DATA
                R.RECORD<500> = Y.O.DATA
                VM.COUNT = DCOUNT(Y.O.DATA,@VM)
            END
        END
    END

RETURN

*---------------
READ.ERROR.CODE:
*---------------
    
    LOOP
    WHILE Y.CNT LE Y.ERR.CODE.CNT
        Y.ERR.CODE = Y.ERR.CODE.LIST<1,Y.CNT>
        Y.ADDL.INFO = Y.ADDL.INFO.LIST<1,Y.CNT>
        LOCATE Y.ERR.CODE IN Y.ERROR.CODE<1,1> SETTING Y.ERROR.CODE.POS ELSE
            Y.O.DATA<-1> = Y.ERR.CODE : "**" : Y.ADDL.INFO
        END
        Y.CNT = Y.CNT+1
    REPEAT
    
RETURN

END
