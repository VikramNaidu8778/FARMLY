* @ValidationCode : MjoxNjM5Njg4MTEwOkNwMTI1MjoxNzEyNjYzNjQxNjgwOjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 09 Apr 2024 17:24:01
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 670909
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.

SUBROUTINE JB.DA.R.ENQ.CONV.MASK.RTN
*-----------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*23/05/2024	Resmi R			                CBPAY-394	        Masking the CID fields in the message content field of Outgoing and incoming 
*									        enquiryfor Non-Privileged User
*
*-------------------------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_ENCRYPT.COMMON
    $INSERT I_F.EB.ENC.PARAMETER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
        
    CALL EB.IDENTIFY.USER.PRIVILEGE(IsUserPrivilege)
    
    IF IsUserPrivilege THEN
        RETURN
    END
           
    GOSUB INIT
    GOSUB PROCESS
    
    O.DATA = Y.DATA
    
RETURN

INIT:
****

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER, F.JBWW.H.EB.GENERICPARAMETER)
        
    Y.DATA = O.DATA
    Y.DATA = TRIM(Y.DATA, "", "A")
    
    R.EB.ENC.REC = ENC$R.EB.ENC.PARAM
    Y.ENQ.MASK.CHARS = R.EB.ENC.REC<EB.ENC.ENQ.MSK.CHARS>
    

    Y.OT.FM.POS = '' ; Y.OT.VM.POS = '' ; Y.OT.SM.POS = ''
    Y.CT.FM.POS = '' ; Y.CT.VM.POS = '' ; Y.CT.SM.POS = ''
    
    AC.ERR.MSG = ''
    
    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,"JBWW.CID.DA.PARAM",R.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER,AC.ERR.MSG)
    Y.GP.FLD.NAME = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.NAME>
    
    LOCATE 'ENQUIRY.MASK' IN Y.GP.FLD.NAME<1,1> SETTING FLD.NAME.POS THEN
        Y.GPM.FLD.LIST = R.JBWW.H.EB.GENERICPARAMETER<JBWW.GEN.PAR.FIELD.VALUE,FLD.NAME.POS>
        CHANGE @SM TO @VM IN Y.GPM.FLD.LIST
        CHANGE @VM TO @FM IN Y.GPM.FLD.LIST      
    END
        
    
RETURN
 
PROCESS:
********
  
    Y.FLD.CNT = DCOUNT(Y.GPM.FLD.LIST,@FM)
    
    Y.INIT = '1'
    
    LOOP
    
    WHILE Y.INIT LE Y.FLD.CNT
       
    GOSUB GET.FIELD.VALUES
    
        FIND Y.OPEN.TAG IN Y.DATA SETTING Y.OT.FM.POS,Y.OT.VM.POS,Y.OT.SM.POS THEN

            FIND Y.CLOSE.TAG IN Y.DATA SETTING Y.CT.FM.POS,Y.CT.VM.POS,Y.CT.SM.POS THEN
                CHANGE @VM  TO "#" IN Y.DATA
                Y.DIFF.POS = Y.CT.VM.POS-Y.OT.VM.POS
                Y.VM.VAL = FIELD(Y.DATA, "#",Y.OT.VM.POS,Y.DIFF.POS)
                Y.APPND.CLOSE.TAG = Y.VM.VAL:"#":Y.CLOSE.TAG
                Y.MASK.VAL = Y.OPEN.TAG:Y.ENQ.MASK.CHARS:Y.CLOSE.TAG
                Y.DATA = EREPLACE(Y.DATA,Y.APPND.CLOSE.TAG,Y.MASK.VAL)
                CHANGE "#" TO @VM IN Y.DATA

            END
        
        END
     
        Y.INIT += 1
        
    REPEAT
      
RETURN

GET.FIELD.VALUES:
*****************

    Y.GPM.FLD = Y.GPM.FLD.LIST<Y.INIT>
    Y.OPEN.TAG = FIELD(Y.GPM.FLD, "_", 1)
    Y.CLOSE.TAG = FIELD(Y.GPM.FLD, "_", 2)

RETURN

*-----------------------------------------------------------------------------------------------------------
END



