SUBROUTINE JB.R.PP.IMPOSERATE.INPUT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              Developer           Reference           Description
* 26/03/2025        Ayush Kumar         CBPAY-2266          This input routine is attached to version control of PAYMENT.ORDER
*                                                           to trigger based on versions defined in generic parameter record
*                                                           JB.D.PP.IMPOSE.CHECK to throw error in case user specifies Treasury Rate
*															but impose treasury rate is not checked
* 29/04/2025        Ayush Kumar         CBPAY-2552          If treasury rate and indicative rate are same then do not raise error
*
* 29/04/2025        Prabhu D S          CBPAY_2274          Difference in user given amount and converted amount in accounting entries
* 09/05/2025        Prabhu D S          CBPAY-2274          Client Charges should be raised for Charge Account Currency
* 02/06/2025        Prabhu D S          CBPAY-2911          If user waive either client / bank charge, then it should be considered.
*                                                           i.e value inputted as 0 (zero)
* 05/06/2025        Prabhu D S          CBPAY-2911          Updated the logic in assigning the Charge currency value 
*
*17/06/2025         Prabhu D S          CBPAY-3225          Updated the logic when Charge Bearer field is 'BEN'
*
* 28/06/2025        Prabhu D S          CBPAY-2274          Fixed the logic for charge accounting entries posting in CHF instead of debit acct currency
* 04/07/2025        Prabhu D S          CBPAY-3220          Removing Bank Charges from local field in case of changing OUR to BEN
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    $PACKAGE PI.Contract

    GOSUB INITIALISE
    GOSUB PROCESS
    GOSUB DEFAULT.CHARGES

RETURN

*----------
INITIALISE:
*----------

    FN.JBWW.H.EB.GENERICPARAMETER = 'F.JBWW.H.EB.GENERICPARAMETER'
    F.JBWW.H.EB.GENERICPARAMETER = ''
    CALL OPF(FN.JBWW.H.EB.GENERICPARAMETER,F.JBWW.H.EB.GENERICPARAMETER)

    Y.GPM.ID = 'JB.D.PP.IMPOSE.CHECK'
    R.GPM.REC = ''
    Y.GPM.ERR = ''
    Y.FIELD.NAME = ''
    Y.FIELD.VALUE = ''
    Y.VER.LIST = ''
    Y.VER.POS = ''
    Y.VERSION.POS = ''
    Y.VERSION.NAME = APPLICATION : PGM.VERSION
    Y.TREASURY.RATE = R.NEW(PO.ORDERING.PAYMENT.TREASURY.RATE)
    Y.IMPOSE.RATE = R.NEW(PI.Contract.PaymentOrder.PoImposeTreasuryRate)
    Y.INDICATIVE.RATE = R.NEW(PI.Contract.PaymentOrder.PoIndicativeRate)        ; * CBPAY-2552 - S/E

    LOC.FLD.NAMES = "L.PO.CLNT.CHG":@VM:"L.PO.CORR.BANK"
    CALL MULTI.GET.LOC.REF("PAYMENT.ORDER",LOC.FLD.NAMES,LOC.FLD.POS)
    CLNT.CHG.POS = LOC.FLD.POS<1,1>
    BNK.CHG.POS = LOC.FLD.POS<1,2>
    CLNT.CHG.AMT = 0
    BNK.CHG.AMT = 0

RETURN

*-------
PROCESS:
*-------

    CALL F.READ(FN.JBWW.H.EB.GENERICPARAMETER,Y.GPM.ID,R.GPM.REC,F.JBWW.H.EB.GENERICPARAMETER,Y.GPM.ERR)
    IF R.GPM.REC THEN
        Y.FIELD.NAME = R.GPM.REC<JBWW.GEN.PAR.FIELD.NAME>
        Y.FIELD.VALUE = R.GPM.REC<JBWW.GEN.PAR.FIELD.VALUE>
    END

    LOCATE 'IMPOSE.CHECK' IN Y.FIELD.NAME<1,1> SETTING Y.VER.POS THEN
        Y.VER.LIST = Y.FIELD.VALUE<1,Y.VER.POS>
        CONVERT SM TO VM IN Y.VER.LIST
    END

    LOCATE Y.VERSION.NAME IN Y.VER.LIST<1,1> SETTING Y.VERSION.POS THEN
*IF Y.TREASURY.RATE AND NOT(Y.IMPOSE.RATE) THEN
        IF Y.TREASURY.RATE AND Y.INDICATIVE.RATE AND (Y.TREASURY.RATE NE Y.INDICATIVE.RATE) AND NOT(Y.IMPOSE.RATE) THEN     ; * CBPAY-2552 - S/E
            AF =  PO.ORDERING.PAYMENT.TREASURY.RATE
            ETEXT = 'PP-JB.D.PP.TREASURYRATE.NOTIMPOSED'
            CALL STORE.END.ERROR
        END
    END

RETURN

*---------------
DEFAULT.CHARGES:
*---------------

 IF R.NEW(PO.CHARGE.BEARER) EQ "BEN" THEN
    R.NEW(PO.LOCAL.REF)<1,BNK.CHG.POS> = ""
    RETURN
 END

 IF R.NEW(PO.ORDER.INITIATION.TYPE) MATCHES "STO":@VM:"STOMXCHATS" THEN RETURN

  IF V$FUNCTION EQ 'I' THEN

    CLNT.CHG.AMT = R.NEW(PO.LOCAL.REF)<1,CLNT.CHG.POS>
    BNK.CHG.AMT = R.NEW(PO.LOCAL.REF)<1,BNK.CHG.POS>
    PO.CHARGE.TYPES = R.NEW(PO.CHARGE.TYPE)
* To raise accounting entries in Charge account currency, default Client Charge currency as charge account currency
* and Charge amount as Charge Account currency amount.
   LOCATE "FTOTPAY0000" IN PO.CHARGE.TYPES<1,1> SETTING CLNT.CHG.TYPE.POS THEN
     R.NEW(PO.CHARGE.CURRENCY)<1,CLNT.CHG.TYPE.POS> = R.NEW(PO.CHARGE.ACCOUNT.CCY)
     IF CLNT.CHG.AMT NE '' THEN
       R.NEW(PO.CHARGE.AC.CCY.AMOUNT)<1,CLNT.CHG.TYPE.POS> = CLNT.CHG.AMT
       R.NEW(PO.CHARGE.AMOUNT)<1,CLNT.CHG.TYPE.POS> = CLNT.CHG.AMT
     END ELSE
        R.NEW(PO.CHARGE.AMOUNT)<1,CLNT.CHG.TYPE.POS> = R.NEW(PO.CHARGE.AC.CCY.AMOUNT)<1,CLNT.CHG.TYPE.POS>
     END
   END

   LOCATE "OUTBOUNDOURCHARGE" IN PO.CHARGE.TYPES<1,1> SETTING BNK.CHG.TYPE.POS THEN
     R.NEW(PO.CHARGE.CURRENCY)<1,BNK.CHG.TYPE.POS> = R.NEW(PO.CHARGE.ACCOUNT.CCY)
     IF BNK.CHG.AMT NE '' THEN
       R.NEW(PO.CHARGE.AC.CCY.AMOUNT)<1,BNK.CHG.TYPE.POS> = BNK.CHG.AMT
       R.NEW(PO.CHARGE.AMOUNT)<1,BNK.CHG.TYPE.POS> = BNK.CHG.AMT
     END ELSE
       R.NEW(PO.CHARGE.AMOUNT)<1,BNK.CHG.TYPE.POS> = R.NEW(PO.CHARGE.AC.CCY.AMOUNT)<1,BNK.CHG.TYPE.POS>
     END
   END


   IF (R.NEW(PO.CHARGE.ACCOUNT) AND SUM(R.NEW(PO.CHARGE.AMOUNT)) GT 0) THEN 
     BEGIN CASE
        CASE R.NEW(PO.CHARGE.BEARER) MATCHES "OUR":VM:"SHA"
           R.NEW(PO.DEBIT.CHARGE.IMPOSED) = "ChargeWithAccount"
        
        CASE R.NEW(PO.CHARGE.BEARER) EQ "BEN"
           R.NEW(PO.DEBIT.CHARGE.IMPOSED) = ""
     
     END CASE
   END
  END

RETURN
END

