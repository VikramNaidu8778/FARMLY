* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 801574
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.PROCESSINGDATE.VALIDATE
*----------------------------------------------------------------------------------------------------------------------------------------------------
* This routine is copy of the existing FT Version Routine JBWW.R.FT.PROCESSINGDATE.VALIDATE and incorporated with TPH Payment order application Logic.
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                                 Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* 12/04/2024     Hariharan T                CBPAY-209,210,211,212,213                       Validation routine for Date Manipulation in Payment order versions
*                                                                                    PO,JB.V.PP.FEECHRG.INP,PO,JB.V.PP.REFUNDS.INP, PO,JB.V.PP.GSTREFUNDS.INP, PO,JB.V.PP.GSTFEECHG.INP & PO,JB.V.PP.INTERNAL.INP
*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.PAYMENT.ORDER
	$INSERT  I_F.PP.ORDER.ENTRY
*-------------------------------------------------------------------------
    IF MESSAGE EQ 'VAL' THEN
        GOSUB INIT
			BEGIN CASE
	  CASE ID.NEW[1,2] EQ 'PI' 
        GOSUB PROCESS.PO
		CASE ID.NEW[1,2] EQ 'OE'
		GOSUB PROCESS.OE
	  END CASE
    END
 
RETURN
*--------------------------------------------------------------------------
INIT:
*****
    Y.CR.ACCT = ''  ; Y.DB.CCY = ''
    Y.CR.CCY = ''   ; Y.REGION = ''
    Y.CR.VAL.DATE = '' ; Y.DATE1 = ''
    Y.DAY.TYPE = ''  ;

    
    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
	
	FN.PP.ORDER.ENTRY = 'F.PP.ORDER.ENTRY'
    F.PP.ORDER.ENTRY = ''
    CALL OPF(FN.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY)
 
RETURN
*--------------------------------------------------------------------------
PROCESS.PO:
***********
    
    Y.CR.ACCT = R.NEW(PO.CREDIT.ACCOUNT)
    Y.DB.CCY  = R.NEW(PO.DEBIT.CCY)
    Y.CR.CCY  = R.NEW(PO.PAYMENT.CURRENCY)
    Y.PO.CREDIT.PL = '' ;  Y.PO.CREDIT.PL = R.NEW(PO.CREDIT.PL)
*For Book Payments, If Credit account is Internal or PL then Debit Currency wull be taken for calculation.
*For Swift payments, Always Credit currency is taken for Holiday Calcualtion.
 
    IF Y.PO.CREDIT.PL OR ISALPHA(Y.CR.ACCT[1,3]) THEN   ; *For Book Payments.
        Y.REGION = Y.DB.CCY[1,2] : '00'
    END ELSE
        Y.REGION = Y.CR.CCY[1,2] : '00'
    END
    
    Y.CR.VAL.DT = R.NEW(PO.CREDIT.VALUE.DATE)
 
    GOSUB EXTRACT.PROC.DATE

    IF Y.DATE1 GT TODAY THEN
        R.NEW(PO.PAYMENT.EXECUTION.DATE) = Y.DATE1
    END ELSE
        R.NEW(PO.PAYMENT.EXECUTION.DATE) = TODAY
    END
 
    CALL JB.R.PP.VALUEDATE.VALIDATE
RETURN

*--------------------------------------------------------------------------
PROCESS.OE:
***********
 
*   Y.CR.ACCT = R.NEW(PP.OEYG.CreditAccountNumber)
*  Y.DB.CCY  = R.NEW(PP.OEYG.DebitAccountCurrency)
    Y.CR.CCY  = R.NEW(PP.OEYG.CreditAccountCurrency)
*   Y.PO.CREDIT.PL = '' ;  Y.PO.CREDIT.PL = R.NEW(PO.CREDIT.PL)
*For Book Payments, If Credit account is Internal or PL then Debit Currency wull be taken for calculation.
*For Swift payments, Always Credit currency is taken for Holiday Calcualtion.
 
*   IF ISALPHA(Y.CR.ACCT[1,3]) THEN   ; *For Book Payments.
*       Y.REGION = Y.DB.CCY[1,2] : '00'
*  END ELSE
        Y.REGION = Y.CR.CCY[1,2] : '00'
*  END
    
    Y.CR.VAL.DT = R.NEW(PP.OEYG.CreditValueDate)
    
	GOSUB EXTRACT.PROC.DATE
	
    IF Y.DATE1 GT TODAY THEN
        R.NEW(PP.OEYG.ProcessingDate) = Y.DATE1
    END ELSE
        R.NEW(PP.OEYG.ProcessingDate) = TODAY
    END
 
RETURN

*--------------------------------------------------------------------------
EXTRACT.PROC.DATE:
******************

    IF Y.CR.VAL.DT NE '' THEN
        CALL CDT(Y.REGION,Y.CR.VAL.DT,'-2W')
        Y.DATE1 = Y.CR.VAL.DT
        CALL AWD('',Y.DATE1,Y.DAY.TYPE)
        IF Y.DAY.TYPE NE 'W' THEN
            CALL CDT('',Y.DATE1,'-1W')
        END
    END

RETURN

*--------------------------------------------------------------------------
END

