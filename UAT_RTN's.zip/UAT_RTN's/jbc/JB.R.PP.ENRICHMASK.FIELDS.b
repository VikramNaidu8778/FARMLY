* @ValidationCode : MjoxNjM5Njg4MTEwOkNwMTI1MjoxNzEyNjYzNjQxNjgwOjY3MDkwOTotMTotMTowOjA6ZmFsc2U6Ti9BOlIyM19BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 20 May 2024 17:24:01
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 677171
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R23_AMR.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2021. All rights reserved.
SUBROUTINE JB.R.PP.ENRICHMASK.FIELDS(USER.ACCESS,ENRICHMENT.FIELDS)
*-----------------------------------------------------------------------------------------------
*Masking the Enrichment details for Non-Privileged User in the TPH Applications
*-----------------------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                             Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*06/09/2024	Resmi R			              CBPAY-425	      	      Initial Draft							                     
*									 
*-------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENCRYPT.COMMON
    $INSERT I_GTS.COMMON
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER
    
    GOSUB INIT
   
    CALL EB.IDENTIFY.USER.PRIVILEGE(IS.USER.PRIVILEGE)
    
    IF IS.USER.PRIVILEGE THEN
        ENRICHMENT.FIELDS = FIELD(ENRICHMENT.FIELDS,@TM,1,1)   
	RETURN        
    END

    GOSUB PROCESS

RETURN

INIT:
****

    Y.APP.FLD.NAME = FIELD(ENRICHMENT.FIELDS,@TM,4,1)
       
    USER.ACCESS = 1
    Y.GP.FLD.NAMES = '' 
    Y.GPM.FLD.VALUES = ''


RETURN

PROCESS:
********
   
   CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.CIDMASK.PARAM",APPLICATION,Y.GPM.FLD.VALUES)

	CHANGE @FM TO @VM IN Y.GPM.FLD.VALUES

        IF Y.APP.FLD.NAME MATCHES Y.GPM.FLD.VALUES THEN
            USER.ACCESS = ''                        
        END ELSE
            USER.ACCESS = '1'
            ENRICHMENT.FIELDS = FIELD(ENRICHMENT.FIELDS,@TM,1,1)          
        END

RETURN

*----------------------------------------------------------------------------------
END


