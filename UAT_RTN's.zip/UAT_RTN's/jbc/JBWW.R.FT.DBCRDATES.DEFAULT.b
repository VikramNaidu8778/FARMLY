*--------------------------------------------------------------------------------------------------
	SUBROUTINE JBWW.R.FT.DBCRDATES.DEFAULT
*--------------------------------------------------------------------------------------------------
* Description: This Auto New Content routine attached to FUNDS.TRANSFER,JBWW.V.SC.EAMTRF.INP to default Debit & Credit Value Dates
*---------------------------------------------------------------------------------------------------
* Modification History :
*
*---------------------------------------------------------------------------------------------------
* Date       	   Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------
* 10-JUL-2018	   Rajagopalan R       JB2A-DAY15-2976	    		Defaulting Debit & Credit Value Dates field
*---------------------------------------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.HOLIDAY
	$INSERT I_F.REGION
	$INSERT I_F.CURRENCY
	$INSERT I_F.FUNDS.TRANSFER

	GOSUB INIT
	GOSUB PROCESS
		
	RETURN
	
INIT:
*****

    FN.FUNDS.TRANSFER = 'F.FUNDS.TRANSFER'
    F.FUNDS.TRANSFER = ''
    CALL OPF(FN.FUNDS.TRANSFER,F.FUNDS.TRANSFER)
	
	RETURN

PROCESS:
********	

    Y.TODAY = TODAY
	CALL CDT('',Y.TODAY,'+2W')
	Y.DBCR.DATE = Y.TODAY

	R.NEW(FT.DEBIT.VALUE.DATE) = Y.DBCR.DATE
	R.NEW(FT.CREDIT.VALUE.DATE) = Y.DBCR.DATE
	
    RETURN

END

