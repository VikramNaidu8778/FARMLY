SUBROUTINE JB.R.PP.PAYTRANSINAUVIEW.NOF(OUT.ARRAY)
*---------------------------------------------------------------------------------------------------
* This is a Nofile enquiry to display authorised Payments Transactions(both Payment Order and
* Order Entry)
*---------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------
* Date            Developer                    Reference               Description
* 09/10/2024      Amala P                      CBPAY-1029              Initial Draft
*---------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.USER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.PAYMENT.ORDER
    $USING EB.DataAccess
    $INSERT I_F.COMPANY

	LOCATE "TransNumber" IN D.FIELDS<1> SETTING F.POS THEN
		Y.TransNumber = D.RANGE.AND.VALUE<F.POS>
        GOSUB OPEN.FILES
        GOSUB PROCESS
	END
RETURN

OPEN.FILES:
***********

    FN.PAYMENT.ORDER.NAU = 'F.PAYMENT.ORDER$NAU'
    F.PAYMENT.ORDER.NAU = ''
    CALL OPF(FN.PAYMENT.ORDER.NAU,F.PAYMENT.ORDER.NAU)

    FN.PP.ORDER.ENTRY.NAU = 'F.PP.ORDER.ENTRY$NAU'
    F.PP.ORDER.ENTRY.NAU = ''
    CALL OPF(FN.PP.ORDER.ENTRY.NAU,F.PP.ORDER.ENTRY.NAU)
	
	LOC.REF.FLD = 'L.PP.DEF.INW.IT'
    LOC.POS = ''
    
    CALL GET.LOC.REF('PP.ORDER.ENTRY',LOC.REF.FLD,LOC.POS)

    Y.PP.COMPANY = '' ; Y.PP.FT.NO = '' ; Y.PP.CR.AC.NO = ''
	Y.PP.TXN.CCY = '' ; Y.PP.TXN.AMT = '' ; Y.PP.DR.AC.NO = ''
	
RETURN

PROCESS:
********

    IF Y.TransNumber[1,2] EQ 'PI' THEN
        R.PAYMENT.ORDER = '' ; PO.ERR = ''
        CALL F.READ(FN.PAYMENT.ORDER.NAU,Y.TransNumber,R.PAYMENT.ORDER,F.PAYMENT.ORDER.NAU,PO.ERR)
        IF R.PAYMENT.ORDER THEN
            Y.PP.COMPANY = ID.COMPANY
            Y.PP.TXN.AMT = R.PAYMENT.ORDER<PO.PAYMENT.AMOUNT>
            Y.PP.TXN.CCY = R.PAYMENT.ORDER<PO.PAYMENT.CURRENCY>
            Y.PP.DR.AC.NO = R.PAYMENT.ORDER<PO.DEBIT.ACCOUNT>
            Y.PP.CR.AC.NO = R.PAYMENT.ORDER<PO.CREDIT.ACCOUNT>
            Y.PP.DATE = R.PAYMENT.ORDER<PO.PAYMENT.EXECUTION.DATE>
            Y.PP.TYPE = R.PAYMENT.ORDER<PO.PAYMENT.ORDER.PRODUCT>
            Y.APPLICATION = "PAYMENT.ORDER"
			Y.PP.DB.PL = R.PAYMENT.ORDER<PO.DEBIT.PL>
            Y.PP.CR.PL = R.PAYMENT.ORDER<PO.CREDIT.PL>

            OUT.ARRAY<-1> = Y.PP.COMPANY:"*":Y.TransNumber:"*":Y.PP.TXN.CCY:"*":Y.PP.TXN.AMT:"*":Y.PP.DR.AC.NO:"*":Y.PP.DB.PL:"*":Y.PP.CR.AC.NO:"*":Y.PP.CR.PL:"*":Y.PP.DATE:"*":Y.PP.TYPE:"*":Y.APPLICATION
        END
    END ELSE
        IF Y.TransNumber[1,2] EQ 'OE' THEN
            R.PP.ORDER.ENTRY = '' ; OE.ERR = ''
            CALL F.READ(FN.PP.ORDER.ENTRY.NAU,Y.TransNumber,R.PP.ORDER.ENTRY,F.PP.ORDER.ENTRY.NAU,OE.ERR)
            IF R.PP.ORDER.ENTRY THEN
                Y.PP.COMPANY = ID.COMPANY
                Y.PP.TXN.AMT = R.PP.ORDER.ENTRY<PP.OEYG.TransactionAmount>
                Y.PP.TXN.CCY = R.PP.ORDER.ENTRY<PP.OEYG.TransactionCurrency>
                Y.PP.DR.AC.NO = R.PP.ORDER.ENTRY<PP.OEYG.DebitAccountNumber>
                Y.PP.CR.AC.NO = R.PP.ORDER.ENTRY<PP.OEYG.CreditAccountNumber>
                Y.PP.DATE = R.PP.ORDER.ENTRY<PP.OEYG.ProcessingDate>
                Y.PP.TYPE = R.PP.ORDER.ENTRY<PP.OEYG.LOCAL.REF,LOC.POS>
                Y.APPLICATION = "PP.ORDER.ENTRY"

                OUT.ARRAY<-1> = Y.PP.COMPANY:"*":Y.TransNumber:"*":Y.PP.TXN.CCY:"*":Y.PP.TXN.AMT:"*":Y.PP.DR.AC.NO:"*":Y.PP.DB.PL:"*":Y.PP.CR.AC.NO:"*":Y.PP.CR.PL:"*":Y.PP.DATE:"*":Y.PP.TYPE:"*":Y.APPLICATION
            END
        END
    END

RETURN

END


    
