* @ValidationCode : MTotMTE0NzQ5MjI5NzpVVEYtODoxNTI4ODEyNTg3OTU2OjIzMzE2MzotMTotMTowOjA6ZmFsc2U6Ti9B
* @ValidationInfo : Timestamp         : 18 April 2024 19:39:47
* @ValidationInfo : Encoding          : UTF-8
* @ValidationInfo : User Name         : 233163
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
SUBROUTINE JB.R.PP.OERLCCRACC.INPUT
*---------------------------------------------------------------------------------------------------------------------------
*This is Field Validation routine to update the Credit Account Number as Internal Suspense account
* to skip the Soft Block check for Outgoing pacs.004 for unprocessed incoming pacs.008.
* Attached as Validation Routine in the following Versions.
* PP.ORDER.ENTRY,JB.V.PP.REPCTRISO.STP , PP.ORDER.ENTRY,JB.V.PP.REPCTR.ISO
*---------------------------------------------------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------------------
* Date            Developer                    Reference                            Description
*---------------------------------------------------------------------------------------------------------------------------
* 15/01/2025      Amala P                      CBPAY-1275                           Initial Draft
*
*---------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.PP.ORDER.ENTRY
    $INSERT I_F.JBWW.H.EB.GENERICPARAMETER

    IF COMI EQ 'Return' THEN
        GOSUB INIT
        GOSUB PROCESS
    END

RETURN

*****
INIT:
*****

    Y.FIELD.NAME = "INSOURCE.RLC":@FM:"SUSP.ACCT":@FM:"INMSG.TYPE"
    Y.FIELD.VALUE = '' ; Y.RLC.SOURCE = '' ; Y.SUSP.ACCT = ''
    Y.INMSG.TYPE = ''
    CALL JBWW.R.EB.GETGENPARM.VAL("JB.D.PP.TPH.CONFIG",Y.FIELD.NAME,Y.FIELD.VALUE)

    Y.RLC.SOURCE = Y.FIELD.VALUE<1>
    Y.SUSP.ACCT = Y.FIELD.VALUE<2>
    Y.INMSG.TYPE = Y.FIELD.VALUE<3>

    CHANGE ',' TO @VM IN Y.RLC.SOURCE
    CHANGE @FM TO @VM IN Y.RLC.SOURCE

    CHANGE ',' TO @VM IN Y.SUSP.ACCT

    CHANGE ',' TO @VM IN Y.INMSG.TYPE
    CHANGE @FM TO @VM IN Y.INMSG.TYPE
    
    Y.OE.STATUS = '' ; Y.OE.SOURCE = '' ; Y.OE.DIRECTION = ''
    Y.OE.MSGTYPE = '' ; Y.OE.RETPAY = ''

RETURN

********
PROCESS:
********

    Y.OE.STATUS = R.NEW(PP.OEYG.Status)
    Y.OE.SOURCE = R.NEW(PP.OEYG.Source)
    Y.OE.DIRECTION = R.NEW(PP.OEYG.Direction)
    Y.OE.MSGTYPE = R.NEW(PP.OEYG.IncomingMessageType)
    Y.OE.RETPAY = R.NEW(PP.OEYG.ReturnPayment)

    IF (Y.OE.STATUS EQ '235') AND (Y.OE.DIRECTION EQ 'I') THEN
        IF (Y.OE.SOURCE MATCHES Y.RLC.SOURCE) AND (Y.OE.MSGTYPE MATCHES Y.INMSG.TYPE) THEN
            Y.CRACC.CCY = R.NEW(PP.OEYG.TransactionCurrency)
            R.NEW(PP.OEYG.CreditAccountNumber) = Y.CRACC.CCY:Y.SUSP.ACCT
        END
    END
RETURN
END