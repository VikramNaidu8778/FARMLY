SUBROUTINE JBHK.R.PP.POPRD.VALIDATEHOOK(PO.ID,R.PAYMENT.ORDER,COMP.ID,RESERVED.IN,SUXS.FAIL,ERR.DETS,OVERRIDE.DETS)
*-----------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
** Date              Developer               Reference                    Description
*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*24-07-2024         Vikram P                CBPAY-362                  This routine is to select the payment Order Product based on the order Initiation Type of Payment Order
*17-02-2025         Resmi R                 CBPAY-1705                 Included the call routine to fetch the Payment order record with the Category Purpose Prop field populated
*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.PAYMENT.ORDER
    $INSERT I_F.PAYMENT.ORDER.PRODUCT

   CALL JB.R.PP.ORDINITIATION.TYPE(PO.ID,R.PAYMENT.ORDER,COMP.ID,RESERVED.IN,SUXS.FAIL,ERR.DETS,OVERRIDE.DETS)

    Y.INITIATIONTYPE = R.PAYMENT.ORDER<PO.ORDER.INITIATION.TYPE>

    IF Y.INITIATIONTYPE EQ 'MXCHATS' THEN
        CALL PPHKCX.VALIDATE.API.FOR.POA(PO.ID,R.PAYMENT.ORDER,COMP.ID,RESERVED.IN,SUXS.FAIL,ERR.DETS,OVERRIDE.DETS)
    END ELSE
        CALL PPSWMX.VALIDATE.API.FOR.POA(PO.ID,R.PAYMENT.ORDER,COMP.ID,RESERVED.IN,SUXS.FAIL,ERR.DETS,OVERRIDE.DETS)
    END

  
RETURN

END

