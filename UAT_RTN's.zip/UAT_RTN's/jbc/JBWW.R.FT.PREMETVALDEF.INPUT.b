*-----------------------------------------------------------------------------
* <Rating>-24</Rating>
*------------------------------------------------------------------------------------------------------------------
    SUBROUTINE JBWW.R.FT.PREMETVALDEF.INPUT 
*------------------------------------------------------------------------------------------------------------------
*   Desc : This routine is to Default the local fields  L.XX.PM.ALLOC,L.XX.PM.METTYPE,L.XX.PM.METID,L.XX.PM.METQTY
*    in FT from CURRENCY.    
*------------------------------------------------------------------------------------------------------------------
* Modification History :
*------------------------------------------------------------------------------------------- 
* Date          Developer                           Reference               Description
*-------------------------------------------------------------------------------------------
* 28/04/2016    Srikanth.dumpeti@cognizant.com     BJB T24 R15_FSD_PMT002     Initial Version
* 27/12/2016    Rekha M                            CR-201                     Amended
* 2/MAY/2017    Mahesh J                           JB2A-31125                 if any values entered the field BEN.CUSTOMER (Tag 88A),It should be cleared.  
* 04/10/2017    Rajagopalan R                      JB2A-43485                 added condition to default field values COMMISION.CODE and CHARGE.CODE
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.CURRENCY
*-----------------------------------------------------------------------------

    GOSUB INIT
    GOSUB PROCESS
    RETURN
*-----------------------------------------------------------------------------

*** <region name= INIT>
INIT:
*** <desc>Initialize variables </desc>

    Y.APP = "CURRENCY":FM:"FUNDS.TRANSFER"
    FLD.NAMES = "L.XX.PM.ALLOC":VM:"L.XX.PM.METTYPE":VM:"L.XX.PM.METID":VM:"L.XX.PM.METQTY":VM:"L.XX.PM.DENOMIN"     ; **** CR-201 S/E
	FLD.NAMES:= FM:"L.XX.PM.ALLOC":VM:"L.XX.PM.METTYPE":VM:"L.XX.PM.METID":VM:"L.XX.PM.METQTY":VM:"L.XX.PM.DENOMIN"   ; **** CR-201 S/E
    FN.CCY  = 'F.CURRENCY'
    F.CCY   = ''
    CALL OPF(FN.CCY,F.CCY)

    R.CURRENCY  = ''
    ERR.CCY    = ''

    CCY.ALLOC.POS = ''
    CCY.METTYPE.POS = ''
    CCY.METID.POS = ''
    CCY.METQTY.POS= ''
	CCY.DENOM.POS = ''
    FT.ALLOC.POS= ''
    FT.METTYPE.POS= ''
    FT.METID.POS=''
    FT.METQTY.POS=''
	FT.DENOM.POS = ''
    FLD.POS= ''

    CALL MULTI.GET.LOC.REF(Y.APP,FLD.NAMES,FLD.POS)

    CCY.ALLOC.POS = FLD.POS<1,1>
    CCY.METTYPE.POS = FLD.POS<1,2>
    CCY.METID.POS = FLD.POS<1,3>
    CCY.METQTY.POS = FLD.POS<1,4>
	CCY.DENOM.POS = FLD.POS<1,5>      ; **** CR-201 S/E

    FT.ALLOC.POS = FLD.POS<2,1>
    FT.METTYPE.POS = FLD.POS<2,2>
    FT.METID.POS = FLD.POS<2,3>
    FT.METQTY.POS = FLD.POS<2,4>
    FT.DENOM.POS = FLD.POS<2,5>       ; **** CR-201 S/E
	
    RETURN
    
*** </region>
*-----------------------------------------------------------------------------

*** <region name= PROCESS>
PROCESS:

    R.NEW(FT.BEN.CUSTOMER) = ''    ; * JB2A-31125 - S/E
	
    Y.DEBIT.CURRENCY = R.NEW(FT.DEBIT.CURRENCY)
	
* JB2A-43485 - starts
	Y.TXN.TYPE = R.NEW(FT.TRANSACTION.TYPE)
	Y.BEN.CHARGES = R.NEW(FT.BEN.OUR.CHARGES)
* JB2A-43485 - ends
    
	CALL F.READ(FN.CCY, Y.DEBIT.CURRENCY ,R.CURRENCY ,F.CCY, ERR.CCY)

    IF R.CURRENCY THEN

        CCY.PM.ALLOC = R.CURRENCY<EB.CUR.LOCAL.REF,CCY.ALLOC.POS>
        CCY.PM.METTYPE = R.CURRENCY<EB.CUR.LOCAL.REF,CCY.METTYPE.POS>
        CCY.PM.METID = R.CURRENCY<EB.CUR.LOCAL.REF,CCY.METID.POS>
        CCY.PM.METQTY = R.CURRENCY<EB.CUR.LOCAL.REF,CCY.METQTY.POS>
		CCY.DENOM.POS = R.CURRENCY<EB.CUR.LOCAL.REF,CCY.DENOM.POS>  ; **** CR-201 S/E

        R.NEW(FT.LOCAL.REF)<1,FT.ALLOC.POS> = CCY.PM.ALLOC
        R.NEW(FT.LOCAL.REF)<1,FT.METTYPE.POS> = CCY.PM.METTYPE
        R.NEW(FT.LOCAL.REF)<1,FT.METID.POS> = CCY.PM.METID
        R.NEW(FT.LOCAL.REF)<1,FT.METQTY.POS> = CCY.PM.METQTY
        R.NEW(FT.LOCAL.REF)<1,FT.DENOM.POS> = CCY.DENOM.POS          ; **** CR-201 S/E

    END
	
* JB2A-43485 - starts
	
	*IF Y.TXN.TYPE EQ "OT60" AND Y.BEN.CHARGES EQ "BEN" THEN
	
		*R.NEW(FT.COMMISSION.CODE) = "CREDIT LESS CHARGES"
		*R.NEW(FT.CHARGE.CODE) = "CREDIT LESS CHARGES"

	*END
	
* JB2A-43485 - ends	
    RETURN

*** <desc>Validation process </desc>

*** </region>
*-----------------------------------------------------------------------------

    END