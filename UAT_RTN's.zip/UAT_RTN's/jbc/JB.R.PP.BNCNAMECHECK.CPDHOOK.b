*----------------------------------------------------------------------------------------------------------------
SUBROUTINE JB.R.PP.BNCNAMECHECK.CPDHOOK(iTransactionDetails,iCreditPartyDetails,HookResponse)
*----------------------------------------------------------------------------------------------------------------
* Description :
* Routine attached in PP.COMPONENT.API.HOOK>CreditPartyDetermination
* API routine to block Payment Order with DR/CR acct being an Income account
* with Added Additional selection criteria Payment Order Type C,Payment Order Direction I
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date              Developer        Reference      Description
*
* 26/12/2024         P Amala         CBPAY-1478     Introduced logic to check the Beneficiary Name.
*
* 24/05/2025         u40786          CBPAY-2355     For MT103 - Beneficiary Name to be referred from Line-1 of Tag 59
*
* 26/06/2025         Prabhu D S      CBPAY-3482     Error Type changed from ERR to WAR to allow user to proceed further
*----------------------------------------------------------------------------------------------------------------
*
    $USING EB.SystemTables
    $USING EB.DataAccess
    $USING PP.CreditPartyDeterminationService
    $USING SC.ScoPortfolioMaintenance
    $USING AC.AccountOpening
    $USING PP.PaymentFrameworkService
    $USING PP.PaymentWorkflowDASService
    $USING PP.StaticDataGUI
    $USING PP.PaymentWorkflowGUI
    $USING PP.PaymentLifecycleHook
    $USING IY.Config
    $USING IY.ModelBank
    $USING PP.PaymentSTPFlowService
    $INSERT I_F.JB.XX.PARTY.DETAILS
    $INSERT I_F.ALTERNATE.ACCOUNT
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ACCOUNT
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.IY.ALIAS.DETAILS
    $INSERT I_F.IY.MATCH.CONFIGURATION
    $INSERT I_F.POR.SUPPLEMENTARY.INFO

    iTransactionContext<PP.PaymentSTPFlowService.TransactionContext.companyID> = iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.companyID>
    iTransactionContext<PP.PaymentSTPFlowService.TransactionContext.ftNumber> = iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
    ioPaymentOrder = '' ; ioAdditionalPaymentOrder = '' ;
    oValidatedResponse = '' ;
    oAdditionalValidatedResponse = '' ;

    PP.PaymentSTPFlowService.nameComparisonPreValidation(iTransactionContext, ioPaymentOrder, ioAdditionalPaymentOrder, oValidatedResponse, oAdditionalValidatedResponse)

* API Response Details: oValidatedResponse
* 1st Argument - Error Description = 1
* 2nd Argument - BNC Status = 2  (1 or 0 // 1 - Required . 0 - Not Required)
* 3rd Argument - matching Percentage = 3
  
    IF oValidatedResponse<2> EQ '1' THEN
        GOSUB INIT
        iPaymentID=iTransactionDetails<PP.PaymentFrameworkService.PORPrimaryKey.ftNumber>
        PP.PaymentWorkflowDASService.getPaymentRecord(iPaymentID, oPaymentRecord, oAdditionalPaymentRecord, oReadErr)
        GOSUB BNC.NAME.CHECK
    END
*
RETURN
*
*----
INIT:
*----
     
    F.ACCOUNT = ''
    FN.ACCOUNT = 'F.ACCOUNT'
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    F.SEC.ACC.MASTER = ''
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    
    FN.ALTERNATE.ACCOUNT = "F.ALTERNATE.ACCOUNT"
    F.ALTERNATE.ACCOUNT = ""
    CALL OPF(FN.ALTERNATE.ACCOUNT, F.ALTERNATE.ACCOUNT)
    
    F.JB.XX.PARTY.DETAILS = ''
    FN.JB.XX.PARTY.DETAILS = 'F.JB.XX.PARTY.DETAILS'
    CALL OPF(FN.JB.XX.PARTY.DETAILS,F.JB.XX.PARTY.DETAILS)
    
    FN.POR.SUPPLEMENTARY.INFO = 'F.POR.SUPPLEMENTARY.INFO'
    F.POR.SUPPLEMENTARY.INFO = ''
    EB.DataAccess.Opf(FN.POR.SUPPLEMENTARY.INFO,F.POR.SUPPLEMENTARY.INFO)
 
    iErrorTableKey<PP.PaymentFrameworkService.ErrorTableKey.errorCode> = 'CPD90004'
    PP.PaymentFrameworkService.getErrorDetails(iErrorTableKey, oErrorDetails, oGetErrTypeError)
*
RETURN
*
*--------------
BNC.NAME.CHECK:
*--------------

    yCrAccount = ''
    yCrAccount = iCreditPartyDetails<PP.CreditPartyDeterminationService.DetermineCreditPartyInput.crMainAccNumber>
           
    R.ACCOUNT = '' ;  ACC.ERROR = '' ; Y.SAM.ID = '' ;
    CALL F.READ(FN.ACCOUNT,yCrAccount,R.ACCOUNT,F.ACCOUNT,ACC.ERROR)
    IF NOT(R.ACCOUNT) THEN
        R.ALT.REC = '' ; ALT.ERR = '' ;
        CALL F.READ(FN.ALTERNATE.ACCOUNT, yCrAccount, R.ALT.REC, F.ALTERNATE.ACCOUNT, ALT.ERR)
        IF R.ALT.REC THEN
            yCrAccount = R.ALT.REC<AAC.GLOBUS.ACCT.NUMBER>
            CALL F.READ(FN.ACCOUNT,yCrAccount,R.ACCOUNT,F.ACCOUNT,ACC.ERROR)
        END
    END
    Y.SAM.ID = R.ACCOUNT<AC.PORTFOLIO.NO,1>
    
    IF Y.SAM.ID NE '' THEN
        GOSUB READ.SAM
    END
    
    R.JB.PARTYDET = '' ; Y.PORT.RELTYPE = '' ; CustomerType = '' ; AccountType = '' ;
    CALL F.READ(FN.JB.XX.PARTY.DETAILS,Y.PARTY.ID,R.JB.PARTYDET,F.JB.XX.PARTY.DETAILS,'')
    IF R.JB.PARTYDET THEN
        Y.PORT.RELTYPE = R.JB.PARTYDET<PART.DET.PORT.REL.TYPE>
        IF Y.PORT.RELTYPE EQ "Individual" THEN
            CustomerType = "PRIVATE"
            Y.JC.IDENT = R.JB.PARTYDET<PART.DET.J.C.IDENTIFIER>
            BEGIN CASE
                CASE Y.JC.IDENT EQ "Joint"
                    AccountType = "JOINT"
                CASE Y.JC.IDENT EQ "Collective"
                    AccountType = "COLLECTIVE"
                CASE OTHERWISE
                    AccountType = "INDIVIDUAL"
            END CASE
        END ELSE
            CustomerType = "LEGAL"
            AccountType = "INDIVIDUAL"
        END
    
    
        GOSUB EXT.BENE.NAME
   
* BNC API Call with Portfolio Names;

        Y.ACCT.HLDR.NAME = R.JB.PARTYDET<PART.DET.PORT.NAME>
        InArgs<1> = iTransactionContext<PP.PaymentSTPFlowService.TransactionContext.ftNumber>
        InArgs<2> = yCrAccount:"~":AccountType:"~":CustomerType
        InArgs<3> = Y.PI.BENENAME
        InArgs<4> = Y.ACCT.HLDR.NAME
        InArgs<5> = ID.COMPANY
        OutArgs = '' ; RetErr = '' ; Reserved1 = '' ; Reserved2 = '' ; Reserved3 = '' ;
        
        CALL IY.DETERMINE.COMPARISON.RESULT(InArgs, OutArgs, RetErr, Reserved1, Reserved2, Reserved3)

*        OutArgs <1> = MatchResult Indicator
*        OutArgs <2> = MatchScore
*        OutArgs <3> = The account holder name associated with the highest match score in OutArgs<2> is identified separately
*        OutArgs <4> = The match score
*        OutArgs <5> = The account holder name corresponding to every individual match score indicated in OutArgs <4> is returned. Values are separated by VM
*        OutArgs <6> = In some exception cases where a No match is evident before the computation of a score, the reason for No-Match corresponding to the account holder is indicated in this argument
*        OutArgs <7> = A high level justification for name comparison outcome i.e Match (True) or No-Match(False) is indicated.
*        OutArgs <8> = A consolidated Score

* BNC API Call with Account Holder Names;
        yOutDetails.1 = "Call 1:":OutArgs<1>:"|MScore:":OutArgs<2>:"|PortName:":Y.ACCT.HLDR.NAME:"|AccountType":AccountType:"|CustomerType":CustomerType:"|Justification:":OutArgs<7>:"Bene Name":Y.PI.BENENAME
      

        IF OutArgs<1> EQ '1' THEN
            HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode, -1> = "CPD90004"
            HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "INF"
            HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = "BNC Against Portfolio Name is Matched" : yOutDetails.1
        END ELSE
            GOSUB EXT.ACCHLD.NAME
            OutArgs = '' ; RetErr = '' ; Reserved1 = '' ; Reserved2 = '' ; Reserved3 = '' ;
            InArgs<4> = Y.ORD.CUSTNAME
            YRETARGU = Y.ORD.CUSTNAME
            CALL IY.DETERMINE.COMPARISON.RESULT(InArgs, OutArgs, RetErr, Reserved1, Reserved2, Reserved3)
            
            CONVERT @VM TO "$" IN YRETARGU
            yOutDetails.2 = "Call 2:":OutArgs<1>:"|MScore:":OutArgs<2>:"|CustName:":YRETARGU:"|Justification:":OutArgs<7>
            
            GOSUB UpdateAuditTrail
        END
             
    END
*
RETURN
*
*----------------
UpdateAuditTrail:
*----------------
   
    IF OutArgs<1> THEN
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode, -1> = "CPD90004"
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "INF"
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = "BNC Against Account Holder(s) Name is Matched" : yOutDetails.1 : yOutDetails.2
    END ELSE
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseCode, -1> = "CPD90004"
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseType , -1> = "WAR"
        HookResponse<PP.PaymentFrameworkService.HookApiResponse.responseText , -1> = "BNC Against Portfolio and Account Holder(s) Name is Not Matched": yOutDetails.1 : yOutDetails.2
    END
*
RETURN
*
*--------
READ.SAM:
*--------

    R.SAM.REC = '' ; Y.PARTY.ID = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM.REC,F.SEC.ACC.MASTER,'')
    IF R.SAM.REC THEN
        Y.PARTY.ID = R.SAM.REC<SC.SAM.ACCOUNT.NAME>
    END
*
RETURN
*
*-------------
EXT.BENE.NAME:
*-------------
    
    Y.PI.BENENAME.POS = '' ; Y.PI.PARTYROLE = '' ; supplementaryRec = ''
    CALL F.READ(FN.POR.SUPPLEMENTARY.INFO, iPaymentID, supplementaryRec, F.POR.SUPPLEMENTARY.INFO, supplementaryError)
    IF supplementaryRec THEN
        Y.PI.PARTYROLE = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyRole>
        LOCATE 'BENFCY' IN Y.PI.PARTYROLE<1,1> SETTING Y.PI.BENENAME.POS THEN
            IF supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdName,Y.PI.BENENAME.POS> THEN
* For MX message
                Y.PI.BENENAME = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdName,Y.PI.BENENAME.POS>
            END ELSE
* For MT message
                Y.PI.BENENAME = supplementaryRec<PP.PaymentWorkflowGUI.PorSupplementaryInfo.PorIdPartyFreeLine,Y.PI.BENENAME.POS,1>
            END
            
        END
    END
*
RETURN
*
*---------------
EXT.ACCHLD.NAME:
*---------------

    Y.ORD.CUSTNAME = '' ; Y.FIRST.ORDCUST = '' ; Y.AC.HOLDER.NAME = ''

    BEGIN CASE
* To review the below case with PO
        CASE CustomerType = "LEGAL"
            Y.ORD.CUSTNAME = R.JB.PARTYDET<PART.DET.PART.F.NAME>
            Y.FIRST.ORDCUST = '' ;
            Y.AC.HOLDER.NAME = R.JB.PARTYDET<PART.DET.PARTY.ID>
            Y.PARTYID.CNT = DCOUNT(Y.AC.HOLDER.NAME,@VM)
            Y.CNT = 0
            LOOP
                Y.CNT = Y.CNT + 1
            WHILE Y.CNT LE Y.PARTYID.CNT
                IF R.JB.PARTYDET<PART.DET.LEGAL.ORG.NAME><1,Y.CNT> NE '' AND Y.FIRST.ORDCUST EQ '' THEN
                    Y.ORD.CUSTNAME = R.JB.PARTYDET<PART.DET.LEGAL.ORG.NAME><1,Y.CNT>
                    Y.FIRST.ORDCUST = '1'
                END ELSE
                    IF R.JB.PARTYDET<PART.DET.LEGAL.ORG.NAME><1,Y.CNT> NE '' AND Y.FIRST.ORDCUST EQ '1' THEN
                        Y.ORD.CUSTNAME := @VM:R.JB.PARTYDET<PART.DET.LEGAL.ORG.NAME><1,Y.CNT>
                    END
                END
            REPEAT
        
        CASE AccountType EQ "INDIVIDUAL"
            Y.ORD.CUSTNAME = R.JB.PARTYDET<PART.DET.PART.F.NAME>
            Y.ORD.CUSTNAME := '*':R.JB.PARTYDET<PART.DET.PART.M.NAME>
            Y.ORD.CUSTNAME := '*':R.JB.PARTYDET<PART.DET.PART.L.NAME>
            
        CASE AccountType EQ "JOINT" OR AccountType EQ "COLLECTIVE"
            Y.AC.HOLDER.NAME = R.JB.PARTYDET<PART.DET.PARTY.ID>
            Y.PARTYID.CNT = DCOUNT(Y.AC.HOLDER.NAME,@VM)
            II = 0  ; Y.FIRST.ORDCUST = '' ;
            LOOP
                II = II + 1
            WHILE II LE Y.PARTYID.CNT
                IF R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II> NE '' AND Y.FIRST.ORDCUST EQ '' THEN
                    Y.ORD.CUSTNAME = R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II>
                    Y.FIRST.ORDCUST = '1'
                END ELSE
                    IF R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II> NE '' AND Y.FIRST.ORDCUST EQ '1' THEN
                        Y.ORD.CUSTNAME := @VM:R.JB.PARTYDET<PART.DET.PART.F.NAME><1,II>
                    END
                END
* First Name / Middle Name / Last Name , should be seperated by * even if the Value is empty in Local Table.
                Y.ORD.CUSTNAME := '*':R.JB.PARTYDET<PART.DET.PART.M.NAME><1,II>
                Y.ORD.CUSTNAME := '*':R.JB.PARTYDET<PART.DET.PART.L.NAME><1,II>

            REPEAT
        
    END CASE
*
RETURN
*
END
*
