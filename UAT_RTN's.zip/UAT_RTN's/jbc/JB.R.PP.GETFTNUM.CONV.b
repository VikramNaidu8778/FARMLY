SUBROUTINE JB.R.PP.GETFTNUM.CONV
*-----------------------------------------------------------------------------
*  Descrption   : Routine to pass SGDxxxx reference id for the corresponding Payment Order.
*  Attached as Conversion routine in Enquiry > JBWW.E.SY.FXSTR.DASH
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date              who             Reference           Description
* 2024-10-18        Amala P         CBPAY-1085          Intial version
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.PAYMENT.ORDER

    GOSUB INIT
    GOSUB PROCESS
    
RETURN
    
******
INIT:
******

    FN.PAYMENT.ORDER = 'F.PAYMENT.ORDER'
    F.PAYMENT.ORDER = ''
    CALL OPF(FN.PAYMENT.ORDER,F.PAYMENT.ORDER)
        
    FN.PAYMENT.ORDER.HIS = 'F.PAYMENT.ORDER$HIS'
    F.PAYMENT.ORDER.HIS = ''
    CALL OPF(FN.PAYMENT.ORDER.HIS,F.PAYMENT.ORDER.HIS)
        
    T24.REFID = '' ; R.PAYMENT.ORDER = '' ; PO.ERR = ''
    R.PAYMENT.ORDER.HIS = '' ; PO.HIS.ERR = ''

RETURN
    
********
PROCESS:
********

    T24.REFID = O.DATA

    IF T24.REFID[1,2] EQ 'PI' THEN

        CALL F.READ(FN.PAYMENT.ORDER,T24.REFID,R.PAYMENT.ORDER,F.PAYMENT.ORDER,PO.ERR)
        IF R.PAYMENT.ORDER THEN
            O.DATA = R.PAYMENT.ORDER<PO.PAYMENT.SYSTEM.ID>
        END ELSE
            CALL EB.READ.HISTORY.REC(F.PAYMENT.ORDER.HIS, T24.REFID, R.PAYMENT.ORDER.HIS, PO.HIS.ERR)
            O.DATA = R.PAYMENT.ORDER.HIS<PO.PAYMENT.SYSTEM.ID>
        END
    END ELSE
        O.DATA = ''
    END
RETURN
END