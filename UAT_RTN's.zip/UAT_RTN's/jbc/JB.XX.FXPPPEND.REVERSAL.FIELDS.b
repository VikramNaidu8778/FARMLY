SUBROUTINE JB.XX.FXPPPEND.REVERSAL.FIELDS
*-----------------------------------------------------------------------------
*This is the template routine for Exception Handling of camt.057 sent from
*other module integration transactions
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 01-May-2024     CBPAY-1435             Kandan                 Initial Version
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
    
    ID.F = '@ID'
    ID.N = '35'
    ID.T = 'A'
    
    CALL Table.addFieldDefinition('RETRY.CNT','10','ANY','')
    CALL Table.addFieldDefinition('XX.RETRY.TIME','65','ANY','')
    CALL Table.addOptionsField('RETRY.STATUS','SUCCESS_FAILURE_RETRYEXCEEDED','','')
   
    fieldName = 'RESERVED.10'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.9'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.8'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.7'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.6'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')

    fieldName = 'RESERVED.5'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.4'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.3'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.2'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
    
    fieldName = 'RESERVED.1'
    fieldLength = '35'
    fieldType = 'A'
    fieldType<3> = 'NOINPUT'
    CALL Table.addFieldDefinition(fieldName, fieldLenght, fieldType, '')
   
*
RETURN
*---------------------------------------------------------------------------
END
*

