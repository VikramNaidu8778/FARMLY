

* @ValidationCode : Mjo1OTA2NTMwNDI6Q3AxMjUyOjE3MTM3NjY1MDU5Njc6ODAxNTc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMjMxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 22 Apr 2024 11:45:05
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 914815
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_202310.0
* @ValidationInfo : Copyright Temenos Headquarters SA 1993-2024. All rights reserved.
*-------------------------------------------------------------------------
* Description:
*----------------------------------------------------------------------------------
* This is Conversion  routine attached to enquiry JB.E.PP.EAMSSDTRANSFERFAILED.NAU which was previously a functionality in Funds.Transfer

* Modification History :
*-------------------------------------------------------------------------------------------
* Date          Developer                               Reference               Description
*-------------------------------------------------------------------------------------------------------------------------------------------------------
*02/04/2024	Murali krishnan H			CBPAY-9		To Convert * to VM for Multiple line display
*
*--------------------------------------------------------------------------------------------------------------------------------------------------------

SUBROUTINE JB.R.PP.MV.CONV
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON

    A = O.DATA
    CHANGE "*" TO VM IN O.DATA
    VM.COUNT = DCOUNT(O.DATA,VM)
    O.DATA = O.DATA<1,VC>

RETURN

END
